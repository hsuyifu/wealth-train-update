@echo off
setlocal
cd /d "%~dp0"
echo TrainBacktester uses only Python built-in packages.
echo No extra packages are required.
py -3.11 --version
pause
