@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$Wsh=New-Object -ComObject WScript.Shell; $Desktop=[Environment]::GetFolderPath('Desktop'); $Shortcut=$Wsh.CreateShortcut((Join-Path $Desktop 'TrainBacktester.lnk')); $Shortcut.TargetPath=(Join-Path (Get-Location) 'start_backtester.vbs'); $Shortcut.WorkingDirectory=(Get-Location).Path; $Shortcut.IconLocation=($env:SystemRoot + '\System32\shell32.dll,167'); $Shortcut.Save()"
echo Desktop shortcut created: TrainBacktester.lnk
pause
