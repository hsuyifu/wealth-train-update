# -*- coding: utf-8 -*-
"""Build 小火車回測器 online update files.

Output:
  release_files/train_backtester_<old>_to_<new>_safe_update_patch.zip
  release_files/backtester_update.json

Upload both files to the same GitHub Pages folder. The app reads backtester_update.json
and resolves package_url relative to that JSON URL.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import zipfile
from datetime import datetime
from pathlib import Path

APP_NAME = "TrainBacktester"
APP_VERSION_RE = re.compile(r'^APP_VERSION\s*=\s*["\']([^"\']+)["\']', re.M)

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "release_files"

INCLUDE_FILES = [
    "train_backtester.py",
    "train_backtester.pyw",
    "strategy_core.py",
    "create_desktop_shortcut.bat",
    "install_requirements.bat",
    "kill_stuck_backtester_python.bat",
    "reset_backtester_window.bat",
    "run_backtester.bat",
    "safe_start_backtester.bat",
    "start_backtester.vbs",
    "backtester_update_url.txt",
    "make_backtester_update_release.bat",
    "make_backtester_update_release.py",
]


def read_version() -> str:
    text = (ROOT / "train_backtester.py").read_text(encoding="utf-8", errors="replace")
    m = APP_VERSION_RE.search(text)
    return m.group(1) if m else "v000"


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> None:
    version = read_version()
    OUT.mkdir(exist_ok=True)
    old = os.environ.get("BACKTESTER_OLD_VERSION", "previous").strip() or "previous"
    zip_name = f"train_backtester_{old}_to_{version}_safe_update_patch.zip"
    zip_path = OUT / zip_name
    with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for rel in INCLUDE_FILES:
            src = ROOT / rel
            if src.exists() and src.is_file():
                zf.write(src, rel)
    digest = sha256_file(zip_path)
    manifest = {
        "app": APP_NAME,
        "version": version,
        "title": f"小火車回測器 {version} 線上更新",
        "message": "下載後會自動備份原檔並覆蓋更新；完成後請關閉並重開小火車回測器。",
        "published_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "required": False,
        "package_type": "safe_update_patch",
        "package_url": zip_name,
        "sha256": digest,
    }
    manifest_path = OUT / "backtester_update.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print("Built:", zip_path)
    print("Manifest:", manifest_path)
    print("SHA256:", digest)
    print("Upload both files in release_files to the same GitHub Pages folder.")


if __name__ == "__main__":
    main()
