@echo off
setlocal
cd /d "%~dp0"
set "SETTINGS=%~dp0data_cache\ui_settings.json"
if not exist "%SETTINGS%" (
    echo No UI settings file found.
    pause
    exit /b 0
)
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:SETTINGS; try { $j=Get-Content -LiteralPath $p -Raw | ConvertFrom-Json; if ($null -ne $j.geometry) { $j.PSObject.Properties.Remove('geometry') }; $j | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $p -Encoding UTF8; Write-Host 'Window position reset.' } catch { Rename-Item -LiteralPath $p -NewName ('ui_settings.bad_' + (Get-Date -Format yyyyMMdd_HHmmss) + '.json'); Write-Host 'Bad UI settings renamed.' }"
echo Done.
pause
