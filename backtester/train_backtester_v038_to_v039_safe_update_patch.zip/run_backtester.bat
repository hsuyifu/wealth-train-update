@echo off
setlocal
cd /d "%~dp0"
if not exist "%~dp0train_backtester.py" (
    echo Missing train_backtester.py
    pause
    exit /b 1
)
py -3.11 "%~dp0train_backtester.py"
if errorlevel 1 (
    echo.
    echo TrainBacktester ended with an error.
    echo Check logs\backtester_startup_log.txt
    pause
)
