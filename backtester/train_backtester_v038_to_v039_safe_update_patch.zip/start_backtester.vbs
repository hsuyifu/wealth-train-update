Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
scriptDir = fso.GetParentFolderName(WScript.ScriptFullName)
cmd = "pyw -3.11 """ & scriptDir & "\train_backtester.pyw"""
shell.Run cmd, 0, False
