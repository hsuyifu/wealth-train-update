@echo off
setlocal
cd /d "%~dp0"
py -3.11 make_backtester_update_release.py
pause
