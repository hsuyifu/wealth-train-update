@echo off
setlocal
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -ieq 'python.exe' -or $_.Name -ieq 'pythonw.exe') -and ($_.CommandLine -match 'train_backtester') } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"
set "SETTINGS=%~dp0data_cache\ui_settings.json"
if exist "%SETTINGS%" powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:SETTINGS; try { $j=Get-Content -LiteralPath $p -Raw | ConvertFrom-Json; if ($null -ne $j.geometry) { $j.PSObject.Properties.Remove('geometry') }; $j | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $p -Encoding UTF8 } catch { Rename-Item -LiteralPath $p -NewName ('ui_settings.bad_' + (Get-Date -Format yyyyMMdd_HHmmss) + '.json') }"
start "" "%~dp0start_backtester.vbs"
exit /b 0
