@echo off
setlocal
REM Kill only Python processes whose command line contains train_backtester.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-CimInstance Win32_Process | Where-Object { ($_.Name -ieq 'python.exe' -or $_.Name -ieq 'pythonw.exe') -and ($_.CommandLine -match 'train_backtester') } | ForEach-Object { Write-Host ('Killing PID ' + $_.ProcessId + ' ' + $_.Name); Stop-Process -Id $_.ProcessId -Force }"
echo Done.
pause
