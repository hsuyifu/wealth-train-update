# -*- coding: utf-8 -*-
# 小火車回測器 v034
# 回測版：原始資料匯入已改由 TrainMADataCenter 獨立工具處理；本程式只讀共用資料庫。

from __future__ import annotations

import csv
import io
import os
import json
import math
import re
import html
import urllib.request
import urllib.error
import urllib.parse
import zipfile
import sqlite3
import hashlib
import pickle
import tempfile
import subprocess
import shutil
import threading
import time as time_module
import itertools
import concurrent.futures
import multiprocessing
import sys
import traceback
from dataclasses import dataclass
from datetime import datetime as RealDateTime, date, time, timedelta
from types import SimpleNamespace
from tkinter import Tk, Toplevel, StringVar, DoubleVar, IntVar, filedialog, messagebox, simpledialog, ttk, BOTH, END
import tkinter.font as tkfont

import strategy_core

# ---------------------------------------------------------------------
# 讓 strategy_core 內部 datetime.now() 使用回測 tick 時間。
# ---------------------------------------------------------------------
_CURRENT_BACKTEST_DT = RealDateTime.now()

class BacktestDateTime(RealDateTime):
    @classmethod
    def now(cls, tz=None):
        if tz is not None:
            try:
                return _CURRENT_BACKTEST_DT.astimezone(tz)
            except Exception:
                return _CURRENT_BACKTEST_DT
        return _CURRENT_BACKTEST_DT

strategy_core.datetime = BacktestDateTime

def _tick_datetime_patch(raw=None, now=None):
    # 回測熱路徑最佳化：feed() 直接把 datetime 當 raw 傳進來，
    # 避免每筆 tick 建立 SimpleNamespace / 字串 MatchTime，275 組回測可省掉大量物件配置。
    if isinstance(raw, RealDateTime):
        return raw
    dt = getattr(raw, "BacktestDateTime", None)
    if isinstance(dt, RealDateTime):
        return dt
    return BacktestDateTime.now()

strategy_core._tick_datetime = _tick_datetime_patch


# 回測專用：策略核心每筆 tick 會多次呼叫 _profile(task)。
# task 的策略在單組回測期間不會改變，因此把 profile 直接掛在 task 上，減少字串判斷成本。
_STRATEGY_CORE_PROFILE_ORIG = getattr(strategy_core, "_profile", None)

def _strategy_core_profile_fast(task):
    prof = getattr(task, "_bt_profile", None)
    if prof is not None:
        return prof
    text = str(getattr(task, "strategy", "") or "")
    text_u = text.upper().replace(" ", "")
    is_ema = bool(text.strip() == "EMA策略" or "EMA策略" in text or text_u.startswith("EMA"))
    if is_ema:
        if "小股" in text or "小型" in text:
            return strategy_core.PROFILES["EMA小股期策略"]
        return strategy_core.PROFILES["EMA大股期策略"]
    # 開盤價策略只替換指標線，其餘商品特性沿用小火車原策略 profile。
    if is_open_price_strategy(text):
        if "台指" in text:
            return strategy_core.PROFILES["台指期策略"]
        if "小股" in text or "小型" in text:
            return strategy_core.PROFILES["小股期策略"]
        return strategy_core.PROFILES["大股期策略"]
    if callable(_STRATEGY_CORE_PROFILE_ORIG):
        return _STRATEGY_CORE_PROFILE_ORIG(task)
    if "台指" in text:
        return strategy_core.PROFILES["台指期策略"]
    if "小股" in text:
        return strategy_core.PROFILES["小股期策略"]
    return strategy_core.PROFILES["大股期策略"]

strategy_core._profile = _strategy_core_profile_fast

# v051B：回測器的「商品類型=台指期」要沿用小火車回測的一般停利/停損/認賠/賺飽邏輯，
# 不啟用台指 API 版舊有的「開盤 20 分鐘鎖利」特規。
# 該特規會在夜盤 15:01 附近造成同秒進出，甚至出現負損益卻標成「開盤鎖利出場」。
try:
    _BT_TAI_PROFILE = strategy_core.PROFILES.get("台指期策略")
    if _BT_TAI_PROFILE is not None:
        _BT_TAI_PROFILE.tai_open20_special = False
        _BT_TAI_PROFILE.tai_open20_lock_profit = 0.0
except Exception:
    pass

# ---------------------------------------------------------------------
# 官方 Daily CSV 欄位
# ---------------------------------------------------------------------
HEADER_ALIASES = {
    "trade_date": ["成交日期", "日期", "交易日期", "date"],
    "product_code": ["商品代號", "商品", "代號", "product", "product_code"],
    "month": ["到期月份(週別)", "到期月份", "月份", "contract", "month"],
    "trade_time": ["成交時間", "時間", "time"],
    "price": ["成交價格", "價格", "price"],
    "qty": ["成交數量(B+S)", "成交數量", "數量", "volume", "qty"],
}

@dataclass
class ProductOption:
    code: str
    display: str
    total_rows: int
    total_qty: float
    primary_month: str
    months: str
    first_dt: RealDateTime | None
    last_dt: RealDateTime | None
    data_days: int = 0
    date_start: date | None = None
    date_end: date | None = None
    missing_dates: str = ""
    avg_daily_qty: float = 0.0
    last_price: float = 0.0
    product_kind: str = "UNKNOWN"
    stock_no: str = ""
    stock_name: str = ""
    margin_percent: float = 0.0
    base_margin: float = 0.0

@dataclass
class OfficialTick:
    dt: RealDateTime
    d: date
    price: float
    qty: float
    avg: float
    code: str
    month: str
    session_key: str
    session_label: str


def norm_header(x):
    return str(x or "").strip().lower().replace(" ", "").replace("_", "")


TEXT_EXTS = (".csv", ".rpt", ".txt")

APP_VERSION = "2026.07.01-055F"
TAIFEX_STOCK_MARGIN_URL = "https://www.taifex.com.tw/cht/5/stockMargining"
EXCLUDE_UNDERLYING_STOCKS = {"2330", "2303"}  # 台積電、聯電

THREE_MA_STRATEGY_DISPLAY = "MA策略"
EMA_STRATEGY_DISPLAY = "EMA策略"
SMA_STRATEGY_DISPLAY = "SMA策略"
TRAIN_STRATEGY_DISPLAY = "小火車策略"
OPEN_PRICE_STRATEGY_DISPLAY = "開盤價策略"
STRATEGY_MODE_VALUES = [TRAIN_STRATEGY_DISPLAY, OPEN_PRICE_STRATEGY_DISPLAY, EMA_STRATEGY_DISPLAY, SMA_STRATEGY_DISPLAY]
MA_PERIOD_VALUES = ["3", "5", "10", "20", "60", "89", "120", "200"]
K_MINUTE_VALUES = ["1", "5", "10", "15", "30", "60", "日K"]
EMA_K_MINUTE_VALUES = ["5", "10", "15", "30", "60", "日K"]
ENTRY_MODE_VALUES = ["逐筆洗價", "收盤確認"]
STOCK_SIZE_MODE_VALUES = ["大股期", "小股期", "台指期"]
TAI_SESSION_MODE_VALUES = ["日盤", "夜盤", "九點盤", "全部"]
TICK_CACHE_PARSER_VERSION = 3  # v052J：EMA台指日夜盤改為日盤08:45起、同日夜盤15:00接續；修正舊v052I夜盤日期前移。
TAI_BIG_CODES = {"TX", "TXF"}
TAI_INDEX_CODES = {"TX", "TXF", "MTX", "MXF", "TMF"}


def is_tai_index_code(code):
    c = clean_code(code)
    return c in TAI_INDEX_CODES or c.startswith("TXF") or c.startswith("MXF") or c.startswith("TMF")


def normalize_tai_session_mode(value):
    text = str(value or "日盤").strip()
    text_u = text.upper().replace(" ", "")
    if text in ("全部", "日夜", "日夜都跑", "全時段", "ALL", "all") or text_u in ("ALL", "FULL"):
        return "全部"
    if (
        text in ("九點盤", "9點盤", "21點盤", "21:00盤", "晚上九點盤")
        or "九點" in text
        or "9點" in text
        or "21:00" in text
        or text_u in ("NINE", "NINEPM", "21", "2100", "21-05", "2100-0500")
    ):
        return "九點盤"
    if "夜" in text:
        return "夜盤"
    if "日" in text:
        return "日盤"
    return "日盤"


def session_allowed_by_mode(session_key, session_mode):
    mode = normalize_tai_session_mode(session_mode)
    if mode == "全部":
        return True
    seg = str(session_key or "").split(":")[-1].upper()
    if mode == "日盤":
        return seg == "DAY"
    if mode == "夜盤":
        return seg == "NIGHT"
    if mode == "九點盤":
        return seg == "NINE"
    return True


def tai_nine_session_for_dt(dt):
    """台指九點盤：21:00～隔日05:00，交易日歸屬21:00開盤日。"""
    hhmm = int(dt.hour) * 100 + int(dt.minute)
    if hhmm >= 2100:
        d = dt.date()
        return d.strftime("%Y-%m-%d") + ":NINE", d.strftime("%Y-%m-%d 九點盤"), True, RealDateTime.combine(d + timedelta(days=1), time(4, 58, 0))
    if hhmm < 500:
        d = dt.date() - timedelta(days=1)
        return d.strftime("%Y-%m-%d") + ":NINE", d.strftime("%Y-%m-%d 九點盤"), True, RealDateTime.combine(dt.date(), time(4, 58, 0))
    return "", "非交易時段", False, None


def official_session_date_for_cache(code, dt):
    try:
        if is_tai_index_code(code):
            skey, _slabel, in_session, _force_dt = session_for("台指期策略", dt)
            if in_session and ":" in skey:
                d = _date_from_text(skey.split(":", 1)[0])
                if d:
                    return d
    except Exception:
        pass
    try:
        return dt.date()
    except Exception:
        return None


def repair_tai_tick_cache_datetime_if_needed(progress=None):
    """修正 v052I 以前已匯入的台指夜盤自然日期前移問題。

    舊 parser_version=2 會把 15:00 後成交日期扣一天。v052J 改回自然日期後，
    若不修正既有 ticks_cache.db，會出現 06/16 22:19 的價格被顯示成 06/15 22:19，
    進而讓回測成交價落在 XQ 同根K棒高低之外。
    """
    try:
        init_tick_cache_db()
        conn = db_connect()
    except Exception:
        return {"fixed_sources": 0, "fixed_rows": 0}
    try:
        rows = conn.execute("SELECT id FROM source_files WHERE COALESCE(parser_version,0)=2").fetchall()
        ids = [int(r[0]) for r in rows if r and r[0] is not None]
        if not ids:
            return {"fixed_sources": 0, "fixed_rows": 0}
        placeholders = ",".join("?" for _ in ids)
        codes = tuple(sorted(TAI_BIG_CODES | {"TXF", "TX"}))
        code_placeholders = ",".join("?" for _ in codes)
        args = ids + list(codes)
        _safe_progress(progress, 0, 1, "修正舊台指夜盤日期｜準備處理")
        cur = conn.execute(
            f"UPDATE ticks SET dt=datetime(dt, '+1 day') WHERE source_file_id IN ({placeholders}) AND code IN ({code_placeholders}) AND substr(dt,12,5)>='15:00'",
            args,
        )
        fixed_rows = int(cur.rowcount if cur.rowcount is not None else 0)
        # 重算台指快取用交易日：夜盤 15:00~23:59 歸屬當日，00:00~04:59 歸屬前一日。
        conn.execute(
            f"""
            UPDATE ticks
               SET trade_date = CASE
                    WHEN substr(dt,12,5)>='15:00' THEN date(dt)
                    WHEN substr(dt,12,5)<'05:00' THEN date(dt,'-1 day')
                    WHEN substr(dt,12,5)>='08:45' AND substr(dt,12,5)<'13:45' THEN date(dt)
                    ELSE date(dt)
               END
             WHERE source_file_id IN ({placeholders}) AND code IN ({code_placeholders})
            """,
            args,
        )
        conn.execute(f"UPDATE source_files SET parser_version=? WHERE id IN ({placeholders})", [TICK_CACHE_PARSER_VERSION] + ids)
        conn.commit()
        _safe_progress(progress, 1, 1, "舊台指夜盤日期已修正｜來源%d｜tick %s" % (len(ids), f"{fixed_rows:,}"))
        return {"fixed_sources": len(ids), "fixed_rows": fixed_rows}
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        return {"fixed_sources": 0, "fixed_rows": 0}
    finally:
        try:
            conn.close()
        except Exception:
            pass


# ---------------------------------------------------------------------
# 小火車回測器線上更新
# ---------------------------------------------------------------------
# 更新 manifest 支援 JSON 欄位：
# {
#   "app": "TrainBacktester",
#   "version": "v039",
#   "package_url": "train_backtester_v039_safe_update_patch.zip",
#   "sha256": "...",
#   "title": "...",
#   "message": "...",
#   "required": false
# }
# package_url 可為絕對網址，也可為相對 manifest 所在目錄的檔名。
BACKTESTER_UPDATE_URL_FILE = "backtester_update_url.txt"
BACKTESTER_DEFAULT_UPDATE_MANIFEST_URLS = [
    "https://hsuyifu.github.io/wealth-train-update/backtester/backtester_update.json",
    "https://hsuyifu.github.io/KGI_AutoTrader/backtester_update.json",
    "https://hsuyifu.github.io/KGI_AutoTrader/train_backtester_update.json",
]


def is_ema_strategy(strategy_name):
    raw = str(strategy_name or "").strip()
    text = raw.upper().replace(" ", "")
    return bool(raw == "EMA策略" or "EMA策略" in raw or text.startswith("EMA"))

def is_sma_strategy(strategy_name):
    raw = str(strategy_name or "").strip()
    text = raw.upper().replace(" ", "")
    return bool(raw == "SMA策略" or "SMA策略" in raw or text.startswith("SMA"))

def is_open_price_strategy(strategy_name):
    raw = str(strategy_name or "").strip()
    text = raw.upper().replace(" ", "")
    return bool(raw == "開盤價策略" or "開盤價策略" in raw or "OPENPRICE" in text or "OPEN_PRICE" in text)

def is_fast_ma_strategy(strategy_name):
    return is_ema_strategy(strategy_name) or is_sma_strategy(strategy_name)

def ma_algo_label(strategy_name):
    return "SMA" if is_sma_strategy(strategy_name) else "EMA" if is_ema_strategy(strategy_name) else "MA"

def is_three_ma_strategy(strategy_name):
    raw = str(strategy_name or "").strip()
    text = raw.upper().replace(" ", "")
    if is_ema_strategy(raw) or is_sma_strategy(raw) or is_open_price_strategy(raw):
        return False
    return raw == "MA策略" or "MA策略" in raw or ("3" + "MA") in text or any(token in text for token in ("5MA", "10MA"))

def is_param_strategy(strategy_name):
    return is_three_ma_strategy(strategy_name) or is_fast_ma_strategy(strategy_name)

def normalize_ma_period(value):
    text = str(value or "3").upper().replace("分", "").replace("K", "").replace(" ", "").replace("策略", "")
    for suffix in ("EMA", "MA"):
        text = text.replace(suffix, "")
    try:
        n = int(float(text))
    except Exception:
        n = 3
    return n if n in (3, 5, 10) else 3

def normalize_ema_period(value):
    text = str(value or "89").upper().replace("分", "").replace("K", "").replace(" ", "").replace("策略", "")
    for suffix in ("EMA", "SMA", "MA"):
        text = text.replace(suffix, "")
    try:
        n = int(float(text))
    except Exception:
        n = 89
    return max(1, min(999, n))

def normalize_sma_period(value):
    # SMA策略允許與 EMA 同樣的輸入範圍，方便直接比較不同均線長度。
    return normalize_ema_period(value)

def normalize_fast_ma_period(value):
    return normalize_ema_period(value)

def normalize_k_minutes(value):
    text = str(value or "1").strip().upper().replace(" ", "")
    if text in ("D", "DAY", "日", "日K"):
        return 1440
    try:
        k = int(float(text.replace("分", "").replace("K", "")))
    except Exception:
        k = 1
    return k if k in (1, 5, 10, 15, 30, 60, 1440) else 1

def normalize_ema_k_minutes(value):
    k = normalize_k_minutes(value)
    return k if k in (5, 10, 15, 30, 60, 1440) else 60


def k_minutes_label(value):
    k = normalize_k_minutes(value)
    return "日K" if k >= 1440 else str(k)


def normalize_entry_mode(value):
    text = str(value or "").strip()
    if "收盤" in text or text.lower() in ("close", "close_confirm", "confirm"):
        return "收盤確認"
    return "逐筆洗價"

class OperationCancelled(Exception):
    pass

def app_dir():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return os.getcwd()

def shared_ma_data_root():
    """回測器與小火車共用 MA 資料中心；預設由獨立匯入工具維護。"""
    root = os.environ.get("TRAIN_MA_DATA_CENTER") or r"C:\TrainMADataCenter"
    try:
        root = os.path.abspath(root)
    except Exception:
        root = r"C:\TrainMADataCenter"
    return root


def cache_dir():
    d = os.path.join(shared_ma_data_root(), "data_cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d

def logs_dir():
    d = os.path.join(app_dir(), "logs")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def startup_log_path():
    return os.path.join(logs_dir(), "backtester_startup_log.txt")


def log_startup(message):
    try:
        with open(startup_log_path(), "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"), str(message)))
    except Exception:
        pass



def _letter_version_value(text):
    """A=1, B=2... AA=27；用來比較 054B -> 054C 這種字母版號。"""
    value = 0
    for ch in str(text or "").upper():
        if "A" <= ch <= "Z":
            value = value * 26 + (ord(ch) - ord("A") + 1)
    return value


def _version_key(value):
    """把 v054C / 2026.06.28-054C / v20260628055A 轉成可比較 tuple。

    版本判斷只比較真正的版號尾段，例如 054C、055A。
    發布器為了讓舊版能偵測新版，可能使用 v20260628055A 這種壓縮日期版號；
    新版必須把它視為 055A，否則更新後會一直把線上版本誤判為新版。
    """
    text = str(value or "").strip()

    # 發布器相容格式：vYYYYMMDD055A -> 視為 055A。
    # 這是為了讓舊版回測器也能看到「大數字版本」而跳出更新；
    # 更新後則要避免因顯示版 2026.06.28-055A 與線上 v20260628055A 不同而重複提示。
    m = re.search(r"^v?(\d{8})(\d{2,4})([A-Za-z]*)\s*$", text, re.I)
    if m:
        try:
            return (int(m.group(2)), _letter_version_value(m.group(3)))
        except Exception:
            pass

    m = re.search(r"(?:^|[-_])v?(\d{2,4})([A-Za-z]*)\s*$", text)
    if m:
        try:
            return (int(m.group(1)), _letter_version_value(m.group(2)))
        except Exception:
            pass
    m = re.search(r"^v?(\d{2,4})([A-Za-z]*)\s*$", text, re.I)
    if m:
        try:
            return (int(m.group(1)), _letter_version_value(m.group(2)))
        except Exception:
            pass
    nums = re.findall(r"\d+", text)
    if not nums:
        return (0, 0)
    try:
        return tuple(int(x) for x in nums)
    except Exception:
        return (0, 0)


def _is_newer_version(remote_version, local_version=APP_VERSION):
    rv = _version_key(remote_version)
    lv = _version_key(local_version)
    n = max(len(rv), len(lv))
    rv = rv + (0,) * (n - len(rv))
    lv = lv + (0,) * (n - len(lv))
    return rv > lv


def _read_update_url_file():
    urls = []
    p = os.path.join(app_dir(), BACKTESTER_UPDATE_URL_FILE)
    if not os.path.exists(p):
        return urls
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                text = str(line or "").strip()
                if not text or text.startswith("#") or text.startswith("//"):
                    continue
                urls.append(text)
    except Exception as exc:
        log_startup("Read update url file failed: %s" % exc)
    return urls


def backtester_update_manifest_urls():
    urls = []
    env = str(os.environ.get("TRAIN_BACKTESTER_UPDATE_MANIFEST_URL", "") or "").strip()
    if env:
        urls.append(env)
    urls.extend(_read_update_url_file())
    # 保留預設候選；若網址不存在，啟動時靜默略過，手動檢查時會顯示原因。
    urls.extend(BACKTESTER_DEFAULT_UPDATE_MANIFEST_URLS)
    out = []
    seen = set()
    for u in urls:
        u = str(u or "").strip()
        if not u or u in seen:
            continue
        if not (u.lower().startswith("http://") or u.lower().startswith("https://")):
            continue
        seen.add(u)
        out.append(u)
    return out


def _http_get_bytes(url, timeout=20, progress=None):
    req = urllib.request.Request(str(url), headers={
        "User-Agent": "TrainBacktester/%s" % APP_VERSION,
        "Cache-Control": "no-cache",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        total = 0
        try:
            total = int(resp.headers.get("Content-Length") or 0)
        except Exception:
            total = 0
        chunks = []
        done = 0
        while True:
            chunk = resp.read(1024 * 256)
            if not chunk:
                break
            chunks.append(chunk)
            done += len(chunk)
            if progress:
                try:
                    progress(done, total or max(done, 1), "下載 %.1f MB" % (done / 1024 / 1024), stage="下載更新")
                except Exception:
                    pass
        return b"".join(chunks)


def fetch_update_manifest(url):
    raw = _http_get_bytes(url, timeout=12)
    try:
        text = raw.decode("utf-8-sig")
    except Exception:
        text = raw.decode("utf-8", errors="replace")
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError("更新 manifest 格式不是 JSON 物件")
    return data


def _manifest_package_url(manifest, manifest_url):
    for key in ("package_url", "patch_url", "url", "download_url"):
        value = str((manifest or {}).get(key) or "").strip()
        if value:
            return urllib.parse.urljoin(str(manifest_url), value)
    raise ValueError("更新 manifest 缺少 package_url")


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_update_relative_name(name):
    n = str(name or "").replace("\\", "/").strip()
    while n.startswith("./"):
        n = n[2:]
    if not n or n.endswith("/"):
        return ""
    parts = [x for x in n.split("/") if x]
    if not parts:
        return ""
    if any(x in (".", "..") for x in parts):
        raise ValueError("更新包含不安全路徑：%s" % name)
    if n.startswith("/") or re.match(r"^[A-Za-z]:", n):
        raise ValueError("更新包含絕對路徑：%s" % name)
    lowered = [x.lower() for x in parts]
    if "__pycache__" in lowered or parts[-1].lower().endswith((".pyc", ".pyo")):
        return ""
    if lowered[0] in ("data_cache", "logs", "update_backups"):
        return ""
    return "/".join(parts)


def _zip_common_root_to_strip(names):
    clean = []
    for n in names:
        try:
            rn = _safe_update_relative_name(n)
        except Exception:
            continue
        if rn:
            clean.append(rn)
    if not clean:
        return ""
    first_parts = [x.split("/", 1)[0] for x in clean]
    root = first_parts[0]
    if not root or any(x != root for x in first_parts):
        return ""
    # 若壓縮包是一層資料夾包住完整檔案，更新時自動剝掉外層資料夾。
    root_lower = root.lower()
    if root_lower in ("train_backtester", "backtester", "release", "update", "小火車回測器", "新增資料夾") or root.startswith("#U"):
        return root + "/"
    return ""


def apply_update_zip(zip_path, progress=None):
    target_dir = app_dir()
    if not zipfile.is_zipfile(zip_path):
        raise ValueError("下載檔不是有效 ZIP：%s" % zip_path)
    stamp = RealDateTime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(target_dir, "update_backups", "%s_%s" % (APP_VERSION, stamp))
    temp_dir = tempfile.mkdtemp(prefix="train_backtester_update_extract_")
    extracted = []
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            strip_prefix = _zip_common_root_to_strip([x.filename for x in zf.infolist()])
            members = [x for x in zf.infolist() if not x.is_dir()]
            total = max(1, len(members))
            for idx, info in enumerate(members, start=1):
                rel = _safe_update_relative_name(info.filename)
                if not rel:
                    continue
                if strip_prefix and rel.startswith(strip_prefix):
                    rel = rel[len(strip_prefix):]
                rel = _safe_update_relative_name(rel)
                if not rel:
                    continue
                src = zf.open(info, "r")
                dst = os.path.join(temp_dir, *rel.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with src, open(dst, "wb") as f:
                    shutil.copyfileobj(src, f)
                extracted.append(rel)
                if progress:
                    progress(idx, total, "解壓 %s" % rel, stage="套用更新")
        if not extracted:
            raise ValueError("更新包沒有可套用的檔案")
        total = max(1, len(extracted))
        for idx, rel in enumerate(extracted, start=1):
            src = os.path.join(temp_dir, *rel.split("/"))
            dst = os.path.join(target_dir, *rel.split("/"))
            if os.path.exists(dst):
                bak = os.path.join(backup_dir, *rel.split("/"))
                os.makedirs(os.path.dirname(bak), exist_ok=True)
                try:
                    shutil.copy2(dst, bak)
                except Exception:
                    shutil.copy(dst, bak)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            try:
                shutil.copy2(src, dst)
            except Exception:
                shutil.copy(src, dst)
            if progress:
                progress(idx, total, "覆蓋 %s" % rel, stage="套用更新")
        return {"updated_files": extracted, "backup_dir": backup_dir}
    finally:
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass


def download_and_apply_update_manifest(manifest, manifest_url, progress=None):
    pkg_url = _manifest_package_url(manifest, manifest_url)
    tmp_dir = tempfile.mkdtemp(prefix="train_backtester_update_download_")
    try:
        zip_path = os.path.join(tmp_dir, "update.zip")
        raw = _http_get_bytes(pkg_url, timeout=60, progress=progress)
        with open(zip_path, "wb") as f:
            f.write(raw)
        expected_sha = str((manifest or {}).get("sha256") or "").strip().lower()
        actual_sha = _sha256_file(zip_path)
        if expected_sha and actual_sha.lower() != expected_sha:
            raise ValueError("更新包 SHA256 不一致，已停止更新。\n預期：%s\n實際：%s" % (expected_sha, actual_sha))
        result = apply_update_zip(zip_path, progress=progress)
        result["package_url"] = pkg_url
        result["sha256"] = actual_sha
        return result
    finally:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

def _parse_geometry_bounds(geo):
    """Return (width, height, x, y) for Tk geometry like 1440x850+0+0."""
    m = re.match(r"^\s*(\d+)x(\d+)([+-]\d+)([+-]\d+)\s*$", str(geo or ""))
    if not m:
        return None
    try:
        return int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
    except Exception:
        return None


def _default_root_geometry(root, width=1440, height=850):
    try:
        sw = max(800, int(root.winfo_screenwidth() or 1440))
        sh = max(600, int(root.winfo_screenheight() or 850))
        w = min(int(width), max(760, sw - 80))
        h = min(int(height), max(560, sh - 80))
        x = max(0, int((sw - w) / 2))
        y = max(0, int((sh - h) / 2))
        return "%dx%d+%d+%d" % (w, h, x, y)
    except Exception:
        return "1200x760+20+20"


def _geometry_is_visible_on_screen(root, geo):
    bounds = _parse_geometry_bounds(geo)
    if not bounds:
        return False
    w, h, x, y = bounds
    if w < 360 or h < 260:
        return False
    try:
        sw = int(root.winfo_screenwidth() or 0)
        sh = int(root.winfo_screenheight() or 0)
    except Exception:
        sw, sh = 0, 0
    if sw <= 0 or sh <= 0:
        return True
    # At least a practical area must remain reachable inside the current remote desktop.
    visible_w = min(x + w, sw) - max(x, 0)
    visible_h = min(y + h, sh) - max(y, 0)
    return visible_w >= 220 and visible_h >= 160

def margin_master_path():
    return os.path.join(cache_dir(), "taifex_stock_margin_master.json")

def ticks_cache_db_path():
    return os.path.join(cache_dir(), "ticks_cache.db")

def product_summary_cache_path():
    return os.path.join(cache_dir(), "product_summary_cache.json")

def ui_settings_path():
    return os.path.join(cache_dir(), "ui_settings.json")

def load_ui_settings():
    p = ui_settings_path()
    if not os.path.exists(p):
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def save_ui_settings(data):
    try:
        os.makedirs(cache_dir(), exist_ok=True)
        tmp = ui_settings_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data if isinstance(data, dict) else {}, f, ensure_ascii=False, indent=2)
        os.replace(tmp, ui_settings_path())
    except Exception:
        pass


def _option_to_json(opt):
    data = {}
    for key in ProductOption.__dataclass_fields__:
        v = getattr(opt, key, None)
        if isinstance(v, RealDateTime):
            data[key] = {"__type__": "datetime", "value": v.isoformat()}
        elif isinstance(v, date):
            data[key] = {"__type__": "date", "value": v.isoformat()}
        else:
            data[key] = v
    # 熱門排名是執行期附加欄位，不在 dataclass 內，也一併保存。
    data["hot_rank"] = int(getattr(opt, "hot_rank", 0) or 0)
    data["hot_status"] = str(getattr(opt, "hot_status", "") or "")
    return data

def _option_from_json(data):
    if not isinstance(data, dict):
        return None
    kwargs = {}
    for key in ProductOption.__dataclass_fields__:
        v = data.get(key)
        if isinstance(v, dict) and v.get("__type__") == "datetime":
            try:
                v = RealDateTime.fromisoformat(str(v.get("value") or ""))
            except Exception:
                v = None
        elif isinstance(v, dict) and v.get("__type__") == "date":
            try:
                v = date.fromisoformat(str(v.get("value") or ""))
            except Exception:
                v = None
        kwargs[key] = v
    try:
        opt = ProductOption(**kwargs)
        opt.hot_rank = int(data.get("hot_rank", 0) or 0)
        opt.hot_status = str(data.get("hot_status", "") or "")
        return opt
    except Exception:
        return None

def save_product_summary_cache(options):
    try:
        payload = {
            "version": APP_VERSION,
            "saved_at": RealDateTime.now().isoformat(timespec="seconds"),
            "db_path": ticks_cache_db_path(),
            "options": [_option_to_json(o) for o in (options or [])],
        }
        tmp = product_summary_cache_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, product_summary_cache_path())
    except Exception:
        pass

def load_product_summary_cache():
    p = product_summary_cache_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as f:
            payload = json.load(f)
        opts = [_option_from_json(x) for x in (payload.get("options", []) or [])]
        return [o for o in opts if o is not None]
    except Exception:
        return []

def db_connect():
    conn = sqlite3.connect(ticks_cache_db_path())
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn


def init_tick_cache_db():
    conn = db_connect()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS source_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_key TEXT UNIQUE,
                path TEXT,
                member TEXT,
                display TEXT,
                size INTEGER,
                mtime REAL,
                crc TEXT,
                sha256 TEXT,
                parser_version INTEGER DEFAULT 0,
                imported_at TEXT,
                rows_total INTEGER DEFAULT 0,
                rows_inserted INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ticks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_file_id INTEGER NOT NULL,
                code TEXT NOT NULL,
                month TEXT NOT NULL,
                dt TEXT NOT NULL,
                trade_date TEXT NOT NULL,
                price REAL NOT NULL,
                qty REAL NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS primary_months (
                source_file_id INTEGER NOT NULL,
                code TEXT NOT NULL,
                primary_month TEXT NOT NULL,
                rows_count INTEGER DEFAULT 0,
                qty_sum REAL DEFAULT 0,
                PRIMARY KEY (source_file_id, code)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ignored_missing_dates (
                trade_date TEXT PRIMARY KEY,
                reason TEXT DEFAULT 'manual_holiday',
                created_at TEXT
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticks_code_date ON ticks(code, trade_date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticks_code_dt ON ticks(code, dt)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticks_source_code_month ON ticks(source_file_id, code, month)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pm_source_code ON primary_months(source_file_id, code)")
        try:
            conn.execute("ALTER TABLE source_files ADD COLUMN parser_version INTEGER DEFAULT 0")
        except sqlite3.OperationalError:
            pass
        conn.commit()
    finally:
        conn.close()



def load_ignored_missing_dates():
    """回傳使用者手動標記的非六日休市/忽略缺日。"""
    init_tick_cache_db()
    conn = db_connect()
    try:
        rows = conn.execute("SELECT trade_date FROM ignored_missing_dates ORDER BY trade_date").fetchall()
    except sqlite3.OperationalError:
        rows = []
    finally:
        conn.close()
    out = set()
    for (txt,) in rows:
        d = _date_from_text(txt)
        if d:
            out.add(d)
    return out


def save_ignored_missing_dates(dates, reason="manual_holiday"):
    vals = []
    for d in dates or []:
        dd = _date_from_text(d) if not isinstance(d, date) else d
        if dd:
            vals.append((_date_text(dd), str(reason or "manual_holiday"), RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S")))
    if not vals:
        return 0
    init_tick_cache_db()
    conn = db_connect()
    try:
        conn.executemany(
            "INSERT OR REPLACE INTO ignored_missing_dates(trade_date,reason,created_at) VALUES(?,?,?)",
            vals,
        )
        conn.commit()
        return len(vals)
    finally:
        conn.close()


def delete_ignored_missing_dates(dates):
    vals = []
    for d in dates or []:
        dd = _date_from_text(d) if not isinstance(d, date) else d
        if dd:
            vals.append((_date_text(dd),))
    if not vals:
        return 0
    init_tick_cache_db()
    conn = db_connect()
    try:
        conn.executemany("DELETE FROM ignored_missing_dates WHERE trade_date=?", vals)
        conn.commit()
        return len(vals)
    finally:
        conn.close()


def _missing_dates_excluding_ignored(expected, have):
    ignored = load_ignored_missing_dates()
    have = set(have or [])
    missing = []
    ignored_missing = []
    for d in expected or []:
        dd = _date_from_text(d) if not isinstance(d, date) else d
        if not dd or dd in have:
            continue
        if dd in ignored:
            ignored_missing.append(dd)
        else:
            missing.append(dd)
    return missing, ignored_missing


def tai_full_cache_trade_dates():
    """TX/TXF 全盤日夜盤合併後的實際交易日，用於判斷國定假日缺日。"""
    init_tick_cache_db()
    expr = _ema_full_trade_date_sql_expr()
    conn = db_connect()
    try:
        rows = conn.execute("""
            SELECT DISTINCT %s AS trade_day
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            WHERE t.code IN ('TXF','TX')
            ORDER BY trade_day
        """ % expr).fetchall()
    finally:
        conn.close()
    out = []
    seen = set()
    for (txt,) in rows:
        d = _date_from_text(txt)
        if d and d not in seen:
            seen.add(d)
            out.append(d)
    return out


def tai_nonweekend_missing_dates_from_cache(include_ignored=False):
    dates = tai_full_cache_trade_dates()
    if not dates:
        return []
    have = set(dates)
    ignored = load_ignored_missing_dates()
    cur, end = dates[0], dates[-1]
    missing = []
    while cur <= end:
        if cur.weekday() < 5 and cur not in have:
            if include_ignored or cur not in ignored:
                missing.append(cur)
        cur += timedelta(days=1)
    return missing

# ---------------------------------------------------------------------
# EMA/SMA 共用快取：保存 5/10/15/30/60分K與日K的 K棒與均線值。
# 原始逐筆仍保存在 ticks_cache.db；停利/停損/突破順序仍回讀原始 tick。
# ---------------------------------------------------------------------
EMA_TXF_CACHE_VERSION = 3
EMA_TXF_K_MINUTES = (5, 10, 15, 30, 60, 1440)
EMA_TXF_CODES = ("TXF", "TX")


def ema_txf_cache_db_path():
    return os.path.join(cache_dir(), "ema_txf_cache.db")


def ema_db_connect():
    conn = sqlite3.connect(ema_txf_cache_db_path())
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn


def init_ema_txf_cache_db():
    conn = ema_db_connect()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ema_cache_meta (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ema_kbars (
                code TEXT NOT NULL,
                k_minutes INTEGER NOT NULL,
                trade_date TEXT NOT NULL,
                bar_index INTEGER NOT NULL,
                start_dt TEXT NOT NULL,
                end_dt TEXT NOT NULL,
                open REAL NOT NULL,
                high REAL NOT NULL,
                low REAL NOT NULL,
                close REAL NOT NULL,
                qty REAL NOT NULL DEFAULT 0,
                tick_count INTEGER NOT NULL DEFAULT 0,
                month TEXT,
                PRIMARY KEY (code, k_minutes, trade_date, bar_index)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ema_periods (
                code TEXT NOT NULL,
                k_minutes INTEGER NOT NULL,
                period INTEGER NOT NULL,
                created_at TEXT,
                PRIMARY KEY (code, k_minutes, period)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ema_values (
                code TEXT NOT NULL,
                k_minutes INTEGER NOT NULL,
                period INTEGER NOT NULL,
                trade_date TEXT NOT NULL,
                bar_index INTEGER NOT NULL,
                ema REAL NOT NULL DEFAULT 0,
                ready INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (code, k_minutes, period, trade_date, bar_index)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sma_periods (
                code TEXT NOT NULL,
                k_minutes INTEGER NOT NULL,
                period INTEGER NOT NULL,
                created_at TEXT,
                PRIMARY KEY (code, k_minutes, period)
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS sma_values (
                code TEXT NOT NULL,
                k_minutes INTEGER NOT NULL,
                period INTEGER NOT NULL,
                trade_date TEXT NOT NULL,
                bar_index INTEGER NOT NULL,
                sma REAL NOT NULL DEFAULT 0,
                ready INTEGER NOT NULL DEFAULT 0,
                PRIMARY KEY (code, k_minutes, period, trade_date, bar_index)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ema_kbars_order ON ema_kbars(code,k_minutes,start_dt)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ema_values_order ON ema_values(code,k_minutes,period,trade_date,bar_index)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_sma_values_order ON sma_values(code,k_minutes,period,trade_date,bar_index)")
        conn.execute("INSERT OR REPLACE INTO ema_cache_meta(key,value) VALUES('version', ?)", (str(EMA_TXF_CACHE_VERSION),))
        conn.commit()
    finally:
        conn.close()


def _ema_txf_trade_day_for_dt(dt):
    """EMA台指全盤日期：同一自然日的日盤08:45先算，15:00夜盤接續；00:00~04:59歸屬前一日。"""
    minute = dt.hour * 60 + dt.minute
    if 8 * 60 + 45 <= minute < 13 * 60 + 45:
        return dt.date()
    if minute >= 15 * 60:
        return dt.date()
    if minute < 5 * 60:
        return dt.date() - timedelta(days=1)
    return None


def _ema_txf_session_offset_minute(dt):
    """TXF EMA全盤分鐘索引：日盤08:45=0，夜盤15:00接在日盤5小時之後。"""
    minute = dt.hour * 60 + dt.minute
    day_open = 8 * 60 + 45
    day_close = 13 * 60 + 45
    night_open = 15 * 60
    if day_open <= minute < day_close:
        return minute - day_open
    if minute >= night_open:
        return 5 * 60 + (minute - night_open)
    if minute < 5 * 60:
        return 5 * 60 + (minute + 24 * 60 - night_open)
    return -1


def _ema_txf_bar_start_from_index(trade_day, k_minutes, bar_index):
    k = normalize_ema_k_minutes(k_minutes)
    idx = max(0, int(bar_index or 0))
    offset = idx * k
    if k >= 1440:
        return RealDateTime.combine(trade_day, time(8, 45, 0))
    if offset < 5 * 60:
        return RealDateTime.combine(trade_day, time(8, 45, 0)) + timedelta(minutes=offset)
    return RealDateTime.combine(trade_day, time(15, 0, 0)) + timedelta(minutes=offset - 5 * 60)


def _ema_txf_bar_identity(dt, k_minutes):
    trade_day = _ema_txf_trade_day_for_dt(dt)
    if trade_day is None:
        return None
    k = normalize_ema_k_minutes(k_minutes)
    if k >= 1440:
        return trade_day, 0, _ema_txf_bar_start_from_index(trade_day, k, 0)
    offset = _ema_txf_session_offset_minute(dt)
    if offset < 0:
        return None
    bar_index = int(offset // k)
    start_dt = _ema_txf_bar_start_from_index(trade_day, k, bar_index)
    return trade_day, bar_index, start_dt


def _fast_ma_trade_day_for_dt(code, dt):
    """EMA/SMA高速K棒交易日。台指用日夜盤全盤；股期保留日盤特性，只算08:45~13:45。"""
    if is_tai_index_code(code):
        return _ema_txf_trade_day_for_dt(dt)
    try:
        minute = dt.hour * 60 + dt.minute
        if 8 * 60 + 45 <= minute < 13 * 60 + 45:
            return dt.date()
    except Exception:
        pass
    return None


def _fast_ma_session_offset_minute(code, dt):
    if is_tai_index_code(code):
        return _ema_txf_session_offset_minute(dt)
    try:
        minute = dt.hour * 60 + dt.minute
        base = 8 * 60 + 45
        if base <= minute < 13 * 60 + 45:
            return minute - base
    except Exception:
        pass
    return -1


def _fast_ma_bar_start_from_index(code, trade_day, k_minutes, bar_index):
    if is_tai_index_code(code):
        return _ema_txf_bar_start_from_index(trade_day, k_minutes, bar_index)
    k = normalize_ema_k_minutes(k_minutes)
    if k >= 1440:
        return RealDateTime.combine(trade_day, time(8, 45, 0))
    return RealDateTime.combine(trade_day, time(8, 45, 0)) + timedelta(minutes=max(0, int(bar_index or 0)) * k)


def _fast_ma_bar_identity(code, dt, k_minutes):
    trade_day = _fast_ma_trade_day_for_dt(code, dt)
    if trade_day is None:
        return None
    k = normalize_ema_k_minutes(k_minutes)
    if k >= 1440:
        return trade_day, 0, _fast_ma_bar_start_from_index(code, trade_day, k, 0)
    offset = _fast_ma_session_offset_minute(code, dt)
    if offset < 0:
        return None
    bar_index = int(offset // k)
    return trade_day, bar_index, _fast_ma_bar_start_from_index(code, trade_day, k, bar_index)


def _fast_ma_session_label(trade_date_text, code):
    return "%s 日夜盤" % str(trade_date_text or "") if is_tai_index_code(code) else "%s 日盤" % str(trade_date_text or "")


def _ema_full_trade_date_sql_expr():
    hh = "substr(t.dt, 12, 5)"
    return "(CASE WHEN %s >= '15:00' THEN date(t.dt) WHEN %s < '05:00' THEN date(t.dt, '-1 day') WHEN %s >= '08:45' AND %s < '13:45' THEN date(t.dt) ELSE t.trade_date END)" % (hh, hh, hh, hh)


def _ema_txf_codes_in_tick_cache():
    # 歷史名稱保留相容；v052V 起此快取同時支援 TXF/TX 與所有已匯入的股票期貨。
    init_tick_cache_db()
    conn = db_connect()
    try:
        rows = conn.execute("""
            SELECT DISTINCT t.code
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            ORDER BY CASE WHEN t.code IN ('TXF','TX') THEN 0 ELSE 1 END, t.code
        """).fetchall()
        return [clean_code(r[0]) for r in rows if clean_code(r[0])]
    finally:
        conn.close()


def rebuild_ema_txf_cache(progress=None):
    """從 ticks_cache.db 重建 EMA/SMA 高速K棒快取。

    v052V：不只 TXF/TX，已匯入的股票期貨也會建立 5/10/15/30/60分K與日K。
    台指保留日夜盤全盤；股期保留日盤 08:45~13:45，不混入夜盤。
    """
    init_tick_cache_db()
    repair_tai_tick_cache_datetime_if_needed(progress=progress)
    init_ema_txf_cache_db()
    codes = _ema_txf_codes_in_tick_cache()
    if not codes:
        _safe_progress(progress, 1, 1, "EMA/SMA快取略過｜ticks_cache.db 內尚無可用商品")
        return {"bars": 0, "codes": []}
    conn_src = db_connect()
    conn_dst = ema_db_connect()
    try:
        placeholders = ",".join("?" for _ in codes)
        sql = f"""
            SELECT t.code, t.dt, t.price, t.qty, t.month
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            WHERE t.code IN ({placeholders})
            ORDER BY t.dt
        """
        rows = conn_src.execute(sql, codes).fetchall()
        total = len(rows) or 1
        bars = {}
        for i, (code, dt_text, price, qty, month) in enumerate(rows, start=1):
            try:
                code = clean_code(code)
                dt = RealDateTime.fromisoformat(str(dt_text))
                price = float(price)
                qty = float(qty or 0.0)
            except Exception:
                continue
            if _fast_ma_trade_day_for_dt(code, dt) is None:
                continue
            for k in EMA_TXF_K_MINUTES:
                ident = _fast_ma_bar_identity(code, dt, k)
                if ident is None:
                    continue
                trade_day, bar_index, start_dt = ident
                key = (code, int(k), trade_day.strftime("%Y-%m-%d"), int(bar_index))
                b = bars.get(key)
                if b is None:
                    bars[key] = {
                        "start_dt": start_dt,
                        "end_dt": dt,
                        "open": price,
                        "high": price,
                        "low": price,
                        "close": price,
                        "qty": qty,
                        "tick_count": 1,
                        "months": {str(month or "")},
                    }
                else:
                    b["end_dt"] = dt
                    b["high"] = max(float(b["high"]), price)
                    b["low"] = min(float(b["low"]), price)
                    b["close"] = price
                    b["qty"] = float(b.get("qty", 0.0) or 0.0) + qty
                    b["tick_count"] = int(b.get("tick_count", 0) or 0) + 1
                    if month:
                        b.setdefault("months", set()).add(str(month))
            if i % 50000 == 0:
                _safe_progress(progress, i, total, "EMA/SMA K棒整理中｜%s/%s tick" % (f"{i:,}", f"{total:,}"))
        conn_dst.execute("DELETE FROM ema_kbars")
        conn_dst.execute("DELETE FROM ema_values")
        try:
            conn_dst.execute("DELETE FROM sma_values")
        except Exception:
            pass
        insert_rows = []
        for (code, k, trade_date, bar_index), b in sorted(bars.items(), key=lambda x: (x[0][0], x[0][1], x[1]["start_dt"])):
            months = "/".join(sorted(m for m in b.get("months", set()) if m))
            insert_rows.append((code, k, trade_date, bar_index, b["start_dt"].strftime("%Y-%m-%d %H:%M:%S"), b["end_dt"].strftime("%Y-%m-%d %H:%M:%S"), float(b["open"]), float(b["high"]), float(b["low"]), float(b["close"]), float(b.get("qty", 0.0) or 0.0), int(b.get("tick_count", 0) or 0), months))
        if insert_rows:
            conn_dst.executemany("""
                INSERT OR REPLACE INTO ema_kbars(code,k_minutes,trade_date,bar_index,start_dt,end_dt,open,high,low,close,qty,tick_count,month)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, insert_rows)
        conn_dst.execute("INSERT OR REPLACE INTO ema_cache_meta(key,value) VALUES('last_rebuild_at', ?)", (RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"),))
        conn_dst.execute("INSERT OR REPLACE INTO ema_cache_meta(key,value) VALUES('bar_count', ?)", (str(len(insert_rows)),))
        conn_dst.commit()
        # 已經用過的 EMA/SMA 參數在重建 K棒後同步重算，確保匯入新資料時兩套資料一致。
        period_rows = conn_dst.execute("SELECT code,k_minutes,period FROM ema_periods ORDER BY code,k_minutes,period").fetchall()
        for idx, (code, k, period) in enumerate(period_rows, start=1):
            _safe_progress(progress, idx, max(1, len(period_rows)), "EMA參數同步重算｜%s %s %s" % (code, k_minutes_label(k), "EMA%d" % int(period)))
            _compute_ema_period_values(conn_dst, clean_code(code), int(k), int(period))
        try:
            sma_period_rows = conn_dst.execute("SELECT code,k_minutes,period FROM sma_periods ORDER BY code,k_minutes,period").fetchall()
        except Exception:
            sma_period_rows = []
        for idx, (code, k, period) in enumerate(sma_period_rows, start=1):
            _safe_progress(progress, idx, max(1, len(sma_period_rows)), "SMA參數同步重算｜%s %s %s" % (code, k_minutes_label(k), "SMA%d" % int(period)))
            _compute_sma_period_values(conn_dst, clean_code(code), int(k), int(period))
        conn_dst.commit()
        _safe_progress(progress, 1, 1, "EMA/SMA快取完成｜K棒 %s 根｜商品 %s" % (f"{len(insert_rows):,}", "/".join(codes)))
        return {"bars": len(insert_rows), "codes": codes}
    finally:
        try:
            conn_src.close()
        except Exception:
            pass
        try:
            conn_dst.close()
        except Exception:
            pass


def rebuild_ema_kbars_for_code_k(code, k_minutes, progress=None):
    """只重建指定商品與K棒週期的 EMA/SMA 高速K棒。

    055F 修正：舊版遇到新加入的 15/30 分K，若 ema_txf_cache.db 內沒有該週期，
    會呼叫 rebuild_ema_txf_cache() 重建全部商品/全部K棒。資料庫商品很多時，畫面會停在
    「快取讀取完成 / 回測運算 100%」很久，看起來像卡死。這裡改成缺哪個商品、哪個K棒，
    就只補那一小段快取。
    """
    code = clean_code(code or "TXF")
    k = normalize_ema_k_minutes(k_minutes)
    if not code:
        return 0
    init_tick_cache_db()
    init_ema_txf_cache_db()
    _safe_progress(progress, 0, 1, "建立高速K棒快取｜%s｜%s｜讀取逐筆中" % (code, k_minutes_label(k)))
    conn_src = db_connect()
    conn_dst = ema_db_connect()
    try:
        rows = conn_src.execute("""
            SELECT t.dt, t.price, t.qty, t.month
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            WHERE t.code=?
            ORDER BY t.dt
        """, (code,)).fetchall()
        total = len(rows) or 1
        bars = {}
        for i, (dt_text, price, qty, month) in enumerate(rows, start=1):
            try:
                dt = RealDateTime.fromisoformat(str(dt_text))
                price = float(price)
                qty = float(qty or 0.0)
            except Exception:
                continue
            ident = _fast_ma_bar_identity(code, dt, k)
            if ident is None:
                continue
            trade_day, bar_index, start_dt = ident
            key = (trade_day.strftime("%Y-%m-%d"), int(bar_index))
            b = bars.get(key)
            if b is None:
                bars[key] = {
                    "start_dt": start_dt,
                    "end_dt": dt,
                    "open": price,
                    "high": price,
                    "low": price,
                    "close": price,
                    "qty": qty,
                    "tick_count": 1,
                    "months": {str(month or "")},
                }
            else:
                b["end_dt"] = dt
                b["high"] = max(float(b["high"]), price)
                b["low"] = min(float(b["low"]), price)
                b["close"] = price
                b["qty"] = float(b.get("qty", 0.0) or 0.0) + qty
                b["tick_count"] = int(b.get("tick_count", 0) or 0) + 1
                if month:
                    b.setdefault("months", set()).add(str(month))
            if i % 50000 == 0:
                _safe_progress(progress, i, total, "建立高速K棒快取｜%s｜%s｜%s/%s tick" % (code, k_minutes_label(k), f"{i:,}", f"{total:,}"))
        insert_rows = []
        for (trade_date, bar_index), b in sorted(bars.items(), key=lambda x: (x[1]["start_dt"], x[0][1])):
            months = "/".join(sorted(m for m in b.get("months", set()) if m))
            insert_rows.append((code, k, trade_date, int(bar_index), b["start_dt"].strftime("%Y-%m-%d %H:%M:%S"), b["end_dt"].strftime("%Y-%m-%d %H:%M:%S"), float(b["open"]), float(b["high"]), float(b["low"]), float(b["close"]), float(b.get("qty", 0.0) or 0.0), int(b.get("tick_count", 0) or 0), months))
        conn_dst.execute("DELETE FROM ema_kbars WHERE code=? AND k_minutes=?", (code, k))
        conn_dst.execute("DELETE FROM ema_values WHERE code=? AND k_minutes=?", (code, k))
        try:
            conn_dst.execute("DELETE FROM sma_values WHERE code=? AND k_minutes=?", (code, k))
        except Exception:
            pass
        if insert_rows:
            conn_dst.executemany("""
                INSERT OR REPLACE INTO ema_kbars(code,k_minutes,trade_date,bar_index,start_dt,end_dt,open,high,low,close,qty,tick_count,month)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, insert_rows)
        conn_dst.execute("INSERT OR REPLACE INTO ema_cache_meta(key,value) VALUES('last_partial_rebuild_at', ?)", (RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"),))
        conn_dst.execute("INSERT OR REPLACE INTO ema_cache_meta(key,value) VALUES(?, ?)", ("partial_bar_count:%s:%s" % (code, k), str(len(insert_rows))))
        conn_dst.commit()
        _safe_progress(progress, 1, 1, "高速K棒快取完成｜%s｜%s｜K棒 %s 根" % (code, k_minutes_label(k), f"{len(insert_rows):,}"))
        return len(insert_rows)
    finally:
        try:
            conn_src.close()
        except Exception:
            pass
        try:
            conn_dst.close()
        except Exception:
            pass


def ensure_ema_kbars_for_code_k(code, k_minutes, progress=None):
    """確認指定商品/K棒週期已有高速K棒；缺資料時只補該商品該週期。"""
    code = clean_code(code or "TXF")
    k = normalize_ema_k_minutes(k_minutes)
    init_ema_txf_cache_db()
    conn = ema_db_connect()
    try:
        row = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=? AND k_minutes=?", (code, k)).fetchone()
        if row and int(row[0] or 0) > 0:
            return int(row[0] or 0)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return rebuild_ema_kbars_for_code_k(code, k, progress=progress)



def _compute_ema_period_values(conn, code, k_minutes, period):
    code = clean_code(code)
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_ema_period(period)
    rows = conn.execute("""
        SELECT trade_date, bar_index, close
        FROM ema_kbars
        WHERE code=? AND k_minutes=?
        ORDER BY start_dt
    """, (code, k)).fetchall()
    conn.execute("DELETE FROM ema_values WHERE code=? AND k_minutes=? AND period=?", (code, k, p))
    alpha = 2.0 / float(p + 1) if p > 1 else 1.0
    closes = []
    prev_ema = 0.0
    out = []
    for trade_date, bar_index, close in rows:
        try:
            c = float(close)
        except Exception:
            c = 0.0
        closes.append(c)
        ema = 0.0
        ready = 0
        if p <= 1 and c > 0:
            ema = c
            ready = 1
        elif len(closes) == p and min(closes[-p:]) > 0:
            ema = sum(closes[-p:]) / float(p)
            ready = 1
        elif len(closes) > p and prev_ema > 0 and c > 0:
            ema = c * alpha + prev_ema * (1.0 - alpha)
            ready = 1
        if ema > 0:
            prev_ema = float(ema)
        out.append((code, k, p, str(trade_date), int(bar_index), float(ema or 0.0), int(ready)))
    if out:
        conn.executemany("""
            INSERT OR REPLACE INTO ema_values(code,k_minutes,period,trade_date,bar_index,ema,ready)
            VALUES(?,?,?,?,?,?,?)
        """, out)
    conn.execute("INSERT OR REPLACE INTO ema_periods(code,k_minutes,period,created_at) VALUES(?,?,?,?)", (code, k, p, RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S")))
    return len(out)


def ensure_ema_txf_period_cache(code, k_minutes, period, progress=None):
    code = clean_code(code or "TXF")
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_ema_period(period)
    init_ema_txf_cache_db()
    conn = ema_db_connect()
    try:
        row = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=? AND k_minutes=?", (code, k)).fetchone()
        if not row or int(row[0] or 0) <= 0:
            try:
                conn.close()
            except Exception:
                pass
            ensure_ema_kbars_for_code_k(code, k, progress=progress)
            conn = ema_db_connect()
        have = conn.execute("SELECT COUNT(*) FROM ema_values WHERE code=? AND k_minutes=? AND period=?", (code, k, p)).fetchone()
        kcnt = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=? AND k_minutes=?", (code, k)).fetchone()
        if not have or int(have[0] or 0) < int((kcnt or [0])[0] or 0):
            _safe_progress(progress, 0, 1, "建立EMA快取｜%s｜%s｜EMA%d" % (code, k_minutes_label(k), p))
            _compute_ema_period_values(conn, code, k, p)
            conn.commit()
        return True
    finally:
        try:
            conn.close()
        except Exception:
            pass




def _compute_sma_period_values(conn, code, k_minutes, period):
    code = clean_code(code)
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_sma_period(period)
    rows = conn.execute("""
        SELECT trade_date, bar_index, close
        FROM ema_kbars
        WHERE code=? AND k_minutes=?
        ORDER BY start_dt
    """, (code, k)).fetchall()
    conn.execute("DELETE FROM sma_values WHERE code=? AND k_minutes=? AND period=?", (code, k, p))
    closes = []
    out = []
    for trade_date, bar_index, close in rows:
        try:
            c = float(close)
        except Exception:
            c = 0.0
        closes.append(c)
        sma = 0.0
        ready = 0
        if p <= 1 and c > 0:
            sma = c
            ready = 1
        elif len(closes) >= p and min(closes[-p:]) > 0:
            sma = sum(closes[-p:]) / float(p)
            ready = 1
        out.append((code, k, p, str(trade_date), int(bar_index), float(sma or 0.0), int(ready)))
    if out:
        conn.executemany("""
            INSERT OR REPLACE INTO sma_values(code,k_minutes,period,trade_date,bar_index,sma,ready)
            VALUES(?,?,?,?,?,?,?)
        """, out)
    conn.execute("INSERT OR REPLACE INTO sma_periods(code,k_minutes,period,created_at) VALUES(?,?,?,?)", (code, k, p, RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S")))
    return len(out)


def ensure_sma_txf_period_cache(code, k_minutes, period, progress=None):
    code = clean_code(code or "TXF")
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_sma_period(period)
    init_ema_txf_cache_db()
    conn = ema_db_connect()
    try:
        row = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=? AND k_minutes=?", (code, k)).fetchone()
        if not row or int(row[0] or 0) <= 0:
            try:
                conn.close()
            except Exception:
                pass
            ensure_ema_kbars_for_code_k(code, k, progress=progress)
            conn = ema_db_connect()
        have = conn.execute("SELECT COUNT(*) FROM sma_values WHERE code=? AND k_minutes=? AND period=?", (code, k, p)).fetchone()
        kcnt = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=? AND k_minutes=?", (code, k)).fetchone()
        if not have or int(have[0] or 0) < int((kcnt or [0])[0] or 0):
            _safe_progress(progress, 0, 1, "建立SMA快取｜%s｜%s｜SMA%d" % (code, k_minutes_label(k), p))
            _compute_sma_period_values(conn, code, k, p)
            conn.commit()
        return True
    finally:
        try:
            conn.close()
        except Exception:
            pass

def ema_txf_seed_closes_for_ticks(ticks, code, k_minutes, period, progress=None):
    """依回測每個全盤交易日，從 EMA K棒快取取前 N-1 根完成K棒收盤價。"""
    if not ticks:
        return None
    code = clean_code(code or getattr(ticks[0], "code", "TXF"))
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_ema_period(period)
    need = max(0, p - 1)
    if need <= 0:
        return None
    try:
        ensure_ema_txf_period_cache(code, k, p, progress=progress)
    except Exception:
        return None
    first_dt_by_session = {}
    for t in list(ticks or []):
        try:
            dt = t.dt
            td = _fast_ma_trade_day_for_dt(code, dt)
            if td is None:
                continue
            skey = td.strftime("%Y-%m-%d") + (":FULL" if is_tai_index_code(code) else ":DAY")
            if skey not in first_dt_by_session or dt < first_dt_by_session[skey]:
                first_dt_by_session[skey] = dt
        except Exception:
            continue
    if not first_dt_by_session:
        return None
    conn = ema_db_connect()
    try:
        out = {}
        for skey, first_dt in sorted(first_dt_by_session.items()):
            ident = _fast_ma_bar_identity(code, first_dt, k)
            if ident is None:
                continue
            _td, _bar_index, start_dt = ident
            rows = conn.execute("""
                SELECT close FROM ema_kbars
                WHERE code=? AND k_minutes=? AND start_dt < ?
                ORDER BY start_dt DESC
                LIMIT ?
            """, (code, k, start_dt.strftime("%Y-%m-%d %H:%M:%S"), need)).fetchall()
            closes = [float(r[0]) for r in rows][::-1]
            if len(closes) >= need:
                out[skey] = closes[-need:]
        if out:
            _safe_progress(progress, 1, 1, "EMA暖機快取套用｜%s｜%s｜EMA%d｜%d個交易日" % (code, k_minutes_label(k), p, len(out)))
        return out or None
    finally:
        conn.close()



def resolve_ema_txf_cache_code(code, k_minutes=None):
    """回傳 ema_txf_cache.db 實際有資料的代號。

    TX/TXF 仍互相容錯；股票期貨不可回退到 TXF，避免股期回測誤讀台指K棒。
    """
    preferred = clean_code(code or "TXF")
    candidates = []
    if preferred:
        candidates.append(preferred)
    if is_tai_index_code(preferred):
        for c in ("TXF", "TX"):
            if c not in candidates:
                candidates.append(c)
    init_ema_txf_cache_db()
    conn = ema_db_connect()
    try:
        for c in candidates:
            if not c:
                continue
            if k_minutes is None:
                row = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=?", (c,)).fetchone()
            else:
                row = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=? AND k_minutes=?", (c, normalize_ema_k_minutes(k_minutes))).fetchone()
            if row and int(row[0] or 0) > 0:
                return c
    except Exception:
        pass
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return preferred


def ema_txf_seed_bars_for_ticks(ticks, code, k_minutes, period, progress=None):
    """從 ema_txf_cache.db 取每個回測交易日前的完整 EMA 暖機K棒。

    v052I 修正重點：不能只補收盤價。EMA策略的 Cross/FB/IFB 需要上一根完成K棒的
    open/high/low/close 與該根完成時的 EMA；只補 close 會讓前高/前低變成 close，進場門檻錯誤。
    """
    if not ticks:
        return None
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_ema_period(period)
    preferred = clean_code(code or getattr(ticks[0], "code", "TXF"))
    try:
        ensure_ema_txf_period_cache(preferred, k, p, progress=progress)
    except Exception:
        try:
            rebuild_ema_txf_cache(progress=progress)
            ensure_ema_txf_period_cache(preferred, k, p, progress=progress)
        except Exception:
            return None
    cache_code = resolve_ema_txf_cache_code(preferred, k)
    if cache_code != preferred:
        try:
            ensure_ema_txf_period_cache(cache_code, k, p, progress=progress)
        except Exception:
            pass
    first_dt_by_session = {}
    for t in list(ticks or []):
        try:
            dt = t.dt
            td = _fast_ma_trade_day_for_dt(preferred, dt)
            if td is None:
                continue
            skey = td.strftime("%Y-%m-%d") + (":FULL" if is_tai_index_code(preferred) else ":DAY")
            if skey not in first_dt_by_session or dt < first_dt_by_session[skey]:
                first_dt_by_session[skey] = dt
        except Exception:
            continue
    if not first_dt_by_session:
        return None
    conn = ema_db_connect()
    try:
        out = {}
        # 取足夠多的前置完成K棒，保留 high/low 與已完成EMA。
        # period+10 足以讓第一根 tick 使用上一根EMA；上限200避免 payload 過大。
        need_rows = max(int(p) + 10, 30)
        need_rows = min(max(need_rows, int(p)), 200)
        for skey, first_dt in sorted(first_dt_by_session.items()):
            ident = _fast_ma_bar_identity(preferred, first_dt, k)
            if ident is None:
                continue
            _td, _bar_index, start_dt = ident
            rows = conn.execute("""
                SELECT kb.trade_date, kb.bar_index, kb.start_dt, kb.end_dt,
                       kb.open, kb.high, kb.low, kb.close,
                       COALESCE(ev.ema, 0), COALESCE(ev.ready, 0)
                FROM ema_kbars kb
                LEFT JOIN ema_values ev
                  ON ev.code=kb.code AND ev.k_minutes=kb.k_minutes AND ev.period=?
                 AND ev.trade_date=kb.trade_date AND ev.bar_index=kb.bar_index
                WHERE kb.code=? AND kb.k_minutes=? AND kb.start_dt < ?
                ORDER BY kb.start_dt DESC
                LIMIT ?
            """, (p, cache_code, k, start_dt.strftime("%Y-%m-%d %H:%M:%S"), need_rows)).fetchall()
            if not rows:
                continue
            rows = list(reversed(rows))
            packed = []
            for r in rows:
                try:
                    td, bi, sdt, edt, op, hi, lo, cl, ema, ready = r
                    packed.append({
                        "key": f"EMA-CACHE:{cache_code}:{k}:{td}:{int(bi)}",
                        "trade_date": str(td),
                        "bar_index": int(bi),
                        "start_dt": str(sdt),
                        "end_dt": str(edt),
                        "open": float(op),
                        "high": float(hi),
                        "low": float(lo),
                        "close": float(cl),
                        "avg_close": float(ema or 0.0) if int(ready or 0) else 0.0,
                    })
                except Exception:
                    continue
            # 至少最後一根完成K棒要有 EMA，否則前一根均線仍不足，策略會等待。
            if packed and float(packed[-1].get("avg_close", 0.0) or 0.0) > 0:
                out[skey] = packed
        if out:
            _safe_progress(progress, 1, 1, "EMA完整暖機K棒套用｜%s｜%s｜EMA%d｜%d個交易日" % (cache_code, k_minutes_label(k), p, len(out)))
            return {"__ema_cached_bars__": True, "code": cache_code, "k_minutes": k, "period": p, "sessions": out}
        return None
    finally:
        try:
            conn.close()
        except Exception:
            pass

def ema_txf_cache_status_text():
    p = ema_txf_cache_db_path()
    if not os.path.exists(p):
        return "EMA/SMA快取尚未建立｜" + ema_txf_cache_db_path()
    init_ema_txf_cache_db()
    conn = ema_db_connect()
    try:
        row = conn.execute("SELECT COUNT(*) FROM ema_kbars").fetchone()
        cnt = int(row[0] or 0) if row else 0
        vals = conn.execute("SELECT COUNT(DISTINCT code || ':' || k_minutes || ':' || period) FROM ema_values").fetchone()
        pcnt = int(vals[0] or 0) if vals else 0
        try:
            svals = conn.execute("SELECT COUNT(DISTINCT code || ':' || k_minutes || ':' || period) FROM sma_values").fetchone()
            spcnt = int(svals[0] or 0) if svals else 0
        except Exception:
            spcnt = 0
        return "EMA/SMA快取 %s｜K棒%s根｜EMA參數%d組｜SMA參數%d組" % (os.path.basename(p), f"{cnt:,}", pcnt, spcnt)
    except Exception:
        return "EMA/SMA快取狀態讀取失敗"
    finally:
        conn.close()


def cache_db_file_exists():
    """輕量檢查 ticks_cache.db 是否存在；啟動時避免立刻開 SQLite/建索引造成卡頓。"""
    try:
        path = ticks_cache_db_path()
        return bool(os.path.exists(path) and os.path.getsize(path) > 0)
    except Exception:
        return False


def cache_has_any_ticks():
    init_tick_cache_db()
    conn = db_connect()
    try:
        row = conn.execute("SELECT COUNT(1) FROM ticks LIMIT 1").fetchone()
        return bool(row and int(row[0] or 0) > 0)
    finally:
        conn.close()


def cache_has_code(code):
    init_tick_cache_db()
    conn = db_connect()
    try:
        row = conn.execute("SELECT COUNT(1) FROM ticks WHERE code=? LIMIT 1", (clean_code(code),)).fetchone()
        return bool(row and int(row[0] or 0) > 0)
    finally:
        conn.close()


def _quick_source_key(info):
    path = os.path.abspath(str(info.get("path") or ""))
    member = str(info.get("member") or "")
    return "%s::%s" % (path, member) if member else path


def _open_info_text_stream(info):
    if info.get("is_zip"):
        zf = zipfile.ZipFile(info["path"], "r")
        f = _zip_text_stream(zf, info["member"])
        # 讓呼叫端 close 文字流時，也關閉 zipfile。
        old_close = f.close
        def _close():
            try:
                old_close()
            finally:
                try:
                    zf.close()
                except Exception:
                    pass
        f.close = _close
        return f
    return open_csv_rows(info["path"])


def _source_fingerprint(info):
    path = str(info.get("path") or "")
    member = str(info.get("member") or "")
    size = int(info.get("size") or 0)
    mtime = float(info.get("mtime") or 0.0)
    crc = str(info.get("crc") or "")
    # SHA256 只在檔案不大或 ZIP member 需要穩定識別時算；已匯入過且大小/mtime/CRC一樣會先略過。
    h = hashlib.sha256()
    try:
        if info.get("is_zip"):
            with zipfile.ZipFile(path, "r") as zf, zf.open(member, "r") as bf:
                for chunk in iter(lambda: bf.read(1024 * 1024), b""):
                    h.update(chunk)
        else:
            with open(path, "rb") as bf:
                for chunk in iter(lambda: bf.read(1024 * 1024), b""):
                    h.update(chunk)
        sha = h.hexdigest()
    except Exception:
        sha = ""
    return size, mtime, crc, sha


def _date_from_text(x):
    if isinstance(x, date) and not isinstance(x, RealDateTime):
        return x
    s = str(x or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y%m%d"):
        try:
            return RealDateTime.strptime(s, fmt).date()
        except Exception:
            pass
    return None


def _date_text(d):
    if isinstance(d, date):
        return d.strftime("%Y-%m-%d")
    return str(d or "")


def import_sources_to_cache(paths, progress=None):
    """把官方 Daily ZIP/CSV 增量匯入 SQLite。已匯入且未變更的來源會略過；同路徑內容變更則先刪後重匯。"""
    init_tick_cache_db()
    infos = daily_source_infos(paths)
    if not infos:
        raise ValueError("沒有可匯入的官方 Daily CSV/ZIP。")
    total_units = sum(max(1, int(i.get("size", 1))) for i in infos) or 1
    done_units = 0
    imported = skipped = replaced = inserted_total = 0
    source_total = len(infos)
    conn = db_connect()
    try:
        for idx, info in enumerate(infos, start=1):
            source_key = _quick_source_key(info)
            size0 = int(info.get("size") or 0)
            mtime0 = float(info.get("mtime") or 0.0)
            crc0 = str(info.get("crc") or "")
            row = conn.execute("SELECT id, size, mtime, crc, sha256, parser_version FROM source_files WHERE source_key=?", (source_key,)).fetchone()
            if (row and int(row[1] or 0) == size0 and abs(float(row[2] or 0.0) - mtime0) < 0.0001
                    and str(row[3] or "") == crc0 and int(row[5] or 0) == TICK_CACHE_PARSER_VERSION):
                skipped += 1
                done_units += max(1, size0)
                _safe_progress(progress, done_units, total_units, "第 %d/%d 檔已匯入，略過｜%s" % (idx, source_total, info.get("display", "")))
                continue
            # 內容可能變更：算 SHA 後再確認；若不同或缺舊 SHA，就覆蓋該來源。
            size, mtime, crc, sha = _source_fingerprint(info)
            row = conn.execute("SELECT id, sha256, parser_version FROM source_files WHERE source_key=?", (source_key,)).fetchone()
            if row and sha and str(row[1] or "") == sha and int(row[2] or 0) == TICK_CACHE_PARSER_VERSION:
                # SHA 一樣但 mtime 不同，更新 metadata 後略過。
                conn.execute("UPDATE source_files SET size=?, mtime=?, crc=?, sha256=?, parser_version=? WHERE id=?", (size, mtime, crc, sha, TICK_CACHE_PARSER_VERSION, int(row[0])))
                conn.commit()
                skipped += 1
                done_units += max(1, size0)
                _safe_progress(progress, done_units, total_units, "第 %d/%d 檔內容相同，略過｜%s" % (idx, source_total, info.get("display", "")))
                continue
            if row:
                sid_old = int(row[0])
                conn.execute("DELETE FROM ticks WHERE source_file_id=?", (sid_old,))
                conn.execute("DELETE FROM primary_months WHERE source_file_id=?", (sid_old,))
                conn.execute("DELETE FROM source_files WHERE id=?", (sid_old,))
                conn.commit()
                replaced += 1
            cur = conn.execute(
                "INSERT INTO source_files(source_key,path,member,display,size,mtime,crc,sha256,parser_version,imported_at,rows_total,rows_inserted) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (source_key, os.path.abspath(str(info.get("path") or "")), str(info.get("member") or ""), str(info.get("display") or ""), size, mtime, crc, sha,
                 TICK_CACHE_PARSER_VERSION, RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"), 0, 0)
            )
            sid = int(cur.lastrowid)
            f = _open_info_text_stream(info)
            month_rows = {}
            month_qty = {}
            tick_rows = []
            total_rows = 0
            inserted_rows = 0
            approx = 0
            try:
                reader = csv.reader(f)
                try:
                    headers = next(reader)
                except StopIteration:
                    headers = []
                if headers:
                    m = map_official_headers(headers)
                    approx += _row_approx_bytes(headers)
                    batch = []
                    for raw_row in reader:
                        total_rows += 1
                        approx += _row_approx_bytes(raw_row)
                        if not raw_row:
                            continue
                        try:
                            code = clean_code(raw_row[m["product_code"]])
                            month = clean_month(raw_row[m["month"]])
                            if not code or not month:
                                continue
                            dt = parse_official_dt(raw_row[m["trade_date"]], raw_row[m["trade_time"]], code)
                            price = to_float(raw_row[m["price"]], 0.0)
                            qty = to_float(raw_row[m["qty"]], 0.0)
                            if price <= 0 or qty <= 0:
                                continue
                        except Exception:
                            continue
                        month_rows[(code, month)] = month_rows.get((code, month), 0) + 1
                        month_qty[(code, month)] = month_qty.get((code, month), 0.0) + qty
                        cache_d = official_session_date_for_cache(code, dt) or dt.date()
                        batch.append((sid, code, month, dt.strftime("%Y-%m-%d %H:%M:%S"), cache_d.strftime("%Y-%m-%d"), price, qty))
                        if len(batch) >= 5000:
                            conn.executemany("INSERT INTO ticks(source_file_id,code,month,dt,trade_date,price,qty) VALUES(?,?,?,?,?,?,?)", batch)
                            inserted_rows += len(batch)
                            batch.clear()
                            cur_units = done_units + min(max(1, size0), max(1, approx))
                            _safe_progress(progress, cur_units, total_units, "第 %d/%d 檔匯入中｜%s｜%s 筆" % (idx, source_total, info.get("display", ""), f"{inserted_rows:,}"))
                    if batch:
                        conn.executemany("INSERT INTO ticks(source_file_id,code,month,dt,trade_date,price,qty) VALUES(?,?,?,?,?,?,?)", batch)
                        inserted_rows += len(batch)
            finally:
                try:
                    f.close()
                except Exception:
                    pass
            codes = sorted(set(c for c, _m in month_rows.keys()))
            pm_rows = []
            for code in codes:
                normal = [(month_qty.get((code, mo), 0.0), month_rows.get((code, mo), 0), mo) for c, mo in month_rows if c == code and month_is_normal(mo)]
                fallback = [(month_qty.get((code, mo), 0.0), month_rows.get((code, mo), 0), mo) for c, mo in month_rows if c == code]
                cand = normal or fallback
                cand.sort(reverse=True)
                if cand:
                    qty_sum, rows_count, primary = cand[0]
                    pm_rows.append((sid, code, primary, int(rows_count or 0), float(qty_sum or 0.0)))
            if pm_rows:
                conn.executemany("INSERT OR REPLACE INTO primary_months(source_file_id,code,primary_month,rows_count,qty_sum) VALUES(?,?,?,?,?)", pm_rows)
            conn.execute("UPDATE source_files SET rows_total=?, rows_inserted=? WHERE id=?", (total_rows, inserted_rows, sid))
            conn.commit()
            imported += 1
            inserted_total += inserted_rows
            done_units += max(1, size0)
            _safe_progress(progress, done_units, total_units, "第 %d/%d 檔完成｜新增 %s 筆｜%s" % (idx, source_total, f"{inserted_rows:,}", info.get("display", "")))
        _safe_progress(progress, total_units, total_units, "匯入完成｜新增%d｜略過%d｜覆蓋%d｜新增tick %s" % (imported, skipped, replaced, f"{inserted_total:,}"))
        return {"imported": imported, "skipped": skipped, "replaced": replaced, "inserted": inserted_total}
    finally:
        conn.close()


def scan_products_from_cache(progress=None):
    init_tick_cache_db()
    conn = db_connect()
    try:
        # 只用每個來源檔該商品的自動主力月份，避免價差或遠月干擾統計。
        global_dates = [r[0] for r in conn.execute("""
            SELECT DISTINCT t.trade_date
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            ORDER BY t.trade_date
        """).fetchall()]
        rows = conn.execute("""
            SELECT t.code, COUNT(*), SUM(t.qty), MIN(t.dt), MAX(t.dt), COUNT(DISTINCT t.trade_date)
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            GROUP BY t.code
            ORDER BY t.code
        """).fetchall()
        options = []
        for i, (code, cnt, qty_sum, first_dt, last_dt, data_days) in enumerate(rows, start=1):
            _safe_progress(progress, i, max(1, len(rows)), "讀取快取商品 %d/%d" % (i, len(rows)))
            code = clean_code(code)
            dates = [r[0] for r in conn.execute("""
                SELECT DISTINCT t.trade_date
                FROM ticks t JOIN primary_months pm
                  ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
                WHERE t.code=?
                ORDER BY t.trade_date
            """, (code,)).fetchall()]
            dstart = _date_from_text(dates[0]) if dates else None
            dend = _date_from_text(dates[-1]) if dates else None
            # 缺少日期以「官方 Daily 已匯入的交易日期」為準，不用自然日補滿；
            # 同時排除週六日，避免把沒有下載項目的例假日誤判為缺資料。
            expected = []
            for d in global_dates:
                dd = _date_from_text(d)
                if not (dstart and dend and dd and dstart <= dd <= dend):
                    continue
                if dd.weekday() >= 5:
                    continue
                expected.append(d)
            have = set(_date_from_text(x) for x in dates if _date_from_text(x))
            missing_dates, ignored_missing = _missing_dates_excluding_ignored(expected, have)
            missing = [_date_text(d) for d in missing_dates]
            mon_rows = conn.execute("""
                SELECT t.month, COUNT(*), SUM(t.qty)
                FROM ticks t JOIN primary_months pm
                  ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
                WHERE t.code=?
                GROUP BY t.month
                ORDER BY SUM(t.qty) DESC, COUNT(*) DESC
                LIMIT 4
            """, (code,)).fetchall()
            months_sorted = [r[0] for r in mon_rows]
            primary = months_sorted[0] if months_sorted else ""
            month_text = ",".join(months_sorted)
            last_price_row = conn.execute("""
                SELECT t.price
                FROM ticks t JOIN primary_months pm
                  ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
                WHERE t.code=? ORDER BY t.dt DESC LIMIT 1
            """, (code,)).fetchone()
            last_price = float(last_price_row[0]) if last_price_row else 0.0
            first_obj = RealDateTime.fromisoformat(first_dt) if first_dt else None
            last_obj = RealDateTime.fromisoformat(last_dt) if last_dt else None
            avg_qty = float(qty_sum or 0.0) / max(1, int(data_days or 0))
            display = "%s｜快取｜%s天｜均量%s｜%s筆｜月份%s" % (code, int(data_days or 0), f"{avg_qty:,.0f}", f"{int(cnt or 0):,}", month_text)
            options.append(ProductOption(
                code=code, display=display, total_rows=int(cnt or 0), total_qty=float(qty_sum or 0.0),
                primary_month=primary, months=month_text, first_dt=first_obj, last_dt=last_obj,
                data_days=int(data_days or 0), date_start=dstart, date_end=dend,
                missing_dates="、".join(missing), avg_daily_qty=avg_qty, last_price=last_price,
            ))
        _safe_progress(progress, 1, 1, "快取商品讀取完成｜%d 個" % len(options))
        return options
    finally:
        conn.close()


def read_cached_ticks(code, strategy_name, start_date=None, end_date=None, progress=None, session_mode="全部"):
    init_tick_cache_db()
    code = clean_code(code)
    if is_fast_ma_strategy(strategy_name) and is_tai_index_code(code):
        repair_tai_tick_cache_datetime_if_needed(progress=progress)
    d1 = _date_text(start_date) if start_date else ""
    d2 = _date_text(end_date) if end_date else ""
    where = ["t.code=?"]
    args = [code]
    mode = normalize_tai_session_mode(session_mode)
    ema_full_mode = bool(is_fast_ma_strategy(strategy_name) and is_tai_index_code(code) and mode == "全部")
    date_expr = _ema_full_trade_date_sql_expr() if ema_full_mode else "t.trade_date"
    if d1:
        where.append(date_expr + ">=?")
        args.append(d1)
    if d2:
        where.append(date_expr + "<=?")
        args.append(d2)
    if is_tai_index_code(code) and mode != "全部":
        hhmm_expr = "substr(t.dt, 12, 5)"
        if mode == "日盤":
            where.append("%s >= '08:45' AND %s < '13:45'" % (hhmm_expr, hhmm_expr))
        elif mode == "夜盤":
            where.append("(%s >= '15:00' OR %s < '05:00')" % (hhmm_expr, hhmm_expr))
        elif mode == "九點盤":
            where.append("(%s >= '21:00' OR %s < '05:00')" % (hhmm_expr, hhmm_expr))
    sql = """
        SELECT t.dt, t.trade_date, t.price, t.qty, t.code, t.month
        FROM ticks t JOIN primary_months pm
          ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
        WHERE %s
        ORDER BY t.dt
    """ % (" AND ".join(where))
    conn = db_connect()
    try:
        rows = conn.execute(sql, args).fetchall()
    finally:
        conn.close()
    total = len(rows) or 1
    raw_rows = []
    for i, (dt_text, _trade_date, price, qty, row_code, month) in enumerate(rows, start=1):
        try:
            dt = RealDateTime.fromisoformat(dt_text)
        except Exception:
            continue
        if is_tai_index_code(code) and mode == "九點盤":
            skey, slabel, in_session, _force_dt = tai_nine_session_for_dt(dt)
        else:
            skey, slabel, in_session, _force_dt = session_for(strategy_name, dt)
        if not in_session:
            continue
        if strategy_kind(strategy_name) == "TAI" and not session_allowed_by_mode(skey, session_mode):
            continue
        raw_rows.append((dt, float(price), float(qty), row_code, month, skey, slabel))
        if i % 20000 == 0:
            _safe_progress(progress, i, total, "從快取讀取 %s｜%s/%s" % (code, f"{i:,}", f"{total:,}"))
    ticks = []
    accum_amt = {}
    accum_qty = {}
    for dt, price, qty, row_code, month, skey, slabel in raw_rows:
        accum_amt[skey] = accum_amt.get(skey, 0.0) + price * qty
        accum_qty[skey] = accum_qty.get(skey, 0.0) + qty
        avg = accum_amt[skey] / accum_qty[skey] if accum_qty[skey] > 0 else price
        ticks.append(OfficialTick(dt, dt.date(), price, qty, avg, row_code, month, skey, slabel))
    _safe_progress(progress, total, total, "快取讀取完成｜%s %s 筆" % (code, f"{len(ticks):,}"))
    return ticks


def count_cached_ticks_for_code(code, start_date=None, end_date=None, session_mode="全部"):
    """估算指定商品與日期區間的主力月份逐筆數，用於群組回測預估時間。"""
    init_tick_cache_db()
    code = clean_code(code)
    if not code:
        return 0
    d1 = _date_text(start_date) if start_date else ""
    d2 = _date_text(end_date) if end_date else ""
    where = ["t.code=?"]
    args = [code]
    mode = normalize_tai_session_mode(session_mode)
    date_expr = _ema_full_trade_date_sql_expr() if (is_tai_index_code(code) and mode == "全部") else "t.trade_date"
    if d1:
        where.append(date_expr + ">=?")
        args.append(d1)
    if d2:
        where.append(date_expr + "<=?")
        args.append(d2)
    if is_tai_index_code(code) and mode != "全部":
        hhmm_expr = "substr(t.dt, 12, 5)"
        if mode == "日盤":
            where.append("%s >= '08:45' AND %s < '13:45'" % (hhmm_expr, hhmm_expr))
        elif mode == "夜盤":
            where.append("(%s >= '15:00' OR %s < '05:00')" % (hhmm_expr, hhmm_expr))
        elif mode == "九點盤":
            where.append("(%s >= '21:00' OR %s < '05:00')" % (hhmm_expr, hhmm_expr))
    sql = """
        SELECT COUNT(*)
        FROM ticks t JOIN primary_months pm
          ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
        WHERE %s
    """ % (" AND ".join(where))
    conn = db_connect()
    try:
        row = conn.execute(sql, args).fetchone()
        return int(row[0] or 0) if row else 0
    finally:
        conn.close()


def cached_trade_dates_for_code(code, start_date=None, end_date=None, session_mode="全部"):
    """回傳指定商品在快取主力月份中實際有逐筆資料的交易日。

    台指期：日盤/夜盤可分開；全部模式依日夜盤合併後的期貨交易日顯示。
    """
    init_tick_cache_db()
    code = clean_code(code)
    if not code:
        return []
    d1 = _date_text(start_date) if start_date else ""
    d2 = _date_text(end_date) if end_date else ""
    where = ["t.code=?"]
    args = [code]
    mode = normalize_tai_session_mode(session_mode)
    date_expr = _ema_full_trade_date_sql_expr() if (is_tai_index_code(code) and mode == "全部") else "t.trade_date"
    if d1:
        where.append(date_expr + ">=?")
        args.append(d1)
    if d2:
        where.append(date_expr + "<=?")
        args.append(d2)
    if is_tai_index_code(code) and mode != "全部":
        hhmm_expr = "substr(t.dt, 12, 5)"
        if mode == "日盤":
            where.append("%s >= '08:45' AND %s < '13:45'" % (hhmm_expr, hhmm_expr))
        elif mode == "夜盤":
            where.append("(%s >= '15:00' OR %s < '05:00')" % (hhmm_expr, hhmm_expr))
        elif mode == "九點盤":
            where.append("(%s >= '21:00' OR %s < '05:00')" % (hhmm_expr, hhmm_expr))
    sql = """
        SELECT DISTINCT %s AS trade_day
        FROM ticks t JOIN primary_months pm
          ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
        WHERE %s
        ORDER BY trade_day
    """ % (date_expr, " AND ".join(where))
    conn = db_connect()
    try:
        rows = conn.execute(sql, args).fetchall()
    finally:
        conn.close()
    out = []
    seen = set()
    for r in rows:
        d = _date_from_text(r[0])
        if d and d not in seen:
            seen.add(d)
            out.append(d)
    return out

def safe_int_text(x):
    try:
        return f"{int(round(float(x or 0))):,}"
    except Exception:
        return "0"

def extract_text_from_html(raw):
    raw = re.sub(r"<script.*?</script>", " ", raw, flags=re.I | re.S)
    raw = re.sub(r"<style.*?</style>", " ", raw, flags=re.I | re.S)
    raw = re.sub(r"<[^>]+>", " ", raw)
    raw = html.unescape(raw)
    raw = re.sub(r"\s+", " ", raw)
    return raw.strip()

def parse_taifex_stock_margin_html(raw):
    text = extract_text_from_html(raw)
    mdate = re.search(r"標的證券為股票之股票期貨契約.*?更新日期[:：]\s*(\d{4}/\d{2}/\d{2})", text)
    source_date = mdate.group(1) if mdate else ""
    start = text.find("標的證券為股票之股票期貨契約")
    end = text.find("標的證券為受益憑證之股票期貨契約", start + 1 if start >= 0 else 0)
    section = text[start:end] if start >= 0 and end > start else text
    pattern = re.compile(
        r"(\d+)\s+([A-Z]{2,4}F)\s+([0-9A-Z]{4,6})\s+(.{1,30}?期貨)\s+(.{1,80}?)\s+(?:級距([123])\s+)?([0-9.]+)%\s+([0-9.]+)%\s+([0-9.]+)%"
    )
    items = {}
    for m in pattern.finditer(section):
        code = m.group(2).strip().upper()
        stock_no = m.group(3).strip()
        short_name = m.group(4).strip()
        stock_name = m.group(5).strip()
        items[code] = {
            "code": code,
            "stock_no": stock_no,
            "short_name": short_name,
            "stock_name": stock_name,
            "is_small": short_name.startswith("小型") or "小型" in short_name,
            "tier": ("級距" + m.group(6)) if m.group(6) else "",
            "clearing_margin_percent": float(m.group(7)),
            "maintenance_margin_percent": float(m.group(8)),
            "initial_margin_percent": float(m.group(9)),
            "is_excluded_underlying": stock_no in EXCLUDE_UNDERLYING_STOCKS,
        }
    if not items:
        raise RuntimeError("無法從期交所網頁解析股票期貨保證金資料。")
    return {
        "source_url": TAIFEX_STOCK_MARGIN_URL,
        "source_date": source_date,
        "updated_at": RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "items": items,
    }

def download_taifex_stock_margin_master(timeout=20):
    req = urllib.request.Request(TAIFEX_STOCK_MARGIN_URL, headers={
        "User-Agent": "Mozilla/5.0 TrainBacktester/013",
        "Accept-Language": "zh-TW,zh;q=0.9,en;q=0.5",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    for enc in ("utf-8", "utf-8-sig", "cp950", "big5"):
        try:
            raw = data.decode(enc)
            break
        except Exception:
            raw = data.decode("utf-8", errors="ignore")
    master = parse_taifex_stock_margin_html(raw)
    with open(margin_master_path(), "w", encoding="utf-8") as f:
        json.dump(master, f, ensure_ascii=False, indent=2)
    return master

def load_cached_margin_master():
    p = margin_master_path()
    if not os.path.exists(p):
        return {"items": {}}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "items" not in data:
            return {"items": {}}
        return data
    except Exception:
        return {"items": {}}

def product_multiplier_from_master_item(item, strategy_name=""):
    if item and bool(item.get("is_small")):
        return 100
    if "小股" in str(strategy_name):
        return 100
    return 2000

def margin_base_from_price(price, percent, multiplier=2000):
    # 依契約乘數估算原始保證金：大股期乘數 2000，小股期乘數 100。
    # 舊版固定用 2000，會讓同一標的的大股期/小股期顯示幾乎相同保證金。
    try:
        value = float(price or 0) * float(multiplier or 2000) * float(percent or 0) / 100.0
    except Exception:
        value = 0.0
    if value <= 0:
        return 0.0
    return float(math.ceil(value / 1000.0) * 1000.0)


def open_csv_rows(path):
    last_err = None
    for enc in ("utf-8-sig", "cp950", "big5", "utf-8"):
        try:
            f = open(path, "r", encoding=enc, newline="")
            # 先嘗試讀一小段，確認編碼可用。
            f.read(4096)
            f.seek(0)
            return f
        except Exception as e:
            last_err = e
            try:
                f.close()
            except Exception:
                pass
    raise RuntimeError("無法讀取 CSV 編碼：%s" % last_err)


def _zip_text_stream(zf, member_name):
    last_err = None
    for enc in ("utf-8-sig", "cp950", "big5", "utf-8"):
        try:
            bf = zf.open(member_name, "r")
            tf = io.TextIOWrapper(bf, encoding=enc, newline="")
            tf.read(4096)
            tf.close()
            bf = zf.open(member_name, "r")
            return io.TextIOWrapper(bf, encoding=enc, newline="")
        except Exception as e:
            last_err = e
            try:
                tf.close()
            except Exception:
                pass
            try:
                bf.close()
            except Exception:
                pass
    raise RuntimeError("ZIP 內檔案無法讀取編碼：%s｜%s" % (member_name, last_err))


def daily_source_infos(paths):
    """列出可讀取的官方 Daily 文字來源；ZIP 內檔案以未壓縮大小估算進度。"""
    infos = []
    for path in paths:
        path = str(path)
        ext = os.path.splitext(path)[1].lower()
        try:
            outer_mtime = os.path.getmtime(path)
        except Exception:
            outer_mtime = 0.0
        if ext == ".zip":
            with zipfile.ZipFile(path, "r") as zf:
                members = [i for i in zf.infolist() if (not i.is_dir()) and os.path.splitext(i.filename)[1].lower() in TEXT_EXTS]
                members.sort(key=lambda i: i.filename)
                for info in members:
                    infos.append({
                        "path": path,
                        "member": info.filename,
                        "source_id": "%s::%s" % (path, info.filename),
                        "display": "%s/%s" % (os.path.basename(path), info.filename),
                        "size": max(1, int(info.file_size or 0)),
                        "mtime": outer_mtime,
                        "crc": str(info.CRC),
                        "is_zip": True,
                    })
        elif ext in TEXT_EXTS or not ext:
            try:
                size = os.path.getsize(path)
            except Exception:
                size = 1
            infos.append({
                "path": path,
                "member": "",
                "source_id": path,
                "display": os.path.basename(path),
                "size": max(1, int(size or 0)),
                "mtime": outer_mtime,
                "crc": "",
                "is_zip": False,
            })
    return infos


def iter_daily_sources(paths, with_size=False):
    """逐一開啟使用者選擇的 CSV/RPT/TXT 或 ZIP 內的每日檔。

    預設產生 (source_id, display_name, text_file)。with_size=True 時多回傳 source_size。
    source_id 會用於每個檔案、每個商品的主力月份判斷；ZIP 內多個檔案也可獨立判斷。
    """
    for info in daily_source_infos(paths):
        if info["is_zip"]:
            with zipfile.ZipFile(info["path"], "r") as zf:
                f = _zip_text_stream(zf, info["member"])
                try:
                    if with_size:
                        yield info["source_id"], info["display"], f, info["size"]
                    else:
                        yield info["source_id"], info["display"], f
                finally:
                    try:
                        f.close()
                    except Exception:
                        pass
        else:
            f = open_csv_rows(info["path"])
            try:
                if with_size:
                    yield info["source_id"], info["display"], f, info["size"]
                else:
                    yield info["source_id"], info["display"], f
            finally:
                try:
                    f.close()
                except Exception:
                    pass


def _row_approx_bytes(row):
    try:
        return sum(len(str(x)) for x in row) + len(row) + 2
    except Exception:
        return 80


def _safe_progress(progress, current, total, detail=""):
    if progress is None:
        return
    try:
        progress(max(0, float(current or 0)), max(1, float(total or 1)), str(detail or ""))
    except Exception:
        pass


def map_official_headers(headers):
    normalized = [norm_header(h) for h in headers]
    result = {}
    for key, aliases in HEADER_ALIASES.items():
        alias_norm = [norm_header(a) for a in aliases]
        for idx, h in enumerate(normalized):
            if h in alias_norm:
                result[key] = idx
                break
    missing = [k for k in ("trade_date", "product_code", "month", "trade_time", "price", "qty") if k not in result]
    if missing:
        raise ValueError("不是可辨識的官方 Daily CSV，缺少欄位：%s\n讀到表頭：%s" % (", ".join(missing), headers))
    return result


def to_float(x, default=0.0):
    try:
        return float(str(x).replace(",", "").strip())
    except Exception:
        return default


def clean_code(x):
    return str(x or "").strip().upper()


def clean_month(x):
    return str(x or "").strip()


def month_is_normal(month):
    """單一契約月份，例如 202606。官方檔也可能有 202606/202607 價差商品，回測期貨本身時不列入主力月份。"""
    s = clean_month(month)
    return s.isdigit() and len(s) >= 6 and "/" not in s


def parse_official_dt(dv, tv, product_code=""):
    ds = "".join(ch for ch in str(dv or "").strip() if ch.isdigit())
    if len(ds) < 8:
        raise ValueError("成交日期格式錯誤：%s" % dv)
    base_date = RealDateTime.strptime(ds[:8], "%Y%m%d").date()
    ts = "".join(ch for ch in str(tv or "").strip() if ch.isdigit())
    # 官方常見為 HMMSS / HHMMSS；不足 6 碼補前導 0。
    ts = ts[-6:].zfill(6)
    hh, mm, ss = int(ts[:2]), int(ts[2:4]), int(ts[4:6])
    # v052J：官方逐筆檔的「成交日期」在本回測器一律視為自然日期。
    # EMA 台指全盤定義為：同一自然日 08:45 日盤開盤起算，15:00 夜盤接續，
    # 隔日 00:00~04:59 歸屬前一自然日夜盤。
    # 舊版曾把 15:00 後扣一天，會把 06/16 22:19 錯標成 06/15 22:19，
    # 導致進場價落在 XQ 同根K棒高低範圍之外。
    return RealDateTime.combine(base_date, time(hh, mm, ss))


def strategy_kind(strategy_name):
    text = str(strategy_name or "")
    if is_param_strategy(text):
        if "台指" in text:
            return "TAI"
        if "小股" in text or "小型" in text:
            return "SMALL"
        return "BIG"
    if "台指" in text:
        return "TAI"
    if "小股" in text:
        return "SMALL"
    return "BIG"


def default_multiplier(strategy_name, product_code=""):
    k = strategy_kind(strategy_name)
    code = str(product_code or "").strip().upper()
    if code == "TXF" or code.startswith("TXF") or code == "TX":
        return 200
    if code == "MXF" or code.startswith("MXF"):
        return 50
    if code == "TMF" or code.startswith("TMF"):
        return 10
    if k == "SMALL":
        return 100
    if k == "BIG":
        return 2000
    return 200


def session_for(strategy_name, dt: RealDateTime):
    """回傳 session_key, session_label, in_session, force_dt。"""
    k = strategy_kind(strategy_name)
    hhmm = dt.hour * 100 + dt.minute
    if k == "TAI":
        if 845 <= hhmm < 1345:
            d = dt.date()
            return dt.strftime("%Y-%m-%d") + ":DAY", dt.strftime("%Y-%m-%d 日盤"), True, RealDateTime.combine(d, time(13, 43, 0))
        if hhmm >= 1500:
            d = dt.date()
            return dt.strftime("%Y-%m-%d") + ":NIGHT", dt.strftime("%Y-%m-%d 夜盤"), True, RealDateTime.combine(d + timedelta(days=1), time(4, 58, 0))
        if hhmm < 500:
            d = dt.date() - timedelta(days=1)
            return d.strftime("%Y-%m-%d") + ":NIGHT", d.strftime("%Y-%m-%d 夜盤"), True, RealDateTime.combine(dt.date(), time(4, 58, 0))
        return "", "非交易時段", False, None
    # 股期只跑日盤；EMA策略不做時間到強制平倉。
    if 845 <= hhmm < 1345:
        d = dt.date()
        force_dt = None if is_fast_ma_strategy(strategy_name) else RealDateTime.combine(d, time(13, 43, 0))
        return dt.strftime("%Y-%m-%d") + ":DAY", dt.strftime("%Y-%m-%d 日盤"), True, force_dt
    return "", "非交易時段", False, None


def scan_products(paths, progress=None):
    """掃描官方 Daily CSV，回傳商品代號清單；月份只作自動主力判斷，不需使用者輸入。"""
    code_rows = {}
    code_qty = {}
    code_month_rows = {}
    code_month_qty = {}
    code_first = {}
    code_last = {}
    code_last_price = {}
    code_dates = {}
    code_daily_qty = {}
    source_trading_dates = set()
    primary_month_by_file_code = {}

    sources = daily_source_infos(paths)
    total_bytes = sum(max(1, int(i.get("size", 1))) for i in sources) or 1
    done_bytes = 0
    source_count = len(sources) or 1
    _safe_progress(progress, 0, total_bytes, "準備掃描")

    for source_index, (source_id, _display_name, f, source_size) in enumerate(iter_daily_sources(paths, with_size=True), start=1):
        month_rows_this_file = {}
        month_qty_this_file = {}
        reader = csv.reader(f)
        try:
            headers = next(reader)
        except StopIteration:
            done_bytes += source_size
            _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔｜空檔案" % (source_index, source_count))
            continue
        m = map_official_headers(headers)
        approx = _row_approx_bytes(headers)
        row_count = 0
        for row in reader:
                row_count += 1
                approx += _row_approx_bytes(row)
                if not row:
                    continue
                try:
                    code = clean_code(row[m["product_code"]])
                    month = clean_month(row[m["month"]])
                    if not code or not month:
                        continue
                    qty = to_float(row[m["qty"]], 0.0)
                    price = to_float(row[m["price"]], 0.0)
                    dt = parse_official_dt(row[m["trade_date"]], row[m["trade_time"]], code)
                    session_d = official_session_date_for_cache(code, dt) or dt.date()
                except Exception:
                    continue
                source_trading_dates.add(session_d)
                code_dates.setdefault(code, set()).add(session_d)
                code_daily_qty[(code, session_d)] = code_daily_qty.get((code, session_d), 0.0) + qty
                if price > 0 and (code not in code_last or dt >= code_last.get(code, dt)):
                    code_last_price[code] = price
                code_rows[code] = code_rows.get(code, 0) + 1
                code_qty[code] = code_qty.get(code, 0.0) + qty
                code_month_rows[(code, month)] = code_month_rows.get((code, month), 0) + 1
                code_month_qty[(code, month)] = code_month_qty.get((code, month), 0.0) + qty
                code_first[code] = min(code_first.get(code, dt), dt)
                code_last[code] = max(code_last.get(code, dt), dt)
                month_rows_this_file[(code, month)] = month_rows_this_file.get((code, month), 0) + 1
                month_qty_this_file[(code, month)] = month_qty_this_file.get((code, month), 0.0) + qty
                if row_count % 10000 == 0:
                    cur = done_bytes + min(float(source_size), float(approx))
                    _safe_progress(progress, cur, total_bytes, "第 %d/%d 檔｜已找到 %d 個商品" % (source_index, source_count, len(code_rows)))
        # 每個來源檔案、每個商品，自動選成交量最大的月份當主力。
        codes_in_file = sorted(set(k[0] for k in month_rows_this_file))
        for code in codes_in_file:
            normal_candidates = [(month_qty_this_file.get((code, month), 0.0), month_rows_this_file.get((code, month), 0), month)
                                 for c, month in month_rows_this_file if c == code and month_is_normal(month)]
            fallback_candidates = [(month_qty_this_file.get((code, month), 0.0), month_rows_this_file.get((code, month), 0), month)
                                   for c, month in month_rows_this_file if c == code]
            candidates = normal_candidates or fallback_candidates
            candidates.sort(reverse=True)
            if candidates:
                primary_month_by_file_code[(source_id, code)] = candidates[0][2]
        done_bytes += source_size
        _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔完成｜已找到 %d 個商品" % (source_index, source_count, len(code_rows)))

    options = []
    for code in sorted(code_rows):
        all_months = [month for c, month in code_month_rows if c == code]
        normal_months = [month for month in all_months if month_is_normal(month)]
        months = normal_months or all_months
        months_sorted = sorted(months, key=lambda mo: (code_month_qty.get((code, mo), 0.0), code_month_rows.get((code, mo), 0)), reverse=True)
        primary = months_sorted[0] if months_sorted else ""
        month_text = ",".join(months_sorted[:4])
        if len(months_sorted) > 4:
            month_text += "..."
        dates = sorted(code_dates.get(code, set()))
        dstart = dates[0] if dates else None
        dend = dates[-1] if dates else None
        # 缺少日期以官方 Daily 檔案實際提供的交易日期為準，排除週六日。
        expected = [d for d in sorted(source_trading_dates) if dstart and dend and dstart <= d <= dend and d.weekday() < 5]
        missing_dates, ignored_missing = _missing_dates_excluding_ignored(expected, set(dates))
        missing = [d.strftime("%Y-%m-%d") for d in missing_dates]
        avg_qty = code_qty.get(code, 0.0) / max(1, len(dates))
        display = "%s｜主力%s｜%s天｜均量%s｜%s筆｜月份%s" % (
            code,
            primary,
            len(dates),
            f"{avg_qty:,.0f}",
            f"{code_rows.get(code, 0):,}",
            month_text,
        )
        options.append(ProductOption(
            code=code,
            display=display,
            total_rows=code_rows.get(code, 0),
            total_qty=code_qty.get(code, 0.0),
            primary_month=primary,
            months=month_text,
            first_dt=code_first.get(code),
            last_dt=code_last.get(code),
            data_days=len(dates),
            date_start=dstart,
            date_end=dend,
            missing_dates="、".join(missing),
            avg_daily_qty=avg_qty,
            last_price=code_last_price.get(code, 0.0),
        ))
    _safe_progress(progress, total_bytes, total_bytes, "掃描完成｜商品 %d 個" % len(options))
    return options, primary_month_by_file_code


def read_official_ticks(paths, code, strategy_name, primary_month_by_file_code, progress=None, session_mode="全部"):
    code = clean_code(code)
    mode = normalize_tai_session_mode(session_mode)
    raw_rows = []
    sources = daily_source_infos(paths)
    total_bytes = sum(max(1, int(i.get("size", 1))) for i in sources) or 1
    done_bytes = 0
    source_count = len(sources) or 1
    _safe_progress(progress, 0, total_bytes, "準備讀取 %s" % code)
    for source_index, (source_id, _display_name, f, source_size) in enumerate(iter_daily_sources(paths, with_size=True), start=1):
        auto_month = primary_month_by_file_code.get((source_id, code), "")
        if not auto_month:
            done_bytes += source_size
            _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔｜無 %s 主力月份" % (source_index, source_count, code))
            continue
        reader = csv.reader(f)
        try:
            headers = next(reader)
        except StopIteration:
            done_bytes += source_size
            _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔｜空檔案" % (source_index, source_count))
            continue
        m = map_official_headers(headers)
        approx = _row_approx_bytes(headers)
        row_count = 0
        for row in reader:
                row_count += 1
                approx += _row_approx_bytes(row)
                if not row:
                    continue
                try:
                    row_code = clean_code(row[m["product_code"]])
                    if row_code != code:
                        if row_count % 20000 == 0:
                            cur = done_bytes + min(float(source_size), float(approx))
                            _safe_progress(progress, cur, total_bytes, "第 %d/%d 檔｜已讀到 %s %s 筆" % (source_index, source_count, code, f"{len(raw_rows):,}"))
                        continue
                    month = clean_month(row[m["month"]])
                    if month != auto_month:
                        continue
                    dt = parse_official_dt(row[m["trade_date"]], row[m["trade_time"]], row_code)
                    if is_tai_index_code(code) and mode == "九點盤":
                        skey, slabel, in_session, _force_dt = tai_nine_session_for_dt(dt)
                    else:
                        skey, slabel, in_session, _force_dt = session_for(strategy_name, dt)
                    if not in_session:
                        continue
                    if strategy_kind(strategy_name) == "TAI" and not session_allowed_by_mode(skey, session_mode):
                        continue
                    price = to_float(row[m["price"]], 0.0)
                    qty = to_float(row[m["qty"]], 0.0)
                    if price <= 0 or qty <= 0:
                        continue
                    raw_rows.append((dt, price, qty, row_code, month, skey, slabel))
                except Exception:
                    continue
                if row_count % 10000 == 0:
                    cur = done_bytes + min(float(source_size), float(approx))
                    _safe_progress(progress, cur, total_bytes, "第 %d/%d 檔｜已讀到 %s %s 筆" % (source_index, source_count, code, f"{len(raw_rows):,}"))
        done_bytes += source_size
        _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔完成｜已讀到 %s %s 筆" % (source_index, source_count, code, f"{len(raw_rows):,}"))
    raw_rows.sort(key=lambda x: x[0])

    ticks = []
    accum_amt = {}
    accum_qty = {}
    for dt, price, qty, row_code, month, skey, slabel in raw_rows:
        accum_amt[skey] = accum_amt.get(skey, 0.0) + price * qty
        accum_qty[skey] = accum_qty.get(skey, 0.0) + qty
        avg = accum_amt[skey] / accum_qty[skey] if accum_qty[skey] > 0 else price
        ticks.append(OfficialTick(dt, dt.date(), price, qty, avg, row_code, month, skey, slabel))
    _safe_progress(progress, total_bytes, total_bytes, "讀取完成｜%s %s 筆" % (code, f"{len(ticks):,}"))
    return ticks


def format_money(x):
    return "%+.0f" % float(x or 0.0)

def format_money_plain(x):
    try:
        return "%.0f" % float(x or 0.0)
    except Exception:
        return "0"

def format_money_signed_negative(x):
    try:
        v = float(x or 0.0)
        return "%.0f" % v
    except Exception:
        return "0"


def parse_dt_text(text):
    if isinstance(text, RealDateTime):
        return text
    s = str(text or "").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%H:%M:%S"):
        try:
            return RealDateTime.strptime(s, fmt)
        except Exception:
            pass
    return None


def side_from_close_direction(direction):
    # 平倉紀錄 direction 是平倉動作：賣=平多，買=平空。
    return "做多" if str(direction) == "賣" else "放空" if str(direction) == "買" else str(direction)


def build_task(strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, one_way_fee=0.0, k_minutes=1, ma_period=3, entry_mode="逐筆洗價"):
    k = strategy_kind(strategy_name)
    code = clean_code(product_code)
    if k == "TAI":
        # 回測資料代號可能是 TX，但策略核心/手續費/乘數要以大台 TXF 計算。
        if code.startswith("MXF"):
            code = "MXF"
        elif code.startswith("TMF"):
            code = "TMF"
        else:
            code = "TXF"
    multiplier = default_multiplier(strategy_name, code)
    qty = max(1, int(lots or 1))
    # v044 修正：strategy_core 的 TP/SL 判斷固定使用「每口商品點數」。
    # 不論台指期、大股期、小股期，這裡都不可先乘商品乘數或口數；
    # 新台幣損益與手續費由策略核心依成交價、乘數與口數另行換算。
    take_profit = abs(float(tp_points or 0.0))
    stop_loss = abs(float(sl_points or 0.0))
    # 053A：回測面板的「認賠下車／賺飽下車」欄位明確標示為新台幣。
    # strategy_core 的累積風控門檻使用商品點數，因此進核心前先依乘數換算；
    # 結果表與參數表仍保留使用者輸入的新台幣數字。
    risk_multiplier = max(float(multiplier or 0), 1.0)
    loss_exit_points = abs(float(loss_exit or 0.0)) / risk_multiplier
    lock_profit_exit_points = abs(float(lock_profit_exit or 0.0)) / risk_multiplier
    return SimpleNamespace(
        id=1,
        account="BACKTEST",
        strategy=strategy_name,
        execution_mode="simulation",
        product_name=code,
        product_symbol=code,
        product_code=code,
        lots=qty,
        take_profit=take_profit,
        stop_loss=stop_loss,
        loss_exit=loss_exit_points,
        lock_profit_exit=lock_profit_exit_points,
        one_way_fee=max(0.0, float(one_way_fee or 0.0)),
        ma_period=(normalize_fast_ma_period(ma_period) if is_fast_ma_strategy(strategy_name) else normalize_ma_period(ma_period)),
        bar_minutes=normalize_k_minutes(k_minutes),
        entry_mode=normalize_entry_mode(entry_mode),
        quote_avg_ready=True,
        quote_avg=0.0,
        last_price=0.0,
        position=0,
        avg_cost=0.0,
        float_pnl=0.0,
        realized_pnl=0.0,
        total_pnl=0.0,
        high_float_pnl=0.0,
        entry_reason="",
        last_signal="",
        signal_source="",
        flat_reason="",
        risk_status="正常",
        lock_profit_armed=False,
        lock_profit_high=0.0,
        order_pending=False,
        _bt_profile=(strategy_core.PROFILES["EMA小股期策略"] if is_ema_strategy(strategy_name) and ("小股" in str(strategy_name) or "小型" in str(strategy_name)) else strategy_core.PROFILES["EMA大股期策略"] if is_ema_strategy(strategy_name) else (_STRATEGY_CORE_PROFILE_ORIG(SimpleNamespace(strategy=strategy_name, product_code=code, product_symbol=code, product_name=code)) if callable(_STRATEGY_CORE_PROFILE_ORIG) else None)),
    )



def _floor_dt_to_k_start(dt, k_minutes):
    k = normalize_k_minutes(k_minutes)
    minute_of_day = dt.hour * 60 + dt.minute
    base_minute = (minute_of_day // k) * k
    return dt.replace(hour=base_minute // 60, minute=base_minute % 60, second=0, microsecond=0)


def _build_3ma_k_bars(rows, k_minutes):
    """把 session 逐筆列聚合成 N 分K；每根K保留 OHLC 與筆數。"""
    k = normalize_k_minutes(k_minutes)
    bars = []
    cur = None
    for row in list(rows or []):
        try:
            dt, price, _avg = row
            price = float(price)
        except Exception:
            continue
        start = _floor_dt_to_k_start(dt, k)
        if cur is None or start != cur["start"]:
            if cur is not None:
                bars.append(cur)
            cur = {
                "start": start,
                "end": dt,
                "open": price,
                "high": price,
                "low": price,
                "close": price,
                "ticks": 1,
            }
        else:
            cur["end"] = dt
            cur["high"] = max(float(cur["high"]), price)
            cur["low"] = min(float(cur["low"]), price)
            cur["close"] = price
            cur["ticks"] = int(cur.get("ticks", 0) or 0) + 1
    if cur is not None:
        bars.append(cur)
    return bars


def _last_k_bar_dict(rows, k_minutes):
    """回傳該時段最後一根 1/5/10 分K，供 MA策略 開盤第一根使用上一時段最後K判斷。"""
    bars = _build_3ma_k_bars(rows, k_minutes)
    if not bars:
        return None
    b = dict(bars[-1])
    try:
        b["key"] = b.get("start").strftime("%Y-%m-%d %H:%M")
    except Exception:
        b["key"] = "PREV"
    return b


def _bar_fill_price(bar, direction, gate_price):
    """K棒回測無法知道精確成交tick；若開盤已跳過gate用開盤，否則用gate。"""
    gate = float(gate_price or 0.0)
    op = float(bar.get("open", gate) or gate)
    hi = float(bar.get("high", op) or op)
    lo = float(bar.get("low", op) or op)
    if direction > 0:
        if op >= gate:
            return op
        if hi >= gate:
            return gate
        return float(bar.get("close", op) or op)
    else:
        if op <= gate:
            return op
        if lo <= gate:
            return gate
        return float(bar.get("close", op) or op)


def _three_ma_bar_path(bar):
    op = float(bar.get("open", 0.0) or 0.0)
    hi = float(bar.get("high", op) or op)
    lo = float(bar.get("low", op) or op)
    cl = float(bar.get("close", op) or op)
    # 上漲K假設先下洗再上攻；下跌K假設先上拉再下殺。只用於停損/保底線同棒判定的近似。
    if cl >= op:
        return [op, lo, hi, cl]
    return [op, hi, lo, cl]


def run_3ma0413_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=1, progress=None):
    """MA策略 回測引擎。

    對應使用者提供的 XQ MA策略：N=3、Cross / FB / IntraFB、ModeSide=0、
    StopLossP=sl_points、FloatProfitTrigger=tp_points；認賠/賺飽不是原策略輸入，故不主動觸發。
    """
    n = 3
    k_minutes = normalize_k_minutes(k_minutes)
    qty = max(1, int(lots or 1))
    multiplier = default_multiplier(strategy_name, product_code)
    stop_loss_p = abs(float(sl_points or 0.0))
    float_trigger = abs(float(tp_points or 0.0))
    all_day_stats = []
    all_closed = []
    all_records = []
    all_events = []
    total_units = sum(len(item[1]) for item in list(session_items or [])) or 1
    done_units = 0
    _safe_progress(progress, 0, total_units, "準備MA策略回測｜%d分K" % k_minutes)

    def trade_net(entry, exit_px, side):
        if side > 0:
            pts = float(exit_px) - float(entry)
        else:
            pts = float(entry) - float(exit_px)
        gross = pts * multiplier * qty
        return gross, gross

    for skey, arr, session_label, month_text, _unique_minutes in list(session_items or []):
        bars = _build_3ma_k_bars(arr, k_minutes)
        done_units += len(arr)
        if not bars:
            continue
        closes = []
        avgs = []
        position = 0
        entry_px = 0.0
        entry_dt = None
        entry_bar_idx = -1
        peak_points = 0.0
        tp_armed = False
        tp_line = 0.0
        realized_total = 0.0
        peak_equity = 0.0
        trough_equity = 0.0
        running_peak = 0.0
        max_dd = 0.0
        session_closed = []

        def update_equity(mark_price):
            nonlocal peak_equity, trough_equity, running_peak, max_dd
            floating = 0.0
            if position != 0 and entry_px > 0:
                if position > 0:
                    floating = (float(mark_price) - entry_px) * multiplier * qty
                else:
                    floating = (entry_px - float(mark_price)) * multiplier * qty
            equity = realized_total + floating
            if equity > peak_equity:
                peak_equity = equity
            if equity < trough_equity:
                trough_equity = equity
            if equity > running_peak:
                running_peak = equity
            dd = equity - running_peak
            if dd < max_dd:
                max_dd = dd

        def reset_position_state():
            nonlocal peak_points, tp_armed, tp_line
            peak_points = 0.0
            tp_armed = False
            tp_line = 0.0

        def close_position(exit_dt, exit_px, event, reason):
            nonlocal position, entry_px, entry_dt, realized_total, entry_bar_idx
            if position == 0 or entry_px <= 0:
                return None
            side = 1 if position > 0 else -1
            gross, net = trade_net(entry_px, exit_px, side)
            realized_total += net
            row = {
                "session": session_label,
                "month": month_text,
                "product_code": clean_code(product_code),
                "entry_time": entry_dt or exit_dt,
                "exit_time": exit_dt,
                "side": "做多" if side > 0 else "放空",
                "entry": float(entry_px),
                "exit": float(exit_px),
                "event": event,
                "reason": reason,
                "gross": float(gross),
                "fee": 0.0,
                "net": float(net),
            }
            session_closed.append(row)
            all_closed.append(row)
            all_records.append(dict(row, closed_trade=True, realized=net, gross_realized=gross, price=float(exit_px)))
            position = 0
            entry_px = 0.0
            entry_dt = None
            entry_bar_idx = -1
            reset_position_state()
            return row

        def open_position(open_dt, open_px, direction, bar_idx):
            nonlocal position, entry_px, entry_dt, entry_bar_idx
            position = qty if direction > 0 else -qty
            entry_px = float(open_px)
            entry_dt = open_dt
            entry_bar_idx = bar_idx
            reset_position_state()

        def update_tp_for_price(price):
            nonlocal peak_points, tp_armed, tp_line
            if position == 0 or entry_px <= 0:
                return
            if position > 0:
                fp = float(price) - entry_px
            else:
                fp = entry_px - float(price)
            if fp > peak_points:
                peak_points = fp
            if (not tp_armed) and peak_points >= float_trigger and float_trigger > 0:
                tp_armed = True
            if tp_armed:
                if peak_points <= 800:
                    lock_pts = math.floor(peak_points * 0.70)
                elif peak_points <= 1200:
                    lock_pts = math.floor(peak_points * 0.80)
                else:
                    lock_pts = math.floor(peak_points * 0.90)
                new_line = entry_px + lock_pts if position > 0 else entry_px - lock_pts
                if tp_line == 0:
                    tp_line = new_line
                elif position > 0 and new_line > tp_line:
                    tp_line = new_line
                elif position < 0 and new_line < tp_line:
                    tp_line = new_line

        def check_exit_by_price(bar, price):
            if position == 0 or entry_px <= 0:
                return False
            update_tp_for_price(price)
            update_equity(price)
            exit_dt = bar.get("end") or bar.get("start")
            if position > 0:
                if tp_armed and tp_line > 0 and float(price) <= tp_line:
                    close_position(exit_dt, tp_line, "停利平倉", "停利平倉")
                    update_equity(tp_line)
                    return True
                if stop_loss_p > 0 and float(price) <= entry_px - stop_loss_p:
                    close_position(exit_dt, entry_px - stop_loss_p, "停損平倉", "停損平倉")
                    update_equity(entry_px - stop_loss_p)
                    return True
            else:
                if tp_armed and tp_line > 0 and float(price) >= tp_line:
                    close_position(exit_dt, tp_line, "停利平倉", "停利平倉")
                    update_equity(tp_line)
                    return True
                if stop_loss_p > 0 and float(price) >= entry_px + stop_loss_p:
                    close_position(exit_dt, entry_px + stop_loss_p, "停損平倉", "停損平倉")
                    update_equity(entry_px + stop_loss_p)
                    return True
            return False

        for i, bar in enumerate(bars):
            cl = float(bar["close"])
            # 先建立本根K的即時均線：目前Close + 前N-1根已完成K Close。
            if len(closes) >= n - 1:
                avg_now = (sum(closes[-(n - 1):]) + cl) / float(n)
            else:
                avg_now = None

            # MA策略 啟動保護近似：至少等到第3根K且均線有資料，才接受 fresh signal。
            if avg_now is not None and i >= max(2, n - 1) and avgs:
                prev_close = closes[-1]
                prev_avg = avgs[-1]
                prev_bar = bars[i - 1]
                arms = []
                arm_seq = 0
                # Cross ↑ / ↓
                if prev_close < prev_avg and cl > avg_now:
                    arm_seq += 1
                    arms.append((arm_seq, 1, 1, float(prev_bar["high"]), "Cross"))
                if prev_close > prev_avg and cl < avg_now:
                    arm_seq += 1
                    arms.append((arm_seq, 1, -1, float(prev_bar["low"]), "Cross"))
                # FB ↓ / ↑
                if float(prev_bar["high"]) > prev_avg and prev_close < prev_avg:
                    arm_seq += 1
                    arms.append((arm_seq, 2, -1, float(prev_bar["low"]), "FB"))
                if float(prev_bar["low"]) < prev_avg and prev_close > prev_avg:
                    arm_seq += 1
                    arms.append((arm_seq, 2, 1, float(prev_bar["high"]), "FB"))
                # IntraFB 近似：本K同時看過均線上下，或只洗過單側後反向。
                seen_above = float(bar["high"]) > avg_now
                seen_below = float(bar["low"]) < avg_now
                want_dir = 0
                if seen_above and seen_below:
                    want_dir = 1 if cl >= avg_now else -1
                elif seen_below:
                    want_dir = 1
                elif seen_above:
                    want_dir = -1
                if want_dir != 0:
                    arm_seq += 1
                    gate = float(prev_bar["high"] if want_dir > 0 else prev_bar["low"])
                    arms.append((arm_seq, 3, want_dir, gate, "IntraFB_L" if want_dir > 0 else "IntraFB_S"))

                winner = None
                for seq, typ, direction, gate, reason in arms:
                    fired = False
                    if direction > 0:
                        if typ == 3:
                            fired = float(bar["high"]) > avg_now and float(bar["high"]) > gate
                        else:
                            fired = float(bar["high"]) > gate
                    else:
                        if typ == 3:
                            fired = float(bar["low"]) < avg_now and float(bar["low"]) < gate
                        else:
                            fired = float(bar["low"]) < gate
                    if fired and (winner is None or seq > winner[0]):
                        winner = (seq, typ, direction, gate, reason)

                if winner is not None:
                    _seq, _typ, direction, gate, reason = winner
                    fill = _bar_fill_price(bar, direction, gate)
                    if position == 0:
                        open_position(bar["end"], fill, direction, i)
                    elif (position > 0 and direction < 0) or (position < 0 and direction > 0):
                        close_position(bar["end"], fill, "反手平倉", "反手平倉")
                        open_position(bar["end"], fill, direction, i)

            # 已持倉時跑保底停利/停損；進場當根不做同棒出場，避免K棒順序不明導致假洗價。
            if position != 0 and i != entry_bar_idx:
                for px in _three_ma_bar_path(bar):
                    if check_exit_by_price(bar, px):
                        break
            else:
                update_equity(cl)

            # 本根K收盤後，保存 close 與該收盤均線供下一根使用。
            closes.append(cl)
            if len(closes) >= n:
                avgs.append(sum(closes[-n:]) / float(n))
            else:
                avgs.append(cl)

        if position != 0 and bars:
            last_bar = bars[-1]
            close_position(last_bar.get("end") or last_bar.get("start"), float(last_bar["close"]), "時間到強制出場", "時間到強制出場")
            update_equity(float(last_bar["close"]))

        total_net = sum(float(x.get("net", 0.0) or 0.0) for x in session_closed)
        all_day_stats.append({
            "session": session_label,
            "month": month_text,
            "minutes": "%d分K/%d根" % (k_minutes, len(bars)),
            "ticks": sum(int(b.get("ticks", 0) or 0) for b in bars),
            "trades": len(session_closed),
            "win_trades": sum(1 for x in session_closed if float(x.get("net", 0.0) or 0.0) > 0),
            "loss_trades": sum(1 for x in session_closed if float(x.get("net", 0.0) or 0.0) < 0),
            "net": total_net,
            "tp": sum(1 for x in session_closed if "停利" in x["reason"]),
            "sl": sum(1 for x in session_closed if "停損" in x["reason"]),
            "reverse": sum(1 for x in session_closed if x["event"] == "反手平倉"),
            "force": sum(1 for x in session_closed if "時間到" in x["reason"]),
            "loss_exit": 0,
            "profit_exit": 0,
            "max_dd": max_dd,
            "peak_pnl": peak_equity,
            "trough_pnl": trough_equity,
            "hit_profit_exit": bool(lock_profit_exit and peak_equity >= abs(float(lock_profit_exit or 0.0))),
            "hit_loss_exit": bool(loss_exit and trough_equity <= -abs(float(loss_exit or 0.0))),
            "hit_20000": total_net >= 20000,
            "stop_reason": "",
        })
        _safe_progress(progress, min(done_units, total_units), total_units, "%s｜MA策略 %d分K完成" % (session_label, k_minutes))

    _safe_progress(progress, total_units, total_units, "MA策略回測完成")
    return all_day_stats, all_closed, all_records, all_events


def _session_op_boundary_dt(strategy_name, session_key):
    """回測專用：OP 用開盤第一根收盤，固定在第二根開頭成交。

    官方 tick 檔若第二根 08:46/15:01 沒有成交，不能等到 08:47 才進 OP；
    應用第一根最後價格與均價，在 08:46:00 / 15:01:00 補一筆合成 tick，
    對齊小火車/XQ 的 OP 進場時間。
    """
    try:
        day_text, segment = str(session_key or "").split(":", 1)
        base_day = RealDateTime.strptime(day_text, "%Y-%m-%d").date()
    except Exception:
        return None
    k = strategy_kind(strategy_name)
    if segment == "DAY":
        return RealDateTime.combine(base_day, time(8, 46, 0))
    if k == "TAI" and segment == "NIGHT":
        return RealDateTime.combine(base_day, time(15, 1, 0))
    if k == "TAI" and segment == "NINE":
        return RealDateTime.combine(base_day, time(21, 1, 0))
    return None

def _prepare_session_items_from_ticks(ticks):
    """把 ticks 依 session 預分組，並壓成回測熱路徑用的三欄 tuple。

    v029 速度重點：多參數回測時每組都重建 by_session / 月份 / 分鐘集合很浪費。
    這裡一次預處理成：[(session_key, rows, label, month_text, unique_minutes)]。
    rows 只保留 (dt, price, avg)，策略核心逐 tick 只需要這三個欄位。
    """
    buckets = {}
    meta = {}
    for t in list(ticks or []):
        try:
            skey = str(t.session_key)
            dt = t.dt
            price = float(t.price)
            avg = float(t.avg)
            month = str(t.month)
            label = str(t.session_label)
        except Exception:
            continue
        buckets.setdefault(skey, []).append((dt, price, avg))
        m = meta.setdefault(skey, {"label": label, "months": set(), "minutes": set(), "first_dt": dt})
        m["months"].add(month)
        try:
            m["minutes"].add(dt.strftime("%Y-%m-%d %H:%M"))
        except Exception:
            pass
        if dt < m["first_dt"]:
            m["first_dt"] = dt
    items = []
    for skey, rows in buckets.items():
        if not rows:
            continue
        rows.sort(key=lambda x: x[0])
        m = meta.get(skey, {})
        month_text = "/".join(sorted(m.get("months") or []))
        items.append((skey, rows, str(m.get("label") or skey), month_text, int(len(m.get("minutes") or [])), rows[0][0]))
    items.sort(key=lambda x: x[5] if x and len(x) > 5 else RealDateTime.min)
    return [(skey, rows, label, month_text, minutes) for skey, rows, label, month_text, minutes, _first_dt in items]


def _prepare_session_items_from_packed_rows(rows):
    """worker initializer 使用：直接從 pickle rows 預分組，不再建立 OfficialTick 物件。"""
    buckets = {}
    meta = {}
    for row in list(rows or []):
        try:
            dt, _d, price, _qty, avg, _code, month, skey, slabel = row
            skey = str(skey)
            dt = dt
            price = float(price)
            avg = float(avg)
            month = str(month)
            label = str(slabel)
        except Exception:
            continue
        buckets.setdefault(skey, []).append((dt, price, avg))
        m = meta.setdefault(skey, {"label": label, "months": set(), "minutes": set(), "first_dt": dt})
        m["months"].add(month)
        try:
            m["minutes"].add(dt.strftime("%Y-%m-%d %H:%M"))
        except Exception:
            pass
        if dt < m["first_dt"]:
            m["first_dt"] = dt
    items = []
    for skey, arr in buckets.items():
        if not arr:
            continue
        arr.sort(key=lambda x: x[0])
        m = meta.get(skey, {})
        items.append((skey, arr, str(m.get("label") or skey), "/".join(sorted(m.get("months") or [])), int(len(m.get("minutes") or [])), arr[0][0]))
    items.sort(key=lambda x: x[5] if x and len(x) > 5 else RealDateTime.min)
    return [(skey, arr, label, month_text, minutes) for skey, arr, label, month_text, minutes, _first_dt in items]



def _force_split_tai_open_price_session_items(session_items, strategy_name, product_code):
    """053F：開盤價策略跑 TXF/MXF/TMF 時，日盤與夜盤必須完全獨立。

    部分舊快取或中間路徑可能把同一交易日資料以同一天/同商品彙整，
    導致每日總表與交易明細、認賠/賺飽判斷在日盤/夜盤之間互相污染。
    這裡在進 strategy_core 前強制依實際 tick 時間重新切成：
      YYYY-MM-DD:DAY   = 08:45~13:45
      YYYY-MM-DD:NIGHT = 15:00~次日05:00
    讓每個時段使用獨立 manager、獨立開盤價、獨立損益與獨立風控門檻。
    """
    if not (is_open_price_strategy(strategy_name) and is_tai_index_code(product_code)):
        return list(session_items or [])
    if any(str(item[0] or "").split(":")[-1].upper() == "NINE" for item in list(session_items or [])):
        return list(session_items or [])
    buckets = {}
    meta = {}
    for _old_key, rows, _old_label, month_text, _old_minutes in list(session_items or []):
        for row in list(rows or []):
            if not row:
                continue
            dt = row[0]
            try:
                skey, slabel, in_session, _force_dt = session_for("開盤價策略-台指期", dt)
            except Exception:
                skey, slabel, in_session = "", "", False
            if not in_session or not skey:
                continue
            buckets.setdefault(skey, []).append(row)
            m = meta.setdefault(skey, {"label": slabel, "months": set(), "minutes": set(), "first_dt": dt})
            for mth in str(month_text or "").split("/"):
                if mth:
                    m["months"].add(mth)
            try:
                m["minutes"].add(dt.strftime("%Y-%m-%d %H:%M"))
            except Exception:
                pass
            if dt < m.get("first_dt", dt):
                m["first_dt"] = dt
    out = []
    for skey, rows in buckets.items():
        rows.sort(key=lambda x: x[0])
        m = meta.get(skey, {})
        out.append((
            skey,
            rows,
            str(m.get("label") or skey),
            "/".join(sorted(m.get("months") or [])),
            int(len(m.get("minutes") or [])),
            m.get("first_dt", rows[0][0]),
        ))
    out.sort(key=lambda x: x[5])
    return [(skey, rows, label, month_text, minutes) for skey, rows, label, month_text, minutes, _first in out]

def _merge_tai_ema_session_items(session_items, strategy_name, product_code):
    """EMA台指回測：把同一自然日的日盤 + 同日夜盤合成全盤序列。"""
    if not (is_fast_ma_strategy(strategy_name) and is_tai_index_code(product_code)):
        return list(session_items or [])
    buckets = {}
    meta = {}
    for skey, rows, label, month_text, unique_minutes in list(session_items or []):
        if not rows:
            continue
        first_dt = rows[0][0]
        try:
            day_text, seg = str(skey or "").split(":", 1)
            base_day = RealDateTime.strptime(day_text, "%Y-%m-%d").date()
        except Exception:
            base_day = _ema_txf_trade_day_for_dt(first_dt) or first_dt.date()
            seg = "FULL"
        trading_day = base_day
        key = trading_day.strftime("%Y-%m-%d") + ":FULL"
        buckets.setdefault(key, []).extend(rows)
        m = meta.setdefault(key, {"months": set(), "minutes": set(), "first_dt": first_dt})
        for mth in str(month_text or "").split("/"):
            if mth:
                m["months"].add(mth)
        for dt, _price, _avg in rows:
            try:
                m["minutes"].add(dt.strftime("%Y-%m-%d %H:%M"))
            except Exception:
                pass
            if dt < m["first_dt"]:
                m["first_dt"] = dt
    out = []
    for key, rows in buckets.items():
        rows.sort(key=lambda x: x[0])
        m = meta.get(key, {})
        day = key.split(":", 1)[0]
        out.append((key, rows, f"{day} 全盤", "/".join(sorted(m.get("months") or [])), int(len(m.get("minutes") or [])), m.get("first_dt", rows[0][0])))
    out.sort(key=lambda x: x[5])
    return [(k, rows, label, month, minutes) for k, rows, label, month, minutes, _first in out]




def _install_open_price_signal_overrides(manager):
    def _backtest_session_minute_for_task(task, dt):
        if str(getattr(task, "backtest_tai_session_mode", "") or "") == "九點盤":
            minute = int(dt.hour) * 60 + int(dt.minute)
            if minute >= 21 * 60:
                return minute - 21 * 60
            if minute < 5 * 60:
                return minute + 24 * 60 - 21 * 60
            return -1
        return strategy_core._session_minute(dt)

    """開盤價策略：沿用小火車風控/成交帳本，只把進場基準改成本時段開盤價。

    053B 修正：回測進場條件完全對齊 XS 開盤價策略 0617 版：
    - Cross 必須先有「前一根收盤在基準另一側」，本根現價回到基準這側才 ARM；
      不是單純看現價在開盤價上方/下方。
    - FB / IntraFB 恢復為 XS 的兩段式價格訊號，Gate 在 ARM 當下固定。
    - 同一 kind + 同方向 pending 不重建、不覆蓋 Gate；只有相反方向取代。
    - 停利後同根再進只吃本根開盤後真正 FIRE、且未曾實際執行進場的訊號。

    053C 修正：
    - 同向舊 pending 不再跨 tick / 跨 K 被停利後誤吃，避免無訊號補進。
    - 反手平倉的交易明細原因改顯示實際進場訊號，例如 Cross多、FB多、IFB空。

    053E 修正：
      - 交易明細「累計」改以日盤/夜盤 session 分開累計，避免同日日盤損益抵銷夜盤。
      - 欄位文字改為「時段累計」，每日總表與交易明細可直接對帳。

    053H 修正：
    - 對齊新版(2) XS：開盤價 Cross 觸碰等於基準不算穿越，必須嚴格 > Base / < Base。
    - 保留 053G 的 OP 十字 K、FB、IntraFB、全域 FIRE 消耗表與 TP 後禁吃舊 ARM。

    053D 修正：
    - 對齊最新 XS 母版「全域 FIRE 消耗表／TP後禁吃舊ARM」。
    - 只有實際送出進場/反手目標的 FIRE 才進入已用表；停利後不可再吃已用 FIRE。
    - 先 ARM、但停利當根才第一次 FIRE 且未實送過的訊號仍可合法再進。
    """
    def _arm_open_price_kind_once(st, kind, direction, gate, source, ref_index):
        if not st.current_bar:
            return None
        direction = 1 if int(direction) > 0 else -1
        gate = float(gate or 0.0)
        for p in list(getattr(st, "pending", []) or []):
            if (
                str(getattr(p, "kind", "") or "") == str(kind)
                and int(getattr(p, "direction", 0) or 0) == direction
                and str(getattr(p, "session_key", "") or "") == str(getattr(st, "session_key", "") or "")
            ):
                # XS：同方向 pending 可一直存在，直到 FIRE 或相反方向 pending 取代；
                # 不得因後續 tick / 換 K 重建，也不得覆蓋原本固定 Gate。
                return p
        return manager._arm(st, str(kind), direction, gate, source, ref_index)

    def _clear_open_price_if_on_line(st):
        # 價格等於基準不成立 Cross / FB / IntraFB；已存在 pending 仍依 XS 生命週期保留，
        # 只在完全沒有 pending 時回到等待新訊號。
        if not st.pending:
            st.need_new_signal = True

    def _gate_from_prev(st, profile, prev):
        try:
            return manager._gate_from_bar(profile, prev)
        except Exception:
            return float(getattr(prev, "high", 0.0) or 0.0), float(getattr(prev, "low", 0.0) or 0.0)

    def _open_price_same_bar_fired(st, kind, direction):
        """XS guard：同一根 K 已實送過同類同方向 FIRE 後，不可用殘留條件重建 pending。"""
        if not st.current_bar:
            return False
        try:
            cur_idx = int(getattr(st.current_bar, "index", -1))
            last_idx = int(getattr(st, "last_fired_bar_index", -999999))
        except Exception:
            return False
        if cur_idx < 0 or last_idx != cur_idx:
            return False
        last_kind = str(getattr(st, "last_fired_kind", "") or "")
        try:
            last_dir = 1 if int(getattr(st, "last_fired_direction", 0) or 0) > 0 else (-1 if int(getattr(st, "last_fired_direction", 0) or 0) < 0 else 0)
        except Exception:
            last_dir = 0
        return bool(last_kind == str(kind or "") and last_dir == (1 if int(direction) > 0 else -1))

    def _arm_open_price_cross_fb(st, profile, price, base):
        if not st.current_bar or not st.bars or float(base or 0.0) <= 0:
            return
        prev = st.bars[-1]
        gate_high, gate_low = _gate_from_prev(st, profile, prev)
        price = float(price or 0.0)
        base = float(base or 0.0)
        prev_close = float(getattr(prev, "close", 0.0) or 0.0)
        prev_high = float(getattr(prev, "high", 0.0) or 0.0)
        prev_low = float(getattr(prev, "low", 0.0) or 0.0)

        # Cross Long：前一根收盤在基準下，本根現價必須嚴格站上基準；等於基準只算碰到，不算穿越。
        # Gate 固定為前一根 High，FIRE 仍必須嚴格突破 Gate。
        if prev_close < base and price > base:
            if not _open_price_same_bar_fired(st, "Cross", 1):
                _arm_open_price_kind_once(st, "Cross", 1, gate_high, "開盤價｜Cross", prev.index)
        # Cross Short：前一根收盤在基準上，本根現價必須嚴格跌破基準；等於基準只算碰到，不算穿越。
        elif prev_close > base and price < base:
            if not _open_price_same_bar_fired(st, "Cross", -1):
                _arm_open_price_kind_once(st, "Cross", -1, gate_low, "開盤價｜Cross", prev.index)
        elif price == base:
            _clear_open_price_if_on_line(st)

        # FB Short：前一根曾刺穿基準上方但收回基準下，Gate 固定為該根 Low。
        if prev_high > base and prev_close < base:
            if not _open_price_same_bar_fired(st, "FB", -1):
                _arm_open_price_kind_once(st, "FB", -1, gate_low, "開盤價｜FB", prev.index)
        # FB Long：前一根曾刺穿基準下方但收回基準上，Gate 固定為該根 High。
        elif prev_low < base and prev_close > base:
            if not _open_price_same_bar_fired(st, "FB", 1):
                _arm_open_price_kind_once(st, "FB", 1, gate_high, "開盤價｜FB", prev.index)

        if not st.pending:
            st.need_new_signal = True

    def _arm_open_price_stock(st, profile, price, avg):
        _arm_open_price_cross_fb(st, profile, price, avg)

    def _arm_open_price_tai(st, price, avg):
        profile = getattr(manager, "_open_price_tai_profile", None)
        if profile is None:
            try:
                profile = strategy_core.PROFILES.get("台指期策略")
            except Exception:
                profile = None
        _arm_open_price_cross_fb(st, profile, price, avg)

    def _arm_open_price_intra(st, price, base):
        """XS IntraFB：本根內先跨到基準另一側，再回到本側才 ARM。"""
        if not st.current_bar or float(base or 0.0) <= 0:
            return
        price = float(price or 0.0)
        base = float(base or 0.0)

        if price > base:
            st.intra_seen_above = True
        if price < base:
            st.intra_seen_below = True

        want_dir = 0
        want_gate = 0.0
        if st.intra_seen_below and price > base:
            want_dir = 1
            want_gate = float(getattr(st, "intra_ref_high", 0.0) or 0.0)
        elif st.intra_seen_above and price < base:
            want_dir = -1
            want_gate = float(getattr(st, "intra_ref_low", 0.0) or 0.0)

        if want_dir and not _open_price_same_bar_fired(st, "IntraFB", want_dir):
            _arm_open_price_kind_once(
                st,
                "IntraFB",
                want_dir,
                want_gate,
                "開盤價｜IntraFB",
                int(getattr(st.current_bar, "index", -1)),
            )
        if not st.pending:
            st.need_new_signal = True

    def _try_open_price_openwait_second_bar(task, st, price, dt):
        """XS OP：第一根不做；第二根只判一次。O=C 時只有真十字 K 才 OP 多。"""
        try:
            if _backtest_session_minute_for_task(task, dt) != 1 or st.openwait_done or st.session_had_entry or st.session_blocked or st.session_inventory_sync_pending or st.restart_inventory_sync_pending:
                return False
        except Exception:
            return False
        if not st.current_bar or len(st.bars) != 1:
            return False
        previous = st.bars[-1]
        try:
            if previous.index != 0 or st.current_bar.index != 1 or not strategy_core._is_true_second_bar(dt, previous):
                return False
        except Exception:
            return False
        if int(getattr(st, "position", 0) or 0) != 0:
            return False
        base = float(getattr(previous, "avg_close", 0.0) or 0.0)
        if base <= 0:
            st.risk_status = "第二根OP等待開盤價"
            st.last_signal = "第二根OP等待開盤價"
            st.signal_source = "OP"
            return False
        prev_close = float(getattr(previous, "close", 0.0) or 0.0)
        prev_high = float(getattr(previous, "high", 0.0) or 0.0)
        prev_low = float(getattr(previous, "low", 0.0) or 0.0)
        direction = 0
        if prev_close > base:
            direction = 1
        elif prev_close < base:
            direction = -1
        else:
            # 真十字 K：必須有上影也有下影；一價到底、T字、倒T字、只單邊影線都不 OP。
            direction = 1 if (prev_high > base and prev_low < base) else 0
        # OP 每個時段只判定一次；跳過也不得下一 tick 重新判定。
        st.openwait_done = True
        if direction == 0:
            st.need_new_signal = True
            st.risk_status = "OP跳過｜第一根O=C且非十字K"
            st.last_signal = "OP跳過｜第一根O=C且非十字K"
            st.signal_source = "OP"
            manager._clear_pending(st, ["OpenWait"])
            return False
        st.arm_seq += 1
        p = strategy_core.Pending("OpenWait", direction, 0.0, "價格｜OpenWait", st.arm_seq, previous.index, st.session_key, int(getattr(st.current_bar, "index", 1)))
        st.pending = [old for old in st.pending if old.kind != "OpenWait"] + [p]
        st.need_new_signal = False
        st.boot_fresh_arm_ready = True
        reason = strategy_core._direction_reason("OpenWait", direction)
        ok = manager.set_target(task, direction * int(getattr(task, "lots", 1)), price, reason, "價格｜OpenWait", reason, from_chip=False, arm_seq=p.seq)
        if not ok:
            manager._clear_pending(st, ["OpenWait"])
            return False
        st.boot_allow_event = True
        st.boot_wait_new_bar = False
        st.boot_unlock_bars_remaining = 0
        manager._clear_pending(st, ["OpenWait"])
        st.need_new_signal = False
        return True

    manager._try_openwait_second_bar = _try_open_price_openwait_second_bar
    manager._arm_stock_intrabar = _arm_open_price_stock
    manager._arm_tai_special_intrabar = _arm_open_price_tai
    manager._arm_intra = _arm_open_price_intra

def _apply_ema_cached_bars_to_manager(manager, task, skey, cached_payload):
    """把 ema_txf_cache.db 的完整K棒暖機資料寫進策略核心狀態。

    這比 apply_ema_manual_closes() 更安全，因為會保留前一根K棒 high/low 與完成EMA，
    EMA策略的突破門檻才不會被錯誤壓成 close。
    """
    if not isinstance(cached_payload, dict) or not cached_payload.get("__ema_cached_bars__"):
        return False
    sessions = cached_payload.get("sessions") or {}
    bars = sessions.get(str(skey)) or sessions.get(str(skey).split(":", 1)[0]) or []
    if not bars:
        return False
    try:
        st = manager._state(task)
        st.session_key = str(skey or "")
        st.bar_aggregation_signature = manager._bar_aggregation_signature(task)
        seed = []
        start_index = -len(bars)
        for offset, b in enumerate(list(bars or [])):
            try:
                seed.append(strategy_core.Bar(
                    key=str(b.get("key") or ("EMA-CACHE-%d" % offset)),
                    open=float(b.get("open", 0.0) or 0.0),
                    high=float(b.get("high", 0.0) or 0.0),
                    low=float(b.get("low", 0.0) or 0.0),
                    close=float(b.get("close", 0.0) or 0.0),
                    avg_close=float(b.get("avg_close", 0.0) or 0.0),
                    index=start_index + offset,
                ))
            except Exception:
                continue
        if not seed:
            return False
        st.bars = seed
        st.current_bar = None
        st.next_bar_index = 0
        st.session_bar_count = 0
        st.first_tick_seen = True
        st.boot_allow_event = True
        st.boot_wait_new_bar = False
        st.boot_unlock_bars_remaining = 0
        st.boot_ref_bar_index = -1
        st.boot_fresh_arm_ready = True
        st.quote_avg_ready_seen = True
        st.ma_ready_effective_period = int(normalize_ema_period(getattr(task, "ma_period", 20)))
        st.avg_entry_wait_bar_index = -1
        st.need_new_signal = True
        st.risk_status = "正常"
        st.last_signal = "等待新訊號"
        st.signal_source = ""
        setattr(task, "backtest_ema_seeded_from_cache", True)
        setattr(task, "backtest_skip_tick_warmup", True)
        return True
    except Exception:
        return False



def _ema_fast_parse_dt(text):
    if isinstance(text, RealDateTime):
        return text
    try:
        return RealDateTime.fromisoformat(str(text))
    except Exception:
        return parse_dt_text(text)


def _ema_fast_fee(strategy_name, product_code=None, price=None):
    """EMA/SMA高速回測用手續費；台指與股期都對齊 strategy_core.計算單邊車票費。

    兼容舊呼叫 _ema_fast_fee(code, price)。
    """
    if price is None:
        price = product_code
        product_code = strategy_name
        strategy_name = ""
    try:
        px = float(price or 0.0)
    except Exception:
        px = 0.0
    if px <= 0:
        return 0.0
    code = clean_code(product_code or "TXF")
    def round_fee(v):
        return float(math.floor(max(0.0, float(v or 0.0)) + 0.5))
    if code == "TX" or code.startswith("TXF") or code == "TXF":
        return round_fee(px * 200 * 0.00002 + 32)
    if code.startswith("MXF"):
        return round_fee(px * 50 * 0.00002 + 18)
    if code.startswith("TMF"):
        return round_fee(px * 10 * 0.00002 + 14)
    if strategy_kind(strategy_name) == "SMALL":
        return round_fee(px * 100 * 0.00002 + 13)
    return round_fee(px * 2000 * 0.00002 + 15)


def _ema_fast_session_label(trade_date_text, code="TXF"):
    return _fast_ma_session_label(trade_date_text, code)


def _ema_fast_bar_month_text(bars):
    months = []
    for b in list(bars or []):
        m = str(b.get("month") or "").strip()
        if m and m not in months:
            months.append(m)
    return "/".join(months)


def _ema_fast_flatten_session_rows(session_items, product_code="TXF"):
    rows = []
    months = {}
    code = clean_code(product_code or "TXF")
    for item in list(session_items or []):
        try:
            _skey, arr, _label, month_text, _unique_minutes = item
        except Exception:
            continue
        for r in list(arr or []):
            try:
                dt, price, _avg = r
                dt = dt if isinstance(dt, RealDateTime) else _ema_fast_parse_dt(dt)
                price = float(price)
                if dt and price > 0:
                    rows.append((dt, price))
                    td = _fast_ma_trade_day_for_dt(code, dt)
                    if td is not None and month_text:
                        months.setdefault(td.strftime("%Y-%m-%d"), set()).update([x for x in str(month_text).split("/") if x])
            except Exception:
                continue
    rows.sort(key=lambda x: x[0])
    return rows, months


def build_ema_txf_fast_context_from_session_items(session_items, product_code, k_minutes, period, progress=None):
    """EMA策略專用高速上下文。

    K棒OHLC、前高前低與完成EMA全部讀 ema_txf_cache.db；傳入的逐筆資料只保留
    每根K內價格發生順序，用於判斷突破/反手/停利停損同根先後。這裡不呼叫
    strategy_core，也不做逐筆暖機或逐筆重組K棒。
    """
    rows, month_by_td = _ema_fast_flatten_session_rows(session_items, product_code)
    if not rows:
        raise ValueError("EMA高速回測無逐筆資料；請確認商品、日期範圍與交易時段。")
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_ema_period(period)
    preferred = clean_code(product_code or "TXF")
    _safe_progress(progress, 0, 1, "準備EMA高速資料｜%s｜%s｜EMA%d" % (preferred, k_minutes_label(k), p))
    ensure_ema_txf_period_cache(preferred, k, p, progress=progress)
    cache_code = resolve_ema_txf_cache_code(preferred, k)
    ensure_ema_txf_period_cache(cache_code, k, p, progress=progress)

    first_ident = _fast_ma_bar_identity(preferred, rows[0][0], k)
    last_ident = _fast_ma_bar_identity(preferred, rows[-1][0], k)
    if first_ident is None or last_ident is None:
        raise ValueError("EMA高速回測日期範圍不在該商品交易時段。")
    _first_td, _first_bi, first_start = first_ident
    _last_td, _last_bi, last_start = last_ident
    first_start_text = first_start.strftime("%Y-%m-%d %H:%M:%S")
    last_start_text = last_start.strftime("%Y-%m-%d %H:%M:%S")

    ticks_by_key = {}
    for dt, price in rows:
        ident = _fast_ma_bar_identity(preferred, dt, k)
        if ident is None:
            continue
        td, bi, _start = ident
        key = (td.strftime("%Y-%m-%d"), int(bi))
        ticks_by_key.setdefault(key, []).append((dt, float(price)))
    for arr in ticks_by_key.values():
        arr.sort(key=lambda x: x[0])

    conn = ema_db_connect()
    try:
        select_cols = """
            kb.trade_date, kb.bar_index, kb.start_dt, kb.end_dt,
            kb.open, kb.high, kb.low, kb.close, kb.qty, kb.tick_count, COALESCE(kb.month,''),
            COALESCE(ev.ema, 0), COALESCE(ev.ready, 0)
        """
        base_join = """
            FROM ema_kbars kb
            LEFT JOIN ema_values ev
              ON ev.code=kb.code AND ev.k_minutes=kb.k_minutes AND ev.period=?
             AND ev.trade_date=kb.trade_date AND ev.bar_index=kb.bar_index
            WHERE kb.code=? AND kb.k_minutes=?
        """
        prev_rows = conn.execute("SELECT " + select_cols + base_join + " AND kb.start_dt < ? ORDER BY kb.start_dt DESC LIMIT 2", (p, cache_code, k, first_start_text)).fetchall()
        bar_rows = conn.execute("SELECT " + select_cols + base_join + " AND kb.start_dt >= ? AND kb.start_dt <= ? ORDER BY kb.start_dt", (p, cache_code, k, first_start_text, last_start_text)).fetchall()
    finally:
        try:
            conn.close()
        except Exception:
            pass

    def pack_bar(r, attach_ticks=True):
        td, bi, sdt, edt, op, hi, lo, cl, qty, tick_count, month, ema, ready = r
        td_text = str(td)
        bi = int(bi)
        key = (td_text, bi)
        attached = list(ticks_by_key.get(key, [])) if attach_ticks else []
        # ema_kbars 的 end_dt 是該K最後一筆；實際策略判斷仍依 ticks_by_key 的逐筆順序。
        return {
            "trade_date": td_text,
            "bar_index": bi,
            "start": _ema_fast_parse_dt(sdt),
            "end": _ema_fast_parse_dt(edt),
            "open": float(op),
            "high": float(hi),
            "low": float(lo),
            "close": float(cl),
            "qty": float(qty or 0.0),
            "tick_count": int(tick_count or 0),
            "month": str(month or ""),
            "ema": float(ema or 0.0),
            "ready": bool(int(ready or 0)),
            "ticks": attached,
        }

    prev_bars = [pack_bar(r, attach_ticks=False) for r in reversed(prev_rows or [])]
    bars = [pack_bar(r, attach_ticks=True) for r in (bar_rows or [])]
    bars = [b for b in bars if b.get("ticks")]
    if not bars:
        raise ValueError("EMA高速回測找不到日期範圍內的 EMA K棒；請重建 EMA/SMA快取。")
    # 第一根要有上一根完成K與完成EMA，否則不能做前高/前低突破判斷。
    prev_bar = None
    for b in reversed(prev_bars):
        if b.get("ready") and float(b.get("ema", 0.0) or 0.0) > 0:
            prev_bar = b
            break
    # 若快取真的不足，允許從區間內第一根 ready 的下一根開始；但不回退慢速暖機。
    months = {}
    for b in bars:
        td = b.get("trade_date")
        if b.get("month"):
            months.setdefault(td, set()).add(str(b.get("month")))
        if td in month_by_td:
            months.setdefault(td, set()).update(month_by_td.get(td) or set())
    _safe_progress(progress, len(bars), len(bars), "EMA高速資料就緒｜%s｜%s｜EMA%d｜K棒%d根｜逐筆只用於觸價順序" % (cache_code, k_minutes_label(k), p, len(bars)))
    return {
        "code": cache_code,
        "k_minutes": k,
        "period": p,
        "bars": bars,
        "prev_bar": prev_bar,
        "months": {td: "/".join(sorted(v)) for td, v in months.items()},
        "tick_count": sum(len(b.get("ticks") or []) for b in bars),
    }




def build_sma_txf_fast_context_from_session_items(session_items, product_code, k_minutes, period, progress=None):
    """SMA策略專用高速上下文。

    v052R：不再為每一個 SMA 參數寫入 sma_values 快取表。
    先前版本會在群組回測時逐組建立/寫入 SQLite SMA 快取，第一次跑 10～100 這種
    多參數範圍時會非常慢，甚至造成 ProcessPool 中斷。SMA 是簡單滑動平均，這裡改為
    只讀 ema_kbars 的 K棒 OHLC，並在記憶體中用區間前 N 根收盤價即時計算完成 SMA。
    """
    rows, month_by_td = _ema_fast_flatten_session_rows(session_items, product_code)
    if not rows:
        raise ValueError("SMA高速回測無逐筆資料；請確認商品、日期範圍與交易時段。")
    k = normalize_ema_k_minutes(k_minutes)
    p = normalize_sma_period(period)
    preferred = clean_code(product_code or "TXF")
    _safe_progress(progress, 0, 1, "準備SMA高速資料｜%s｜%s｜SMA%d" % (preferred, k_minutes_label(k), p))

    init_ema_txf_cache_db()
    conn = ema_db_connect()
    try:
        row = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE code=? AND k_minutes=?", (preferred, k)).fetchone()
        if not row or int(row[0] or 0) <= 0:
            try:
                conn.close()
            except Exception:
                pass
            ensure_ema_kbars_for_code_k(preferred, k, progress=progress)
            conn = ema_db_connect()
        cache_code = resolve_ema_txf_cache_code(preferred, k)
    finally:
        try:
            conn.close()
        except Exception:
            pass

    first_ident = _fast_ma_bar_identity(preferred, rows[0][0], k)
    last_ident = _fast_ma_bar_identity(preferred, rows[-1][0], k)
    if first_ident is None or last_ident is None:
        raise ValueError("SMA高速回測日期範圍不在該商品交易時段。")
    _first_td, _first_bi, first_start = first_ident
    _last_td, _last_bi, last_start = last_ident
    first_start_text = first_start.strftime("%Y-%m-%d %H:%M:%S")
    last_start_text = last_start.strftime("%Y-%m-%d %H:%M:%S")

    ticks_by_key = {}
    for dt, price in rows:
        ident = _fast_ma_bar_identity(preferred, dt, k)
        if ident is None:
            continue
        td, bi, _start = ident
        key = (td.strftime("%Y-%m-%d"), int(bi))
        ticks_by_key.setdefault(key, []).append((dt, float(price)))
    for arr in ticks_by_key.values():
        arr.sort(key=lambda x: x[0])

    conn = ema_db_connect()
    try:
        select_cols = """
            trade_date, bar_index, start_dt, end_dt,
            open, high, low, close, qty, tick_count, COALESCE(month,'')
        """
        base_where = """
            FROM ema_kbars
            WHERE code=? AND k_minutes=?
        """
        # 只需要區間前 N 根左右即可計算第一根回測K的完成 SMA，不必掃完整個資料庫。
        prev_limit = max(2, int(p) + 2)
        prev_rows = conn.execute(
            "SELECT " + select_cols + base_where + " AND start_dt < ? ORDER BY start_dt DESC LIMIT ?",
            (cache_code, k, first_start_text, prev_limit)
        ).fetchall()
        bar_rows = conn.execute(
            "SELECT " + select_cols + base_where + " AND start_dt >= ? AND start_dt <= ? ORDER BY start_dt",
            (cache_code, k, first_start_text, last_start_text)
        ).fetchall()
    finally:
        try:
            conn.close()
        except Exception:
            pass

    ordered_rows = list(reversed(prev_rows or [])) + list(bar_rows or [])
    sma_by_key = {}
    window = []
    rolling_sum = 0.0
    bad_count = 0
    for r in ordered_rows:
        td, bi, _sdt, _edt, _op, _hi, _lo, cl, _qty, _tick_count, _month = r
        try:
            c = float(cl)
        except Exception:
            c = 0.0
        window.append(c)
        rolling_sum += c
        if c <= 0:
            bad_count += 1
        if len(window) > p:
            old = window.pop(0)
            rolling_sum -= old
            if old <= 0:
                bad_count -= 1
        ready = bool(len(window) == p and bad_count == 0)
        sma = (rolling_sum / float(p)) if ready else 0.0
        sma_by_key[(str(td), int(bi))] = (float(sma or 0.0), int(1 if ready else 0))

    def pack_bar(r, attach_ticks=True):
        td, bi, sdt, edt, op, hi, lo, cl, qty, tick_count, month = r
        td_text = str(td)
        bi = int(bi)
        key = (td_text, bi)
        attached = list(ticks_by_key.get(key, [])) if attach_ticks else []
        sma, ready = sma_by_key.get(key, (0.0, 0))
        return {
            "trade_date": td_text,
            "bar_index": bi,
            "start": _ema_fast_parse_dt(sdt),
            "end": _ema_fast_parse_dt(edt),
            "open": float(op),
            "high": float(hi),
            "low": float(lo),
            "close": float(cl),
            "qty": float(qty or 0.0),
            "tick_count": int(tick_count or 0),
            "month": str(month or ""),
            "ema": float(sma or 0.0),
            "ready": bool(int(ready or 0)),
            "ticks": attached,
        }

    prev_bars = [pack_bar(r, attach_ticks=False) for r in reversed(prev_rows or [])]
    bars = [pack_bar(r, attach_ticks=True) for r in (bar_rows or [])]
    bars = [b for b in bars if b.get("ticks")]
    if not bars:
        raise ValueError("SMA高速回測找不到日期範圍內的 K棒；請確認資料或重建快取。")
    prev_bar = None
    for b in reversed(prev_bars):
        if b.get("ready") and float(b.get("ema", 0.0) or 0.0) > 0:
            prev_bar = b
            break
    months = {}
    for b in bars:
        td = b.get("trade_date")
        if b.get("month"):
            months.setdefault(td, set()).add(str(b.get("month")))
        if td in month_by_td:
            months.setdefault(td, set()).update(month_by_td.get(td) or set())
    seed_closes = [float(b.get("close", 0.0) or 0.0) for b in prev_bars if float(b.get("close", 0.0) or 0.0) > 0]
    _safe_progress(progress, len(bars), len(bars), "SMA高速資料就緒｜%s｜%s｜SMA%d｜K棒%d根｜SMA記憶體計算｜逐筆只用於觸價順序" % (cache_code, k_minutes_label(k), p, len(bars)))
    return {
        "code": cache_code,
        "k_minutes": k,
        "period": p,
        "algo": "SMA",
        "bars": bars,
        "prev_bar": prev_bar,
        "seed_closes": seed_closes,
        "months": {td: "/".join(sorted(v)) for td, v in months.items()},
        "tick_count": sum(len(b.get("ticks") or []) for b in bars),
    }

def run_ema_txf_fast_backtest_context(context, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=60, ma_period=20, entry_mode="逐筆洗價", one_way_fee=0.0, progress=None):
    bars = list((context or {}).get("bars") or [])
    if not bars:
        raise ValueError("均線高速回測沒有可用K棒。")
    k = normalize_ema_k_minutes(k_minutes)
    period = normalize_ema_period(ma_period)
    if int((context or {}).get("k_minutes") or k) != k or int((context or {}).get("period") or period) != period:
        raise ValueError("均線高速上下文參數不一致；請重新建立均線快取。")
    qty = max(1, int(lots or 1))
    code = "TXF" if clean_code(product_code or "TXF") in ("TX", "TXF") else clean_code(product_code or "TXF")
    multiplier = default_multiplier(strategy_name, code)
    is_sma = bool(is_sma_strategy(strategy_name) or str((context or {}).get("algo") or "").upper() == "SMA")
    avg_label = "SMA" if is_sma else "EMA"
    alpha = 2.0 / float(period + 1) if period > 1 else 1.0
    sma_completed_closes = [float(x) for x in list((context or {}).get("seed_closes") or []) if float(x or 0.0) > 0]
    tp_points = abs(float(tp_points or 0.0))
    # EMA/SMA策略固定不使用停損、認賠下車、賺飽下車。
    sl_points = 0.0
    loss_exit = 0.0
    lock_profit_exit = 0.0
    close_confirm = normalize_entry_mode(entry_mode) == "收盤確認"

    all_day_stats = []
    all_closed = []
    all_records = []
    all_events = []
    day_state = {}
    position = 0
    entry_px = 0.0
    entry_dt = None
    entry_fee = 0.0
    entry_side = 0
    entry_debug = {}
    pending = []
    arm_seq = 0
    last_fired_bar_index = -1
    last_fired_arm_seq = -1
    realized_total = 0.0
    running_peak = 0.0
    total_peak = 0.0
    total_trough = 0.0
    max_dd_total = 0.0
    pos_peak_points = 0.0
    tp_armed = False
    tp_line = 0.0
    # v052Z：停利後再進只接受本根開盤後「真正觸發」過的訊號。
    # 不能在停利當下只因價格仍在 gate 外就重新補進。
    same_bar_reentry_candidate = None
    bar_prev_price = None
    total_units = max(1, len(bars))

    def bar_check_price(px, bar, label):
        v = float(px or 0.0)
        hi = float(bar.get("high", 0.0) or 0.0)
        lo = float(bar.get("low", 0.0) or 0.0)
        if v < lo - 1e-6 or v > hi + 1e-6:
            raise ValueError(
                "%s回測防呆停止：%s價格 %.2f 不在K棒範圍 %.2f～%.2f｜bar_start=%s" %
                (avg_label, label, v, lo, hi, bar.get("start"))
            )

    def dstate(td):
        st = day_state.setdefault(td, {
            "session": _ema_fast_session_label(td, code), "month": str((context.get("months") or {}).get(td, "")),
            "minutes": "%s/%d根" % (k_minutes_label(k), 0), "ticks": 0, "trades": 0,
            "win_trades": 0, "loss_trades": 0, "net": 0.0, "tp": 0, "sl": 0, "reverse": 0,
            "force": 0, "loss_exit": 0, "profit_exit": 0, "max_dd": 0.0,
            "peak_pnl": 0.0, "trough_pnl": 0.0, "hit_profit_exit": False,
            "hit_loss_exit": False, "hit_20000": False, "stop_reason": "",
            "_running_peak": 0.0, "_bar_count": 0,
        })
        return st

    def gross_points(side, entry, exit_px):
        return (float(exit_px) - float(entry)) if side > 0 else (float(entry) - float(exit_px))

    def current_float(mark_price):
        if position == 0 or entry_px <= 0:
            return 0.0
        side = 1 if position > 0 else -1
        gross = gross_points(side, entry_px, mark_price) * multiplier * abs(position)
        est_exit_fee = _ema_fast_fee(strategy_name, code, mark_price) * abs(position)
        return gross - entry_fee - est_exit_fee

    def update_equity(td, mark_price):
        nonlocal running_peak, total_peak, total_trough, max_dd_total
        ds = dstate(td)
        eq_day = float(ds.get("net", 0.0) or 0.0) + current_float(mark_price)
        if eq_day > float(ds.get("peak_pnl", 0.0) or 0.0):
            ds["peak_pnl"] = eq_day
        if eq_day < float(ds.get("trough_pnl", 0.0) or 0.0):
            ds["trough_pnl"] = eq_day
        if eq_day > float(ds.get("_running_peak", 0.0) or 0.0):
            ds["_running_peak"] = eq_day
        dd = eq_day - float(ds.get("_running_peak", 0.0) or 0.0)
        if dd < float(ds.get("max_dd", 0.0) or 0.0):
            ds["max_dd"] = dd
        eq_total = realized_total + current_float(mark_price)
        total_peak = max(total_peak, eq_total)
        total_trough = min(total_trough, eq_total)
        if eq_total > running_peak:
            running_peak = eq_total
        dd_total = eq_total - running_peak
        if dd_total < max_dd_total:
            max_dd_total = dd_total

    def reset_position_runtime():
        nonlocal pos_peak_points, tp_armed, tp_line
        pos_peak_points = 0.0
        tp_armed = False
        tp_line = 0.0

    def open_position(dt, px, direction, bar, prev_bar, ema_now, reason):
        nonlocal position, entry_px, entry_dt, entry_fee, entry_side, entry_debug
        bar_check_price(px, bar, "進場")
        direction = 1 if direction > 0 else -1
        position = direction * qty
        entry_side = direction
        entry_px = float(px)
        entry_dt = dt
        entry_fee = _ema_fast_fee(strategy_name, code, px) * qty
        ma_value = float(ema_now or 0.0)
        entry_debug = {
            "entry_bar_start": bar.get("start"),
            "bar_high": float(bar.get("high", 0.0) or 0.0),
            "bar_low": float(bar.get("low", 0.0) or 0.0),
            "prev_high": float((prev_bar or {}).get("high", 0.0) or 0.0),
            "prev_low": float((prev_bar or {}).get("low", 0.0) or 0.0),
            "ema": ma_value,
            "ma_algo": avg_label,
            "ma_period": int(period),
            "entry_ma": ma_value,
            "entry_ma_algo": avg_label,
            "entry_ma_period": int(period),
            "entry_sma": ma_value if is_sma else 0.0,
            "entry_ema": ma_value if not is_sma else 0.0,
            "entry_reason": reason,
        }
        reset_position_runtime()

    def close_position(dt, px, event, reason, bar, avg_now=0.0):
        nonlocal position, entry_px, entry_dt, entry_fee, entry_side, realized_total, entry_debug
        if position == 0 or entry_px <= 0:
            return None
        bar_check_price(px, bar, "出場")
        side = 1 if position > 0 else -1
        gross = gross_points(side, entry_px, px) * multiplier * abs(position)
        exit_fee = _ema_fast_fee(strategy_name, code, px) * abs(position)
        fee = entry_fee + exit_fee
        net = gross - fee
        realized_total += net
        td = str(bar.get("trade_date"))
        ds = dstate(td)
        ds["net"] = float(ds.get("net", 0.0) or 0.0) + net
        ds["trades"] = int(ds.get("trades", 0) or 0) + 1
        if net > 0:
            ds["win_trades"] = int(ds.get("win_trades", 0) or 0) + 1
        elif net < 0:
            ds["loss_trades"] = int(ds.get("loss_trades", 0) or 0) + 1
        if "停利" in reason:
            ds["tp"] = int(ds.get("tp", 0) or 0) + 1
        if "停損" in reason:
            ds["sl"] = int(ds.get("sl", 0) or 0) + 1
        if event == "反手平倉":
            ds["reverse"] = int(ds.get("reverse", 0) or 0) + 1
        row = {
            "session": ds["session"], "month": ds.get("month", ""), "product_code": code,
            "entry_time": entry_dt, "exit_time": dt, "side": "做多" if side > 0 else "放空",
            "entry": float(entry_px), "exit": float(px), "event": event, "reason": reason,
            "gross": float(gross), "fee": float(fee), "net": float(net),
        }
        row.update(entry_debug or {})
        exit_ma_value = float(avg_now or 0.0)
        row["exit_ma"] = exit_ma_value
        row["exit_ma_algo"] = avg_label
        row["exit_ma_period"] = int(period)
        row["exit_sma"] = exit_ma_value if is_sma else 0.0
        row["exit_ema"] = exit_ma_value if not is_sma else 0.0
        all_closed.append(row)
        all_records.append(dict(row, closed_trade=True, realized=net, gross_realized=gross, price=float(px)))
        position = 0
        entry_px = 0.0
        entry_dt = None
        entry_fee = 0.0
        entry_side = 0
        entry_debug = {}
        reset_position_runtime()
        return row

    def update_tp_runtime(price):
        nonlocal pos_peak_points, tp_armed, tp_line
        if position == 0 or entry_px <= 0:
            return
        side = 1 if position > 0 else -1
        fp = gross_points(side, entry_px, price)
        if fp > pos_peak_points:
            pos_peak_points = fp
        if tp_points > 0 and (not tp_armed) and pos_peak_points >= tp_points:
            tp_armed = True
        if tp_armed:
            if pos_peak_points <= 800:
                lock_pts = math.floor(pos_peak_points * 0.70)
            elif pos_peak_points <= 1200:
                lock_pts = math.floor(pos_peak_points * 0.80)
            else:
                lock_pts = math.floor(pos_peak_points * 0.90)
            new_line = entry_px + lock_pts if side > 0 else entry_px - lock_pts
            if tp_line == 0:
                tp_line = new_line
            elif side > 0 and new_line > tp_line:
                tp_line = new_line
            elif side < 0 and new_line < tp_line:
                tp_line = new_line

    def _keep_current_bar_pending_only(bar):
        nonlocal pending
        cur_idx = int((bar or {}).get("bar_index") or -1)
        if cur_idx < 0:
            pending = []
            return
        pending = [p for p in list(pending or []) if int(p.get("bar_index") or -999999) == cur_idx]

    def _candidate_still_valid(candidate, price, avg_now):
        if not candidate:
            return False
        direction = 1 if int(candidate.get("direction") or 0) > 0 else -1
        gate = float(candidate.get("gate") or 0.0)
        kind = str(candidate.get("kind") or "")
        price = float(price or 0.0)
        avg_now = float(avg_now or 0.0)
        if price <= 0 or gate <= 0:
            return False
        if kind in ("Cross", "FB", "CloseCross"):
            return bool(price > gate if direction > 0 else price < gate)
        if kind == "IntraFB":
            if avg_now <= 0:
                return False
            return bool((price > avg_now and price > gate) if direction > 0 else (price < avg_now and price < gate))
        return False

    def _winner_is_fresh_fire(winner, price, avg_now, prev_price):
        """判斷 winner 是否為本 tick 新觸發，而不是早已在 gate 外的舊條件。"""
        if winner is None:
            return False
        direction = 1 if int(winner.get("direction") or 0) > 0 else -1
        gate = float(winner.get("gate") or 0.0)
        kind = str(winner.get("kind") or "")
        price = float(price or 0.0)
        avg_now = float(avg_now or 0.0)
        if gate <= 0 or price <= 0:
            return False
        # 本根第一筆/開盤若已經符合進場條件，視為「開盤本來就可進」。
        if prev_price is None:
            return _candidate_still_valid(winner, price, avg_now)
        prev = float(prev_price or 0.0)
        if kind in ("Cross", "FB", "CloseCross"):
            return bool((prev <= gate and price > gate) if direction > 0 else (prev >= gate and price < gate))
        if kind == "IntraFB":
            if avg_now <= 0:
                return False
            now_ok = (price > avg_now and price > gate) if direction > 0 else (price < avg_now and price < gate)
            prev_ok = (prev > avg_now and prev > gate) if direction > 0 else (prev < avg_now and prev < gate)
            return bool(now_ok and not prev_ok)
        return False

    def _remember_same_bar_reentry_candidate(winner, price, avg_now, bar):
        nonlocal same_bar_reentry_candidate
        if winner is None:
            return
        cur_idx = int((bar or {}).get("bar_index") or -1)
        if cur_idx < 0 or int(winner.get("bar_index") or -999999) != cur_idx:
            return
        if not _candidate_still_valid(winner, price, avg_now):
            return
        old = same_bar_reentry_candidate
        if old is None or int(winner.get("seq") or 0) >= int(old.get("seq") or 0):
            same_bar_reentry_candidate = dict(winner)

    def _same_bar_reentry_winner(price, avg_now, bar, prev_bar):
        """停利後同根再進只使用先前已真正 FIRE 的本根候選。

        v052Z：不在停利當下重新 arm/fire。否則價格只要還在前高/前低外，
        就會把停利前已存在的狀態誤當新訊號，形成無條件再進。
        """
        cur_idx = int((bar or {}).get("bar_index") or -1)
        c = same_bar_reentry_candidate
        if cur_idx < 0 or not c:
            return None
        if int(c.get("bar_index") or -999999) != cur_idx:
            return None
        if not _candidate_still_valid(c, price, avg_now):
            return None
        return dict(c)

    def risk_exit_if_needed(dt, price, bar, reverse_winner=None, avg_now=0.0):
        nonlocal pending, last_fired_bar_index, last_fired_arm_seq, same_bar_reentry_candidate
        if position == 0 or entry_px <= 0:
            return False
        update_tp_runtime(price)
        side = 1 if position > 0 else -1
        # 停利/停損是逐 tick 判斷；EMA預設99999，不會干擾訊號測試。
        # 停利後同根再進：只保留「本根K開盤後」建立/成立的價格訊號；
        # 上一根或更早K棒留下的 pending 一律切斷，避免平倉後無條件補進。
        if side > 0:
            if tp_armed and tp_line > 0 and float(price) <= tp_line:
                reentry = _same_bar_reentry_winner(price, avg_now, bar, prev_bar)
                close_position(dt, tp_line, "停利平倉", "停利平倉", bar, avg_now=avg_now)
                if reentry is not None:
                    open_position(dt, price, reentry["direction"], bar, reentry.get("prev_bar"), reentry.get("ema"), _winner_entry_reason(reentry))
                    pending = []
                    last_fired_bar_index = int(bar.get("bar_index") or -1)
                    last_fired_arm_seq = int(reentry.get("seq") or 0)
                else:
                    # 沒有合格候選時不可保留停利前 pending；下一筆必須重新突破才可進場。
                    pending = []
                    same_bar_reentry_candidate = None
                return True
            if sl_points > 0 and float(price) <= entry_px - sl_points:
                if reverse_winner is not None:
                    reverse_reason = _winner_entry_reason(reverse_winner)
                    close_position(dt, price, "反手平倉", reverse_reason, bar, avg_now=avg_now)
                    open_position(dt, price, reverse_winner["direction"], bar, reverse_winner.get("prev_bar"), reverse_winner.get("ema"), reverse_reason)
                    return True
                close_position(dt, entry_px - sl_points, "停損平倉", "停損平倉", bar, avg_now=avg_now)
                return True
        else:
            if tp_armed and tp_line > 0 and float(price) >= tp_line:
                reentry = _same_bar_reentry_winner(price, avg_now, bar, prev_bar)
                close_position(dt, tp_line, "停利平倉", "停利平倉", bar, avg_now=avg_now)
                if reentry is not None:
                    open_position(dt, price, reentry["direction"], bar, reentry.get("prev_bar"), reentry.get("ema"), _winner_entry_reason(reentry))
                    pending = []
                    last_fired_bar_index = int(bar.get("bar_index") or -1)
                    last_fired_arm_seq = int(reentry.get("seq") or 0)
                else:
                    # 沒有合格候選時不可保留停利前 pending；下一筆必須重新突破才可進場。
                    pending = []
                    same_bar_reentry_candidate = None
                return True
            if sl_points > 0 and float(price) >= entry_px + sl_points:
                if reverse_winner is not None:
                    reverse_reason = _winner_entry_reason(reverse_winner)
                    close_position(dt, price, "反手平倉", reverse_reason, bar, avg_now=avg_now)
                    open_position(dt, price, reverse_winner["direction"], bar, reverse_winner.get("prev_bar"), reverse_winner.get("ema"), reverse_reason)
                    return True
                close_position(dt, entry_px + sl_points, "停損平倉", "停損平倉", bar, avg_now=avg_now)
                return True
        return False

    def arm(kind, direction, gate, source, bar_index):
        nonlocal arm_seq, pending
        arm_seq += 1
        direction = 1 if direction > 0 else -1
        pnd = {"kind": kind, "direction": direction, "gate": float(gate or 0.0), "source": source, "seq": arm_seq, "bar_index": int(bar_index)}
        pending = [x for x in pending if x.get("kind") != kind]
        pending.append(pnd)
        return pnd

    def arm_from_intrabar(bar, prev_bar, price, ema_now, cur_high, cur_low):
        if not prev_bar or ema_now <= 0 or not prev_bar.get("ready"):
            return
        prev_avg = float(prev_bar.get("ema", 0.0) or 0.0)
        if prev_avg <= 0:
            return
        label = "%s%d" % (avg_label, period)
        prev_close = float(prev_bar.get("close", 0.0) or 0.0)
        if prev_close < prev_avg and float(price) > float(ema_now):
            arm("Cross", 1, float(prev_bar.get("high", 0.0) or 0.0), label + "｜Cross", bar.get("bar_index", 0))
        elif prev_close > prev_avg and float(price) < float(ema_now):
            arm("Cross", -1, float(prev_bar.get("low", 0.0) or 0.0), label + "｜Cross", bar.get("bar_index", 0))
        if float(prev_bar.get("high", 0.0) or 0.0) > prev_avg and prev_close < prev_avg:
            arm("FB", -1, float(prev_bar.get("low", 0.0) or 0.0), label + "｜FB", bar.get("bar_index", 0))
        elif float(prev_bar.get("low", 0.0) or 0.0) < prev_avg and prev_close > prev_avg:
            arm("FB", 1, float(prev_bar.get("high", 0.0) or 0.0), label + "｜FB", bar.get("bar_index", 0))
        if float(cur_high) > float(ema_now) and float(cur_low) < float(ema_now):
            direction = 1 if float(price) >= float(ema_now) else -1
            gate = float(prev_bar.get("high", 0.0) if direction > 0 else prev_bar.get("low", 0.0))
            arm("IntraFB", direction, gate, label + "｜IntraFB", bar.get("bar_index", 0))

    def arm_close_confirm(bar, prev_bar, prev2_bar):
        if not close_confirm or not prev_bar or not prev2_bar:
            return
        if not prev_bar.get("ready") or not prev2_bar.get("ready"):
            return
        prev_avg = float(prev_bar.get("ema", 0.0) or 0.0)
        prev2_avg = float(prev2_bar.get("ema", 0.0) or 0.0)
        if prev_avg <= 0 or prev2_avg <= 0:
            return
        label = "%s%d" % (avg_label, period)
        # 對齊 strategy_core：n-1/n 收盤穿越，下一根突破 n-1 高/低。
        pending[:] = [x for x in pending if x.get("kind") not in ("CloseCross", "Cross", "FB", "IntraFB")]
        if float(prev2_bar.get("close", 0.0) or 0.0) < prev2_avg and float(prev_bar.get("close", 0.0) or 0.0) > prev_avg:
            arm("CloseCross", 1, float(prev2_bar.get("high", 0.0) or 0.0), label + "｜收盤穿越多｜突破前高", bar.get("bar_index", 0))
        elif float(prev2_bar.get("close", 0.0) or 0.0) > prev2_avg and float(prev_bar.get("close", 0.0) or 0.0) < prev_avg:
            arm("CloseCross", -1, float(prev2_bar.get("low", 0.0) or 0.0), label + "｜收盤穿越空｜跌破前低", bar.get("bar_index", 0))

    def _winner_entry_reason(winner):
        if not winner:
            return "反手"
        kind = str(winner.get("kind") or "")
        direction = int(winner.get("direction") or 0)
        try:
            return strategy_core._direction_reason(kind, direction)
        except Exception:
            return "%s%s" % (kind or "訊號", "多" if direction > 0 else "空")

    def fire_winner(price, ema_now, bar, prev_bar):
        out = []
        for pnd in list(pending or []):
            kind = pnd.get("kind")
            direction = int(pnd.get("direction") or 0)
            gate = float(pnd.get("gate") or 0.0)
            ok = False
            if kind in ("Cross", "FB", "CloseCross"):
                ok = float(price) > gate if direction > 0 else float(price) < gate
            elif kind == "IntraFB":
                ok = (float(price) > float(ema_now) and float(price) > gate) if direction > 0 else (float(price) < float(ema_now) and float(price) < gate)
            if ok:
                q = dict(pnd)
                q["ema"] = float(ema_now or 0.0)
                q["bar"] = bar
                q["prev_bar"] = prev_bar
                out.append(q)
        if not out:
            return None
        winner = max(out, key=lambda x: int(x.get("seq") or 0))
        if last_fired_bar_index == int(bar.get("bar_index") or -1) and last_fired_arm_seq == int(winner.get("seq") or -2):
            return None
        return winner

    prev_bar = (context or {}).get("prev_bar")
    prev2_bar = None
    if prev_bar is None:
        # 快取不足時不慢速暖機，只從第一根完成EMA後接續。
        _safe_progress(progress, 0, total_units, "%s高速快取缺少區間前一根完成K｜將略過直到完成均線可接續" % avg_label)
    for idx, bar in enumerate(bars, start=1):
        td = str(bar.get("trade_date"))
        ds = dstate(td)
        ds["_bar_count"] = int(ds.get("_bar_count", 0) or 0) + 1
        ds["ticks"] = int(ds.get("ticks", 0) or 0) + len(bar.get("ticks") or [])
        cur_high = float(bar.get("open", 0.0) or 0.0)
        cur_low = float(bar.get("open", 0.0) or 0.0)
        same_bar_reentry_candidate = None
        bar_prev_price = None
        if close_confirm:
            arm_close_confirm(bar, prev_bar, prev2_bar)
        # v052R：SMA盤中值 = 前 N-1 根完成K收盤和 + 最新價。
        # 同一根K內前 N-1 根完成收盤不變，先把加總算好，避免每一筆 tick 都 sum(slice)。
        sma_seed_sum = 0.0
        sma_seed_ready = False
        if is_sma:
            if period <= 1:
                sma_seed_ready = True
            elif len(sma_completed_closes) >= period - 1:
                recent_closes = sma_completed_closes[-(period - 1):]
                if len(recent_closes) == period - 1 and min(recent_closes) > 0:
                    sma_seed_sum = sum(recent_closes)
                    sma_seed_ready = True
        for dt, price in list(bar.get("ticks") or []):
            cur_high = max(cur_high, float(price))
            cur_low = min(cur_low, float(price))
            if is_sma:
                if period <= 1:
                    ema_now = float(price)
                elif sma_seed_ready:
                    ema_now = (sma_seed_sum + float(price)) / float(period)
                else:
                    ema_now = 0.0
            elif prev_bar and prev_bar.get("ready") and float(prev_bar.get("ema", 0.0) or 0.0) > 0:
                ema_now = float(price) * alpha + float(prev_bar.get("ema", 0.0) or 0.0) * (1.0 - alpha)
            else:
                ema_now = 0.0
            if ema_now > 0:
                if not close_confirm:
                    arm_from_intrabar(bar, prev_bar, price, ema_now, cur_high, cur_low)
                winner = fire_winner(price, ema_now, bar, prev_bar)
                if winner is not None and not _winner_is_fresh_fire(winner, price, ema_now, bar_prev_price):
                    winner = None
            else:
                winner = None
            reverse = winner if (winner is not None and position != 0 and position * int(winner.get("direction") or 0) < 0) else None
            if winner is not None and position != 0 and position * int(winner.get("direction") or 0) > 0:
                _remember_same_bar_reentry_candidate(winner, price, ema_now, bar)
            if risk_exit_if_needed(dt, price, bar, reverse, avg_now=ema_now):
                update_equity(td, price)
                bar_prev_price = float(price)
                continue
            if winner is not None:
                nonlocal_values = None
                direction = int(winner.get("direction") or 0)
                if position == 0:
                    open_position(dt, price, direction, bar, prev_bar, ema_now, _winner_entry_reason(winner))
                    pending = []
                    last_fired_bar_index = int(bar.get("bar_index") or -1)
                    last_fired_arm_seq = int(winner.get("seq") or 0)
                elif position * direction < 0:
                    reverse_reason = _winner_entry_reason(winner)
                    close_position(dt, price, "反手平倉", reverse_reason, bar, avg_now=ema_now)
                    open_position(dt, price, direction, bar, prev_bar, ema_now, reverse_reason)
                    pending = []
                    last_fired_bar_index = int(bar.get("bar_index") or -1)
                    last_fired_arm_seq = int(winner.get("seq") or 0)
                elif position * direction > 0:
                    # 同向 FIRE 不加碼，但必須視為已用過並清掉 pending，
                    # 避免舊訊號跨 tick / 跨 K 被停利後再進誤吃。
                    pending = []
                    last_fired_bar_index = int(bar.get("bar_index") or -1)
                    last_fired_arm_seq = int(winner.get("seq") or 0)
            update_equity(td, price)
            bar_prev_price = float(price)
        # K棒收盤後，防呆檢查快取EMA與即時計算必須同方向可接續；以快取完成EMA作下一根 prev_ema。
        if not bar.get("ready") or float(bar.get("ema", 0.0) or 0.0) <= 0:
            # 不產生假EMA，也不重置；下一根仍需等待快取 ready。
            pass
        if is_sma and float(bar.get("close", 0.0) or 0.0) > 0:
            sma_completed_closes.append(float(bar.get("close", 0.0) or 0.0))
            if len(sma_completed_closes) > max(2 * period + 10, 50):
                sma_completed_closes = sma_completed_closes[-max(2 * period + 10, 50):]
        prev2_bar = prev_bar
        prev_bar = bar
        if progress is not None and (idx == 1 or idx == total_units or idx % 20 == 0):
            _safe_progress(progress, idx, total_units, "%s高速回測｜%s｜%d/%d 根K｜逐筆僅判斷觸價順序" % (avg_label, td, idx, total_units))

    for td in sorted(day_state.keys()):
        ds = day_state[td]
        ds["minutes"] = "%s/%d根" % (k_minutes_label(k), int(ds.get("_bar_count", 0) or 0))
        ds["hit_20000"] = float(ds.get("net", 0.0) or 0.0) >= 20000
        ds.pop("_running_peak", None)
        ds.pop("_bar_count", None)
        all_day_stats.append(ds)
    _safe_progress(progress, total_units, total_units, "%s高速回測完成｜K棒%d根｜逐筆%d筆只用於觸價順序" % (avg_label, len(bars), int((context or {}).get("tick_count", 0) or 0)))
    return all_day_stats, all_closed, all_records, all_events


def run_ema_txf_fast_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=60, ma_period=20, entry_mode="逐筆洗價", one_way_fee=0.0, progress=None):
    context = build_ema_txf_fast_context_from_session_items(session_items, product_code, k_minutes, ma_period, progress=progress)
    return run_ema_txf_fast_backtest_context(context, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=k_minutes, ma_period=ma_period, entry_mode=entry_mode, one_way_fee=one_way_fee, progress=progress)

def run_sma_txf_fast_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=60, ma_period=20, entry_mode="逐筆洗價", one_way_fee=0.0, progress=None):
    context = build_sma_txf_fast_context_from_session_items(session_items, product_code, k_minutes, ma_period, progress=progress)
    return run_ema_txf_fast_backtest_context(context, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=k_minutes, ma_period=ma_period, entry_mode=entry_mode, one_way_fee=one_way_fee, progress=progress)

def count_cached_ema_txf_kbars_for_code(code, start_date=None, end_date=None, k_minutes=60):
    """估算 EMA高速路徑工作量：用K棒數，不再用逐筆數。"""
    k = normalize_ema_k_minutes(k_minutes)
    preferred = clean_code(code or "TXF")
    try:
        init_ema_txf_cache_db()
        cache_code = resolve_ema_txf_cache_code(preferred, k)
        conn = ema_db_connect()
        try:
            where = ["code=?", "k_minutes=?"]
            args = [cache_code, k]
            d1 = _date_text(start_date) if start_date else ""
            d2 = _date_text(end_date) if end_date else ""
            if d1:
                where.append("trade_date>=?"); args.append(d1)
            if d2:
                where.append("trade_date<=?"); args.append(d2)
            row = conn.execute("SELECT COUNT(*) FROM ema_kbars WHERE " + " AND ".join(where), args).fetchone()
            return int(row[0] or 0) if row else 0
        finally:
            conn.close()
    except Exception:
        return 0


def _ema_fast_estimated_bar_count_from_ticks(ticks, k_minutes, product_code="TXF"):
    seen = set()
    k = normalize_ema_k_minutes(k_minutes)
    code = clean_code(product_code or getattr(ticks[0], "code", "TXF") if ticks else product_code or "TXF")
    for t in list(ticks or []):
        try:
            dt = t.dt
        except Exception:
            try:
                dt = t[0]
            except Exception:
                continue
        ident = _fast_ma_bar_identity(code, dt, k)
        if ident is None:
            continue
        td, bi, _start = ident
        seen.add((td.strftime("%Y-%m-%d"), int(bi)))
    return len(seen)


def run_strategy_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=1, ma_period=3, entry_mode="逐筆洗價", one_way_fee=0.0, progress=None, manual_ema_closes=None):
    if is_fast_ma_strategy(strategy_name):
        if is_sma_strategy(strategy_name):
            return run_sma_txf_fast_backtest_session_items(
                session_items, strategy_name, lots, tp_points, 0.0, 0.0, 0.0, product_code,
                k_minutes=normalize_ema_k_minutes(k_minutes), ma_period=normalize_sma_period(ma_period),
                entry_mode=entry_mode, one_way_fee=one_way_fee, progress=progress,
            )
        return run_ema_txf_fast_backtest_session_items(
            session_items, strategy_name, lots, tp_points, 0.0, 0.0, 0.0, product_code,
            k_minutes=normalize_ema_k_minutes(k_minutes), ma_period=normalize_ema_period(ma_period),
            entry_mode=entry_mode, one_way_fee=one_way_fee, progress=progress,
        )
    if is_fast_ma_strategy(strategy_name):
        loss_exit = 0.0
        lock_profit_exit = 0.0
    # 053F：開盤價策略台指期日盤/夜盤必須完全獨立，不可沿用舊分組或同日合併結果。
    session_items = _force_split_tai_open_price_session_items(session_items, strategy_name, product_code)
    # v052B：EMA台指回測日夜盤合成同一交易日；進場模式與實單一致。
    session_items = _merge_tai_ema_session_items(session_items, strategy_name, product_code)
    all_day_stats = []
    all_closed = []
    all_records = []
    all_events = []
    total_ticks = sum(len(item[1]) for item in list(session_items or [])) or 1
    processed_ticks = 0
    last_progress_tick = 0
    _safe_progress(progress, 0, total_ticks, "準備回測")

    for skey, arr, session_label, month_text, unique_minutes in list(session_items or []):
        if not arr:
            continue
        records = []
        events = []
        feed_count = 0
        peak = 0.0
        trough = 0.0
        max_dd = 0.0
        running_peak = 0.0

        def logger(_text):
            return None

        def record_callback(rec):
            records.append(dict(rec))

        def event_callback(task, key, detail):
            events.append({"session": session_label, "key": key, "detail": detail, "status": getattr(task, "risk_status", "")})

        manager = strategy_core.策略模擬管理器(logger=logger, record_callback=record_callback, event_callback=event_callback)
        manager.set_real_mode(False)
        # v029 熱路徑：回測永遠是模擬、均價由官方逐筆累計得出、UI 同步不需要。
        manager.sync_task = lambda _task: None
        manager._task_real_mode = lambda _task: False
        manager._task_quote_avg_ready = lambda _task, _avg: float(_avg or 0.0) > 0.0
        open_price_mode = bool(is_open_price_strategy(strategy_name))
        session_open_price = float(arr[0][1]) if (open_price_mode and arr) else 0.0
        if open_price_mode:
            _install_open_price_signal_overrides(manager)
        task = build_task(
            strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code,
            one_way_fee=one_way_fee, k_minutes=k_minutes, ma_period=ma_period, entry_mode=entry_mode,
        )
        if is_tai_index_code(product_code) and str(skey or "").split(":")[-1].upper() == "NINE":
            setattr(task, "backtest_tai_session_mode", "九點盤")
        if is_ema_strategy(strategy_name):
            # v052G：EMA回測由歷史 tick 順序自然累積K棒，並可由 ema_txf_cache.db 補暖機；
            # 策略核心不要再啟動實盤用的 tick-history 暖機重建熱路徑。
            setattr(task, "backtest_skip_tick_warmup", True)
        if is_ema_strategy(strategy_name) and manual_ema_closes:
            try:
                if isinstance(manual_ema_closes, dict) and manual_ema_closes.get("__ema_cached_bars__"):
                    _apply_ema_cached_bars_to_manager(manager, task, skey, manual_ema_closes)
                else:
                    seed_closes = manual_ema_closes
                    if isinstance(manual_ema_closes, dict):
                        seed_closes = manual_ema_closes.get(skey) or manual_ema_closes.get(str(skey).split(":", 1)[0]) or []
                    if seed_closes:
                        try:
                            st_seed = manager._state(task)
                            st_seed.session_key = str(skey or "")
                            st_seed.bar_aggregation_signature = manager._bar_aggregation_signature(task)
                        except Exception:
                            pass
                        manager.apply_ema_manual_closes(task, seed_closes)
                        setattr(task, "backtest_ema_seeded_from_cache", True)
            except Exception:
                pass
        def feed(dt, price, avg):
            global _CURRENT_BACKTEST_DT
            nonlocal feed_count, peak, trough, max_dd, running_peak
            _CURRENT_BACKTEST_DT = dt
            signal_avg = session_open_price if open_price_mode and session_open_price > 0 else avg
            task.last_price = price
            task.quote_avg = signal_avg
            manager.on_tick(task, price, signal_avg, dt)
            feed_count += 1
            st = manager.states.get(1)
            v = float(st.total_pnl or 0.0) if st is not None else 0.0
            if v > peak:
                peak = v
            if v < trough:
                trough = v
            if v > running_peak:
                running_peak = v
            dd = v - running_peak
            if dd < max_dd:
                max_dd = dd

        op_boundary = _session_op_boundary_dt(strategy_name, skey)
        op_injected = False
        last_before_op = None
        for dt, price, avg in arr:
            if op_boundary is not None and not op_injected and dt >= op_boundary:
                if last_before_op is not None and last_before_op[0] < op_boundary:
                    feed(op_boundary, last_before_op[1], last_before_op[2])
                op_injected = True
            feed(dt, price, avg)
            if op_boundary is not None and dt < op_boundary:
                last_before_op = (dt, price, avg)
            processed_ticks += 1
            if progress is not None and (processed_ticks - last_progress_tick >= 3000 or processed_ticks == total_ticks):
                last_progress_tick = processed_ticks
                _safe_progress(progress, processed_ticks, total_ticks, "%s｜%s / %s 筆" % (session_label, f"{processed_ticks:,}", f"{total_ticks:,}"))

        st = manager._state(task)
        if int(getattr(st, "position", 0) or 0) != 0:
            last_dt, last_price, last_avg = arr[-1]
            _skey, _slabel, _in_session, force_dt = session_for(strategy_name, last_dt)
            if force_dt and last_dt < force_dt:
                feed(force_dt, last_price, last_avg)

        # 053I：回測明細要能全域檢查進場訊號。
        # strategy_core 的成交紀錄中，「進場」列才有 Cross/FB/IntraFB/OP 的 reason；
        # closed_trade 平倉列只有出場原因。先把進場 reason 依 entry_time+entry_price 對回
        # closed row，讓 GUI/CSV 的進場列能顯示 FB多/FB空，不會看起來像 FB 從未啟動。
        def _entry_reason_key(_dt, _px):
            try:
                _dt2 = _dt if isinstance(_dt, RealDateTime) else parse_dt_text(_dt)
            except Exception:
                _dt2 = None
            if _dt2 is not None:
                _t = _dt2.strftime("%Y-%m-%d %H:%M:%S")
            else:
                _t = str(_dt or "")
            try:
                _p = round(float(_px or 0.0), 4)
            except Exception:
                _p = 0.0
            return (_t, _p)

        entry_reason_map = {}
        for _rec0 in records:
            try:
                if _rec0.get("closed_trade"):
                    continue
                if str(_rec0.get("event", "")) != "進場":
                    continue
                _er = str(_rec0.get("reason", "") or _rec0.get("entry_reason", "") or "")
                if not _er:
                    continue
                _edt = parse_dt_text(_rec0.get("entry_time")) or parse_dt_text(_rec0.get("timestamp"))
                _epx = _rec0.get("entry_price", _rec0.get("price", 0.0))
                entry_reason_map.setdefault(_entry_reason_key(_edt, _epx), []).append(_er)
            except Exception:
                continue

        closed = []
        for rec in records:
            if not rec.get("closed_trade"):
                continue
            exit_dt = parse_dt_text(rec.get("exit_time")) or parse_dt_text(rec.get("timestamp")) or arr[0][0]
            entry_dt = parse_dt_text(rec.get("entry_time")) or exit_dt
            event = str(rec.get("event", ""))
            reason = str(rec.get("reason", ""))
            show_reason = reason or event
            entry_px_val = float(rec.get("entry_price", 0.0) or 0.0)
            _er_key = _entry_reason_key(entry_dt, entry_px_val)
            _er_queue = entry_reason_map.get(_er_key) or []
            entry_reason = ""
            if _er_queue:
                entry_reason = str(_er_queue.pop(0) or "")
            if not entry_reason:
                entry_reason = str(rec.get("entry_reason", "") or rec.get("signal_reason", "") or "")
            row = {
                "session": session_label,
                "month": month_text,
                "product_code": clean_code(product_code),
                "entry_time": entry_dt,
                "exit_time": exit_dt,
                "side": side_from_close_direction(rec.get("direction", "")),
                "entry": entry_px_val,
                "exit": float(rec.get("exit_price", rec.get("price", 0.0)) or 0.0),
                "event": event,
                "reason": show_reason,
                "entry_reason": entry_reason,
                "gross": float(rec.get("gross_realized", 0.0) or 0.0),
                "fee": float(rec.get("fee", 0.0) or 0.0),
                "net": float(rec.get("realized", 0.0) or 0.0),
            }
            if open_price_mode and session_open_price > 0:
                row.update({
                    "entry_ma": float(session_open_price),
                    "exit_ma": float(session_open_price),
                    "entry_ma_algo": "開盤價",
                    "exit_ma_algo": "開盤價",
                    "entry_ma_period": 0,
                    "exit_ma_period": 0,
                })
            closed.append(row)
            all_closed.append(row)

        total_net = sum(x["net"] for x in closed)
        # 053F：停止原因以「本 session 自己」的損益判斷。
        # 不可用同一自然日的日盤損益去推算夜盤，也不可只因明細文字曾出現「認賠」就把該夜盤標成認賠。
        loss_limit_ntd = abs(float(loss_exit or 0.0))
        profit_limit_ntd = abs(float(lock_profit_exit or 0.0))
        session_hit_loss_exit = bool(loss_limit_ntd > 0 and trough <= -loss_limit_ntd)
        session_hit_profit_exit = bool(profit_limit_ntd > 0 and peak >= profit_limit_ntd)
        stop_reason = ""
        if session_hit_loss_exit:
            stop_reason = "認賠下車出場"
        elif session_hit_profit_exit:
            stop_reason = "賺飽下車出場"
        elif events:
            for e in events:
                if e["key"] == "force_flat":
                    stop_reason = "時間到強制出場"

        all_day_stats.append({
            "session": session_label,
            "month": month_text,
            "minutes": unique_minutes,
            "ticks": feed_count,
            "trades": len(closed),
            "win_trades": sum(1 for x in closed if float(x.get("net", 0.0) or 0.0) > 0),
            "loss_trades": sum(1 for x in closed if float(x.get("net", 0.0) or 0.0) < 0),
            "net": total_net,
            "tp": sum(1 for x in closed if "停利" in x["reason"]),
            "sl": sum(1 for x in closed if "停損" in x["reason"]),
            "reverse": sum(1 for x in closed if x["event"] == "反手平倉"),
            "force": sum(1 for x in closed if "時間到" in x["reason"]),
            "loss_exit": 1 if session_hit_loss_exit else 0,
            "profit_exit": 1 if session_hit_profit_exit else 0,
            "max_dd": max_dd,
            "peak_pnl": peak,
            "trough_pnl": trough,
            "hit_profit_exit": session_hit_profit_exit,
            "hit_loss_exit": session_hit_loss_exit,
            "hit_20000": total_net >= 20000,
            "stop_reason": stop_reason,
        })
        all_records.extend(records)
        all_events.extend(events)


    _safe_progress(progress, total_ticks, total_ticks, "回測完成")
    return all_day_stats, all_closed, all_records, all_events


def run_strategy_backtest_ticks(ticks, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=1, ma_period=3, entry_mode="逐筆洗價", one_way_fee=0.0, progress=None, manual_ema_closes=None):
    session_items = _prepare_session_items_from_ticks(ticks)
    return run_strategy_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=k_minutes, ma_period=ma_period, entry_mode=entry_mode, one_way_fee=one_way_fee, progress=progress, manual_ema_closes=manual_ema_closes)

def _backtest_day_count_and_range_static(ds):
    rows = list(ds or [])
    if not rows:
        return 0, "無資料"
    sessions = [str(x.get("session", "")) for x in rows if str(x.get("session", ""))]
    date_texts = []
    for s0 in sessions:
        m = re.search(r"\d{4}-\d{2}-\d{2}", s0)
        if m:
            date_texts.append(m.group(0))
    uniq = sorted(set(date_texts))
    if uniq:
        return len(uniq), "%s～%s" % (uniq[0], uniq[-1])
    return len(rows), ("%s ~ %s" % (sessions[0], sessions[-1])) if sessions else ""


def _average_net_excluding_zero_trade_days_static(ds):
    rows = list(ds or [])
    active = [x for x in rows if int(x.get("trades", 0) or 0) > 0]
    base = active or rows
    if not base:
        return 0.0, 0
    total = sum(float(x.get("net", 0.0) or 0.0) for x in base)
    return total / max(1, len(base)), len(base)


def _average_net_all_backtest_days_static(ds):
    """SMA排行用：平均每日獲利的分母固定採回測期間天數，不剔除0交易日。"""
    rows = list(ds or [])
    if not rows:
        return 0.0, 0
    day_count, _rng = _backtest_day_count_and_range_static(rows)
    day_count = max(1, int(day_count or 0))
    total = sum(float(x.get("net", 0.0) or 0.0) for x in rows)
    return total / day_count, day_count


def _average_net_for_strategy_static(ds, strategy_name):
    if is_fast_ma_strategy(strategy_name):
        # EMA 與 SMA 排行一致：平均每日獲利分母固定用回測區間天數，
        # 不因當天沒有交易而剔除。
        return _average_net_all_backtest_days_static(ds)
    return _average_net_excluding_zero_trade_days_static(ds)


def _day_stats_summary_static(ds):
    rows = list(ds or [])
    if not rows:
        return {"total_days": 0, "range": "無資料"}
    total_days, rng = _backtest_day_count_and_range_static(rows)
    return {"total_days": total_days, "range": rng}


def _summarize_combo_result(ds, tr, params):
    """把單組回測結果壓成排行榜摘要；避免多核心回傳大量每日明細。"""
    strategy_name = str((params or {}).get("strategy_name", "") or "")
    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds)
    avg, valid_days = _average_net_for_strategy_static(ds, strategy_name)
    summary = _day_stats_summary_static(ds)
    peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
    trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
    tp_count = sum(int(x.get("tp", 0) or 0) for x in ds)
    sl_count = sum(int(x.get("sl", 0) or 0) for x in ds)
    rev_count = sum(int(x.get("reverse", 0) or 0) for x in ds)
    loss_exit_count = sum(int(x.get("loss_exit", 0) or 0) for x in ds)
    profit_exit_count = sum(int(x.get("profit_exit", 0) or 0) for x in ds)
    return {
        "strategy": params.get("strategy_name", ""), "status": "完成", "avg": avg, "total": total,
        "valid_days": valid_days, "total_days": summary.get("total_days", 0), "range": summary.get("range", ""),
        "trades": len(tr), "tp": tp_count, "sl": sl_count, "reverse": rev_count,
        "loss_exit_count": loss_exit_count, "profit_exit_count": profit_exit_count,
        "peak": peak, "trough": trough, "params": params,
    }


def _summarize_failed_combo_result(params, err):
    """單一參數組失敗時回傳可排序/可顯示的摘要，避免整批 ProcessPool 直接中斷。"""
    msg = str(err or "").strip() or err.__class__.__name__
    if len(msg) > 180:
        msg = msg[:180] + "..."
    return {
        "strategy": (params or {}).get("strategy_name", ""), "status": "失敗：%s" % msg,
        "avg": -1e18, "total": 0.0, "valid_days": 0, "total_days": 0, "range": "回測失敗",
        "trades": 0, "tp": 0, "sl": 0, "reverse": 0, "loss_exit_count": 0, "profit_exit_count": 0, "peak": 0.0, "trough": 0.0,
        "params": dict(params or {}), "error": msg,
    }


def _combo_params(strategy_name, lots, product_code, combo, k_minutes=1, ma_period=3, entry_mode="逐筆洗價", one_way_fee=0.0):
    combo = tuple(combo or ())
    if len(combo) >= 5:
        combo_ma_period, tp, sl, loss_exit, profit_exit = combo[:5]
        ma_period = combo_ma_period
    else:
        tp, sl, loss_exit, profit_exit = combo
    if is_fast_ma_strategy(strategy_name):
        loss_exit = 0.0
        profit_exit = 0.0
    if not is_param_strategy(strategy_name):
        ma_period = 3
        k_minutes = 1
    return dict(
        strategy_name=strategy_name,
        lots=int(lots or 1),
        tp_points=round(float(tp), 2),
        sl_points=round(float(sl), 2),
        loss_exit=float(loss_exit),
        lock_profit_exit=float(profit_exit),
        product_code=clean_code(product_code or ""),
        ma_period=(normalize_fast_ma_period(ma_period) if is_fast_ma_strategy(strategy_name) else normalize_ma_period(ma_period)),
        k_minutes=(normalize_ema_k_minutes(k_minutes) if is_fast_ma_strategy(strategy_name) else normalize_k_minutes(k_minutes)),
        entry_mode=normalize_entry_mode(entry_mode),
        one_way_fee=max(0.0, float(one_way_fee or 0.0)),
    )


def _pack_ticks_for_worker(ticks):
    """把 dataclass tick 壓成內建型別，避免 Windows ProcessPool pickling 類別失敗。"""
    packed = []
    for t in list(ticks or []):
        try:
            packed.append((t.dt, t.d, float(t.price), float(t.qty), float(t.avg), str(t.code), str(t.month), str(t.session_key), str(t.session_label)))
        except Exception:
            pass
    return packed


def _unpack_ticks_for_worker(rows):
    return [OfficialTick(dt, d, price, qty, avg, code, month, session_key, session_label)
            for dt, d, price, qty, avg, code, month, session_key, session_label in list(rows or [])]


_WORKER_TICKS_CACHE = None
_WORKER_SESSION_ITEMS = None
_WORKER_STRATEGY_NAME = "大股期策略"
_WORKER_LOTS = 1
_WORKER_PRODUCT_CODE = ""
_WORKER_K_MINUTES = 1
_WORKER_MA_PERIOD = 3
_WORKER_ONE_WAY_FEE = 0.0
_WORKER_ENTRY_MODE = "逐筆洗價"
_WORKER_MANUAL_EMA_CLOSES = None


def _init_backtest_worker_from_file(ticks_file, strategy_name, lots, product_code, k_minutes=1, ma_period=3, entry_mode="逐筆洗價", one_way_fee=0.0, manual_ema_closes=None):
    """ProcessPool initializer：每個 worker 只載入一次同商品 ticks。"""
    global _WORKER_TICKS_CACHE, _WORKER_SESSION_ITEMS, _WORKER_STRATEGY_NAME, _WORKER_LOTS, _WORKER_PRODUCT_CODE, _WORKER_K_MINUTES, _WORKER_MA_PERIOD, _WORKER_ONE_WAY_FEE, _WORKER_ENTRY_MODE, _WORKER_MANUAL_EMA_CLOSES
    _WORKER_STRATEGY_NAME = strategy_name or "大股期策略"
    _WORKER_LOTS = int(lots or 1)
    _WORKER_PRODUCT_CODE = clean_code(product_code or "")
    _WORKER_K_MINUTES = normalize_k_minutes(k_minutes)
    _WORKER_MA_PERIOD = normalize_fast_ma_period(ma_period) if is_fast_ma_strategy(_WORKER_STRATEGY_NAME) else normalize_ma_period(ma_period)
    _WORKER_ONE_WAY_FEE = max(0.0, float(one_way_fee or 0.0))
    _WORKER_ENTRY_MODE = normalize_entry_mode(entry_mode)
    if isinstance(manual_ema_closes, dict):
        _WORKER_MANUAL_EMA_CLOSES = manual_ema_closes
    else:
        _WORKER_MANUAL_EMA_CLOSES = list(manual_ema_closes or []) if manual_ema_closes else None
    with open(ticks_file, "rb") as f:
        rows = pickle.load(f)
    # v029：worker 只預分組一次；每一組參數直接重用同一份 session_items。
    _WORKER_TICKS_CACHE = None
    _WORKER_SESSION_ITEMS = _prepare_session_items_from_packed_rows(rows)


def _run_backtest_combo_worker(combo):
    """ProcessPool worker：ticks 已在 initializer 載入，不再每組重複傳輸。"""
    params = _combo_params(_WORKER_STRATEGY_NAME, _WORKER_LOTS, _WORKER_PRODUCT_CODE, combo, k_minutes=_WORKER_K_MINUTES, ma_period=_WORKER_MA_PERIOD, entry_mode=_WORKER_ENTRY_MODE, one_way_fee=_WORKER_ONE_WAY_FEE)
    session_items = _WORKER_SESSION_ITEMS or _prepare_session_items_from_ticks(_WORKER_TICKS_CACHE or [])
    ds, tr, _records, _events = run_strategy_backtest_session_items(session_items, progress=None, manual_ema_closes=_WORKER_MANUAL_EMA_CLOSES, **params)
    return _summarize_combo_result(ds, tr, params)

def _run_backtest_combo_chunk_worker(combos):
    """v029：一個 future 連跑多組，降低 ProcessPool 排程/IPC 成本。v052M：EMA/SMA共用高速K棒上下文。"""
    out = []
    session_items = _WORKER_SESSION_ITEMS or _prepare_session_items_from_ticks(_WORKER_TICKS_CACHE or [])
    fast_context_cache = {}
    for combo in list(combos or []):
        params = _combo_params(_WORKER_STRATEGY_NAME, _WORKER_LOTS, _WORKER_PRODUCT_CODE, combo, k_minutes=_WORKER_K_MINUTES, ma_period=_WORKER_MA_PERIOD, entry_mode=_WORKER_ENTRY_MODE, one_way_fee=_WORKER_ONE_WAY_FEE)
        try:
            if is_fast_ma_strategy(_WORKER_STRATEGY_NAME):
                ckey = (
                    ma_algo_label(_WORKER_STRATEGY_NAME),
                    int(params.get("k_minutes", _WORKER_K_MINUTES) or _WORKER_K_MINUTES),
                    int(params.get("ma_period", _WORKER_MA_PERIOD) or _WORKER_MA_PERIOD),
                )
                ctx = fast_context_cache.get(ckey)
                if ctx is None:
                    if is_sma_strategy(_WORKER_STRATEGY_NAME):
                        ctx = build_sma_txf_fast_context_from_session_items(session_items, _WORKER_PRODUCT_CODE, ckey[1], ckey[2], progress=None)
                    else:
                        ctx = build_ema_txf_fast_context_from_session_items(session_items, _WORKER_PRODUCT_CODE, ckey[1], ckey[2], progress=None)
                    fast_context_cache[ckey] = ctx
                ds, tr, _records, _events = run_ema_txf_fast_backtest_context(ctx, progress=None, **params)
            else:
                ds, tr, _records, _events = run_strategy_backtest_session_items(session_items, progress=None, manual_ema_closes=_WORKER_MANUAL_EMA_CLOSES, **params)
            out.append(_summarize_combo_result(ds, tr, params))
        except Exception as e:
            out.append(_summarize_failed_combo_result(params, e))
    return out


def _run_backtest_combo_chunk(payload):
    """舊入口保留相容；新版群組回測改用 initializer，避免每批重複傳 ticks。"""
    ticks = payload.get("ticks") or []
    combos = payload.get("combos") or []
    strategy_name = payload.get("strategy_name") or "大股期策略"
    lots = int(payload.get("lots") or 1)
    code = clean_code(payload.get("product_code") or "")
    out = []
    for combo in combos:
        params = _combo_params(strategy_name, lots, code, combo, k_minutes=payload.get("k_minutes", 1), ma_period=payload.get("ma_period", 3), entry_mode=payload.get("entry_mode", "逐筆洗價"), one_way_fee=payload.get("one_way_fee", 0.0))
        ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, progress=None, manual_ema_closes=payload.get("manual_ema_closes"), **params)
        out.append(_summarize_combo_result(ds, tr, params))
    return out


def _adaptive_parallel_workers(requested_workers, combo_count, tick_count):
    """避免少量參數卻開太多 process，造成大量 tick 複製與啟動成本。"""
    requested_workers = max(1, int(requested_workers or 1))
    combo_count = max(1, int(combo_count or 1))
    tick_count = max(0, int(tick_count or 0))
    if combo_count <= 1 or requested_workers <= 1:
        return 1
    # v030 追求最快：大多數情況盡量照使用者指定核心跑；只在組數明顯少於核心時縮小。
    if combo_count <= 4:
        return max(1, min(requested_workers, combo_count))
    if combo_count <= 12:
        return max(1, min(requested_workers, combo_count, max(4, requested_workers)))
    return max(1, min(requested_workers, combo_count))


def _terminate_process_pool(executor):
    """取消時主動終止已在跑的 worker；比等待 as_completed 回來快很多。"""
    if executor is None:
        return
    # Python 3.14+ 有正式 API；Python 3.11 走底層 _processes。
    for method_name in ("terminate_workers", "kill_workers"):
        method = getattr(executor, method_name, None)
        if callable(method):
            try:
                method()
                return
            except Exception:
                pass
    try:
        procs = getattr(executor, "_processes", None) or {}
        for proc in list(procs.values()):
            try:
                if proc.is_alive():
                    proc.terminate()
            except Exception:
                pass
        # terminate 可能對正在純 CPU 迴圈的 Windows 子行程不夠即時，再補 kill。
        deadline = time_module.time() + 0.8
        while time_module.time() < deadline:
            alive = []
            for proc in list(procs.values()):
                try:
                    if proc.is_alive():
                        alive.append(proc)
                except Exception:
                    pass
            if not alive:
                break
            time_module.sleep(0.05)
        for proc in list(procs.values()):
            try:
                if proc.is_alive():
                    proc.kill()
            except Exception:
                pass
    except Exception:
        pass


def _force_exit_current_process_tree():
    """關閉視窗時使用：殺掉目前 Python 與其 ProcessPool 子行程。

    這只在使用者關閉整個面板時呼叫；一般「取消」不會殺掉主程式。
    """
    if os.name == "nt":
        try:
            creationflags = 0x08000000  # CREATE_NO_WINDOW
            subprocess.Popen(
                ["taskkill", "/PID", str(os.getpid()), "/T", "/F"],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                close_fds=True, creationflags=creationflags,
            )
            return True
        except Exception:
            return False
    return False


def _chunk_list_even(items, parts):
    items = list(items or [])
    parts = max(1, int(parts or 1))
    if not items:
        return []
    parts = min(parts, len(items))
    base = len(items) // parts
    extra = len(items) % parts
    chunks = []
    start = 0
    for i in range(parts):
        n = base + (1 if i < extra else 0)
        chunk = items[start:start+n]
        if chunk:
            chunks.append(chunk)
        start += n
    return chunks

class App:
    def __init__(self, root):
        self.root = root
        self.ui_settings = load_ui_settings()
        root.title(f"小火車回測器 {APP_VERSION}（小火車/開盤價/EMA/SMA策略）")
        saved_root_geo = self.get_setting("geometry.root", "")
        self._apply_safe_root_geometry(saved_root_geo)
        try:
            root.protocol("WM_DELETE_WINDOW", self.on_close)
        except Exception:
            pass
        self.file_text = StringVar(value="")
        self.strategy = StringVar(value="大股期策略")  # 舊單組相容用；實際回測由 strategy_mode + 商品類型解析。
        self.strategy_mode = StringVar(value=str(self.get_setting("defaults.strategy_mode", TRAIN_STRATEGY_DISPLAY) or TRAIN_STRATEGY_DISPLAY))
        if self.strategy_mode.get() not in STRATEGY_MODE_VALUES:
            old_mode_text = str(self.strategy_mode.get() or "")
            self.strategy_mode.set(OPEN_PRICE_STRATEGY_DISPLAY if is_open_price_strategy(old_mode_text) else (SMA_STRATEGY_DISPLAY if is_sma_strategy(old_mode_text) else (EMA_STRATEGY_DISPLAY if is_ema_strategy(old_mode_text) else TRAIN_STRATEGY_DISPLAY)))
        self.ma_period_text = StringVar(value=str(self.get_setting("defaults.ma_period", "3") or "3"))
        self.k_minutes_text = StringVar(value=str(self.get_setting("defaults.k_minutes", "1") or "1"))
        self.entry_mode = StringVar(value=normalize_entry_mode(self.get_setting("defaults.entry_mode", "逐筆洗價")))
        self.stock_size_mode = StringVar(value=str(self.get_setting("defaults.stock_size_mode", "大股期") or "大股期"))
        if self.stock_size_mode.get() not in STOCK_SIZE_MODE_VALUES:
            self.stock_size_mode.set("大股期")
        self.tai_session_mode = StringVar(value=normalize_tai_session_mode(self.get_setting("defaults.tai_session_mode", "日盤")))
        self.tai_margin_text = StringVar(value=str(self.get_setting("defaults.tai_margin", "") or ""))
        self.result_filter_text = StringVar(value="總表")
        self.result_filter_code_map = {}
        self.product_keyword = StringVar(value="")
        self.product_choice = StringVar(value="")
        self.lots = IntVar(value=int(self.get_setting("defaults.lots", 1) or 1))
        self.one_way_fee_text = StringVar(value="0")  # v041：手續費固定自動計算；舊設定不再沿用。v042：認賠/賺飽依新台幣淨損益判斷。
        self.tp_points = DoubleVar(value=5.0)
        self.sl_points = DoubleVar(value=0.0)
        self.loss_exit = DoubleVar(value=30000)
        self.lock_profit_exit = DoubleVar(value=25000)
        self.margin = DoubleVar(value=110000)
        self.ratio_text = StringVar(value="")  # 保留給舊函式相容；v019 介面不再使用保證金比例測試。
        self.date_start_text = StringVar(value="")
        self.date_end_text = StringVar(value="")
        self.opt_start_text = StringVar(value="")  # 保留給舊函式相容；v019 介面不再顯示找最佳/驗證。
        self.opt_end_text = StringVar(value="")
        self.valid_start_text = StringVar(value="")
        self.valid_end_text = StringVar(value="")
        self.tp_start_text = StringVar(value=str(self.get_setting("defaults.tp_start", "5") or "5"))
        self.tp_end_text = StringVar(value=str(self.get_setting("defaults.tp_end", "20") or "20"))
        self.tp_step_text = StringVar(value=str(self.get_setting("defaults.tp_step", "1") or "1"))
        self.sl_start_text = StringVar(value=str(self.get_setting("defaults.sl_start", "10") or "10"))
        self.sl_end_text = StringVar(value=str(self.get_setting("defaults.sl_end", "10") or "10"))
        self.sl_step_text = StringVar(value=str(self.get_setting("defaults.sl_step", "1") or "1"))
        self.no_tp_var = IntVar(value=1 if str(self.get_setting("defaults.no_tp", "0")).strip().lower() in ("1", "true", "yes", "on", "是", "y") else 0)
        self.no_sl_var = IntVar(value=1 if str(self.get_setting("defaults.no_sl", "0")).strip().lower() in ("1", "true", "yes", "on", "是", "y") else 0)
        self.loss_start_text = StringVar(value=str(self.get_setting("defaults.loss_start", "30000") or "30000"))
        self.loss_end_text = StringVar(value=str(self.get_setting("defaults.loss_end", "45000") or "45000"))
        self.loss_step_text = StringVar(value=str(self.get_setting("defaults.loss_step", "2500") or "2500"))
        self.profit_start_text = StringVar(value=str(self.get_setting("defaults.profit_start", "30000") or "30000"))
        self.profit_end_text = StringVar(value=str(self.get_setting("defaults.profit_end", "45000") or "45000"))
        self.profit_step_text = StringVar(value=str(self.get_setting("defaults.profit_step", "2500") or "2500"))
        self.sma_start_text = StringVar(value=str(self.get_setting("defaults.sma_start", "20") or "20"))
        self.sma_end_text = StringVar(value=str(self.get_setting("defaults.sma_end", "20") or "20"))
        self.sma_step_text = StringVar(value=str(self.get_setting("defaults.sma_step", "1") or "1"))
        self.cpu_workers_text = StringVar(value=self._initial_cpu_workers_text())
        self.estimate_text = StringVar(value="預估：請先加入待回測商品並設定範圍")
        self.ratio_preview = StringVar(value="")
        self.margin_info = StringVar(value="尚未更新期交所保證金資料")
        self.margin_master = load_cached_margin_master()
        self.paths = []
        self.raw_options = []
        self.options = []
        self.option_map = {}
        self.primary_month_by_file_code = {}
        self.ticks = []
        self.selected_code = ""
        self.last_day_stats = []
        self.last_trades = []
        self.last_sweep = []
        self.last_optimize = []
        self.last_group_results = []
        self.result_row_map = {}
        self.result_detail_cache = {}
        self.backtest_group = []
        self.backtest_group_codes = set()
        self.group_summary_text = StringVar(value="待回測商品：0 檔")
        # v052T：資料日期摘要會查 SQLite；快取起來，避免啟動、切換策略、輸入保證金時反覆查庫造成 UI 卡頓。
        self._product_dates_text_cache = {}
        self.product_dialog = None
        self.product_combo = None
        self.group_tree = None
        self.product_status = None
        self.sweep_row_map = {}
        self.busy = False
        self.busy_action = ""
        self.cancel_requested = False
        self.pause_requested = False
        self._active_executor = None
        self._active_executor_lock = threading.Lock()
        self.action_widgets = []
        self.lock_widgets = []
        self.build_ui()
        try:
            self._upgrade_legacy_no_tp_sl_flags()
        except Exception as exc:
            log_startup("Upgrade no TP/SL flags failed: %s" % exc)
        try:
            # v040：若使用者已輸入過四項停利參數，不再於啟動時覆蓋；首次使用才套用預設範圍。
            if not bool(self.get_setting("defaults.param_texts_saved", False)):
                self.apply_stock_size_defaults()
        except Exception as exc:
            log_startup("Apply startup default ranges failed: %s" % exc)
        try:
            self.root.after(50, self.force_window_visible)
            self.root.after(1200, self.force_window_visible)
        except Exception:
            pass
        try:
            # v052V：啟動時不立即開 SQLite/建索引，只排程讀摘要快取，避免打開視窗卡一陣子。
            self.root.after(250, self.load_cache_products_on_start)
            self.root.after(3000, lambda: self.check_online_update(silent=True))
        except Exception as exc:
            log_startup("Startup schedule failed: %s" % exc)

    def get_setting(self, key, default=None):
        try:
            cur = self.ui_settings
            for part in str(key).split("."):
                if not isinstance(cur, dict) or part not in cur:
                    return default
                cur = cur[part]
            return cur
        except Exception:
            return default

    def set_setting(self, key, value):
        try:
            cur = self.ui_settings
            parts = str(key).split(".")
            for part in parts[:-1]:
                cur = cur.setdefault(part, {})
            cur[parts[-1]] = value
        except Exception:
            pass

    def _apply_safe_root_geometry(self, saved_root_geo=""):
        geo = str(saved_root_geo or "").strip()
        ok = False
        try:
            if geo and _geometry_is_visible_on_screen(self.root, geo):
                self.root.geometry(geo)
                ok = True
            else:
                self.root.geometry(_default_root_geometry(self.root))
                if geo:
                    self.set_setting("geometry.root", "")
                    log_startup("Reset off-screen root geometry: %s" % geo)
        except Exception as exc:
            try:
                self.root.geometry(_default_root_geometry(self.root))
            except Exception:
                pass
            log_startup("Root geometry fallback: %s" % exc)
        if (not geo) or (not ok):
            try:
                self.root.state("zoomed")
            except Exception:
                pass

    def force_window_visible(self):
        """Bring the main window back on screen after AnyDesk/RDP resolution changes."""
        try:
            if str(self.root.state()) == "iconic":
                self.root.state("normal")
        except Exception:
            pass
        try:
            self.root.update_idletasks()
        except Exception:
            pass
        try:
            geo = self.root.geometry()
            if not _geometry_is_visible_on_screen(self.root, geo):
                self.root.geometry(_default_root_geometry(self.root))
                self.set_setting("geometry.root", "")
                log_startup("Force visible reset geometry: %s" % geo)
        except Exception:
            pass
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass
        try:
            self.root.attributes("-topmost", True)
            self.root.after(900, lambda: self.root.attributes("-topmost", False))
        except Exception:
            pass

    def save_settings(self):
        save_ui_settings(self.ui_settings)

    def _param_preset_key(self):
        product_mode = str(self.stock_size_mode.get() or "大股期").strip()
        suffix = "tai" if product_mode == "台指期" else ("small" if product_mode == "小股期" else "big")
        if self.is_sma_mode():
            return "sma_" + suffix
        if self.is_ema_mode():
            return "ema_" + suffix
        if self.is_three_ma_mode():
            return "three_ma_" + suffix
        if self.is_open_price_mode():
            return "open_price_" + suffix
        return "train_" + suffix

    def _current_param_texts(self):
        return {
            "tp_start": str(self.tp_start_text.get() or ""),
            "tp_end": str(self.tp_end_text.get() or ""),
            "tp_step": str(self.tp_step_text.get() or ""),
            "sl_start": str(self.sl_start_text.get() or ""),
            "sl_end": str(self.sl_end_text.get() or ""),
            "sl_step": str(self.sl_step_text.get() or ""),
            "loss_start": str(self.loss_start_text.get() or ""),
            "loss_end": str(self.loss_end_text.get() or ""),
            "loss_step": str(self.loss_step_text.get() or ""),
            "profit_start": str(self.profit_start_text.get() or ""),
            "profit_end": str(self.profit_end_text.get() or ""),
            "profit_step": str(self.profit_step_text.get() or ""),
            "sma_start": str(self.sma_start_text.get() or ""),
            "sma_end": str(self.sma_end_text.get() or ""),
            "sma_step": str(self.sma_step_text.get() or ""),
            "no_tp": bool(self.no_tp_enabled()) if hasattr(self, "no_tp_var") else False,
            "no_sl": bool(self.no_sl_enabled()) if hasattr(self, "no_sl_var") else False,
        }

    def save_current_param_texts(self):
        try:
            data = self._current_param_texts()
            for k, v in data.items():
                self.set_setting("defaults." + k, v)
            self.set_setting("defaults.lots", int(self.lots.get() or 1))
            self.set_setting("defaults.tai_margin", str(self.tai_margin_text.get() or ""))
            self.set_setting("defaults.param_texts_saved", True)
            self.set_setting("param_presets." + self._param_preset_key(), data)
            self.save_settings()
        except Exception:
            pass

    def _load_param_preset(self, key):
        data = self.get_setting("param_presets." + str(key), None)
        if not isinstance(data, dict):
            return False
        mapping = {
            "tp_start": self.tp_start_text, "tp_end": self.tp_end_text, "tp_step": self.tp_step_text,
            "sl_start": self.sl_start_text, "sl_end": self.sl_end_text, "sl_step": self.sl_step_text,
            "loss_start": self.loss_start_text, "loss_end": self.loss_end_text, "loss_step": self.loss_step_text,
            "profit_start": self.profit_start_text, "profit_end": self.profit_end_text, "profit_step": self.profit_step_text,
            "sma_start": self.sma_start_text, "sma_end": self.sma_end_text, "sma_step": self.sma_step_text,
        }
        for k, var in mapping.items():
            if k in data:
                var.set(str(data.get(k) or ""))
        def _as_bool(v):
            return str(v).strip().lower() in ("1", "true", "yes", "on", "是", "y")
        try:
            key_text = str(key or "").lower()
            if hasattr(self, "no_tp_var"):
                if "no_tp" in data:
                    self.no_tp_var.set(1 if _as_bool(data.get("no_tp")) else 0)
                elif key_text.startswith(("ema_", "sma_")) and str(data.get("tp_start", "")).strip() == "99999" and str(data.get("tp_end", "")).strip() == "99999":
                    self.no_tp_var.set(1)
                elif "no_tp" not in data:
                    self.no_tp_var.set(0)
            if hasattr(self, "no_sl_var"):
                if "no_sl" in data:
                    self.no_sl_var.set(1 if _as_bool(data.get("no_sl")) else 0)
                elif key_text.startswith(("ema_", "sma_")) and str(data.get("sl_start", "")).strip() == "99999" and str(data.get("sl_end", "")).strip() == "99999":
                    self.no_sl_var.set(1)
                elif "no_sl" not in data:
                    self.no_sl_var.set(0)
        except Exception:
            pass
        return True

    def one_way_fee_value(self):
        """v041：回測手續費固定自動計算。

        傳 0 給 strategy_core，核心會依商品種類與每筆進出成交價
        自動計算單邊車票費；進場扣一次、平倉再扣一次。
        舊版 defaults.one_way_fee 僅保留相容，不再參與回測。
        """
        return 0.0

    def no_tp_enabled(self):
        try:
            return bool(int(self.no_tp_var.get() or 0))
        except Exception:
            return False

    def no_sl_enabled(self):
        try:
            return bool(int(self.no_sl_var.get() or 0))
        except Exception:
            return False

    def on_no_tp_sl_changed(self):
        try:
            self._update_strategy_parameter_controls()
        except Exception:
            pass
        try:
            self.mark_estimate_dirty()
        except Exception:
            pass
        try:
            self.save_current_param_texts()
        except Exception:
            pass

    def _upgrade_legacy_no_tp_sl_flags(self):
        """v052W：舊版 EMA/SMA 用 99999 代表實質不停利/不停損，更新後自動轉成勾選狀態。"""
        if not self.is_fast_ma_mode():
            return
        try:
            if (not self.no_tp_enabled()) and str(self.tp_start_text.get() or "").strip() == "99999" and str(self.tp_end_text.get() or "").strip() == "99999":
                self.no_tp_var.set(1)
            if (not self.no_sl_enabled()) and str(self.sl_start_text.get() or "").strip() == "99999" and str(self.sl_end_text.get() or "").strip() == "99999":
                self.no_sl_var.set(1)
            self._update_strategy_parameter_controls()
        except Exception:
            pass

    def save_root_geometry(self):
        try:
            geo = self.root.geometry()
            if _geometry_is_visible_on_screen(self.root, geo):
                self.set_setting("geometry.root", geo)
            else:
                self.set_setting("geometry.root", "")
            self.save_settings()
        except Exception:
            pass

    def on_close(self):
        # v051：關閉視窗時一律完整結束 Python。
        # 即使沒有正在回測，Tk after callback / 背景掃描 thread / ProcessPool 管理器也可能讓
        # 工作管理員殘留 python.exe / pythonw.exe；所以先保存設定、停止 executor，再強制結束程序樹。
        self.cancel_requested = True
        self.pause_requested = False
        try:
            self.save_current_param_texts()
            self.save_all_column_widths()
            self.save_root_geometry()
        except Exception:
            pass
        try:
            self._cancel_active_executor()
        except Exception:
            pass
        try:
            self.info.configure(text="正在關閉：已停止背景回測與 Python。", foreground="red")
            self.root.update_idletasks()
        except Exception:
            pass
        try:
            self.root.quit()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass
        # Windows 用 taskkill /T /F 連同子行程一起清；非 Windows 或 taskkill 失敗則 os._exit。
        if _force_exit_current_process_tree():
            return
        try:
            os._exit(0)
        except Exception:
            pass

    def apply_dialog_geometry(self, win, key, default_geo=None):
        geo = self.get_setting("geometry." + key, "")
        try:
            if geo and _geometry_is_visible_on_screen(win, geo):
                win.geometry(geo)
            elif default_geo:
                win.geometry(default_geo)
            else:
                win.geometry(_default_root_geometry(win, 1000, 700))
        except Exception:
            pass
        try:
            win.after(80, lambda: (win.deiconify(), win.lift(), win.focus_force()))
        except Exception:
            pass
        def _save(event=None):
            if event is not None and getattr(event, "widget", None) is not win:
                return
            try:
                geo_now = win.geometry()
                if _geometry_is_visible_on_screen(win, geo_now):
                    self.set_setting("geometry." + key, geo_now)
                else:
                    self.set_setting("geometry." + key, "")
                self.save_settings()
            except Exception:
                pass
        try:
            win.bind("<Destroy>", _save, add="+")
        except Exception:
            pass

    def save_tree_column_widths(self, tree):
        key = getattr(tree, "_settings_key", "")
        if not key:
            return
        try:
            data = {col: int(tree.column(col, "width") or 0) for col in list(tree["columns"])}
            self.set_setting("columns." + key, data)
            try:
                self.set_setting("column_order." + key, list(tree["displaycolumns"]))
            except Exception:
                pass
            self.save_settings()
        except Exception:
            pass

    def enable_tree_column_drag(self, tree):
        tree._drag_col = None
        def displayed_cols():
            cols = list(tree["displaycolumns"])
            if not cols or cols == ["#all"]:
                cols = list(tree["columns"])
            return cols
        def col_from_event(event):
            try:
                if tree.identify_region(event.x, event.y) != "heading":
                    return None
                col_id = tree.identify_column(event.x)
                if not col_id.startswith("#"):
                    return None
                idx = int(col_id[1:]) - 1
                cols = displayed_cols()
                if 0 <= idx < len(cols):
                    return cols[idx]
            except Exception:
                return None
            return None
        def start(event):
            tree._drag_col = col_from_event(event)
        def motion(event):
            src = getattr(tree, "_drag_col", None)
            dst = col_from_event(event)
            if not src or not dst or src == dst:
                return
            cols = displayed_cols()
            if src not in cols or dst not in cols:
                return
            cols.remove(src)
            cols.insert(cols.index(dst), src)
            tree["displaycolumns"] = cols
        def end(event):
            if getattr(tree, "_drag_col", None):
                self.save_tree_column_widths(tree)
            tree._drag_col = None
        try:
            tree.bind("<ButtonPress-1>", start, add="+")
            tree.bind("<B1-Motion>", motion, add="+")
            tree.bind("<ButtonRelease-1>", end, add="+")
        except Exception:
            pass

    def save_all_column_widths(self):
        for name in ("result_tree", "summary_tree", "detail_tree", "sweep_tree", "optimize_tree"):
            tree = getattr(self, name, None)
            if tree is not None:
                self.save_tree_column_widths(tree)

    def available_trade_dates_for_code(self, code):
        code = clean_code(code)
        if not code or not cache_has_code(code):
            return []
        return cached_trade_dates_for_code(code, session_mode=("全部" if (self.is_fast_ma_mode() and is_tai_index_code(code)) else (self.get_tai_session_mode() if is_tai_index_code(code) else "全部")))

    def apply_sma_database_date_defaults(self):
        """v052V：SMA/EMA策略預設起訖日帶入目前回測目標的資料庫實際範圍。

        台指期仍使用 TXF/TX 日夜盤；股期保留目前大股期/小股期商品群組，不再強制改 TXF。
        """
        try:
            if not self.is_fast_ma_mode():
                return False
            codes = []
            if self.is_tai_product_mode():
                base = self._tai_data_code() if hasattr(self, "_tai_data_code") else "TXF"
                for c in (base, "TXF", "TX"):
                    c = clean_code(c)
                    if c and c not in codes:
                        codes.append(c)
            else:
                targets = list(getattr(self, "backtest_group", []) or [])
                if not targets:
                    try:
                        cur = self.current_product_option()
                    except Exception:
                        cur = None
                    if cur is not None:
                        targets = [cur]
                for opt in targets:
                    c = clean_code(getattr(opt, "code", opt))
                    if c and c not in codes:
                        codes.append(c)
            for code in codes:
                dates = self.available_trade_dates_for_code(code)
                if dates:
                    self.date_start_text.set(_date_text(dates[0]))
                    self.date_end_text.set(_date_text(dates[-1]))
                    return True
            return False
        except Exception:
            return False

    def resolve_date_range_for_code(self, code, start_var, end_var, label="回測"):
        d1 = _date_from_text(str(start_var.get() or "").strip()) if str(start_var.get() or "").strip() else None
        d2 = _date_from_text(str(end_var.get() or "").strip()) if str(end_var.get() or "").strip() else None
        if str(start_var.get() or "").strip() and not d1:
            raise ValueError("%s起日格式錯誤，請用 YYYY-MM-DD。" % label)
        if str(end_var.get() or "").strip() and not d2:
            raise ValueError("%s迄日格式錯誤，請用 YYYY-MM-DD。" % label)
        if d1 and d2 and d1 > d2:
            raise ValueError("%s起日不可晚於迄日。" % label)
        dates = self.available_trade_dates_for_code(code)
        notes = []
        if dates:
            if d1 and d1 not in dates:
                cand = [d for d in dates if d >= d1]
                nd = cand[0] if cand else dates[-1]
                notes.append("%s起日 %s 無資料，已改用 %s" % (label, _date_text(d1), _date_text(nd)))
                d1 = nd
                try: start_var.set(_date_text(d1))
                except Exception: pass
            if d2 and d2 not in dates:
                cand = [d for d in dates if d <= d2]
                nd = cand[-1] if cand else dates[0]
                notes.append("%s迄日 %s 無資料，已改用 %s" % (label, _date_text(d2), _date_text(nd)))
                d2 = nd
                try: end_var.set(_date_text(d2))
                except Exception: pass
            if d1 and d2 and d1 > d2:
                # 起迄修正後仍交錯時，縮成最近同一天，避免空資料。
                nd = d1 if d1 in dates else dates[0]
                d2 = nd
                try: end_var.set(_date_text(d2))
                except Exception: pass
                notes.append("%s日期區間無交集，已縮成 %s" % (label, _date_text(nd)))
        if notes:
            try:
                self.info.configure(text="｜".join(notes), foreground="#B00020")
            except Exception:
                pass
            try:
                messagebox.showinfo("日期已自動修正", "\n".join(notes))
            except Exception:
                pass
        return d1, d2, notes

    @staticmethod
    def ticks_date_range_text(ticks):
        dates = sorted(set((_date_from_text(str(t.session_key).split(":")[0]) or t.d) for t in ticks))
        dates = [d for d in dates if d]
        if not dates:
            return "無資料", 0
        return "%s～%s" % (_date_text(dates[0]), _date_text(dates[-1])), len(dates)

    @staticmethod
    def day_stats_summary(ds):
        sessions = [str(x.get("session", "")) for x in ds]
        date_texts = []
        for s0 in sessions:
            m = re.search(r"\d{4}-\d{2}-\d{2}", s0)
            if m:
                date_texts.append(m.group(0))
        uniq = sorted(set(date_texts))
        total_days = len(uniq) if uniq else len(ds)
        valid = [x for x in ds if float(x.get("trades", 0) or 0) > 0]
        valid_days = len(valid)
        rng = "%s～%s" % (uniq[0], uniq[-1]) if uniq else "無資料"
        return {"range": rng, "total_days": total_days, "valid_days": valid_days, "valid_stats": valid}

    @staticmethod
    def average_net_excluding_zero_trade_days(ds):
        valid = [x for x in ds if float(x.get("trades", 0) or 0) > 0]
        if not valid:
            return 0.0, 0
        return sum(float(x.get("net", 0.0) or 0.0) for x in valid) / len(valid), len(valid)

    @staticmethod
    def average_net_all_backtest_days(ds):
        return _average_net_all_backtest_days_static(ds)

    @staticmethod
    def average_net_for_strategy(ds, strategy_name):
        return _average_net_for_strategy_static(ds, strategy_name)

    def open_date_picker(self, var, title="選擇日期"):
        base = _date_from_text(var.get()) or date.today()
        win = Toplevel(self.root)
        win.title(title)
        self.apply_dialog_geometry(win, "date_picker", "360x320")
        cur = {"year": base.year, "month": base.month}
        head = ttk.Frame(win, padding=8)
        head.pack(fill="x")
        body = ttk.Frame(win, padding=8)
        body.pack(fill=BOTH, expand=True)
        title_var = StringVar(value="")
        def draw():
            for w in body.winfo_children():
                w.destroy()
            y, m = cur["year"], cur["month"]
            title_var.set("%04d-%02d" % (y, m))
            week_names = ["一", "二", "三", "四", "五", "六", "日"]
            for c, name in enumerate(week_names):
                ttk.Label(body, text=name, anchor="center").grid(row=0, column=c, sticky="nsew", padx=2, pady=2)
            first = date(y, m, 1)
            if m == 12:
                next_month = date(y+1, 1, 1)
            else:
                next_month = date(y, m+1, 1)
            days = (next_month - first).days
            r = 1
            c = first.weekday()
            for day in range(1, days+1):
                d = date(y, m, day)
                def pick(dd=d):
                    var.set(_date_text(dd))
                    try: win.destroy()
                    except Exception: pass
                ttk.Button(body, text=str(day), command=pick, width=4).grid(row=r, column=c, sticky="nsew", padx=2, pady=2)
                c += 1
                if c >= 7:
                    c = 0
                    r += 1
            for cc in range(7):
                body.columnconfigure(cc, weight=1)
        def prev_month():
            if cur["month"] == 1:
                cur["year"] -= 1; cur["month"] = 12
            else:
                cur["month"] -= 1
            draw()
        def next_month():
            if cur["month"] == 12:
                cur["year"] += 1; cur["month"] = 1
            else:
                cur["month"] += 1
            draw()
        ttk.Button(head, text="<", command=prev_month, width=4).pack(side="left")
        ttk.Label(head, textvariable=title_var, anchor="center").pack(side="left", fill="x", expand=True)
        ttk.Button(head, text=">", command=next_month, width=4).pack(side="left")
        bottom = ttk.Frame(win, padding=(8, 0, 8, 8))
        bottom.pack(fill="x")
        ttk.Button(bottom, text="清空", command=lambda: (var.set(""), win.destroy())).pack(side="left")
        ttk.Button(bottom, text="今天", command=lambda: (var.set(_date_text(date.today())), win.destroy())).pack(side="right")
        draw()

    def on_root_configure(self, event=None):
        try:
            width = max(520, int(self.root.winfo_width()) - 60)
            if hasattr(self, "estimate_label"):
                self.estimate_label.configure(wraplength=width)
            if hasattr(self, "info"):
                self.info.configure(wraplength=width)
            if hasattr(self, "group_summary_label"):
                self._refresh_group_summary_wrap()
        except Exception:
            pass

    def _refresh_group_summary_wrap(self):
        try:
            lbl = getattr(self, "group_summary_label", None)
            if lbl is None or not lbl.winfo_exists():
                return
            root_w = max(820, int(self.root.winfo_width() or 1200))
            btn_w = 340
            frame = getattr(self, "product_button_frame", None)
            if frame is not None and frame.winfo_exists():
                try:
                    frame.update_idletasks()
                except Exception:
                    pass
                btn_w = max(300, int(frame.winfo_reqwidth() or 0) + 60)
            # 保留右側操作鍵與邊距，摘要寬度不足時直接換行，不推擠按鈕。
            lbl.configure(wraplength=max(320, root_w - btn_w - 80))
        except Exception:
            pass

    def product_name_text(self, opt_or_code):
        opt = None
        if isinstance(opt_or_code, ProductOption):
            opt = opt_or_code
        else:
            code = clean_code(str(opt_or_code or ""))
            for o in self.options:
                if clean_code(o.code) == code:
                    opt = o
                    break
        if not opt:
            code0 = clean_code(str(opt_or_code or ""))
            return "台指期大台" if is_tai_index_code(code0) else code0
        if is_tai_index_code(getattr(opt, "code", "")) or str(getattr(opt, "product_kind", "") or "") == "台指期":
            return "台指期大台"
        name = str(getattr(opt, "stock_name", "") or "").strip()
        if name:
            if not name.endswith("期貨"):
                name = name + "期貨"
            return name
        return clean_code(str(getattr(opt, "code", "") or opt_or_code or ""))

    def option_title(self, opt_or_code):
        # 介面顯示只保留中文商品名稱；商品代號仍保留在內部供查詢與回測。
        return self.product_name_text(opt_or_code)

    def _set_active_executor(self, executor):
        try:
            with self._active_executor_lock:
                self._active_executor = executor
        except Exception:
            self._active_executor = executor

    def _cancel_active_executor(self):
        try:
            with self._active_executor_lock:
                ex = self._active_executor
        except Exception:
            ex = getattr(self, "_active_executor", None)
        if ex is not None:
            try:
                _terminate_process_pool(ex)
            except Exception:
                pass
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                try:
                    ex.shutdown(wait=False)
                except Exception:
                    pass
            except Exception:
                pass

    def request_cancel(self):
        if self.busy:
            self.cancel_requested = True
            self._cancel_active_executor()
            try:
                self.info.configure(text="取消中：%s｜正在停止回測核心，不等待整批跑完" % self.busy_action, foreground="red")
            except Exception:
                pass

    def toggle_pause(self):
        if not self.busy:
            return
        self.pause_requested = not bool(self.pause_requested)
        try:
            self.pause_btn.configure(text="繼續" if self.pause_requested else "暫停")
            self.info.configure(text=("已暫停：" if self.pause_requested else "繼續執行：") + self.busy_action, foreground="red")
        except Exception:
            pass

    def register_lock_widget(self, widget):
        self.lock_widgets.append(widget)
        return widget

    def action_button(self, parent, text, command, **pack_kwargs):
        btn = ttk.Button(parent, text=text, command=command)
        self.action_widgets.append(btn)
        self.lock_widgets.append(btn)
        btn.pack(**pack_kwargs)
        return btn

    @staticmethod
    def _format_seconds(seconds):
        try:
            seconds = int(max(0, float(seconds)))
        except Exception:
            seconds = 0
        if seconds < 60:
            return "%d秒" % seconds
        minutes, sec = divmod(seconds, 60)
        if minutes < 60:
            return "%d分%02d秒" % (minutes, sec)
        hours, minutes = divmod(minutes, 60)
        return "%d小時%02d分" % (hours, minutes)

    def progress_update(self, current, total, detail="", stage="回測運算"):
        if not self.busy:
            return
        while bool(getattr(self, "pause_requested", False)) and not bool(getattr(self, "cancel_requested", False)):
            time_module.sleep(0.2)
        if bool(getattr(self, "cancel_requested", False)):
            raise OperationCancelled("使用者已取消本次背景作業")
        now = time_module.time()
        if now - getattr(self, "_last_progress_update", 0.0) < 0.85 and float(current or 0) < float(total or 1):
            return
        self._last_progress_update = now
        start = getattr(self, "progress_start", now) or now
        elapsed = max(0.0, now - start)
        total = max(1.0, float(total or 1))
        current = max(0.0, min(float(current or 0), total))
        ratio = current / total
        percent = ratio * 100.0
        if ratio >= 0.999:
            eta_text = "0秒"
        elif elapsed < 3.0 or ratio <= 0.005:
            eta_text = "正在即時估算..."
        else:
            remaining = elapsed * (1.0 - ratio) / max(ratio, 0.0001)
            eta_text = self._format_seconds(remaining)
        msg = "背景執行中：%s｜%s｜%s %.1f%%｜即時剩餘 %s" % (self.busy_action, str(detail or "處理中"), str(stage or "回測運算"), percent, eta_text)
        def _apply():
            if self.busy:
                try:
                    self.info.configure(text=msg, foreground="red")
                except Exception:
                    pass
                try:
                    if getattr(self, "progress_bar", None) is not None:
                        self.progress_bar.configure(value=percent)
                except Exception:
                    pass
        try:
            self.root.after(0, _apply)
        except Exception:
            pass

    def status_update(self, detail, foreground="red"):
        msg = str(detail or "")
        def _apply():
            if self.busy:
                try:
                    self.info.configure(text=msg, foreground=foreground)
                except Exception:
                    pass
        try:
            self.root.after(0, _apply)
        except Exception:
            pass

    def set_busy(self, busy, action=""):
        self.busy = bool(busy)
        self.busy_action = str(action or "")
        if self.busy:
            self.progress_start = time_module.time()
            self._last_progress_update = 0.0
            self.cancel_requested = False
            self.pause_requested = False
        else:
            self._set_active_executor(None)
        state = "disabled" if self.busy else "normal"
        for widget in self.lock_widgets:
            try:
                # Combobox 在忙碌結束後恢復 readonly；其他 widget 恢復 normal。
                if not self.busy and isinstance(widget, ttk.Combobox):
                    widget.configure(state="readonly")
                else:
                    widget.configure(state=state)
            except Exception:
                pass
        try:
            if not self.busy:
                self._update_strategy_parameter_controls()
        except Exception:
            pass
        try:
            if hasattr(self, "pause_btn"):
                self.pause_btn.configure(state=("normal" if self.busy else "disabled"), text="暫停")
            if hasattr(self, "cancel_btn"):
                self.cancel_btn.configure(state=("normal" if self.busy else "disabled"))
        except Exception:
            pass
        try:
            self.root.configure(cursor="watch" if self.busy else "")
        except Exception:
            pass
        if self.busy:
            self.info.configure(text="背景執行中：%s，請稍候。" % self.busy_action, foreground="red")
            try:
                if getattr(self, "progress_bar", None) is not None:
                    self.progress_bar.configure(value=0)
            except Exception:
                pass
        else:
            try:
                self.info.configure(foreground="#333333")
            except Exception:
                pass
            try:
                if getattr(self, "progress_bar", None) is not None:
                    self.progress_bar.configure(value=0)
            except Exception:
                pass
        self.root.update_idletasks()

    def _should_show_backtest_done_popup(self, action):
        """回測類背景作業成功完成後，跳出提醒；取消/失敗/非回測作業不提醒。"""
        text = str(action or "")
        if not text or "載入該列" in text:
            return False
        return any(key in text for key in ("回測", "精跑", "比例測試", "最佳化熱門商品"))

    def _backtest_done_popup_text(self, action, result):
        """依不同回測結果組成簡短完成訊息；失敗時回傳通用文字。"""
        lines = ["%s已完成。" % str(action or "回測")]
        try:
            if isinstance(result, dict):
                products = int(result.get("products", 0) or 0)
                jobs = int(result.get("jobs", 0) or 0)
                elapsed = float(result.get("elapsed", 0.0) or 0.0)
                if products > 0:
                    lines.append("商品：%d 檔" % products)
                if jobs > 0:
                    lines.append("完成組數：%s 組" % f"{jobs:,}")
                if elapsed > 0:
                    lines.append("耗時：%s" % self._format_seconds(elapsed))
                return "\n".join(lines)

            if isinstance(result, tuple) and len(result) >= 4:
                code = result[0]
                ds = result[2] if isinstance(result[2], list) else []
                tr = result[3] if isinstance(result[3], list) else []
                if ds:
                    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds if isinstance(x, dict))
                    avg, valid_days = self.average_net_for_strategy(ds, str(self.strategy.get() or ""))
                    summary = self.day_stats_summary(ds)
                    lines.append("商品：%s" % self.option_title(code))
                    lines.append("區間：%s｜有效 %d 天" % (summary.get("range", ""), valid_days))
                    lines.append("總淨利：%s 元｜平均每日：%s 元" % (format_money_plain(total), format_money_plain(avg)))
                    lines.append("平倉次數：%d" % len(tr))
                    return "\n".join(lines)

            if isinstance(result, list):
                lines.append("結果筆數：%s" % f"{len(result):,}")
                return "\n".join(lines)
        except Exception:
            pass
        return "\n".join(lines)

    def _show_backtest_done_popup(self, action, result):
        try:
            messagebox.showinfo("回測完成", self._backtest_done_popup_text(action, result))
        except Exception:
            pass

    def run_background(self, action, worker, on_done):
        if self.busy:
            messagebox.showinfo("背景執行中", "目前正在執行：%s，請等它完成。" % self.busy_action)
            return
        self.set_busy(True, action)

        def _thread_main():
            try:
                result = worker()
                error = None
            except Exception as exc:
                result = None
                error = exc

            def _finish():
                success = False
                try:
                    if error is not None:
                        if isinstance(error, OperationCancelled):
                            self.info.configure(text="已取消：%s｜已完成的畫面結果保留，不寫入新結果。" % action, foreground="red")
                        else:
                            messagebox.showerror("%s失敗" % action, str(error))
                    else:
                        on_done(result)
                        success = True
                finally:
                    self.set_busy(False)
                if success and self._should_show_backtest_done_popup(action):
                    self._show_backtest_done_popup(action, result)

            try:
                self.root.after(0, _finish)
            except Exception:
                # 視窗已關閉時，不讓背景 thread 繼續拖住 python。
                try:
                    self._cancel_active_executor()
                except Exception:
                    pass

        threading.Thread(target=_thread_main, daemon=True).start()

    def _find_online_update_manifest(self):
        urls = backtester_update_manifest_urls()
        if not urls:
            return {"status": "no_url", "errors": []}
        errors = []
        for url in urls:
            try:
                manifest = fetch_update_manifest(url)
                app_name = str(manifest.get("app") or manifest.get("name") or "").strip()
                if app_name and app_name not in ("TrainBacktester", "小火車回測器", "train_backtester"):
                    raise ValueError("manifest app 不符：%s" % app_name)
                version = str(manifest.get("version") or "").strip()
                if not version:
                    raise ValueError("manifest 缺少 version")
                if _is_newer_version(version, APP_VERSION):
                    return {"status": "update", "manifest": manifest, "manifest_url": url}
                return {"status": "latest", "manifest": manifest, "manifest_url": url}
            except Exception as exc:
                errors.append("%s -> %s" % (url, exc))
                log_startup("Update check failed: %s -> %s" % (url, exc))
        return {"status": "failed", "errors": errors}

    def _update_prompt_text(self, manifest):
        version = str((manifest or {}).get("version") or "").strip()
        title = str((manifest or {}).get("title") or "小火車回測器線上更新").strip()
        message = str((manifest or {}).get("message") or (manifest or {}).get("notes") or "").strip()
        required = bool((manifest or {}).get("required", False))
        lines = [
            "%s" % title,
            "目前版本：%s" % APP_VERSION,
            "線上版本：%s" % version,
        ]
        if required:
            lines.append("此更新標記為必要更新。")
        if message:
            lines.append("")
            lines.append(message)
        lines.append("")
        lines.append("是否立即下載並套用？套用完成後會自動關閉並重開小火車回測器。")
        return "\n".join(lines)

    def _schedule_restart_after_update(self):
        """線上更新完成後，啟動新的回測面板，再關閉目前舊行程。"""
        target_dir = app_dir()
        try:
            self.save_current_param_texts()
            self.save_all_column_widths()
            self.save_root_geometry()
        except Exception:
            pass

        if os.name == "nt":
            try:
                bat_path = os.path.join(tempfile.gettempdir(), "restart_train_backtester_after_update_%s.bat" % os.getpid())
                vbs_path = os.path.join(target_dir, "start_backtester.vbs")
                pyw_path = os.path.join(target_dir, "train_backtester.pyw")
                py_path = os.path.join(target_dir, "train_backtester.py")
                lines = [
                    "@echo off",
                    "setlocal",
                    "cd /d \"%s\"" % target_dir,
                    "timeout /t 1 /nobreak >nul",
                    "if exist \"%s\" (" % vbs_path,
                    "  wscript.exe \"%s\"" % vbs_path,
                    ") else if exist \"%s\" (" % pyw_path,
                    "  start \"\" pyw -3.11 \"%s\"" % pyw_path,
                    ") else (",
                    "  start \"\" py -3.11 \"%s\"" % py_path,
                    ")",
                    "del \"%~f0\" >nul 2>nul",
                    "exit /b 0",
                ]
                with open(bat_path, "w", encoding="mbcs", errors="ignore") as f:
                    f.write("\r\n".join(lines) + "\r\n")
                creationflags = 0x08000000  # CREATE_NO_WINDOW
                subprocess.Popen(["cmd", "/c", bat_path], cwd=target_dir,
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 close_fds=True, creationflags=creationflags)
                return True
            except Exception as exc:
                log_startup("Restart after update scheduling failed: %s" % exc)
                return False

        try:
            target = os.path.join(target_dir, "train_backtester.pyw")
            if not os.path.exists(target):
                target = os.path.join(target_dir, "train_backtester.py")
            subprocess.Popen([sys.executable, target], cwd=target_dir, start_new_session=True)
            return True
        except Exception as exc:
            log_startup("Restart after update scheduling failed: %s" % exc)
            return False

    def restart_after_online_update(self):
        if bool(getattr(self, "_restart_in_progress", False)):
            return
        self._restart_in_progress = True
        ok = self._schedule_restart_after_update()
        if not ok:
            try:
                messagebox.showwarning("自動重開失敗", "線上更新已套用，但自動重開失敗。請手動關閉並重新開啟小火車回測器。")
            except Exception:
                pass
            return
        try:
            self.info.configure(text="線上更新已完成｜正在關閉並自動重開小火車回測器...", foreground="#B00020")
            self.root.update_idletasks()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass
        try:
            os._exit(0)
        except Exception:
            pass

    def _prompt_apply_online_update(self, manifest, manifest_url, startup=False):
        if bool(getattr(self, "busy", False)) and str(getattr(self, "busy_action", "")) != "檢查線上更新":
            # 回測運算中不打斷；等使用者手動按檢查更新。
            if not startup:
                messagebox.showinfo("背景執行中", "目前正在執行：%s，請完成或取消後再更新。" % self.busy_action)
            return
        try:
            ok = messagebox.askyesno("發現小火車回測器更新", self._update_prompt_text(manifest))
        except Exception:
            ok = False
        if ok:
            self.root.after(50, lambda: self.apply_online_update(manifest, manifest_url))

    def check_online_update(self, silent=False):
        """檢查小火車回測器線上更新。silent=True 用於啟動後自動檢查。"""
        if silent:
            def _thread_main():
                try:
                    result = self._find_online_update_manifest()
                    if result.get("status") == "update":
                        self.root.after(0, lambda: self._prompt_apply_online_update(result.get("manifest"), result.get("manifest_url"), startup=True))
                except Exception as exc:
                    log_startup("Silent update check failed: %s" % exc)
            try:
                threading.Thread(target=_thread_main, daemon=True).start()
            except Exception:
                pass
            return

        def worker():
            return self._find_online_update_manifest()

        def done(result):
            status = (result or {}).get("status")
            if status == "update":
                self.info.configure(text="發現線上更新｜目前%s → 線上%s" % (APP_VERSION, str((result.get("manifest") or {}).get("version") or "")), foreground="#B00020")
                self._prompt_apply_online_update(result.get("manifest"), result.get("manifest_url"), startup=False)
            elif status == "latest":
                self.info.configure(text="小火車回測器已是最新版：%s" % APP_VERSION, foreground="#333333")
                messagebox.showinfo("檢查線上更新", "目前已是最新版：%s" % APP_VERSION)
            elif status == "no_url":
                messagebox.showinfo(
                    "尚未設定更新網址",
                    "請在小火車回測器資料夾建立或編輯 %s，放入 backtester_update.json 的網址。\n\n"
                    "也可用環境變數 TRAIN_BACKTESTER_UPDATE_MANIFEST_URL 指定。" % BACKTESTER_UPDATE_URL_FILE,
                )
            else:
                detail = "\n".join((result or {}).get("errors") or [])
                if len(detail) > 1600:
                    detail = detail[:1600] + "\n..."
                messagebox.showerror("檢查線上更新失敗", detail or "無法讀取線上更新資訊。")

        self.run_background("檢查線上更新", worker, done)

    def apply_online_update(self, manifest, manifest_url):
        if not manifest or not manifest_url:
            messagebox.showerror("線上更新失敗", "缺少更新資訊。")
            return

        def worker():
            return download_and_apply_update_manifest(manifest, manifest_url, progress=self.progress_update)

        def done(result):
            files = (result or {}).get("updated_files") or []
            backup = (result or {}).get("backup_dir") or ""
            self.info.configure(text="線上更新已套用｜%d個檔案｜準備自動重開小火車回測器" % len(files), foreground="#B00020")
            msg = "線上更新已完成。\n\n已更新檔案：%d 個\n備份位置：%s\n\n按確定後會自動關閉並重開小火車回測器，讓新版生效。" % (len(files), backup or "未建立")
            messagebox.showinfo("線上更新完成", msg)
            try:
                self.root.after(100, self.restart_after_online_update)
            except Exception:
                self.restart_after_online_update()

        self.run_background("下載並套用線上更新", worker, done)

    def margin_items(self):
        try:
            return dict(self.margin_master.get("items", {}) or {})
        except Exception:
            return {}

    def margin_item_for(self, code):
        return self.margin_items().get(clean_code(code), {})

    def enrich_options(self, options):
        items = self.margin_items()
        enriched = []
        for opt in options:
            code0 = clean_code(opt.code)
            item = items.get(code0, {}) if items else {}
            if is_tai_index_code(code0):
                opt.product_kind = "台指期"
                opt.stock_no = "TXF"
                opt.stock_name = "台指期大台"
                opt.margin_percent = 0.0
                opt.base_margin = self.tai_margin_value()
                opt.display = self.product_display_text(opt)
                enriched.append(opt)
                continue
            # 期交所保證金資料存在時，只納入股票期貨，並排除台積電/聯電。
            if items:
                if not item:
                    continue
                if item.get("is_excluded_underlying") or item.get("stock_no") in EXCLUDE_UNDERLYING_STOCKS:
                    continue
            if item:
                opt.product_kind = "小股期" if item.get("is_small") else "大股期"
                opt.stock_no = str(item.get("stock_no", ""))
                opt.stock_name = str(item.get("short_name") or item.get("stock_name") or "")
                opt.margin_percent = float(item.get("initial_margin_percent", 0.0) or 0.0)
                multiplier = product_multiplier_from_master_item(item)
                opt.base_margin = margin_base_from_price(opt.last_price, opt.margin_percent, multiplier)
            else:
                opt.product_kind = "UNKNOWN"
                opt.base_margin = 0.0
            opt.display = self.product_display_text(opt)
            enriched.append(opt)
        return enriched

    def product_display_text(self, opt):
        d1 = opt.date_start.strftime("%Y-%m-%d") if opt.date_start else ""
        d2 = opt.date_end.strftime("%Y-%m-%d") if opt.date_end else ""
        miss_count = len([x for x in str(opt.missing_dates or "").split("、") if x.strip()])
        try:
            ignored_count = len([d for d in tai_nonweekend_missing_dates_from_cache(include_ignored=True) if d in load_ignored_missing_dates()]) if is_tai_index_code(getattr(opt, "code", "")) else 0
        except Exception:
            ignored_count = 0
        kind = opt.product_kind if opt.product_kind != "UNKNOWN" else "未分類"
        if str(getattr(opt, "product_kind", "") or "") == "台指期":
            margin = "原始保證金約%s元" % safe_int_text(opt.base_margin) if opt.base_margin else "台指保證金未輸入"
        else:
            margin = "約%s元" % safe_int_text(opt.base_margin) if opt.base_margin else "保證金待更新"
        rank = int(getattr(opt, "hot_rank", 0) or 0)
        status = str(getattr(opt, "hot_status", "") or "")
        rank_text = "#%d%s｜" % (rank, status) if rank > 0 else ""
        name = self.product_name_text(opt)
        ignored_text = "｜休市忽略%d天" % ignored_count if ignored_count else ""
        return "%s%s｜%s｜%s天｜平均每日成交量%s口｜%s～%s｜缺%d天%s｜%s" % (
            rank_text, name, kind, opt.data_days,
            f"{opt.avg_daily_qty:,.0f}", d1, d2, miss_count, ignored_text, margin
        )

    def current_option(self):
        return self.option_map.get(self.product_choice.get())

    def update_margin_text_for_option(self, opt):
        if not opt:
            source_date = self.margin_master.get("source_date", "") if isinstance(self.margin_master, dict) else ""
            if source_date:
                self.margin_info.set("期交所股票期貨保證金資料日期：%s" % source_date)
            else:
                self.margin_info.set("尚未更新期交所保證金資料，請先按「更新期交所保證金資料」。")
            return
        d1 = opt.date_start.strftime("%Y-%m-%d") if opt.date_start else ""
        d2 = opt.date_end.strftime("%Y-%m-%d") if opt.date_end else ""
        missing = opt.missing_dates or "無"
        if len(missing) > 80:
            missing = missing[:80] + "..."
        source_date = self.margin_master.get("source_date", "") if isinstance(self.margin_master, dict) else ""
        if str(getattr(opt, "product_kind", "") or "") == "台指期" or is_tai_index_code(getattr(opt, "code", "")):
            dates_text = self.product_data_dates_text(opt)
            self.margin_info.set(
                "商品資料狀態：%s｜台指期｜資料：%s｜手動原始保證金約%s元" % (
                    self.product_name_text(opt), dates_text, self.tai_margin_display_text()
                )
            )
            return
        rank = int(getattr(opt, "hot_rank", 0) or 0)
        status = str(getattr(opt, "hot_status", "") or "")
        rank_text = "｜熱門排名：#%d %s" % (rank, status) if rank > 0 else "｜熱門排名：未進前15"
        self.margin_info.set(
            "商品資料狀態：%s｜%s%s｜日盤資料%d天｜期交所日期%s～%s｜缺少日期：%s｜最新價%.2f｜保證金資料%s｜基準原始保證金約%s元" % (
                self.product_name_text(opt), opt.product_kind, rank_text, opt.data_days, d1, d2, missing, opt.last_price or 0.0,
                source_date or "未更新", safe_int_text(opt.base_margin)
            )
        )

    def update_ratio_preview(self):
        opt = self.current_option()
        ratio_text = str(self.ratio_text.get() or "").strip()
        if not opt:
            self.ratio_preview.set("請先選擇商品")
            return
        if not opt.base_margin:
            self.ratio_preview.set("缺少期交所保證金資料或商品最新價，無法換算。")
            return
        item = self.margin_item_for(opt.code)
        multiplier = product_multiplier_from_master_item(item, self.strategy.get())
        if not ratio_text:
            r1, r2 = 5.0, 15.0
            tp1 = opt.base_margin / r1
            tp2 = opt.base_margin / r2
            self.ratio_preview.set("空白=測試 1/5～1/15｜停利約 %s～%s 元｜%s 約 %.2f～%.2f 點" % (
                safe_int_text(tp1), safe_int_text(tp2), opt.product_kind, tp1 / multiplier, tp2 / multiplier
            ))
            return
        try:
            ratio = float(ratio_text)
            if ratio <= 0:
                raise ValueError()
        except Exception:
            self.ratio_preview.set("分母請輸入正數，例如 5、10、15。")
            return
        tp_ntd = opt.base_margin / ratio
        tp_points = tp_ntd / multiplier
        self.ratio_preview.set("1/%g｜停利約 %s 元｜%s %.2f 點｜認賠預設可設 %.0f 元｜賺飽預設可設 %.0f 元" % (
            ratio, safe_int_text(tp_ntd), opt.product_kind, tp_points, tp_ntd * 3.0, tp_ntd * 2.0
        ))

    def update_margin_master(self):
        def worker():
            return download_taifex_stock_margin_master()
        def done(master):
            self.margin_master = master
            if self.raw_options:
                self.options = self.enrich_options(self.raw_options)
                self._product_dates_text_cache = {}
                self.apply_hot_ranks()
                save_product_summary_cache(self.options)
                self.filter_products()
            count = len(master.get("items", {}) or {})
            self.info.configure(text="期交所股票期貨保證金資料更新完成｜資料日期：%s｜商品數：%d" % (master.get("source_date", ""), count))
            self.update_margin_text_for_option(self.current_option())
            self.update_ratio_preview()
        self.run_background("更新期交所保證金資料", worker, done)

    def hot_rankings(self):
        big = [o for o in self.options if o.product_kind == "大股期"]
        small = [o for o in self.options if o.product_kind == "小股期"]
        big.sort(key=lambda o: o.avg_daily_qty, reverse=True)
        small.sort(key=lambda o: o.avg_daily_qty, reverse=True)
        return big[:15], small[:15]

    def apply_hot_ranks(self):
        """將大股期/小股期熱門排名寫回商品顯示文字。
        每類第1~10名為正式熱門；第11~15名為觀察緩衝。
        """
        for opt in self.options:
            try:
                opt.hot_rank = 0
                opt.hot_status = ""
            except Exception:
                pass
        big = [o for o in self.options if o.product_kind == "大股期"]
        small = [o for o in self.options if o.product_kind == "小股期"]
        for group in (big, small):
            group.sort(key=lambda o: o.avg_daily_qty, reverse=True)
            for i, opt in enumerate(group[:15], start=1):
                opt.hot_rank = i
                opt.hot_status = "前10" if i <= 10 else "觀察"
        for opt in self.options:
            opt.display = self.product_display_text(opt)

    def open_hot_ranking(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「更新期交所保證金資料」，再按「重整商品清單/排名」。")
            return
        win = Toplevel(self.root)
        win.title("股票期貨熱門商品排名｜大股期/小股期")
        self.apply_dialog_geometry(win, "hot_ranking", "1250x760")
        note = ttk.Label(win, text="規則：只納入股票期貨；台積電、聯電自動跳過；每類第1～10名為正式熱門，第11～15名為觀察緩衝。可在此一鍵加入待回測群組，再回主畫面刪除不用的商品。", anchor="w")
        note.pack(fill="x", padx=10, pady=(10, 4))
        nb = ttk.Notebook(win)
        nb.pack(fill=BOTH, expand=True, padx=10, pady=8)
        big, small = self.hot_rankings()
        self._build_rank_tab(nb, "大股期前10＋緩衝15", big)
        self._build_rank_tab(nb, "小股期前10＋緩衝15", small)

    def _build_rank_tab(self, notebook, title, options):
        frame = ttk.Frame(notebook)
        notebook.add(frame, text=title)
        btnbar = ttk.Frame(frame)
        btnbar.pack(fill="x", padx=4, pady=(4, 4))
        option_by_iid = {}
        ttk.Button(btnbar, text="加入選取到待回測", command=lambda: self.add_hot_tree_selection_to_group(tree, option_by_iid, title + "選取")).pack(side="left", padx=(0, 6))
        ttk.Button(btnbar, text="加入本頁前10", command=lambda opts=list(options[:10]): self.add_options_to_group(opts, title + "前10")).pack(side="left", padx=6)
        ttk.Button(btnbar, text="加入本頁全部15", command=lambda opts=list(options): self.add_options_to_group(opts, title + "全部15")).pack(side="left", padx=6)
        ttk.Label(btnbar, text="提示：可先加入前10或全部15，再回主畫面刪除不用的。雙擊單列也會加入該商品。", foreground="#555555").pack(side="left", padx=12)
        cols = [
            ("rank", "排名", 60), ("status", "狀態", 90), ("code", "商品代號", 90),
            ("name", "商品", 160), ("avg_qty", "平均每日成交量", 140),
            ("days", "資料天數", 90), ("range", "日期範圍", 190), ("missing", "缺少日期", 250),
            ("margin", "基準原始保證金", 140), ("tp5", "1/5停利", 110), ("point", "點數", 90)
        ]
        tree = self.make_tree(frame, cols, settings_key="hot_" + title)
        for i, opt in enumerate(options, start=1):
            status = "前10" if i <= 10 else "觀察"
            d1 = opt.date_start.strftime("%Y-%m-%d") if opt.date_start else ""
            d2 = opt.date_end.strftime("%Y-%m-%d") if opt.date_end else ""
            tp5 = (opt.base_margin or 0.0) / 5.0 if opt.base_margin else 0.0
            item = self.margin_item_for(opt.code)
            mult = product_multiplier_from_master_item(item, self.strategy.get())
            points = tp5 / mult if mult else 0.0
            iid = tree.insert("", END, values=(i, status, opt.code, opt.stock_name, f"{opt.avg_daily_qty:,.0f}", opt.data_days,
                                               "%s～%s" % (d1, d2), opt.missing_dates or "無", safe_int_text(opt.base_margin),
                                               safe_int_text(tp5), "%.2f" % points))
            option_by_iid[iid] = opt
        tree.bind("<Double-1>", lambda _e: self.add_hot_tree_selection_to_group(tree, option_by_iid, title + "雙擊"), add="+")

    def build_ui(self):
        style = ttk.Style()
        try:
            base_font = tkfont.nametofont("TkDefaultFont")
            base_font.configure(family="Microsoft JhengHei UI", size=11)
            tkfont.nametofont("TkTextFont").configure(family="Microsoft JhengHei UI", size=11)
            tkfont.nametofont("TkHeadingFont").configure(family="Microsoft JhengHei UI", size=11, weight="bold")
        except Exception:
            pass
        try:
            style.configure("Treeview", rowheight=30, font=("Microsoft JhengHei UI", 10))
            style.configure("Treeview.Heading", font=("Microsoft JhengHei UI", 10, "bold"))
            style.map("Treeview", foreground=[], background=[("selected", "#DCEBFF")])
        except Exception:
            pass

        top = ttk.Frame(self.root, padding=8)
        top.pack(fill="x")

        # v021：右側控制鍵固定靠右，避免視窗寬度不足時「取消」被擠出畫面。
        top_right = ttk.Frame(top)
        top_right.pack(side="right", padx=(8, 0))
        self.cancel_btn = ttk.Button(top_right, text="取消", command=self.request_cancel, state="disabled", width=8)
        self.cancel_btn.pack(side="right", padx=(3, 0))
        self.pause_btn = ttk.Button(top_right, text="暫停", command=self.toggle_pause, state="disabled", width=8)
        self.pause_btn.pack(side="right", padx=(0, 3))

        top_left = ttk.Frame(top)
        top_left.pack(side="left", fill="x", expand=True)
        ttk.Label(top_left, text="共用MA資料庫：").pack(side="left")
        self.file_entry = self.register_lock_widget(ttk.Entry(top_left, textvariable=self.file_text, width=62, state="readonly"))
        try:
            self.file_text.set(cache_dir())
        except Exception:
            pass
        self.file_entry.pack(side="left", padx=5, fill="x", expand=True)
        self.action_button(top_left, text="重新載入商品清單/排名", command=self.scan_files, side="left", padx=5)
        # 054C：期交所保證金更新鍵固定放在「熱門排名」左邊，符合實際操作順序。
        self.action_button(top_left, text="更新期交所保證金資料", command=self.update_margin_master, side="left", padx=5)
        self.action_button(top_left, text="熱門排名", command=self.open_hot_ranking, side="left", padx=5)
        self.action_button(top_left, text="檢查線上更新", command=lambda: self.check_online_update(silent=False), side="left", padx=5)

        product_bar = ttk.LabelFrame(self.root, text="待回測商品", padding=8)
        product_bar.pack(fill="x", padx=8, pady=4)
        # 054C：改用 grid，左欄摘要可換行，右欄按鈕固定保留寬度，不再被長商品清單推出畫面。
        try:
            product_bar.columnconfigure(0, weight=1)
            product_bar.columnconfigure(1, weight=0)
        except Exception:
            pass
        self.group_summary_label = ttk.Label(product_bar, textvariable=self.group_summary_text, anchor="w", justify="left")
        self.group_summary_label.grid(row=0, column=0, sticky="ew", padx=(0, 8), pady=0)
        self.product_button_frame = ttk.Frame(product_bar)
        self.product_button_frame.grid(row=0, column=1, sticky="ne", padx=(8, 0), pady=0)
        self.manage_product_btn = ttk.Button(self.product_button_frame, text="選擇商品 / 管理群組", command=self.open_product_dialog)
        self.manage_product_btn.pack(side="left", padx=4)
        self.clear_group_btn = ttk.Button(self.product_button_frame, text="清空待回測", command=self.clear_backtest_group)
        self.clear_group_btn.pack(side="left", padx=4)
        try:
            self.group_summary_label.configure(wraplength=760)
        except Exception:
            pass
        self.lock_widgets.extend([self.manage_product_btn, self.clear_group_btn])
        try:
            self.product_keyword.trace_add("write", lambda *_: self.filter_products())
        except Exception:
            pass
        self.render_backtest_group()

        p = ttk.LabelFrame(self.root, text="群組回測參數", padding=8)
        p.pack(fill="x", padx=8, pady=4)
        for _c in range(12):
            try:
                p.columnconfigure(_c, weight=(1 if _c == 11 else 0))
            except Exception:
                pass
        ttk.Label(p, text="策略").grid(row=0, column=0, sticky="e", padx=4, pady=4)
        strategy_mode_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.strategy_mode, values=STRATEGY_MODE_VALUES, width=13, state="readonly"))
        strategy_mode_box.grid(row=0, column=1, sticky="w", padx=4, pady=4)
        strategy_mode_box.bind("<<ComboboxSelected>>", lambda _e: self.on_strategy_mode_changed())
        self.ma_period_label = ttk.Label(p, text="均線參數")
        self.ma_period_label.grid(row=0, column=2, sticky="e", padx=4, pady=4)
        self.ma_period_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.ma_period_text, values=MA_PERIOD_VALUES, width=5, state="readonly"))
        self.ma_period_box.grid(row=0, column=3, sticky="w", padx=4, pady=4)
        self.ma_period_box.bind("<<ComboboxSelected>>", lambda _e: self.on_ma_period_changed())
        ttk.Label(p, text="K棒").grid(row=0, column=4, sticky="e", padx=4, pady=4)
        self.k_minutes_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.k_minutes_text, values=K_MINUTE_VALUES, width=5, state="readonly"))
        self.k_minutes_box.grid(row=0, column=5, sticky="w", padx=4, pady=4)
        self.k_minutes_box.bind("<<ComboboxSelected>>", lambda _e: self.on_k_minutes_changed())
        ttk.Label(p, text="進場").grid(row=0, column=6, sticky="e", padx=4, pady=4)
        self.entry_mode_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.entry_mode, values=ENTRY_MODE_VALUES, width=8, state="readonly"))
        self.entry_mode_box.grid(row=0, column=7, sticky="w", padx=4, pady=4)
        self.entry_mode_box.bind("<<ComboboxSelected>>", lambda _e: self.on_entry_mode_changed())
        ttk.Label(p, text="商品類型").grid(row=0, column=8, sticky="e", padx=4, pady=4)
        self.stock_mode_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.stock_size_mode, values=STOCK_SIZE_MODE_VALUES, width=8, state="readonly"))
        self.stock_mode_box.grid(row=0, column=9, sticky="w", padx=4, pady=4)
        self.stock_mode_box.bind("<<ComboboxSelected>>", lambda _e: self.apply_stock_size_defaults())
        ttk.Label(p, text="回測時段").grid(row=0, column=10, sticky="e", padx=4, pady=4)
        self.tai_session_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.tai_session_mode, values=TAI_SESSION_MODE_VALUES, width=8, state="readonly"))
        self.tai_session_box.grid(row=0, column=11, sticky="w", padx=4, pady=4)
        self.tai_session_box.bind("<<ComboboxSelected>>", lambda _e: self.on_tai_session_mode_changed())
        ttk.Label(p, text="口數").grid(row=1, column=0, sticky="e", padx=4, pady=4)
        lots_entry = self.register_lock_widget(ttk.Entry(p, textvariable=self.lots, width=7))
        lots_entry.grid(row=1, column=1, sticky="w", padx=4, pady=4)
        ttk.Label(p, text="台指保證金").grid(row=1, column=4, sticky="e", padx=(12, 4), pady=4)
        self.tai_margin_entry = self.register_lock_widget(ttk.Entry(p, textvariable=self.tai_margin_text, width=12))
        self.tai_margin_entry.grid(row=1, column=5, sticky="w", padx=4, pady=4)
        apply_default_btn = ttk.Button(p, text="套用預設範圍", command=self.apply_stock_size_defaults)
        apply_default_btn.grid(row=1, column=6, sticky="w", padx=4, pady=4)
        self.lock_widgets.append(apply_default_btn)
        fee_box_frame = ttk.Frame(p)
        fee_box_frame.grid(row=1, column=7, columnspan=2, sticky="w", padx=4, pady=4)
        ttk.Label(fee_box_frame, text="手續費：自動").pack(side="left", padx=(0, 4))
        ttk.Label(fee_box_frame, text="依成交價扣進出場").pack(side="left", padx=(3, 0))
        ttk.Label(p, text="回測核心數").grid(row=1, column=9, sticky="e", padx=(12, 4), pady=4)
        cpu_values = ["最快", "自動"] + [str(i) for i in range(1, max(17, min(33, int(os.cpu_count() or 16) + 1)))]
        cpu_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.cpu_workers_text, values=cpu_values, width=6, state="readonly"))
        cpu_box.grid(row=1, column=10, sticky="w", padx=4, pady=4)
        try:
            self.cpu_workers_text.trace_add("write", lambda *_: self.on_cpu_workers_changed())
        except Exception:
            pass
        try:
            self.tai_margin_text.trace_add("write", lambda *_: self.on_tai_margin_changed())
        except Exception:
            pass

        def date_field(label, var, row, col):
            ttk.Label(p, text=label).grid(row=row, column=col, sticky="e", padx=4, pady=4)
            df = ttk.Frame(p)
            df.grid(row=row, column=col + 1, sticky="w", padx=4, pady=4)
            ent = self.register_lock_widget(ttk.Entry(df, textvariable=var, width=13))
            ent.pack(side="left")
            btn = ttk.Button(df, text="選", width=3, command=lambda v=var, lb=label: self.open_date_picker(v, lb))
            btn.pack(side="left", padx=(2, 0))
            self.lock_widgets.append(btn)

        date_field("回測起日", self.date_start_text, 1, 0)
        date_field("回測迄日", self.date_end_text, 1, 2)

        ttk.Label(p, text="變數").grid(row=2, column=0, sticky="e", padx=4, pady=(8, 2))
        ttk.Label(p, text="起始").grid(row=2, column=1, sticky="w", padx=4, pady=(8, 2))
        ttk.Label(p, text="結束").grid(row=2, column=2, sticky="w", padx=4, pady=(8, 2))
        ttk.Label(p, text="每次增加").grid(row=2, column=3, sticky="w", padx=4, pady=(8, 2))
        ttk.Label(p, text="說明").grid(row=2, column=4, columnspan=8, sticky="w", padx=4, pady=(8, 2))

        self._param_range_entries = {}
        def range_row(row, label, start_var, end_var, step_var, note, key="", disable_var=None, disable_text=""):
            label_frame = ttk.Frame(p)
            label_frame.grid(row=row, column=0, sticky="e", padx=4, pady=3)
            ttk.Label(label_frame, text=label).pack(side="left")
            if disable_var is not None:
                chk = self.register_lock_widget(ttk.Checkbutton(label_frame, text=disable_text, variable=disable_var, command=self.on_no_tp_sl_changed))
                chk.pack(side="left", padx=(6, 0))
                if key == "tp":
                    self.no_tp_check = chk
                elif key == "sl":
                    self.no_sl_check = chk
            entries = []
            for col, var in ((1, start_var), (2, end_var), (3, step_var)):
                ent = self.register_lock_widget(ttk.Entry(p, textvariable=var, width=12))
                ent.grid(row=row, column=col, sticky="w", padx=4, pady=3)
                entries.append(ent)
            if key:
                self._param_range_entries[key] = entries
            ttk.Label(p, text=note, foreground="#555555").grid(row=row, column=4, columnspan=8, sticky="w", padx=4, pady=3)

        range_row(3, "EMA/SMA參數", self.sma_start_text, self.sma_end_text, self.sma_step_text, "EMA/SMA策略使用；可設定範圍比較哪個均線參數獲利較佳。", "sma")
        range_row(4, "每次停利（點）", self.tp_start_text, self.tp_end_text, self.tp_step_text, "勾選不停利時固定不使用停利；取消勾選後才讀取起始/結束/增加。", "tp", self.no_tp_var, "不停利")
        range_row(5, "每次停損（點）", self.sl_start_text, self.sl_end_text, self.sl_step_text, "EMA/SMA策略不使用，固定為不停損；其他策略可勾選不停損。", "sl", self.no_sl_var, "不停損")
        range_row(6, "認賠下車（新台幣）", self.loss_start_text, self.loss_end_text, self.loss_step_text, "EMA/SMA策略不使用，固定反灰。", "loss")
        range_row(7, "賺飽下車（新台幣）", self.profit_start_text, self.profit_end_text, self.profit_step_text, "EMA/SMA策略不使用，固定反灰。", "profit")
        self.estimate_label = ttk.Label(p, textvariable=self.estimate_text, foreground="#005A9E", anchor="w", justify="left", wraplength=1200)
        self.estimate_label.grid(row=8, column=0, columnspan=8, sticky="ew", padx=4, pady=(8, 2))

        for var in (self.date_start_text, self.date_end_text, self.tp_start_text, self.tp_end_text, self.tp_step_text,
                    self.sl_start_text, self.sl_end_text, self.sl_step_text, self.loss_start_text, self.loss_end_text,
                    self.loss_step_text, self.profit_start_text, self.profit_end_text, self.profit_step_text,
                    self.sma_start_text, self.sma_end_text, self.sma_step_text,
                    self.no_tp_var, self.no_sl_var,
                    self.strategy_mode, self.ma_period_text, self.k_minutes_text, self.entry_mode, self.stock_size_mode, self.tai_session_mode):
            try:
                var.trace_add("write", lambda *_: self.mark_estimate_dirty())
            except Exception:
                pass
        self._update_strategy_parameter_controls()

        buttons = ttk.Frame(self.root, padding=(8, 2))
        buttons.pack(fill="x")
        self.action_button(buttons, text="重新計算預估時間", command=self.update_group_estimate, side="left", padx=4)
        self.action_button(buttons, text="執行群組參數回測", command=self.run_group_backtest, side="left", padx=4)
        self.action_button(buttons, text="以選取結果精跑", command=self.run_fine_backtest_selected, side="left", padx=4)
        self.action_button(buttons, text="以前5名精跑", command=self.run_fine_backtest_top5, side="left", padx=4)
        self.action_button(buttons, text="存入精選結果", command=self.save_selected_result, side="left", padx=4)
        self.action_button(buttons, text="查看精選結果", command=self.open_selected_results_window, side="left", padx=4)
        self.action_button(buttons, text="匯出結果 CSV", command=self.export_csv, side="left", padx=4)
        self.action_button(buttons, text="放大目前表格", command=self.open_current_table_large, side="left", padx=4)

        self.info = ttk.Label(self.root, text="就緒", anchor="w", justify="left", wraplength=1200)
        self.info.pack(fill="x", padx=10, pady=(4, 0))
        try:
            self.progress_style = ttk.Style(self.root)
            self.progress_style.configure("BacktesterGreen.Horizontal.TProgressbar", troughcolor="#E6E6E6", background="#22A652")
            self.progress_bar = ttk.Progressbar(self.root, mode="determinate", maximum=100, style="BacktesterGreen.Horizontal.TProgressbar")
            self.progress_bar.pack(fill="x", padx=10, pady=(3, 4))
            self.progress_bar.configure(value=0)
        except Exception:
            self.progress_bar = None
        try:
            self.root.bind("<Configure>", self.on_root_configure, add="+")
        except Exception:
            pass

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=BOTH, expand=True, padx=8, pady=8)

        self.result_frame = ttk.Frame(self.tabs)
        self.summary_frame = ttk.Frame(self.tabs)
        self.detail_frame = ttk.Frame(self.tabs)
        self.tabs.add(self.result_frame, text="回測結果")
        self.tabs.add(self.summary_frame, text="每日總表")
        self.tabs.add(self.detail_frame, text="交易明細")

        result_filter_bar = ttk.Frame(self.result_frame, padding=(0, 0, 0, 6))
        result_filter_bar.pack(fill="x")
        ttk.Label(result_filter_bar, text="結果商品：").pack(side="left", padx=(0, 4))
        self.result_filter_box = ttk.Combobox(result_filter_bar, textvariable=self.result_filter_text, values=["總表"], width=28, state="readonly")
        self.result_filter_box.pack(side="left", padx=(0, 10))
        self.result_filter_box.bind("<<ComboboxSelected>>", lambda _e: self.render_result_view())
        ttk.Label(result_filter_bar, text="總表與各商品頁均只顯示該商品前10名；排名依『平均每日獲利 ÷ 原始保證金』。點選只選取；Ctrl/Shift可多選；雙擊才載入每日總表與交易明細。", foreground="#555555").pack(side="left")

        self.result_tree = self.make_tree(self.result_frame, [
            ("rank", "排序", 60), ("name", "商品名稱", 160), ("margin", "保證金", 105), ("score", "獲利/保證金", 120),
            ("avg", "平均每日獲利", 130), ("total", "總淨利", 115), ("days", "有效天數", 90), ("range", "日期範圍", 180),
            ("ma_period", "MA", 60), ("k_minutes", "K棒", 70), ("tp_points", "停利/觸發", 95), ("sl_points", "停損點", 90), ("loss_exit", "認賠", 105), ("profit_exit", "賺飽", 105),
            ("trades", "平倉次數", 90), ("tp", "停利次數", 90), ("sl", "停損次數", 90), ("loss_exit_count", "認賠次數", 90), ("profit_exit_count", "賺飽次數", 90),
            ("peak", "最高損益", 105), ("trough", "最低損益", 105), ("status", "狀態", 120)
        ], settings_key="result")
        # 055C：點選結果列只負責選取，避免自動載入每日總表/交易明細拖慢操作；雙擊才載入明細。
        self.result_tree.bind("<Double-1>", self.on_result_double_clicked, add="+")

        self.summary_tree = self.make_tree(self.summary_frame, [
            ("session", "日期/時段", 125), ("month", "自動月份", 95), ("minutes", "分鐘數", 80),
            ("ticks", "逐筆數", 90), ("trades", "平倉次數", 90), ("win_trades", "賺錢次數", 90), ("loss_trades", "賠錢次數", 90), ("net", "淨利", 110),
            ("tp", "停利", 70), ("sl", "停損", 70), ("reverse", "反手", 70),
            ("force", "時間到", 80), ("loss_exit", "認賠", 70), ("profit_exit", "賺飽", 70),
            ("peak", "最高損益", 110), ("trough", "最低損益", 110), ("stop", "停止原因", 150)
        ], settings_key="summary")
        self.detail_tree = self.make_tree(self.detail_frame, [
            ("seq", "筆次", 60), ("side", "方向", 70), ("action", "動作", 60),
            ("time", "時間", 130), ("price", "價格", 90), ("ma_value", "均線", 105), ("points", "損益點數", 95),
            ("net", "淨損益", 105), ("day_total", "時段累計", 110), ("reason", "原因", 150)
        ], settings_key="detail")

    def make_tree(self, parent, cols, settings_key=""):
        frame = ttk.Frame(parent)
        frame.pack(fill=BOTH, expand=True)
        tree = ttk.Treeview(frame, columns=[c[0] for c in cols], show="headings", selectmode="extended")
        ybar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        xbar = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        tree._sort_reverse = {}
        tree._settings_key = settings_key or ""
        saved_widths = self.get_setting("columns." + tree._settings_key, {}) if tree._settings_key else {}
        saved_order = self.get_setting("column_order." + tree._settings_key, []) if tree._settings_key else []
        try:
            tree.tag_configure("pos", foreground="#FF0000")
            tree.tag_configure("neg", foreground="#008000")
            tree.tag_configure("long", foreground="#FF0000")
            tree.tag_configure("short", foreground="#008000")
            tree.tag_configure("zero", foreground="#333333")
            # 交易明細專用：一筆交易上下兩列同底色；進場列黑字、出場列依淨損益紅/綠。
            for _bg_idx, _bg in ((0, "#FFFBE6"), (1, "#EAF4FF")):
                tree.tag_configure(f"trade_entry_group{_bg_idx}", foreground="#333333", background=_bg)
                tree.tag_configure(f"trade_exit_pos_group{_bg_idx}", foreground="#FF0000", background=_bg)
                tree.tag_configure(f"trade_exit_neg_group{_bg_idx}", foreground="#008000", background=_bg)
                tree.tag_configure(f"trade_exit_zero_group{_bg_idx}", foreground="#333333", background=_bg)
                # 舊標籤保留相容，避免舊結果放大視窗未重繪時沒有顏色。
                tree.tag_configure(f"trade_pos_day{_bg_idx}", foreground="#FF0000", background=_bg)
                tree.tag_configure(f"trade_neg_day{_bg_idx}", foreground="#008000", background=_bg)
                tree.tag_configure(f"trade_zero_day{_bg_idx}", foreground="#333333", background=_bg)
            tree.tag_configure("day_total_pos", foreground="#FF0000", background="#FFFFFF")
            tree.tag_configure("day_total_neg", foreground="#008000", background="#FFFFFF")
            tree.tag_configure("day_total_zero", foreground="#333333", background="#FFFFFF")
        except Exception:
            pass
        for key, title, width in cols:
            tree.heading(key, text=title, command=lambda k=key, t=tree: self.sort_tree(t, k))
            use_width = int(saved_widths.get(key, width)) if isinstance(saved_widths, dict) else width
            tree.column(key, width=use_width, minwidth=45, anchor="center", stretch=True)
        try:
            default_cols = [c[0] for c in cols]
            if isinstance(saved_order, list):
                order = [c for c in saved_order if c in default_cols] + [c for c in default_cols if c not in saved_order]
                if order:
                    tree["displaycolumns"] = order
        except Exception:
            pass
        tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        try:
            tree.bind("<ButtonRelease-1>", lambda _e, t=tree: self.save_tree_column_widths(t), add="+")
            self.enable_tree_column_drag(tree)
        except Exception:
            pass
        return tree

    def _sort_value(self, value):
        s = str(value or "").strip()
        if not s:
            return (1, "")
        raw = s.replace(",", "").replace("元", "").replace("點", "").replace("%", "").strip()
        if raw.startswith("1/"):
            raw = raw[2:]
        raw = raw.replace("+", "")
        try:
            return (0, float(raw))
        except Exception:
            return (1, s)

    def sort_tree(self, tree, col):
        cols = list(tree["columns"])
        try:
            idx = cols.index(col)
        except ValueError:
            return
        if col in getattr(tree, "_sort_reverse", {}):
            reverse = bool(tree._sort_reverse.get(col, False))
        else:
            # 數值欄第一次點擊先由大到小，總淨利、平倉次數等排序較直覺。
            reverse = col not in ("session", "month", "entry_time", "exit_time", "side", "event", "reason", "stop")
        items = list(tree.get_children(""))
        footer = []
        sortable = []
        for item in items:
            vals = tree.item(item, "values")
            if vals and str(vals[0]) in ("平均", "合計"):
                footer.append(item)
            else:
                sortable.append(item)
        sortable.sort(key=lambda item: self._sort_value(tree.item(item, "values")[idx] if idx < len(tree.item(item, "values")) else ""), reverse=reverse)
        for pos, item in enumerate(sortable + footer):
            tree.move(item, "", pos)
        tree._sort_reverse[col] = not reverse

    def clear_tree(self, tree):
        for item in tree.get_children():
            tree.delete(item)

    def mark_estimate_dirty(self):
        try:
            self.estimate_text.set("預估：參數或日期已變更，按『重新計算預估時間』更新")
        except Exception:
            pass

    def is_tai_product_mode(self):
        # EMA/SMA 不再強制視為台指；股期高速回測要保留股期商品群組與日盤特性。
        return bool(str(self.stock_size_mode.get() or "").strip() == "台指期")

    def get_tai_session_mode(self):
        return normalize_tai_session_mode(self.tai_session_mode.get())

    def on_tai_session_mode_changed(self):
        try:
            self.tai_session_mode.set(normalize_tai_session_mode(self.tai_session_mode.get()))
            self.set_setting("defaults.tai_session_mode", self.tai_session_mode.get())
            self.save_settings()
        except Exception:
            pass
        self.ticks = []
        try:
            self._product_dates_text_cache = {}
        except Exception:
            pass
        self.render_backtest_group()
        self.mark_estimate_dirty()

    def tai_margin_value(self):
        raw = str(self.tai_margin_text.get() if hasattr(self, "tai_margin_text") else "").strip().replace(",", "")
        if raw == "":
            return 0.0
        try:
            val = float(raw)
        except Exception:
            return 0.0
        return max(0.0, val)

    def tai_margin_display_text(self):
        val = self.tai_margin_value()
        return safe_int_text(val) if val > 0 else "未輸入"

    def on_tai_margin_changed(self):
        try:
            # v052T：輸入中只更新記憶體設定；關閉或開始回測時再寫入檔案，避免每打一字就磁碟 I/O。
            self.set_setting("defaults.tai_margin", str(self.tai_margin_text.get() or ""))
        except Exception:
            pass
        try:
            margin_value = self.tai_margin_value()
            for opt in list(self.options or []):
                if is_tai_index_code(getattr(opt, "code", "")) or str(getattr(opt, "product_kind", "") or "") == "台指期":
                    opt.base_margin = margin_value
        except Exception:
            pass
        # v052T：台指保證金輸入框每打一字都會觸發 trace；不可在這裡重畫日期摘要或計算預估。
        # 真正預估只在使用者按「重新計算預估時間」或開始回測時執行。
        self.mark_estimate_dirty()

    @staticmethod
    def _format_data_dates_text(dates):
        dates = sorted(set(d for d in list(dates or []) if d))
        if not dates:
            return "無資料"
        start, end = dates[0], dates[-1]
        range_text = _date_text(start) if start == end else "%s～%s" % (_date_text(start), _date_text(end))
        have = set(dates)
        expected = []
        cur = start
        while cur <= end:
            # 週六日不列入缺日；期交所休市日若未匯入仍可能顯示為缺，需以實際檔案為準。
            if cur.weekday() < 5:
                expected.append(cur)
            cur = cur + timedelta(days=1)
        missing, ignored_missing = _missing_dates_excluding_ignored(expected, have)
        if missing:
            show = [_date_text(d) for d in missing[:12]]
            miss_text = "缺：" + "、".join(show)
            if len(missing) > 12:
                miss_text += "...共%d天" % len(missing)
        else:
            miss_text = "無缺日"
        if ignored_missing:
            show_ig = [_date_text(d) for d in ignored_missing[:12]]
            ig_text = "｜休市忽略：" + "、".join(show_ig)
            if len(ignored_missing) > 12:
                ig_text += "...共%d天" % len(ignored_missing)
            miss_text += ig_text
        return "%s（%d天）｜%s" % (range_text, len(dates), miss_text)

    def product_data_dates_text(self, opt_or_code):
        try:
            code = clean_code(getattr(opt_or_code, "code", opt_or_code))
        except Exception:
            code = clean_code(opt_or_code)
        if not code:
            return "無資料"
        try:
            mode = "全部" if (self.is_fast_ma_mode() and is_tai_index_code(code)) else (self.get_tai_session_mode() if is_tai_index_code(code) else "全部")
            cache_key = (code, mode)
            cache = getattr(self, "_product_dates_text_cache", None)
            if isinstance(cache, dict) and cache_key in cache:
                return cache[cache_key]
            dates = cached_trade_dates_for_code(code, session_mode=mode) if cache_has_code(code) else []
            text = self._format_data_dates_text(dates)
            if isinstance(cache, dict):
                cache[cache_key] = text
            return text
        except Exception:
            return "無資料"

    def group_data_dates_summary(self, max_items=3):
        items = self.active_backtest_targets()
        if not items:
            return "資料：無商品"
        parts = []
        for opt in list(items)[:max_items]:
            parts.append("%s：%s" % (self.product_name_text(opt), self.product_data_dates_text(opt)))
        if len(items) > max_items:
            parts.append("另%d檔" % (len(items) - max_items))
        return "資料：" + "；".join(parts)

    def _tai_data_code(self):
        for opt in list(self.options or []):
            if is_tai_index_code(getattr(opt, "code", "")):
                return clean_code(opt.code)
        for code in ("TXF", "TX"):
            try:
                if cache_has_code(code):
                    return code
            except Exception:
                pass
        return "TXF"

    def tai_index_option(self):
        data_code = self._tai_data_code()
        for opt in list(self.options or []):
            if clean_code(getattr(opt, "code", "")) == data_code:
                opt.product_kind = "台指期"
                opt.stock_name = "台指期大台"
                opt.base_margin = self.tai_margin_value()
                opt.display = self.product_display_text(opt)
                return opt
        return ProductOption(
            code=data_code, display="台指期大台｜台指期｜固定大台", total_rows=0, total_qty=0.0,
            primary_month="", months="", first_dt=None, last_dt=None, data_days=0,
            product_kind="台指期", stock_no="TXF", stock_name="台指期大台", base_margin=self.tai_margin_value(),
        )

    def active_backtest_targets(self):
        if self.is_tai_product_mode():
            return [self.tai_index_option()]
        return list(self.backtest_group or [])

    def is_three_ma_mode(self):
        return str(self.strategy_mode.get() or "") == THREE_MA_STRATEGY_DISPLAY

    def is_ema_mode(self):
        return str(self.strategy_mode.get() or "") == EMA_STRATEGY_DISPLAY

    def is_sma_mode(self):
        return str(self.strategy_mode.get() or "") == SMA_STRATEGY_DISPLAY

    def is_open_price_mode(self):
        return str(self.strategy_mode.get() or "") == OPEN_PRICE_STRATEGY_DISPLAY

    def is_fast_ma_mode(self):
        return self.is_ema_mode() or self.is_sma_mode()

    def is_param_strategy_mode(self):
        return self.is_three_ma_mode() or self.is_fast_ma_mode()

    def get_ma_period(self):
        if self.is_sma_mode():
            # EMA/SMA策略不再使用上方「均線參數」欄位；單組/明細取下方參數範圍起始值。
            return normalize_sma_period(self.sma_start_text.get() or self.get_setting("defaults.sma_start", "20"))
        if self.is_ema_mode():
            # EMA 與 SMA 面板/參數來源一致，只差均線算法不同。
            return normalize_fast_ma_period(self.sma_start_text.get() or self.get_setting("defaults.sma_start", self.get_setting("defaults.ma_period", "20")))
        if self.is_three_ma_mode():
            return normalize_ma_period(self.ma_period_text.get())
        return 3

    def on_ma_period_changed(self):
        try:
            if self.is_fast_ma_mode():
                # EMA/SMA策略的參數來源只看下方 EMA/SMA參數範圍，不保存/套用上方均線參數。
                self.ma_period_text.set(str(self.get_ma_period()))
            elif not self.is_param_strategy_mode():
                self.ma_period_text.set("3")
            else:
                self.ma_period_text.set(str(normalize_ma_period(self.ma_period_text.get())))
                self.set_setting("defaults.ma_period", str(self.ma_period_text.get()))
                self.save_settings()
        except Exception:
            pass
        self.mark_estimate_dirty()

    def get_k_minutes(self):
        if self.is_fast_ma_mode():
            return normalize_ema_k_minutes(self.k_minutes_text.get())
        if not self.is_param_strategy_mode():
            return 1
        return normalize_k_minutes(self.k_minutes_text.get())

    def on_k_minutes_changed(self):
        try:
            if self.is_fast_ma_mode():
                # v052G：EMA/SMA 的 K棒選擇也必須立即保存；
                # v052G 只改畫面文字但未保存，啟動回測/反灰刷新時會被 defaults.k_minutes 覆蓋回舊值，
                # 造成畫面選 5分、實際結果卻跑 60分，甚至訊號全錯。
                self.k_minutes_text.set(k_minutes_label(normalize_ema_k_minutes(self.k_minutes_text.get())))
                self.set_setting("defaults.k_minutes", str(self.k_minutes_text.get()))
                self.save_settings()
            elif not self.is_param_strategy_mode():
                self.k_minutes_text.set("1")
            else:
                self.k_minutes_text.set(k_minutes_label(self.k_minutes_text.get()))
                self.set_setting("defaults.k_minutes", str(self.k_minutes_text.get()))
                self.save_settings()
        except Exception:
            pass
        self.mark_estimate_dirty()

    def get_entry_mode(self):
        return normalize_entry_mode(self.entry_mode.get())

    def on_entry_mode_changed(self):
        try:
            self.entry_mode.set(normalize_entry_mode(self.entry_mode.get()))
            self.set_setting("defaults.entry_mode", self.entry_mode.get())
            self.save_settings()
        except Exception:
            pass
        self.mark_estimate_dirty()

    def _update_strategy_parameter_controls(self):
        is_param = self.is_param_strategy_mode()
        busy = bool(getattr(self, "busy", False))
        try:
            if self.is_fast_ma_mode():
                # EMA/SMA策略不顯示也不使用上方「均線參數」，只同步成下方參數起始值供舊流程相容。
                # v052V：不再強制改成台指期；股期可保留大/小股期與待回測商品群組。
                self.ma_period_text.set(str(self.get_ma_period()))
                self.k_minutes_text.set(k_minutes_label(normalize_ema_k_minutes(self.k_minutes_text.get() or self.get_setting("defaults.k_minutes", "60"))))
                if self.is_tai_product_mode():
                    self.tai_session_mode.set("全部")
            elif self.is_three_ma_mode():
                self.ma_period_text.set(str(normalize_ma_period(self.get_setting("defaults.ma_period", self.ma_period_text.get() or "3"))))
                self.k_minutes_text.set(k_minutes_label(self.get_setting("defaults.k_minutes", self.k_minutes_text.get() or "1")))
            else:
                self.ma_period_text.set("3")
                self.k_minutes_text.set("1")
            if hasattr(self, "ma_period_box"):
                try:
                    self.ma_period_box.configure(values=(MA_PERIOD_VALUES if self.is_ema_mode() else ["3", "5", "10"]))
                except Exception:
                    pass
                try:
                    if self.is_fast_ma_mode():
                        if hasattr(self, "ma_period_label"):
                            self.ma_period_label.grid_remove()
                        self.ma_period_box.grid_remove()
                    else:
                        if hasattr(self, "ma_period_label"):
                            self.ma_period_label.grid()
                        self.ma_period_box.grid()
                except Exception:
                    pass
                self.ma_period_box.configure(state="disabled")
            if hasattr(self, "k_minutes_box"):
                try:
                    self.k_minutes_box.configure(values=(EMA_K_MINUTE_VALUES if self.is_fast_ma_mode() else K_MINUTE_VALUES))
                except Exception:
                    pass
                self.k_minutes_box.configure(state=("readonly" if self.is_fast_ma_mode() and not busy else "disabled"))
            if hasattr(self, "entry_mode_box"):
                self.entry_mode_box.configure(state=("readonly" if (self.is_fast_ma_mode() and not busy) else "disabled"))
            if hasattr(self, "stock_mode_box"):
                self.stock_mode_box.configure(state=("disabled" if busy else "readonly"))
            if hasattr(self, "tai_session_box"):
                self.tai_session_box.configure(state=("disabled" if self.is_fast_ma_mode() else ("readonly" if self.is_tai_product_mode() and not busy else "disabled")))
            tai_state = "normal" if (self.is_tai_product_mode() and not busy) else "disabled"
            if hasattr(self, "tai_margin_entry"):
                self.tai_margin_entry.configure(state=tai_state)
            for name in ("manage_product_btn", "clear_group_btn"):
                btn = getattr(self, name, None)
                if btn is not None:
                    btn.configure(state=("disabled" if (busy or self.is_tai_product_mode()) else "normal"))
            # v052I：EMA策略不使用認賠/賺飽下車；畫面反灰且核心固定 0。
            try:
                param_entries = getattr(self, "_param_range_entries", {}) or {}
                for key, entries in param_entries.items():
                    disabled = bool(
                        busy
                        or (self.is_fast_ma_mode() and key in ("loss", "profit"))
                        or (not self.is_fast_ma_mode() and key == "sma")
                        or (key == "tp" and self.no_tp_enabled())
                        or (key == "sl" and self.no_sl_enabled())
                    )
                    for ent in list(entries or []):
                        ent.configure(state=("disabled" if disabled else "normal"))
                for chk_name in ("no_tp_check", "no_sl_check"):
                    chk = getattr(self, chk_name, None)
                    if chk is not None:
                        chk.configure(state=("disabled" if busy else "normal"))
                if self.is_fast_ma_mode():
                    self.loss_start_text.set("0"); self.loss_end_text.set("0"); self.loss_step_text.set("1")
                    self.profit_start_text.set("0"); self.profit_end_text.set("0"); self.profit_step_text.set("1")
            except Exception:
                pass
        except Exception:
            pass

    def on_strategy_mode_changed(self):
        mode = str(self.strategy_mode.get() or TRAIN_STRATEGY_DISPLAY)
        if mode not in STRATEGY_MODE_VALUES:
            mode = TRAIN_STRATEGY_DISPLAY
            self.strategy_mode.set(mode)
        try:
            self.set_setting("defaults.strategy_mode", mode)
            self.save_settings()
        except Exception:
            pass
        if mode in (EMA_STRATEGY_DISPLAY, SMA_STRATEGY_DISPLAY):
            preset_key = self._param_preset_key()
            # v052W：EMA/SMA 可用「不停利／不停損」勾選真正停用 TP/SL；舊 99999 預設自動視為停用。
            loaded_preset = self._load_param_preset(preset_key)
            if not loaded_preset:
                self.no_tp_var.set(1)
                self.no_sl_var.set(1)
                self.tp_start_text.set("99999")
                self.tp_end_text.set("99999")
                self.tp_step_text.set("1")
                self.sl_start_text.set("99999")
                self.sl_end_text.set("99999")
                self.sl_step_text.set("1")
            self.loss_start_text.set("0")
            self.loss_end_text.set("0")
            self.loss_step_text.set("1")
            self.profit_start_text.set("0")
            self.profit_end_text.set("0")
            self.profit_step_text.set("1")
            try:
                if self.is_tai_product_mode():
                    self.tai_session_mode.set("全部")
                self.render_backtest_group()
                applied_dates = self.apply_sma_database_date_defaults()
                algo = "SMA" if self.is_sma_mode() else "EMA"
                market_note = "台指期固定TXF＋日夜盤" if self.is_tai_product_mode() else ("股期保留%s商品群組＋日盤" % str(self.stock_size_mode.get() or "大股期"))
                if applied_dates:
                    self.info.configure(text="已切換%s策略：%s；起訖日已帶入資料庫實際範圍；上方均線參數已隱藏，請用下方 EMA/SMA參數範圍設定。" % (algo, market_note))
                else:
                    self.info.configure(text="已切換%s策略：%s；上方均線參數已隱藏，請用下方 EMA/SMA參數範圍設定；K棒可選5分/10分/15分/30分/60分/日K。" % (algo, market_note))
            except Exception:
                pass
        else:
            key = self._param_preset_key()
            if not self._load_param_preset(key):
                self.apply_stock_size_defaults()
            try:
                if self.is_open_price_mode():
                    self.k_minutes_text.set("1")
                    market_note = "台指期固定TXF，可選日盤、夜盤或九點盤" if self.is_tai_product_mode() else ("股期保留%s商品群組，只跑日盤" % str(self.stock_size_mode.get() or "大股期"))
                    self.info.configure(text="已切換開盤價策略：%s；固定1分K；第一根不做、第二根OP、第三根起以當天開盤價判斷過前高/破前低。" % market_note)
                else:
                    self.info.configure(text="已切換小火車原策略：固定使用 1分K；均線參數、K棒、進場模式已反灰。")
            except Exception:
                pass
        self._update_strategy_parameter_controls()
        self.mark_estimate_dirty()

    def apply_stock_size_defaults(self):
        """依大股期/小股期/台指期套用群組回測預設範圍。

        大股期預設：停利 5~20、停損 10、認賠/賺飽 30000~45000 每 2500。
        小股期：停利/停損點數為大股期的 20 倍；認賠/賺飽金額與大股期相同。
        台指期：固定大台 TXF，點數預設先沿用大股期，可選日盤/夜盤/九點盤。
        """
        mode = str(self.stock_size_mode.get() or "大股期").strip()
        if mode not in STOCK_SIZE_MODE_VALUES:
            mode = "大股期"
            self.stock_size_mode.set(mode)
        if self.is_fast_ma_mode():
            preset_key = self._param_preset_key()
            self._load_param_preset(preset_key)
            self.no_tp_var.set(1); self.no_sl_var.set(1)
            self.tp_start_text.set("99999"); self.tp_end_text.set("99999"); self.tp_step_text.set("1")
            self.sl_start_text.set("0"); self.sl_end_text.set("0"); self.sl_step_text.set("1")
            self.loss_start_text.set("0"); self.loss_end_text.set("0"); self.loss_step_text.set("1")
            self.profit_start_text.set("0"); self.profit_end_text.set("0"); self.profit_step_text.set("1")
            try:
                self.set_setting("defaults.stock_size_mode", mode)
                if mode == "台指期":
                    self.tai_session_mode.set("全部")
                self.set_setting("defaults.tai_session_mode", self.get_tai_session_mode())
                self.save_current_param_texts()
            except Exception:
                pass
            self._update_strategy_parameter_controls()
            self.render_backtest_group()
            self.mark_estimate_dirty()
            try:
                algo = "SMA" if self.is_sma_mode() else "EMA"
                note = "固定TXF日夜盤" if mode == "台指期" else ("保留%s商品群組，股期只跑日盤" % mode)
                self.info.configure(text="已套用%s策略＋%s：%s；停利/停損預設99999，認賠/賺飽停用。" % (algo, mode, note))
            except Exception:
                pass
            return
        if self.is_three_ma_mode():
            preset_key = self._param_preset_key()
            if not self._load_param_preset(preset_key):
                self.no_tp_var.set(0); self.no_sl_var.set(0)
                self.tp_start_text.set("400"); self.tp_end_text.set("400"); self.tp_step_text.set("50")
                self.sl_start_text.set("300"); self.sl_end_text.set("300"); self.sl_step_text.set("50")
                self.loss_start_text.set("0"); self.loss_end_text.set("0"); self.loss_step_text.set("1")
                self.profit_start_text.set("0"); self.profit_end_text.set("0"); self.profit_step_text.set("1")
            try:
                self.set_setting("defaults.stock_size_mode", mode)
                self.set_setting("defaults.tai_session_mode", self.get_tai_session_mode())
            except Exception:
                pass
            self.save_current_param_texts()
            self._update_strategy_parameter_controls()
            self.render_backtest_group()
            self.mark_estimate_dirty()
            try:
                if mode == "台指期":
                    self.info.configure(text="已切換MA策略＋台指期：固定回測大台 TXF，可選日盤、夜盤或九點盤，MA參數/K棒照原本設定。")
            except Exception:
                pass
            return
        self.no_tp_var.set(0); self.no_sl_var.set(0)
        vals = {
            "tp_start": 5.0, "tp_end": 20.0, "tp_step": 1.0,
            "sl_start": 10.0, "sl_end": 10.0, "sl_step": 1.0,
            "loss_start": 30000.0, "loss_end": 45000.0, "loss_step": 2500.0,
            "profit_start": 30000.0, "profit_end": 45000.0, "profit_step": 2500.0,
        }
        if mode == "小股期":
            for key in ("tp_start", "tp_end", "tp_step", "sl_start", "sl_end", "sl_step"):
                vals[key] = vals[key] * 20.0
            # 認賠/賺飽是新台幣門檻，與大股期相同，不再除以 20。
        elif mode == "台指期":
            # 台指期固定大台 TXF；點數先沿用小火車大台常用預設，使用者可再自行改範圍。
            pass

        def _txt(v):
            try:
                v = float(v)
                if abs(v - round(v)) < 1e-9:
                    return str(int(round(v)))
                return ("%.2f" % v).rstrip("0").rstrip(".")
            except Exception:
                return str(v)

        self.tp_start_text.set(_txt(vals["tp_start"]))
        self.tp_end_text.set(_txt(vals["tp_end"]))
        self.tp_step_text.set(_txt(vals["tp_step"]))
        self.sl_start_text.set(_txt(vals["sl_start"]))
        self.sl_end_text.set(_txt(vals["sl_end"]))
        self.sl_step_text.set(_txt(vals["sl_step"]))
        self.loss_start_text.set(_txt(vals["loss_start"]))
        self.loss_end_text.set(_txt(vals["loss_end"]))
        self.loss_step_text.set(_txt(vals["loss_step"]))
        self.profit_start_text.set(_txt(vals["profit_start"]))
        self.profit_end_text.set(_txt(vals["profit_end"]))
        self.profit_step_text.set(_txt(vals["profit_step"]))
        try:
            self.set_setting("defaults.stock_size_mode", mode)
            self.set_setting("defaults.tai_session_mode", self.get_tai_session_mode())
            self.save_current_param_texts()
        except Exception:
            pass
        self.mark_estimate_dirty()
        try:
            self._update_strategy_parameter_controls()
            self.render_backtest_group()
            if mode == "台指期":
                self.info.configure(text="已切換台指期：固定回測大台 TXF，不需選商品；可選日盤、夜盤或九點盤；策略仍可選 MA策略或小火車策略。")
            else:
                self.info.configure(text="已套用%s預設範圍。" % mode)
        except Exception:
            pass

    def auto_strategy_for_option(self, opt):
        kind = str(getattr(opt, "product_kind", "") or "")
        name = str(getattr(opt, "stock_name", "") or "") + str(getattr(opt, "display", "") or "")
        if self.is_open_price_mode():
            prefix = OPEN_PRICE_STRATEGY_DISPLAY
            if "台指" in kind or "台指" in name or self.is_tai_product_mode():
                return prefix + "-台指期"
            if "小股期" in kind or "小型" in name or str(self.stock_size_mode.get() or "") == "小股期":
                return prefix + "-小股期"
            return prefix + "-大股期"
        if self.is_sma_mode() or self.is_ema_mode():
            prefix = "SMA策略" if self.is_sma_mode() else "EMA策略"
            if "台指" in kind or "台指" in name or self.is_tai_product_mode():
                return prefix + "-台指期"
            if "小股期" in kind or "小型" in name or str(self.stock_size_mode.get() or "") == "小股期":
                return prefix + "-小股期"
            return prefix + "-大股期"
        if self.is_three_ma_mode():
            prefix = "MA策略"
            if "台指" in kind or "台指" in name:
                return prefix + "-台指期"
            if "小股期" in kind or "小型" in name:
                return prefix + "-小股期"
            return prefix + "-大股期"
        if "台指" in kind or "台指" in name:
            return "台指期策略"
        if "小股期" in kind or "小型" in name:
            return "小股期策略"
        return "大股期策略"

    def current_product_option(self):
        """取得目前下拉選到的商品。

        v019 修正：不要只依賴 option_map 的完整顯示字串。使用者搜尋後，
        下拉文字或排名資訊可能重建，這裡改用代號回查，避免選到 KCF
        但按加入時仍抓不到商品。
        """
        text = str(self.product_choice.get() or "").strip()
        opt = self.option_map.get(text)
        if opt:
            return opt
        code_guess = clean_code(text.split("｜")[0].split("|")[0].strip())
        if code_guess:
            for item in list(self.options or []):
                if clean_code(getattr(item, "code", "")) == code_guess:
                    return item
        return None

    def group_codes_text(self, max_items=8):
        if self.is_tai_product_mode():
            return "台指期大台（%s）" % self.get_tai_session_mode()
        names = []
        for opt in list(self.backtest_group or [])[:max_items]:
            names.append(self.product_name_text(opt))
        if len(self.backtest_group or []) > max_items:
            names.append("...共%d檔" % len(self.backtest_group))
        return "、".join(x.strip() for x in names if x.strip())

    def add_selected_product_to_group(self):
        if self.is_tai_product_mode():
            self.info.configure(text="商品類型為台指期時固定回測大台 TXF，不需要加入商品。")
            self.render_backtest_group()
            self.mark_estimate_dirty()
            return
        opt = self.current_product_option()
        if not opt:
            messagebox.showinfo("尚未選擇商品", "請先在商品下拉選單選擇商品。")
            return
        code = clean_code(opt.code)
        if code in self.backtest_group_codes:
            self.info.configure(text="待回測群組已包含：%s｜目前群組：%s" % (self.option_title(opt), self.group_codes_text()))
            return
        self.backtest_group.append(opt)
        self.backtest_group_codes.add(code)
        self.render_backtest_group()
        self.mark_estimate_dirty()
        self.info.configure(text="已加入待回測：%s｜目前%d檔：%s｜請按『重新計算預估時間』更新預估。" % (
            self.option_title(opt),
            len(self.backtest_group),
            self.group_codes_text(),
        ))

    def remove_selected_group_products(self):
        try:
            selected = list(self.group_tree.selection())
        except Exception:
            selected = []
        if not selected:
            return
        remove_codes = set()
        for iid in selected:
            code = clean_code(iid)
            if code:
                remove_codes.add(code)
        self.backtest_group = [o for o in self.backtest_group if clean_code(o.code) not in remove_codes]
        self.backtest_group_codes = set(clean_code(o.code) for o in self.backtest_group)
        self.render_backtest_group()
        self.mark_estimate_dirty()

    def clear_backtest_group(self):
        self.backtest_group = []
        self.backtest_group_codes = set()
        self.render_backtest_group()
        self.mark_estimate_dirty()

    def render_backtest_group(self):
        tai_mode = self.is_tai_product_mode()
        if tai_mode:
            count = 1
            summary = self.group_codes_text(max_items=6)
            try:
                session_label = "日夜盤" if self.is_fast_ma_mode() else self.get_tai_session_mode()
                self.group_summary_text.set("待回測商品：TXF（%s）｜固定大台｜台指保證金：%s｜%s" % (
                    session_label, self.tai_margin_display_text(), self.group_data_dates_summary(max_items=1)
                ))
            except Exception:
                pass
        else:
            count = len(self.backtest_group or [])
            summary = self.group_codes_text(max_items=6)
            try:
                data_summary = self.group_data_dates_summary(max_items=2) if count else "資料：無商品"
                self.group_summary_text.set("待回測商品：%d 檔%s｜%s" % (count, "｜" + summary if summary else "", data_summary))
            except Exception:
                pass
        self._refresh_group_summary_wrap()
        try:
            tree = getattr(self, "group_tree", None)
            if tree is None or not tree.winfo_exists():
                return
            for item in tree.get_children():
                tree.delete(item)
            items = [self.tai_index_option()] if tai_mode else list(self.backtest_group or [])
            for idx, opt in enumerate(items, start=1):
                rank = getattr(opt, "hot_rank", "") or (self.get_tai_session_mode() if tai_mode else "")
                code = clean_code(getattr(opt, "code", ""))
                tree.insert("", END, iid=code or "row_%d" % idx, values=(idx, self.product_name_text(opt), rank))
        except Exception:
            pass

    def add_options_to_group(self, options, source_text=""):
        if self.busy:
            messagebox.showinfo("背景執行中", "目前正在執行：%s，請等它完成後再修改待回測群組。" % self.busy_action)
            return 0
        added = 0
        skipped = 0
        for opt in list(options or []):
            if not opt:
                continue
            code = clean_code(getattr(opt, "code", ""))
            if not code:
                continue
            if code in self.backtest_group_codes:
                skipped += 1
                continue
            self.backtest_group.append(opt)
            self.backtest_group_codes.add(code)
            added += 1
        self.render_backtest_group()
        self.mark_estimate_dirty()
        label = (str(source_text or "熱門排名").strip() or "熱門排名")
        if added:
            self.info.configure(text="已由%s加入%d檔到待回測｜略過重複%d檔｜目前%d檔：%s｜請按『重新計算預估時間』更新預估。" % (
                label, added, skipped, len(self.backtest_group), self.group_codes_text()
            ))
        else:
            self.info.configure(text="%s沒有新增商品｜略過重複%d檔｜目前%d檔：%s" % (
                label, skipped, len(self.backtest_group), self.group_codes_text()
            ))
        return added

    def add_hot_tree_selection_to_group(self, tree, option_by_iid, source_text="熱門排名選取"):
        try:
            selected = list(tree.selection())
        except Exception:
            selected = []
        if not selected:
            messagebox.showinfo("尚未選取商品", "請先在熱門排名表格選取一列或多列，或直接按『加入本頁前10』。")
            return 0
        opts = [option_by_iid.get(iid) for iid in selected if option_by_iid.get(iid) is not None]
        return self.add_options_to_group(opts, source_text)


    def _initial_cpu_workers_text(self):
        saved = str(self.get_setting("backtest.cpu_workers", "最快") or "最快").strip()
        logical = int(os.cpu_count() or 1)
        # 舊版常保存 8/12，會讓 16 邏輯核心只吃 50%~75%。
        # v030 是最快結果版：若舊設定低於「最快」核心數，自動切到最快；使用者仍可手動改回自動/固定核心。
        if logical >= 12:
            if saved in ("", "自動", "auto", "AUTO"):
                return "最快"
            try:
                if int(float(saved)) < max(1, logical - 1):
                    return "最快"
            except Exception:
                pass
        return saved

    def on_cpu_workers_changed(self):
        try:
            self.set_setting("backtest.cpu_workers", str(self.cpu_workers_text.get() or "8"))
            self.save_settings()
        except Exception:
            pass
        self.mark_estimate_dirty()

    def get_backtest_workers(self):
        logical = max(1, int(os.cpu_count() or 1))
        raw = str(self.cpu_workers_text.get() or "最快").strip()
        if raw in ("最快", "max", "MAX", "fast", "FAST"):
            # 最快模式：保留 1 個邏輯核心給 Windows / Tkinter，其餘全部給回測。
            return max(1, min(logical, logical - 1 if logical >= 4 else logical))
        if raw in ("自動", "auto", "AUTO", ""):
            # 穩定模式：保留 2 個邏輯核心。
            return max(1, min(logical, max(1, logical - 2)))
        try:
            val = int(float(raw))
        except Exception:
            val = max(1, logical - 1 if logical >= 4 else logical)
        return max(1, min(logical, val))

    def _round_point2(self, value):
        return round(float(value or 0.0) + 0.0, 2)

    @staticmethod
    def _parse_float_text(text, label):
        raw = str(text or "").strip().replace(",", "")
        if raw == "":
            raise ValueError("%s不可空白。" % label)
        try:
            return float(raw)
        except Exception:
            raise ValueError("%s格式錯誤，請輸入數字。" % label)

    def _range_values(self, start_var, end_var, step_var, label, allow_zero=False, max_values=500):
        start_raw = str(start_var.get() or "").strip()
        end_raw = str(end_var.get() or "").strip()
        step_raw = str(step_var.get() or "").strip()
        start = self._parse_float_text(start_raw, label + "起始")
        end = self._parse_float_text(end_raw, label + "結束") if end_raw else start
        if start < 0 or end < 0:
            raise ValueError("%s不可小於 0。" % label)
        if not allow_zero and (start <= 0 or end <= 0):
            raise ValueError("%s必須大於 0。" % label)
        if end < start:
            raise ValueError("%s結束不可小於起始。" % label)
        if abs(end - start) < 1e-9:
            return [round(start, 2)]
        step = self._parse_float_text(step_raw, label + "每次增加") if step_raw else 0.0
        if step <= 0:
            raise ValueError("%s每次增加必須大於 0。" % label)
        vals = []
        cur = start
        guard = 0
        while cur <= end + 1e-9:
            vals.append(round(cur, 2))
            cur += step
            guard += 1
            if guard > max_values:
                raise ValueError("%s產生超過 %d 組，請加大『每次增加』或縮小範圍。" % (label, max_values))
        return vals

    def get_group_ma_period_values(self):
        if self.is_fast_ma_mode():
            label = "SMA參數" if self.is_sma_mode() else "EMA參數"
            vals = self._range_values(self.sma_start_text, self.sma_end_text, self.sma_step_text, label, allow_zero=False, max_values=999)
            out = []
            for v in vals:
                n = normalize_sma_period(v) if self.is_sma_mode() else normalize_fast_ma_period(v)
                if n not in out:
                    out.append(n)
            # EMA/SMA策略只看下方參數範圍，不再回退到上方均線參數。
            default_val = self.sma_start_text.get() or self.get_setting("defaults.sma_start", "20")
            return out or [normalize_sma_period(default_val) if self.is_sma_mode() else normalize_fast_ma_period(default_val)]
        return [self.get_ma_period()]

    def get_group_param_ranges(self):
        tp_label = "FloatProfitTrigger" if self.is_three_ma_mode() else "每次停利"
        sl_label = "StopLossP" if self.is_three_ma_mode() else "每次停損"
        tp_values = [0.0] if self.no_tp_enabled() else self._range_values(self.tp_start_text, self.tp_end_text, self.tp_step_text, tp_label, allow_zero=False)
        sl_values = [0.0] if self.no_sl_enabled() else self._range_values(self.sl_start_text, self.sl_end_text, self.sl_step_text, sl_label, allow_zero=True)
        if self.is_fast_ma_mode():
            return tp_values, [0.0], [0.0], [0.0]
        # v042：MA策略策略四項風控中，認賠/賺飽固定依扣完手續費後的新台幣累積淨損益判斷。
        loss_values = self._range_values(self.loss_start_text, self.loss_end_text, self.loss_step_text, "認賠下車", allow_zero=True)
        profit_values = self._range_values(self.profit_start_text, self.profit_end_text, self.profit_step_text, "賺飽下車", allow_zero=True)
        return tp_values, sl_values, loss_values, profit_values

    def group_combo_count(self):
        ma_values = self.get_group_ma_period_values()
        tp_values, sl_values, loss_values, profit_values = self.get_group_param_ranges()
        return len(ma_values) * len(tp_values) * len(sl_values) * len(loss_values) * len(profit_values)

    def _estimate_tick_count_for_group(self, d1=None, d2=None):
        total = 0
        per_code = {}
        for opt in self.active_backtest_targets():
            code = clean_code(opt.code)
            cnt = 0
            try:
                if cache_has_code(code):
                    if self.is_fast_ma_mode():
                        cnt = count_cached_ema_txf_kbars_for_code(code, d1, d2, self.get_k_minutes()) or count_cached_ticks_for_code(code, d1, d2, "全部")
                    else:
                        cnt = count_cached_ticks_for_code(code, d1, d2, self.get_tai_session_mode() if self.is_tai_product_mode() else "全部")
                else:
                    cnt = int(getattr(opt, "total_rows", 0) or 0)
            except Exception:
                cnt = int(getattr(opt, "total_rows", 0) or 0)
            per_code[code] = max(0, int(cnt or 0))
            total += per_code[code]
        return total, per_code

    def update_group_estimate(self, silent=False):
        try:
            targets_for_estimate = self.active_backtest_targets()
            if not targets_for_estimate:
                self.estimate_text.set("預估：待回測群組 0 檔，請先選商品後按『加入待回測』")
                return None
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                self.estimate_text.set("預估：請先填完整回測起日與回測迄日")
                return None
            ma_values = self.get_group_ma_period_values()
            tp_values, sl_values, loss_values, profit_values = self.get_group_param_ranges()
            combo_count = len(ma_values) * len(tp_values) * len(sl_values) * len(loss_values) * len(profit_values)
            tp_desc = "不停利" if self.no_tp_enabled() else "停利%d" % len(tp_values)
            sl_desc = "不停損" if self.no_sl_enabled() else "停損%d" % len(sl_values)
            if self.is_sma_mode():
                combo_desc = "SMA策略｜SMA%d組 × K=%s｜%s × %s｜認賠/賺飽停用 = 每檔 %s 組" % (len(ma_values), k_minutes_label(self.get_k_minutes()), tp_desc, sl_desc, f"{combo_count:,}")
            elif self.is_ema_mode():
                combo_desc = "EMA策略｜EMA%d組 × K=%s｜%s × %s｜認賠/賺飽停用 = 每檔 %s 組" % (len(ma_values), k_minutes_label(self.get_k_minutes()), tp_desc, sl_desc, f"{combo_count:,}")
            else:
                prefix_desc = "開盤價策略｜固定1分K｜" if self.is_open_price_mode() else ""
                combo_desc = "%s%s × %s × 認賠%d × 賺飽%d = 每檔 %s 組" % (prefix_desc, tp_desc, sl_desc, len(loss_values), len(profit_values), f"{combo_count:,}")
            products = len(targets_for_estimate)
            total_jobs = products * combo_count
            ticks_one_round, per_code = self._estimate_tick_count_for_group(d1, d2)
            total_tick_units = ticks_one_round * combo_count
            default_speed = 35000.0
            speed = float(self.get_setting("benchmark.tick_units_per_sec", default_speed) or default_speed)
            # v018 初始預設 450 tick-units/sec 太保守，會把十幾分鐘誤估成二十幾小時。
            # 若舊設定檔已存到過低速度，v019 直接拉回合理下限；跑完後仍會用本機實測速度校正。
            if speed < 5000.0:
                speed = default_speed
            workers = self.get_backtest_workers() if hasattr(self, "get_backtest_workers") else 1
            if self.is_sma_mode():
                # v052S：估算也用安全核心上限，避免畫面顯示15/16但實際會被穩定性限制。
                workers = min(max(1, workers), 6)
            effective_speed = speed * max(1, workers) * 0.75
            eta_text = self._format_seconds(total_tick_units / effective_speed) if total_tick_units > 0 else "無資料"
            if self.is_fast_ma_mode():
                product_label = "固定商品 TXF（日夜盤）" if self.is_tai_product_mode() else "%d檔股期商品（日盤）" % products
            else:
                product_label = "固定商品 TXF" if self.is_tai_product_mode() else "%d檔商品" % products
            unit_label = (ma_algo_label(self.strategy_mode.get()) + "高速K棒約") if self.is_fast_ma_mode() else "逐筆運算約"
            speed_label = "K棒/秒" if self.is_fast_ma_mode() else "筆/秒"
            detail = (
                "預估：%s｜%s｜共 %s 次回測｜"
                "%s %s 單位｜估計約 %s｜核心%d/%d｜速度基準約 %s %s｜"
                "執行後改用即時速度；完成後先顯示前1000名，CSV仍含全部。"
            ) % (
                product_label, combo_desc, f"{total_jobs:,}", unit_label,
                f"{int(total_tick_units):,}", eta_text, workers, max(1, int(os.cpu_count() or 1)), f"{int(speed):,}", speed_label
            )
            self.estimate_text.set(detail)
            return {"products": products, "combo_count": combo_count, "total_jobs": total_jobs, "tick_units": total_tick_units, "per_code": per_code, "eta_text": eta_text}
        except Exception as e:
            msg = "預估失敗：%s" % e
            self.estimate_text.set(msg)
            if not silent:
                messagebox.showerror("預估失敗", str(e))
            return None

    def _estimate_tick_units_for_job_groups(self, job_groups, d1=None, d2=None):
        total = 0
        per_code = {}
        for group in list(job_groups or []):
            opt = group.get("opt")
            combos = list(group.get("combos") or [])
            code = clean_code(getattr(opt, "code", ""))
            if not code:
                continue
            try:
                if cache_has_code(code):
                    if self.is_fast_ma_mode():
                        cnt = count_cached_ema_txf_kbars_for_code(code, d1, d2, k_minutes if 'k_minutes' in locals() else self.get_k_minutes()) or count_cached_ticks_for_code(code, d1, d2, "全部")
                    else:
                        cnt = count_cached_ticks_for_code(code, d1, d2, self.get_tai_session_mode() if self.is_tai_product_mode() or str(getattr(opt, "product_kind", "")) == "台指期" else "全部")
                else:
                    cnt = int(getattr(opt, "total_rows", 0) or 0)
            except Exception:
                cnt = int(getattr(opt, "total_rows", 0) or 0)
            per_code[code] = max(0, int(cnt or 0))
            total += per_code[code] * max(1, len(combos))
        return total, per_code

    def _run_group_job_groups(self, job_groups, d1, d2, lots, action_name="群組參數回測", mode_note="v030最快結果模式+預分組Tick+高核心+Top快速出表", k_minutes=None, ma_period=None):
        k_minutes = self.get_k_minutes() if k_minutes is None else (normalize_ema_k_minutes(k_minutes) if self.is_fast_ma_mode() else normalize_k_minutes(k_minutes))
        ma_period = self.get_ma_period() if ma_period is None else (normalize_fast_ma_period(ma_period) if self.is_fast_ma_mode() else normalize_ma_period(ma_period))
        job_groups = [g for g in list(job_groups or []) if g.get("opt") is not None and list(g.get("combos") or [])]
        if not job_groups:
            messagebox.showinfo("沒有可執行的參數", "沒有產生任何回測參數組。")
            return
        total_jobs = sum(len(g.get("combos") or []) for g in job_groups)
        targets_count = len(job_groups)
        total_tick_units_est, _per_code = self._estimate_tick_units_for_job_groups(job_groups, d1, d2)
        if total_jobs > 20000:
            ok = messagebox.askyesno("回測組數很多", "這次會執行 %s 次回測，可能非常久。\n確定要開始嗎？" % f"{total_jobs:,}")
            if not ok:
                return
        started_at = time_module.time()

        def worker():
            results = []
            done_units = 0
            processed_jobs = 0
            total_units = max(1, int(total_tick_units_est or 0))
            requested_workers = max(1, self.get_backtest_workers())
            logical = max(1, int(os.cpu_count() or 1))
            # v052S：SMA 多核心不再全開 15/16 核。TXF 一個月約數百萬 tick，
            # 每個 Process 都會載入一份資料；全開容易讓 Windows 子程序被記憶體/IPC 壓力中斷。
            # 先用產品逐筆數在每檔商品內動態限制成安全核心，避免 ProcessPool abruptly terminated。
            sma_memory_mode = bool(self.is_sma_mode())
            workers = min(requested_workers, 6) if sma_memory_mode else requested_workers
            parallel_enabled = workers > 1 and total_jobs > 1
            mode_text = "%s｜使用核心%d/%d%s%s" % (
                mode_note, workers, logical,
                "｜安全多核心平行" if parallel_enabled and sma_memory_mode else ("｜多核心平行" if parallel_enabled else "｜單核心"),
                "｜SMA記憶體均線" if sma_memory_mode else ""
            )

            def _runtime_suffix():
                elapsed2 = max(0.01, time_module.time() - started_at)
                if processed_jobs <= 0:
                    return "即時速度估算中"
                jobs_per_sec = processed_jobs / elapsed2
                remain_jobs = max(0, total_jobs - processed_jobs)
                return "即時速度 %.2f 組/秒｜即時剩餘 %s" % (jobs_per_sec, self._format_seconds(remain_jobs / max(jobs_per_sec, 0.0001)))

            self.status_update("背景執行中：%s｜準備開始｜共%s組｜使用核心%d/%d｜理論預估僅供參考，執行中改用即時速度" % (action_name, f"{total_jobs:,}", workers, logical))

            for pidx, group in enumerate(job_groups, start=1):
                if self.cancel_requested:
                    raise OperationCancelled()
                opt = group.get("opt")
                combos = list(group.get("combos") or [])
                code = clean_code(getattr(opt, "code", ""))
                strategy_name = self.auto_strategy_for_option(opt)
                self.progress_update(done_units, total_units, "準備讀取 %d/%d｜%s｜%d組參數｜使用核心%d/%d" % (
                    pidx, targets_count, self.option_title(opt), len(combos), workers, logical
                ))
                ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="讀取 %d/%d" % (pidx, targets_count), start_date=d1, end_date=d2)
                if self.cancel_requested:
                    raise OperationCancelled()
                if not ticks:
                    results.append({"opt": opt, "strategy": strategy_name, "status": "無逐筆資料", "avg": -1e18, "total": 0.0, "valid_days": 0, "range": "無資料", "ds": [], "tr": [], "params": {}})
                    continue
                raw_tick_count = max(1, len(ticks))
                product_units = raw_tick_count
                if self.is_fast_ma_mode():
                    product_units = max(1, _ema_fast_estimated_bar_count_from_ticks(ticks, k_minutes, code))
                    self.progress_update(done_units, total_units, "商品 %d/%d｜%s｜逐筆已讀取 %s 筆｜準備%s高速K棒快取 %s" % (
                        pidx, targets_count, self.option_title(opt), f"{raw_tick_count:,}", ma_algo_label(strategy_name), k_minutes_label(k_minutes)
                    ))
                    ensure_ema_kbars_for_code_k(code, k_minutes, progress=lambda cur, total, detail: self.progress_update(done_units, total_units, "商品 %d/%d｜%s｜%s" % (
                        pidx, targets_count, self.option_title(opt), detail
                    )))
                combo_count = len(combos)
                manual_ema_closes = None
                if self.is_fast_ma_mode():
                    # v052M：EMA/SMA回測固定走 ema_txf_cache.db 高速路徑；不再提示/套用實盤暖機補值。
                    manual_ema_closes = None

                if parallel_enabled:
                    # v026：同商品 tick 只寫入暫存檔一次；每個回測核心在 initializer 載入一次後共用。
                    # 舊版把整份 ticks 塞進每個 payload，11組參數就會重複序列化/複製11次，取消也要等整批跑完。
                    run_workers = _adaptive_parallel_workers(workers, combo_count, product_units)
                    if sma_memory_mode and self.is_fast_ma_mode():
                        # v052S：SMA worker 會各自載入 TXF 逐筆資料並建立記憶體K棒上下文。
                        # 資料量越大越不能全開核心，否則 Windows 會直接殺掉子程序。
                        if raw_tick_count >= 2000000:
                            sma_cap = 2
                        elif raw_tick_count >= 500000:
                            sma_cap = 4
                        else:
                            sma_cap = 6
                        run_workers = max(1, min(run_workers, combo_count, sma_cap, logical))
                    packed_file = None
                    completed_jobs_for_product = 0
                    try:
                        fd, packed_file = tempfile.mkstemp(prefix="train_ticks_%s_" % code, suffix=".pkl")
                        with os.fdopen(fd, "wb") as f:
                            pickle.dump(_pack_ticks_for_worker(ticks), f, protocol=pickle.HIGHEST_PROTOCOL)
                        loaded_unit_text = ("%s 筆Tick / 約 %s 根K棒" % (f"{raw_tick_count:,}", f"{product_units:,}")) if self.is_fast_ma_mode() else ("%s 筆Tick" % f"{raw_tick_count:,}")
                        self.progress_update(done_units, total_units, "商品 %d/%d｜%s｜已載入 %s｜啟動核心%d/%d" % (
                            pidx, targets_count, self.option_title(opt), loaded_unit_text, run_workers, logical
                        ))
                        ex = concurrent.futures.ProcessPoolExecutor(
                            max_workers=run_workers,
                            initializer=_init_backtest_worker_from_file,
                            initargs=(packed_file, strategy_name, lots, code, k_minutes, ma_period, self.get_entry_mode(), self.one_way_fee_value(), manual_ema_closes),
                        )
                        try:
                            self._set_active_executor(ex)
                            # v029：每個 future 連跑多組，減少 275 個 future 的排程/IPC 成本；
                            # chunks 約為核心數的 3 倍，兼顧負載平衡與進度更新。
                            # v043：不可用 ProcessPoolExecutor 的 with 區塊收尾。Windows 上有機率
                            # 在所有 future 已回收、進度已到 100%% 後，卡在 shutdown(wait=True)。
                            # 因此結果一取回就主動 non-blocking shutdown，再補終止子核心，避免面板停在 100%%。
                            chunk_count = max(run_workers, min(combo_count, run_workers * 3))
                            combo_chunks = _chunk_list_even(combos, chunk_count)
                            pending = set(ex.submit(_run_backtest_combo_chunk_worker, chunk) for chunk in combo_chunks if chunk)
                            last_ui_update = 0.0
                            while pending:
                                if self.cancel_requested:
                                    for f in list(pending):
                                        f.cancel()
                                    self._cancel_active_executor()
                                    raise OperationCancelled()
                                done_set, pending = concurrent.futures.wait(
                                    pending, timeout=0.20, return_when=concurrent.futures.FIRST_COMPLETED
                                )
                                if not done_set:
                                    continue
                                if self.cancel_requested:
                                    for f in list(pending) + list(done_set):
                                        f.cancel()
                                    self._cancel_active_executor()
                                    raise OperationCancelled()
                                for fut in done_set:
                                    try:
                                        chunk_results = fut.result()
                                    except Exception:
                                        if self.cancel_requested:
                                            self._cancel_active_executor()
                                            raise OperationCancelled()
                                        raise
                                    for rr in list(chunk_results or []):
                                        rr["opt"] = opt
                                        results.append(rr)
                                    n_done = len(chunk_results or [])
                                    completed_jobs_for_product += n_done
                                    processed_jobs += n_done
                                    done_units += product_units * n_done
                                now_ui = time_module.time()
                                if now_ui - last_ui_update >= 0.35 or completed_jobs_for_product >= combo_count:
                                    last_ui_update = now_ui
                                    self.progress_update(done_units, total_units, "商品 %d/%d｜%s｜完成 %d/%d 組｜總組 %d/%d｜核心%d/%d｜%s" % (
                                        pidx, targets_count, self.option_title(opt), completed_jobs_for_product, combo_count,
                                        processed_jobs, total_jobs, run_workers, logical, _runtime_suffix()
                                    ))
                            self.status_update("背景執行中：%s｜多核心結果已回收｜正在關閉子核心..." % action_name)
                        finally:
                            self._set_active_executor(None)
                            try:
                                ex.shutdown(wait=False, cancel_futures=True)
                            except Exception:
                                pass
                            try:
                                _terminate_process_pool(ex)
                            except Exception:
                                pass
                    finally:
                        self._set_active_executor(None)
                        if packed_file:
                            try:
                                os.remove(packed_file)
                            except Exception:
                                pass
                else:
                    fast_context_cache = {}
                    for cidx, combo in enumerate(combos, start=1):
                        if self.cancel_requested:
                            raise OperationCancelled()
                        params = _combo_params(strategy_name, lots, code, combo, k_minutes=k_minutes, ma_period=ma_period, entry_mode=self.get_entry_mode(), one_way_fee=self.one_way_fee_value())
                        tp = float(params.get("tp_points", 0.0) or 0.0)
                        sl = float(params.get("sl_points", 0.0) or 0.0)
                        loss_exit = float(params.get("loss_exit", 0.0) or 0.0)
                        profit_exit = float(params.get("lock_profit_exit", 0.0) or 0.0)
                        params2 = dict(params)
                        if manual_ema_closes:
                            params2["manual_ema_closes"] = manual_ema_closes
                        if total_jobs <= 3:
                            base_units = done_units
                            def _progress(cur, total, detail, _pidx=pidx, _cidx=cidx, _opt=opt, _tp=tp, _sl=sl, _loss=loss_exit, _profit=profit_exit, _base=base_units, _combo_count=combo_count):
                                self.progress_update(_base + min(float(cur or 0), product_units), total_units,
                                                     "商品 %d/%d｜組 %d/%d｜%s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f｜%s" % (
                                                         _pidx, targets_count, _cidx, _combo_count, self.option_title(_opt), _tp, _sl, _loss, _profit, detail
                                                     ))
                            params2["progress"] = _progress
                        else:
                            params2["progress"] = None
                        try:
                            if is_fast_ma_strategy(strategy_name):
                                ckey = (ma_algo_label(strategy_name), int(params.get("k_minutes", k_minutes) or k_minutes), int(params.get("ma_period", ma_period) or ma_period))
                                ctx = fast_context_cache.get(ckey)
                                if ctx is None:
                                    if is_sma_strategy(strategy_name):
                                        ctx = build_sma_txf_fast_context_from_session_items(_prepare_session_items_from_ticks(ticks), code, ckey[1], ckey[2], progress=params2.get("progress"))
                                    else:
                                        ctx = build_ema_txf_fast_context_from_session_items(_prepare_session_items_from_ticks(ticks), code, ckey[1], ckey[2], progress=params2.get("progress"))
                                    fast_context_cache[ckey] = ctx
                                ds, tr, _records, _events = run_ema_txf_fast_backtest_context(ctx, progress=params2.get("progress"), **params)
                            else:
                                ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, **params2)
                            result = _summarize_combo_result(ds, tr, params)
                        except Exception as e:
                            result = _summarize_failed_combo_result(params, e)
                        result["opt"] = opt
                        results.append(result)
                        processed_jobs += 1
                        done_units += product_units
                        if processed_jobs == 1 or processed_jobs % 3 == 0 or processed_jobs == total_jobs:
                            self.progress_update(done_units, total_units, "已完成 %d/%d 組回測｜%s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f｜使用核心%d/%d｜%s" % (
                                processed_jobs, total_jobs, self.option_title(opt), tp, sl, loss_exit, profit_exit, workers, logical, _runtime_suffix()
                            ))
            self.status_update("背景執行中：%s｜回測運算100%%｜結果排序/整理中...｜完成%s組｜使用核心%d/%d" % (action_name, f"{processed_jobs:,}", workers, logical))
            for _row in results:
                try:
                    _row["rank_score"] = self.result_rank_score(_row)
                except Exception:
                    _row["rank_score"] = -1e18
            results.sort(key=lambda x: (float(x.get("rank_score", -1e18) or -1e18), float(x.get("avg", -1e18) or -1e18)), reverse=True)
            elapsed = max(0.01, time_module.time() - started_at)
            actual_units = max(1, done_units or total_tick_units_est)
            return {"results": results, "elapsed": elapsed, "tick_units": actual_units, "jobs": processed_jobs, "products": targets_count, "mode_note": mode_text, "workers": workers, "logical": logical}

        def done(payload):
            results = payload.get("results", []) if isinstance(payload, dict) else []
            elapsed = float(payload.get("elapsed", 0.0) or 0.0) if isinstance(payload, dict) else 0.0
            tick_units = float(payload.get("tick_units", 0.0) or 0.0) if isinstance(payload, dict) else 0.0
            jobs = int(payload.get("jobs", 0) or 0) if isinstance(payload, dict) else 0
            products = int(payload.get("products", targets_count) or targets_count) if isinstance(payload, dict) else targets_count
            note = str(payload.get("mode_note", mode_note) or mode_note) if isinstance(payload, dict) else mode_note
            if elapsed > 0 and tick_units > 0:
                speed = tick_units / elapsed
                old = float(self.get_setting("benchmark.tick_units_per_sec", speed) or speed)
                self.set_setting("benchmark.tick_units_per_sec", max(1.0, old * 0.4 + speed * 0.6))
                self.save_settings()
            self.status_update("背景執行中：%s｜結果排序完成｜正在快速出表...｜共%s組" % (action_name, f"{len(results):,}"))
            self.render_group_results(results)
            if results:
                best = results[0]
                show_note = "｜總表/分商品均顯示每檔前10名｜排序依平均每日獲利/原始保證金"
                self.info.configure(text="%s完成｜商品%d檔｜完成%d組｜耗時%s｜%s%s｜最佳 %s｜平均每日獲利 %s｜參數：停利%.2f 停損%.2f 認賠%.0f 賺飽%.0f" % (
                    action_name, products, jobs, self._format_seconds(elapsed), note, show_note, self.option_title(best.get("opt")), format_money_plain(best.get("avg", 0)),
                    best.get("params", {}).get("tp_points", 0.0), best.get("params", {}).get("sl_points", 0.0),
                    best.get("params", {}).get("loss_exit", 0.0), best.get("params", {}).get("lock_profit_exit", 0.0)
                ))
            else:
                self.info.configure(text="%s完成，但沒有可用結果。" % action_name)
            self.tabs.select(self.result_frame)

        self.run_background(action_name, worker, done)

    def run_group_backtest(self):
        if not self.options and not self.is_tai_product_mode():
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再加入待回測商品。")
            return
        targets = self.active_backtest_targets()
        if not targets:
            messagebox.showinfo("待回測群組是空的", "請先選商品，按「加入待回測」。")
            return
        try:
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                raise ValueError("請填完整回測起日與回測迄日。")
            ma_values = self.get_group_ma_period_values()
            tp_values, sl_values, loss_values, profit_values = self.get_group_param_ranges()
        except Exception as e:
            messagebox.showerror("參數錯誤", str(e))
            return
        if self.is_fast_ma_mode():
            combos = list(itertools.product(ma_values, tp_values, sl_values, loss_values, profit_values))
        else:
            combos = list(itertools.product(tp_values, sl_values, loss_values, profit_values))
        self.save_current_param_texts()
        combo_count = len(combos)
        targets = self.active_backtest_targets()
        total_jobs = combo_count * len(targets)
        self.update_group_estimate(silent=True)
        try:
            self.info.configure(text="本次回測清單已鎖定：%s｜共%d檔｜%d組參數/檔｜共%d次回測" % (
                self.group_codes_text(), len(targets), combo_count, total_jobs
            ) + (("｜SMA%d～%d|%s|%s" % (min(ma_values), max(ma_values), k_minutes_label(self.get_k_minutes()), self.get_entry_mode())) if self.is_sma_mode() else (("｜EMA%d～%d|%s|%s" % (min(ma_values), max(ma_values), k_minutes_label(self.get_k_minutes()), self.get_entry_mode())) if self.is_ema_mode() else (("｜%dMA|%s" % (self.get_ma_period(), k_minutes_label(self.get_k_minutes()))) if self.is_three_ma_mode() else ("｜開盤價|1分K" if self.is_open_price_mode() else "")))) + ("｜全盤" if (self.is_fast_ma_mode() and self.is_tai_product_mode()) else ("｜%s" % self.get_tai_session_mode() if self.is_tai_product_mode() else "")), foreground="red")
        except Exception:
            pass
        lots = int(self.lots.get() or 1)
        job_groups = [{"opt": opt, "combos": combos} for opt in targets]
        self._run_group_job_groups(job_groups, d1, d2, lots, action_name="群組參數回測", mode_note="v030最快結果模式+預分組Tick+高核心+Top快速出表", k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period())

    def _current_numeric_step(self, var, default_value):
        try:
            val = float(str(var.get() or "").strip().replace(",", ""))
            if val > 0:
                return val
        except Exception:
            pass
        return float(default_value)

    def _fine_point_values(self, center, coarse_step, allow_zero=False):
        center = float(center or 0.0)
        coarse_step = max(0.01, float(coarse_step or 1.0))
        if coarse_step >= 5.0:
            fine_step = 1.0
        elif coarse_step > 1.0:
            fine_step = 0.5
        else:
            fine_step = max(0.25, coarse_step)
        span = max(coarse_step, fine_step * 2.0)
        start = center - span
        end = center + span
        if allow_zero:
            start = max(0.0, start)
        else:
            start = max(fine_step, start)
        vals = []
        cur = start
        guard = 0
        while cur <= end + 1e-9:
            vals.append(round(cur, 2))
            cur += fine_step
            guard += 1
            if guard > 200:
                break
        if round(center, 6) not in vals and (allow_zero or center > 0):
            vals.append(round(center, 6))
        return sorted(set(vals))

    def _fine_money_values(self, center, coarse_step, allow_zero=False):
        center = float(center or 0.0)
        coarse_step = max(1.0, float(coarse_step or 1000.0))
        if coarse_step >= 5000:
            fine_step = 1000.0
        elif coarse_step >= 1000:
            fine_step = 1000.0
        else:
            fine_step = max(100.0, coarse_step)
        span = max(coarse_step, fine_step * 2.0)
        start = center - span
        end = center + span
        if allow_zero:
            start = max(0.0, start)
        else:
            start = max(fine_step, start)
        # 新台幣門檻以整數處理，避免出現 24999.999 類型的顯示。
        vals = []
        cur = start
        guard = 0
        while cur <= end + 1e-9:
            vals.append(float(round(cur)))
            cur += fine_step
            guard += 1
            if guard > 300:
                break
        c = float(round(center))
        if c not in vals and (allow_zero or c > 0):
            vals.append(c)
        return sorted(set(vals))

    def _fine_combos_for_result_row(self, row):
        params = row.get("params") or {}
        if not params:
            return []
        tp = float(params.get("tp_points", 0.0) or 0.0)
        sl = float(params.get("sl_points", 0.0) or 0.0)
        loss = float(params.get("loss_exit", 0.0) or 0.0)
        profit = float(params.get("lock_profit_exit", 0.0) or 0.0)
        tp_step = self._current_numeric_step(self.tp_step_text, 1.0)
        sl_step = self._current_numeric_step(self.sl_step_text, 1.0)
        loss_step = self._current_numeric_step(self.loss_step_text, 1000.0)
        profit_step = self._current_numeric_step(self.profit_step_text, 1000.0)
        tp_values = [0.0] if (self.no_tp_enabled() or tp <= 0) else self._fine_point_values(tp, tp_step, allow_zero=False)
        sl_values = [0.0] if (self.no_sl_enabled() or sl <= 0) else self._fine_point_values(sl, sl_step, allow_zero=True)
        strategy_name = str(row.get("strategy") or params.get("strategy_name") or "")
        if is_fast_ma_strategy(strategy_name):
            # EMA/SMA 精跑必須沿用選取結果的均線參數，不可回到畫面目前起始值。
            ma_val = normalize_fast_ma_period(params.get("ma_period", self.get_ma_period()))
            return list(itertools.product([ma_val], tp_values, sl_values, [0.0], [0.0]))
        loss_values = self._fine_money_values(loss, loss_step, allow_zero=False)
        profit_values = self._fine_money_values(profit, profit_step, allow_zero=False)
        return list(itertools.product(tp_values, sl_values, loss_values, profit_values))

    def _build_fine_job_groups(self, seed_rows):
        groups = {}
        for row in list(seed_rows or []):
            if not row or row.get("status") != "完成":
                continue
            opt = row.get("opt")
            code = clean_code(getattr(opt, "code", ""))
            if not code:
                continue
            combos = self._fine_combos_for_result_row(row)
            if not combos:
                continue
            if code not in groups:
                groups[code] = {"opt": opt, "combo_set": set(), "combos": []}
            for combo in combos:
                key = tuple(round(float(x), 6) for x in combo)
                if key in groups[code]["combo_set"]:
                    continue
                groups[code]["combo_set"].add(key)
                groups[code]["combos"].append(combo)
        return [{"opt": data["opt"], "combos": data["combos"]} for data in groups.values()]

    def _fine_job_count_text(self, job_groups):
        products = len(job_groups or [])
        total = sum(len(g.get("combos") or []) for g in list(job_groups or []))
        return "%d檔商品｜共%d組精跑參數" % (products, total)

    def run_fine_backtest_selected(self):
        if not self.last_group_results:
            messagebox.showinfo("尚無回測結果", "請先執行群組參數回測，再點選一筆結果精跑。")
            return
        try:
            sel = list(self.result_tree.selection())
        except Exception:
            sel = []
        if not sel:
            messagebox.showinfo("尚未選取結果", "請先在『回測結果』表格點選一筆結果，再按精跑。")
            return
        row = self.result_row_map.get(sel[0])
        if not row:
            messagebox.showinfo("尚未選取結果", "請先在『回測結果』表格點選一筆有效結果。")
            return
        try:
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                raise ValueError("請填完整回測起日與回測迄日。")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return
        job_groups = self._build_fine_job_groups([row])
        if not job_groups:
            messagebox.showinfo("無法精跑", "選取結果沒有可用參數。")
            return
        self.info.configure(text="準備以選取結果精跑｜%s" % self._fine_job_count_text(job_groups), foreground="red")
        self._run_group_job_groups(job_groups, d1, d2, int(self.lots.get() or 1), action_name="選取結果精跑", mode_note="v026自動細化", k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period())

    def run_fine_backtest_top5(self):
        rows = [r for r in list(self.last_group_results or []) if r.get("status") == "完成"][:5]
        if not rows:
            messagebox.showinfo("尚無回測結果", "請先執行群組參數回測，產生排名後再以前5名精跑。")
            return
        try:
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                raise ValueError("請填完整回測起日與回測迄日。")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return
        job_groups = self._build_fine_job_groups(rows)
        if not job_groups:
            messagebox.showinfo("無法精跑", "前5名結果沒有可用參數。")
            return
        total_jobs = sum(len(g.get("combos") or []) for g in job_groups)
        ok = messagebox.askyesno("確認以前5名精跑", "將以前5名結果各自展開附近參數並去除重複。\n%s\n是否開始？" % self._fine_job_count_text(job_groups))
        if not ok:
            return
        self.info.configure(text="準備以前5名精跑｜%s" % self._fine_job_count_text(job_groups), foreground="red")
        self._run_group_job_groups(job_groups, d1, d2, int(self.lots.get() or 1), action_name="前5名精跑", mode_note="v026自動細化", k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period())

    def result_rank_score(self, row):
        try:
            avg = float(row.get("avg", -1e18) or -1e18)
            if avg < -1e17:
                return -1e18
            opt = row.get("opt")
            margin = float(getattr(opt, "base_margin", 0.0) or 0.0)
            if margin <= 0 and (str(getattr(opt, "product_kind", "") or "") == "台指期" or is_tai_index_code(getattr(opt, "code", ""))):
                margin = self.tai_margin_value()
                try:
                    opt.base_margin = margin
                except Exception:
                    pass
            if margin <= 0:
                return -1e18
            return avg / margin
        except Exception:
            return -1e18

    def result_product_key(self, row):
        try:
            opt = row.get("opt")
            return clean_code(getattr(opt, "code", ""))
        except Exception:
            return ""

    def _sort_result_rows_by_score(self, rows):
        return sorted(list(rows or []), key=lambda x: (self.result_rank_score(x), float(x.get("avg", -1e18) or -1e18)), reverse=True)

    def _top10_each_product(self, rows):
        grouped = {}
        for row in list(rows or []):
            if row.get("status") != "完成":
                continue
            code = self.result_product_key(row)
            if not code:
                code = "UNKNOWN"
            grouped.setdefault(code, []).append(row)
        picked = []
        for code in grouped:
            picked.extend(self._sort_result_rows_by_score(grouped[code])[:10])
        return self._sort_result_rows_by_score(picked)

    def _current_result_rows_for_display(self):
        rows = list(self.last_group_results or [])
        filt = str(self.result_filter_text.get() or "總表")
        code = self.result_filter_code_map.get(filt, "")
        if code:
            rows = [r for r in rows if self.result_product_key(r) == code]
            return self._sort_result_rows_by_score([r for r in rows if r.get("status") == "完成"])[:10]
        return self._top10_each_product(rows)

    def update_result_filter_options(self, results):
        code_to_name = {}
        for row in list(results or []):
            opt = row.get("opt")
            code = clean_code(getattr(opt, "code", ""))
            if not code or code in code_to_name:
                continue
            code_to_name[code] = self.product_name_text(opt)
        values = ["總表"] + [code_to_name[c] for c in sorted(code_to_name, key=lambda k: code_to_name[k])]
        self.result_filter_code_map = {code_to_name[c]: c for c in code_to_name}
        try:
            self.result_filter_box.configure(values=values)
        except Exception:
            pass
        cur = str(self.result_filter_text.get() or "")
        if cur not in values:
            self.result_filter_text.set("總表")

    def _result_row_uses_ma(self, row):
        params = row.get("params") or {}
        strategy_name = str(row.get("strategy") or params.get("strategy_name") or "")
        return is_param_strategy(strategy_name)

    def _update_result_display_columns(self, rows):
        try:
            tree = self.result_tree
            default_cols = list(tree["columns"] or [])
            saved_order = self.get_setting("column_order.result", [])
            if isinstance(saved_order, list) and saved_order:
                order = [c for c in saved_order if c in default_cols] + [c for c in default_cols if c not in saved_order]
            else:
                order = default_cols
            # 055C：舊欄位順序設定不含 margin 時，仍固定讓「保證金」貼在商品名稱後面，不要被補到最右側。
            if "margin" in order and "name" in order:
                try:
                    order = [c for c in order if c != "margin"]
                    order.insert(order.index("name") + 1, "margin")
                except Exception:
                    pass
            show_ma = any(self._result_row_uses_ma(r) for r in list(rows or []))
            if not show_ma:
                order = [c for c in order if c != "ma_period"]
            tree["displaycolumns"] = order
        except Exception:
            pass

    def render_result_view(self):
        self.clear_tree(self.result_tree)
        self.result_row_map = {}
        rows_to_show = self._current_result_rows_for_display()
        self._update_result_display_columns(rows_to_show)
        for idx, row in enumerate(rows_to_show, start=1):
            opt = row.get("opt")
            params = row.get("params") or {}
            avg = float(row.get("avg", 0.0) or 0.0)
            status = row.get("status", "")
            avg_text = "" if avg < -1e17 else format_money_plain(avg)
            score = self.result_rank_score(row)
            score_text = "" if score < -1e17 else ("%.2f%%" % (score * 100.0))
            # ttk Treeview 不支援單一儲存格上色；結果列先維持黑字，避免整列紅/綠。
            iid = self.result_tree.insert("", END, values=(
                idx,
                self.product_name_text(opt),
                format_money_plain(float(getattr(opt, "base_margin", 0.0) or 0.0)),
                score_text,
                avg_text,
                format_money_plain(row.get("total", 0)),
                row.get("valid_days", 0),
                row.get("range", ""),
                ( (ma_algo_label(str(row.get("strategy") or params.get("strategy_name") or "")) + str(normalize_fast_ma_period(params.get("ma_period", 89)))) if is_fast_ma_strategy(str(row.get("strategy") or params.get("strategy_name") or "")) else (str(normalize_ma_period(params.get("ma_period", 3))) + "MA") ) if (params and self._result_row_uses_ma(row)) else "",
                (k_minutes_label(normalize_ema_k_minutes(params.get("k_minutes", 1))) if is_fast_ma_strategy(str(row.get("strategy") or params.get("strategy_name") or "")) else k_minutes_label(normalize_k_minutes(params.get("k_minutes", 1)))) if params else "",
                ("不停利" if float(params.get("tp_points", 0.0) or 0.0) <= 0 else "%.2f" % float(params.get("tp_points", 0.0) or 0.0)) if params else "",
                ("不停損" if float(params.get("sl_points", 0.0) or 0.0) <= 0 else "%.2f" % float(params.get("sl_points", 0.0) or 0.0)) if params else "",
                safe_int_text(params.get("loss_exit", 0.0)) if params else "",
                safe_int_text(params.get("lock_profit_exit", 0.0)) if params else "",
                row.get("trades", 0),
                row.get("tp", 0),
                row.get("sl", 0),
                row.get("loss_exit_count", 0),
                row.get("profit_exit_count", 0),
                format_money_plain(row.get("peak", 0.0)),
                format_money_plain(row.get("trough", 0.0)),
                status,
            ), tags=("zero",))
            self.result_row_map[iid] = row
        try:
            self.status_update("回測結果已依平均每日獲利/原始保證金排序｜目前顯示%s｜%d列" % (str(self.result_filter_text.get() or "總表"), len(rows_to_show)))
        except Exception:
            pass

    def render_group_results(self, results):
        """大量參數回測完成後出榜。

        v032：總表與各商品頁都只顯示每檔商品前10名；排名依
        平均每日獲利 / 原始保證金，由大到小。完整資料仍保留在
        self.last_group_results 供精跑與匯出依目前篩選使用。
        """
        self.last_group_results = self._sort_result_rows_by_score(list(results or []))
        for row in self.last_group_results:
            try:
                row["rank_score"] = self.result_rank_score(row)
            except Exception:
                row["rank_score"] = -1e18
        self.result_detail_cache = {}
        self.update_result_filter_options(self.last_group_results)
        self.render_result_view()

    def _result_detail_cache_key(self, row):
        opt = row.get("opt")
        params = row.get("params") or {}
        return (
            clean_code(getattr(opt, "code", "") or params.get("product_code", "")),
            str(row.get("strategy", "") or params.get("strategy_name", "")),
            float(params.get("tp_points", 0.0) or 0.0),
            float(params.get("sl_points", 0.0) or 0.0),
            float(params.get("loss_exit", 0.0) or 0.0),
            float(params.get("lock_profit_exit", 0.0) or 0.0),
            int(params.get("lots", self.lots.get() or 1) or 1),
            normalize_k_minutes(params.get("k_minutes", self.get_k_minutes() if hasattr(self, "get_k_minutes") else 1)),
            (normalize_fast_ma_period(params.get("ma_period", self.get_ma_period() if hasattr(self, "get_ma_period") else 89)) if is_fast_ma_strategy(str(row.get("strategy") or params.get("strategy_name") or "")) else normalize_ma_period(params.get("ma_period", self.get_ma_period() if hasattr(self, "get_ma_period") else 3))),
            float(params.get("one_way_fee", 0.0) or 0.0),
            str(row.get("range", "")),
        )

    def load_result_row_detail(self, row):
        try:
            if not row:
                return
            params = dict(row.get("params") or {})
            opt = row.get("opt")
            code = clean_code(getattr(opt, "code", "") or params.get("product_code", ""))
            strategy_name = str(row.get("strategy", "") or params.get("strategy_name", "") or strategy_for_option(opt, self.strategy.get()))
            if not code:
                return
            d1, d2 = self._parse_date_range()
            key = self._result_detail_cache_key(row)
            cached = self.result_detail_cache.get(key)
            if cached:
                ds, tr = cached
                self.last_day_stats, self.last_trades = ds, tr
                self.render_day_stats(ds)
                self.render_trades(tr)
                self.info.configure(text="已載入快取明細｜%s｜平均每日獲利 %s｜總淨利 %s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f" % (
                    self.option_title(opt), format_money_plain(row.get("avg", 0)), format_money_plain(row.get("total", 0)),
                    float(params.get("tp_points", 0.0) or 0.0), float(params.get("sl_points", 0.0) or 0.0),
                    float(params.get("loss_exit", 0.0) or 0.0), float(params.get("lock_profit_exit", 0.0) or 0.0)
                ))
                self.tabs.select(self.summary_frame)
                return

            def worker():
                ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="明細讀取", start_date=d1, end_date=d2)
                if not ticks:
                    raise ValueError("所選商品在回測日期範圍沒有可用逐筆資料。")
                run_params = dict(params)
                run_params.update({
                    "strategy_name": strategy_name,
                    "lots": int(params.get("lots", self.lots.get() or 1) or 1),
                    "product_code": code,
                    "progress": lambda cur, total, detail: self.progress_update(cur, total, "點選明細即時計算｜%s｜%s" % (self.option_title(opt), detail)),
                })
                if is_ema_strategy(strategy_name):
                    # v052L：點選明細也使用同一條 EMA高速快取路徑，不再回到 strategy_core 暖機流程。
                    run_params.pop("manual_ema_closes", None)
                ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, **run_params)
                return key, ds, tr, row

            def done(payload):
                k, ds, tr, src_row = payload
                self.result_detail_cache[k] = (ds, tr)
                self.last_day_stats, self.last_trades = ds, tr
                self.render_day_stats(ds)
                self.render_trades(tr)
                p = src_row.get("params") or {}
                self.info.configure(text="已即時計算並載入明細｜%s｜平均每日獲利 %s｜總淨利 %s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f" % (
                    self.option_title(src_row.get("opt")), format_money_plain(src_row.get("avg", 0)), format_money_plain(src_row.get("total", 0)),
                    float(p.get("tp_points", 0.0) or 0.0), float(p.get("sl_points", 0.0) or 0.0),
                    float(p.get("loss_exit", 0.0) or 0.0), float(p.get("lock_profit_exit", 0.0) or 0.0)
                ))
                self.tabs.select(self.summary_frame)

            self.run_background("載入該列每日/交易明細", worker, done)
        except Exception:
            pass


    def on_result_selected(self, _event=None):
        # 055C：保留相容舊呼叫，但點選回測結果不再自動載入每日總表與交易明細。
        return

    def on_result_double_clicked(self, event=None):
        try:
            iid = ""
            if event is not None:
                iid = self.result_tree.identify_row(event.y)
            if not iid:
                sel = list(self.result_tree.selection() or [])
                iid = sel[0] if sel else ""
            if not iid:
                return
            try:
                self.result_tree.selection_set(iid)
                self.result_tree.focus(iid)
            except Exception:
                pass
            row = self.result_row_map.get(iid)
            if not row:
                return
            self.load_result_row_detail(row)
        except Exception:
            pass

    def selected_results_json_path(self):
        return os.path.join(app_dir(), "selected_backtest_results.json")

    def selected_results_csv_path(self):
        return os.path.join(app_dir(), "selected_backtest_results.csv")

    def _selected_result_headers(self):
        return [
            "儲存時間", "顯示排名", "商品名稱", "商品代號", "保證金", "策略", "MA", "K棒", "進場",
            "商品類型", "回測時段", "回測起日", "回測迄日", "日期範圍",
            "獲利/保證金", "平均每日獲利", "總淨利", "有效天數", "總天數",
            "停利", "停損", "認賠", "賺飽", "平倉次數", "停利次數", "停損次數", "認賠次數", "賺飽次數",
            "最高損益", "最低損益", "狀態", "儲存鍵",
        ]

    def _selected_result_to_csv_row(self, rec):
        return [
            rec.get("saved_at", ""), rec.get("display_rank", ""), rec.get("product_name", ""), rec.get("product_code", ""), rec.get("base_margin", ""),
            rec.get("strategy", ""), rec.get("ma_label", ""), rec.get("k_label", rec.get("k_minutes", "")), rec.get("entry_mode", ""),
            rec.get("stock_size_mode", ""), rec.get("tai_session_mode", ""), rec.get("backtest_start", ""), rec.get("backtest_end", ""), rec.get("date_range", ""),
            rec.get("profit_margin_ratio", ""), rec.get("avg_daily_profit", ""), rec.get("total_profit", ""), rec.get("valid_days", ""), rec.get("total_days", ""),
            rec.get("tp_points", ""), rec.get("sl_points", ""), rec.get("loss_exit", ""), rec.get("lock_profit_exit", ""),
            rec.get("trades", ""), rec.get("tp_count", ""), rec.get("sl_count", ""), rec.get("loss_exit_count", ""), rec.get("profit_exit_count", ""),
            rec.get("peak", ""), rec.get("trough", ""), rec.get("status", ""), rec.get("save_key", ""),
        ]

    def _read_selected_result_records(self):
        p = self.selected_results_json_path()
        if not os.path.exists(p):
            return []
        try:
            with open(p, "r", encoding="utf-8-sig") as f:
                data = json.load(f)
            if isinstance(data, list):
                return [x for x in data if isinstance(x, dict)]
        except Exception as exc:
            log_startup("Read selected results failed: %s" % exc)
        return []

    def _write_selected_result_records(self, records):
        records = [x for x in list(records or []) if isinstance(x, dict)]
        json_path = self.selected_results_json_path()
        tmp_path = json_path + ".tmp"
        try:
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(records, f, ensure_ascii=False, indent=2)
            os.replace(tmp_path, json_path)
        except Exception:
            try:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
            except Exception:
                pass
            raise
        self._write_selected_result_csv(records, self.selected_results_csv_path())

    def _write_selected_result_csv(self, records, path):
        with open(path, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            w.writerow(self._selected_result_headers())
            for rec in list(records or []):
                w.writerow(self._selected_result_to_csv_row(rec))

    def _result_ma_label(self, row):
        params = row.get("params") or {}
        strategy_name = str(row.get("strategy") or params.get("strategy_name") or "")
        if not params or not self._result_row_uses_ma(row):
            return ""
        if is_fast_ma_strategy(strategy_name):
            return ma_algo_label(strategy_name) + str(normalize_fast_ma_period(params.get("ma_period", 89)))
        return str(normalize_ma_period(params.get("ma_period", 3))) + "MA"

    def _selected_result_date_bounds(self, row):
        text = str((row or {}).get("range") or "")
        dates = re.findall(r"\d{4}-\d{2}-\d{2}", text)
        start = dates[0] if dates else str(self.date_start_text.get() or "")
        end = dates[-1] if len(dates) >= 2 else str(self.date_end_text.get() or "")
        return start, end

    def _result_row_save_key(self, rec):
        parts = [
            rec.get("product_code", ""), rec.get("strategy", ""), rec.get("ma_period", ""), rec.get("k_minutes", ""), rec.get("entry_mode", ""),
            rec.get("tp_points", ""), rec.get("sl_points", ""), rec.get("loss_exit", ""), rec.get("lock_profit_exit", ""),
            rec.get("backtest_start", ""), rec.get("backtest_end", ""), rec.get("stock_size_mode", ""), rec.get("tai_session_mode", ""),
        ]
        return "|".join(str(x) for x in parts)

    def _selected_result_record_from_row(self, row, display_rank=None):
        opt = row.get("opt")
        params = dict(row.get("params") or {})
        strategy_name = str(row.get("strategy") or params.get("strategy_name") or "")
        code = clean_code(getattr(opt, "code", "") or params.get("product_code", ""))
        start, end = self._selected_result_date_bounds(row)
        score = self.result_rank_score(row)
        rec = {
            "saved_at": RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "app_version": APP_VERSION,
            "display_rank": int(display_rank or 0) if str(display_rank or "").strip() else "",
            "product_code": code,
            "product_name": self.product_name_text(opt or code),
            "product_display": str(getattr(opt, "display", "") or ""),
            "product_kind": str(getattr(opt, "product_kind", "") or ""),
            "stock_name": str(getattr(opt, "stock_name", "") or ""),
            "stock_no": str(getattr(opt, "stock_no", "") or ""),
            "base_margin": float(getattr(opt, "base_margin", 0.0) or 0.0) if opt else 0.0,
            "stock_size_mode": str(self.stock_size_mode.get() or ""),
            "tai_session_mode": str(self.tai_session_mode.get() or ""),
            "strategy": strategy_name,
            "ma_label": self._result_ma_label(row),
            "ma_period": int(params.get("ma_period", 0) or 0) if params else "",
            "k_minutes": int(params.get("k_minutes", 0) or 0) if params else "",
            "k_label": k_minutes_label(params.get("k_minutes", 1)) if params else "",
            "entry_mode": normalize_entry_mode(params.get("entry_mode", self.get_entry_mode())) if params else "",
            "lots": int(params.get("lots", self.lots.get() or 1) or 1) if params else int(self.lots.get() or 1),
            "one_way_fee": float(params.get("one_way_fee", 0.0) or 0.0) if params else 0.0,
            "tp_points": float(params.get("tp_points", 0.0) or 0.0) if params else "",
            "sl_points": float(params.get("sl_points", 0.0) or 0.0) if params else "",
            "loss_exit": float(params.get("loss_exit", 0.0) or 0.0) if params else "",
            "lock_profit_exit": float(params.get("lock_profit_exit", 0.0) or 0.0) if params else "",
            "backtest_start": start,
            "backtest_end": end,
            "date_range": row.get("range", ""),
            "profit_margin_ratio": score if score > -1e17 else "",
            "avg_daily_profit": row.get("avg", ""),
            "total_profit": row.get("total", ""),
            "valid_days": row.get("valid_days", ""),
            "total_days": row.get("total_days", ""),
            "trades": row.get("trades", 0),
            "tp_count": row.get("tp", 0),
            "sl_count": row.get("sl", 0),
            "loss_exit_count": row.get("loss_exit_count", 0),
            "profit_exit_count": row.get("profit_exit_count", 0),
            "peak": row.get("peak", 0),
            "trough": row.get("trough", 0),
            "status": row.get("status", ""),
        }
        rec["save_key"] = self._result_row_save_key(rec)
        return rec

    def _current_selected_result_rows(self):
        try:
            tree = self.result_tree
            sel = list(tree.selection() or [])
            if not sel:
                focus = tree.focus()
                if focus:
                    sel = [focus]
            if not sel:
                return []
            seen = set()
            ordered = []
            for iid in sorted(sel, key=lambda x: tree.index(x)):
                if iid in seen:
                    continue
                seen.add(iid)
                row = self.result_row_map.get(iid)
                if not row:
                    continue
                ordered.append((iid, row, tree.index(iid) + 1))
            return ordered
        except Exception:
            return []

    def _current_selected_result_row(self):
        try:
            rows = self._current_selected_result_rows()
            if not rows:
                return None, None, None
            return rows[0]
        except Exception:
            return None, None, None

    def _save_result_row_items_to_selected(self, row_items, quiet=False):
        try:
            row_items = [(iid, row, rank) for iid, row, rank in list(row_items or []) if row]
            if not row_items:
                if not quiet:
                    messagebox.showinfo("尚未選取結果", "請先在回測結果總表點選一列，或用 Ctrl/Shift 多選後，再按「存入精選結果」。")
                return False
            records = self._read_selected_result_records()
            key_to_index = {str(rec.get("save_key", "")): idx for idx, rec in enumerate(records)}
            added = 0
            updated = 0
            saved_recs = []
            for _iid, row, display_rank in row_items:
                rec = self._selected_result_record_from_row(row, display_rank=display_rank)
                key = str(rec.get("save_key", ""))
                if key in key_to_index:
                    records[key_to_index[key]] = rec
                    updated += 1
                else:
                    key_to_index[key] = len(records)
                    records.append(rec)
                    added += 1
                saved_recs.append(rec)
            self._write_selected_result_records(records)
            if len(saved_recs) == 1:
                rec = saved_recs[0]
                action = "已更新精選結果" if updated and not added else "已存入精選結果"
                self.info.configure(text="%s：%s｜保證金%s｜%s｜K=%s｜平均每日獲利%s｜總淨利%s｜共%d筆" % (
                    action, rec.get("product_name", ""), format_money_plain(rec.get("base_margin", 0) or 0), rec.get("ma_label", rec.get("strategy", "")), rec.get("k_label", rec.get("k_minutes", "")),
                    format_money_plain(rec.get("avg_daily_profit", 0) or 0), format_money_plain(rec.get("total_profit", 0) or 0), len(records)
                ), foreground="#005A9E")
            else:
                self.info.configure(text="已批次存入精選結果：選取%d筆｜新增%d筆｜更新%d筆｜精選總數%d筆" % (
                    len(saved_recs), added, updated, len(records)
                ), foreground="#005A9E")
            return True
        except Exception as exc:
            log_startup("Save selected result failed: %s" % exc)
            if not quiet:
                messagebox.showerror("存入精選結果失敗", str(exc))
            return False

    def save_selected_result(self, row=None, display_rank=None, quiet=False):
        try:
            if row is None:
                return self._save_result_row_items_to_selected(self._current_selected_result_rows(), quiet=quiet)
            return self._save_result_row_items_to_selected([(None, row, display_rank)], quiet=quiet)
        except Exception as exc:
            log_startup("Save selected result failed: %s" % exc)
            if not quiet:
                messagebox.showerror("存入精選結果失敗", str(exc))
            return False

    def _option_for_selected_record(self, rec):
        code = clean_code((rec or {}).get("product_code", ""))
        if not code:
            return None
        for pool in (getattr(self, "backtest_group", []), getattr(self, "options", []), getattr(self, "raw_options", [])):
            for opt in list(pool or []):
                if clean_code(getattr(opt, "code", "")) == code:
                    return opt
        name = str((rec or {}).get("stock_name") or (rec or {}).get("product_name") or code).replace("期貨", "")
        return ProductOption(
            code=code, display=str((rec or {}).get("product_display") or (rec or {}).get("product_name") or code),
            total_rows=0, total_qty=0.0, primary_month="", months="", first_dt=None, last_dt=None,
            product_kind=str((rec or {}).get("product_kind") or (rec or {}).get("stock_size_mode") or ""),
            stock_no=str((rec or {}).get("stock_no") or code), stock_name=name,
            base_margin=float((rec or {}).get("base_margin", 0.0) or 0.0),
        )

    def apply_selected_result_record(self, rec, win=None):
        try:
            if not rec:
                return
            strategy = str(rec.get("strategy", "") or "")
            if is_sma_strategy(strategy):
                mode = SMA_STRATEGY_DISPLAY
            elif is_ema_strategy(strategy):
                mode = EMA_STRATEGY_DISPLAY
            elif is_open_price_strategy(strategy):
                mode = OPEN_PRICE_STRATEGY_DISPLAY
            else:
                mode = THREE_MA_STRATEGY_DISPLAY if is_three_ma_strategy(strategy) else TRAIN_STRATEGY_DISPLAY

            stock_mode = str(rec.get("stock_size_mode", "") or "").strip()
            if stock_mode not in STOCK_SIZE_MODE_VALUES:
                kind_text = str(rec.get("product_kind", "") or rec.get("product_name", "") or "")
                if "台指" in kind_text or is_tai_index_code(rec.get("product_code", "")):
                    stock_mode = "台指期"
                elif "小" in kind_text:
                    stock_mode = "小股期"
                else:
                    stock_mode = "大股期"

            self.stock_size_mode.set(stock_mode)
            self.strategy_mode.set(mode)
            self.on_strategy_mode_changed()
            self.stock_size_mode.set(stock_mode)
            try:
                self.tai_session_mode.set(normalize_tai_session_mode(rec.get("tai_session_mode", self.tai_session_mode.get())))
            except Exception:
                pass
            try:
                self.lots.set(int(rec.get("lots", self.lots.get() or 1) or 1))
            except Exception:
                pass
            try:
                k = normalize_ema_k_minutes(rec.get("k_minutes", 1)) if mode in (EMA_STRATEGY_DISPLAY, SMA_STRATEGY_DISPLAY) else normalize_k_minutes(rec.get("k_minutes", 1))
                self.k_minutes_text.set(k_minutes_label(k))
            except Exception:
                pass
            try:
                self.entry_mode.set(normalize_entry_mode(rec.get("entry_mode", self.entry_mode.get())))
            except Exception:
                pass

            ma = int(float(rec.get("ma_period", 0) or 0) or 0)
            if mode in (EMA_STRATEGY_DISPLAY, SMA_STRATEGY_DISPLAY):
                ma = normalize_fast_ma_period(ma or 20)
                self.sma_start_text.set(str(ma)); self.sma_end_text.set(str(ma)); self.sma_step_text.set("1")
                self.ma_period_text.set(str(ma))
            elif mode == THREE_MA_STRATEGY_DISPLAY:
                ma = normalize_ma_period(ma or 3)
                self.ma_period_text.set(str(ma))

            def set_exact(var_start, var_end, var_step, value, default="0"):
                text = str(value if value not in (None, "") else default)
                var_start.set(text); var_end.set(text); var_step.set("1")

            tp = float(rec.get("tp_points", 0.0) or 0.0)
            sl = float(rec.get("sl_points", 0.0) or 0.0)
            no_tp = tp <= 0 or tp >= 99999
            no_sl = sl <= 0 or sl >= 99999
            try:
                self.no_tp_var.set(1 if no_tp else 0)
                self.no_sl_var.set(1 if no_sl else 0)
            except Exception:
                pass
            set_exact(self.tp_start_text, self.tp_end_text, self.tp_step_text, 99999 if no_tp else tp, "99999")
            set_exact(self.sl_start_text, self.sl_end_text, self.sl_step_text, 99999 if no_sl else sl, "99999")
            set_exact(self.loss_start_text, self.loss_end_text, self.loss_step_text, rec.get("loss_exit", 0.0), "0")
            set_exact(self.profit_start_text, self.profit_end_text, self.profit_step_text, rec.get("lock_profit_exit", 0.0), "0")
            if rec.get("backtest_start"):
                self.date_start_text.set(str(rec.get("backtest_start")))
            if rec.get("backtest_end"):
                self.date_end_text.set(str(rec.get("backtest_end")))

            if stock_mode == "台指期":
                try:
                    self.tai_session_mode.set("全部" if mode in (EMA_STRATEGY_DISPLAY, SMA_STRATEGY_DISPLAY) else normalize_tai_session_mode(rec.get("tai_session_mode", self.tai_session_mode.get())))
                except Exception:
                    pass
            else:
                opt = self._option_for_selected_record(rec)
                code = clean_code(getattr(opt, "code", "")) if opt else ""
                if code and code not in self.backtest_group_codes:
                    self.backtest_group.append(opt)
                    self.backtest_group_codes.add(code)

            self._update_strategy_parameter_controls()
            self.render_backtest_group()
            self.save_current_param_texts()
            self.mark_estimate_dirty()
            self.info.configure(text="已套回精選參數：%s｜%s｜%s｜K=%s｜請按『重新計算預估時間』或直接回測。" % (
                rec.get("product_name", ""), mode, rec.get("ma_label", ""), rec.get("k_label", rec.get("k_minutes", ""))
            ), foreground="#005A9E")
            if win is not None:
                try:
                    win.lift()
                except Exception:
                    pass
        except Exception as exc:
            log_startup("Apply selected result failed: %s" % exc)
            messagebox.showerror("套回精選參數失敗", str(exc))

    def export_selected_results_csv(self, records=None):
        records = list(records if records is not None else self._read_selected_result_records())
        if not records:
            messagebox.showinfo("沒有精選結果", "目前沒有已存入的精選結果。")
            return
        p = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")], initialfile="selected_backtest_results.csv")
        if not p:
            return
        try:
            self._write_selected_result_csv(records, p)
            self.info.configure(text="已匯出精選結果CSV：%s" % p, foreground="#005A9E")
        except Exception as exc:
            messagebox.showerror("匯出精選CSV失敗", str(exc))

    def open_selected_results_window(self):
        records = self._read_selected_result_records()
        win = Toplevel(self.root)
        win.title("精選回測結果｜已存參數")
        self.apply_dialog_geometry(win, "selected_results", self.get_setting("geometry.selected_results", "1280x720"))
        frame = ttk.Frame(win, padding=8)
        frame.pack(fill=BOTH, expand=True)
        note = ttk.Label(frame, text="雙擊列或按「套回參數」可把商品、策略、MA/EMA/SMA、K棒、停利/停損、認賠/賺飽、保證金與日期帶回上方設定。", foreground="#005A9E", anchor="w")
        note.pack(fill="x", pady=(0, 6))
        cols = [
            ("saved_at", "儲存時間", 145), ("product", "商品", 150), ("margin", "保證金", 95), ("strategy", "策略", 95), ("ma", "MA", 75), ("k", "K棒", 60),
            ("score", "獲利/保證金", 105), ("avg", "平均每日獲利", 115), ("total", "總淨利", 105), ("days", "有效天數", 85),
            ("tp", "停利", 75), ("sl", "停損", 75), ("loss", "認賠", 90), ("profit", "賺飽", 90),
            ("trades", "平倉", 65), ("tp_count", "停利次數", 85), ("sl_count", "停損次數", 85), ("loss_count", "認賠次數", 85), ("profit_count", "賺飽次數", 85),
            ("range", "日期範圍", 170),
        ]
        tree_frame = ttk.Frame(frame)
        tree_frame.pack(fill=BOTH, expand=True)
        tree = ttk.Treeview(tree_frame, columns=[c[0] for c in cols], show="headings")
        ybar = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
        xbar = ttk.Scrollbar(tree_frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        for key, title, width in cols:
            tree.heading(key, text=title, command=lambda k=key, t=tree: self.sort_tree(t, k))
            tree.column(key, width=width, minwidth=45, anchor="center", stretch=True)
        tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)
        row_map = {}

        def fill_tree():
            tree.delete(*tree.get_children())
            row_map.clear()
            for idx, rec in enumerate(records, start=1):
                score = rec.get("profit_margin_ratio", "")
                if isinstance(score, (int, float)):
                    score = "%.2f%%" % (float(score) * 100.0)
                iid = "r%d" % idx
                tree.insert("", END, iid=iid, values=(
                    rec.get("saved_at", ""), rec.get("product_name", ""), format_money_plain(rec.get("base_margin", 0) or 0), rec.get("strategy", ""), rec.get("ma_label", ""), rec.get("k_label", rec.get("k_minutes", "")),
                    score, format_money_plain(rec.get("avg_daily_profit", 0) or 0), format_money_plain(rec.get("total_profit", 0) or 0), rec.get("valid_days", ""),
                    rec.get("tp_points", ""), rec.get("sl_points", ""), safe_int_text(rec.get("loss_exit", 0) or 0), safe_int_text(rec.get("lock_profit_exit", 0) or 0),
                    rec.get("trades", 0), rec.get("tp_count", 0), rec.get("sl_count", 0), rec.get("loss_exit_count", 0), rec.get("profit_exit_count", 0),
                    rec.get("date_range", ""),
                ))
                row_map[iid] = rec

        def selected_rec():
            sel = list(tree.selection() or [])
            return row_map.get(sel[0]) if sel else None

        def apply_current():
            rec = selected_rec()
            if not rec:
                messagebox.showinfo("尚未選取", "請先選取一筆精選結果。", parent=win)
                return
            self.apply_selected_result_record(rec, win=win)

        def delete_current():
            rec = selected_rec()
            if not rec:
                messagebox.showinfo("尚未選取", "請先選取一筆精選結果。", parent=win)
                return
            ok = messagebox.askyesno("刪除精選結果", "確定刪除這筆精選結果？\n\n%s｜%s｜%s" % (rec.get("product_name", ""), rec.get("strategy", ""), rec.get("ma_label", "")), parent=win)
            if not ok:
                return
            key = str(rec.get("save_key", ""))
            try:
                records[:] = [x for x in records if str(x.get("save_key", "")) != key]
                self._write_selected_result_records(records)
                fill_tree()
                self.info.configure(text="已刪除精選結果｜剩餘%d筆" % len(records), foreground="#005A9E")
            except Exception as exc:
                messagebox.showerror("刪除失敗", str(exc), parent=win)

        btnbar = ttk.Frame(frame)
        btnbar.pack(fill="x", pady=(8, 0))
        ttk.Button(btnbar, text="套回參數", command=apply_current).pack(side="left", padx=(0, 6))
        ttk.Button(btnbar, text="刪除", command=delete_current).pack(side="left", padx=6)
        ttk.Button(btnbar, text="匯出精選CSV", command=lambda: self.export_selected_results_csv(records)).pack(side="left", padx=6)
        ttk.Button(btnbar, text="關閉", command=win.destroy).pack(side="right")
        tree.bind("<Double-1>", lambda _e: apply_current(), add="+")
        fill_tree()
        if not records:
            self.info.configure(text="目前沒有精選結果；請先在回測結果總表選一列後按『存入精選結果』。", foreground="#333333")

    def browse(self):
        ps = filedialog.askopenfilenames(filetypes=[("官方 Daily ZIP/CSV", "*.zip *.csv *.rpt *.txt"), ("ZIP 壓縮檔", "*.zip"), ("CSV/RPT", "*.csv *.rpt *.txt"), ("所有檔案", "*.*")])
        if ps:
            self.paths = list(ps)
            names = [os.path.basename(p) for p in self.paths]
            if len(names) <= 3:
                self.file_text.set("；".join(names))
            else:
                self.file_text.set("已選 %d 個檔案：%s ..." % (len(names), "；".join(names[:3])))
            self.raw_options = []
            self.options = []
            self.option_map = {}
            self.primary_month_by_file_code = {}
            try:
                if self.product_combo is not None and self.product_combo.winfo_exists():
                    self.product_combo.configure(values=[])
            except Exception:
                pass
            self.product_choice.set("")
            self.ticks = []
            self.selected_code = ""

    def _resolved_paths(self):
        paths = list(self.paths or [])
        if not paths:
            text = self.file_text.get().strip()
            if text and os.path.exists(text):
                paths = [text]
        if not paths:
            raise ValueError("請先用 TrainMADataCenter 原始資料匯入工具建立共用資料庫。")
        return paths

    def _parse_date_range(self):
        s1 = str(self.date_start_text.get() or "").strip()
        s2 = str(self.date_end_text.get() or "").strip()
        d1 = _date_from_text(s1) if s1 else None
        d2 = _date_from_text(s2) if s2 else None
        if s1 and not d1:
            raise ValueError("回測起日格式錯誤，請用 YYYY-MM-DD。")
        if s2 and not d2:
            raise ValueError("回測迄日格式錯誤，請用 YYYY-MM-DD。")
        if d1 and d2 and d1 > d2:
            raise ValueError("回測起日不可晚於迄日。")
        return d1, d2

    def date_range_text(self):
        try:
            d1, d2 = self._parse_date_range()
        except Exception:
            return "日期格式錯誤"
        if not d1 and not d2:
            return "全部日期"
        return "%s～%s" % (_date_text(d1) if d1 else "最早", _date_text(d2) if d2 else "最新")

    def load_cache_products_on_start(self):
        """快速啟動：只讀摘要快取，不在主執行緒重算商品/保證金/預估。"""
        if self.busy:
            return
        options = load_product_summary_cache()
        if not options:
            if not cache_db_file_exists():
                return
            self.file_text.set("已偵測到本機快取資料庫｜%s" % os.path.basename(ticks_cache_db_path()))
            self.info.configure(text="已偵測到 ticks_cache.db，但啟動時不掃 SQLite，避免視窗卡頓；請按『重整商品清單/排名』一次建立商品摘要快取。之後重開會直接讀摘要快取。")
            return
        try:
            self._product_dates_text_cache = {}
        except Exception:
            pass
        self.paths = []
        self.raw_options = list(options)
        # v052T：啟動時不再 enrich_options() + save_product_summary_cache()；那會掃大量商品並卡住 Tk。
        # 需要重算商品/保證金時，由使用者按「重整商品清單/排名」或「更新期交所保證金資料」。
        self.options = list(options)
        try:
            self.apply_hot_ranks()
        except Exception:
            pass
        self.primary_month_by_file_code = {}
        self.file_text.set("已載入本機快取資料庫｜%s" % os.path.basename(ticks_cache_db_path()))
        self.filter_products()
        applied_sma_dates = self.apply_sma_database_date_defaults() if self.is_fast_ma_mode() else False
        try:
            self.render_backtest_group()
        except Exception:
            pass
        self.mark_estimate_dirty()
        if applied_sma_dates:
            self.info.configure(text="快速啟動完成｜已讀商品摘要快取｜商品數：%d｜SMA/EMA起訖日已帶入資料庫實際範圍｜未自動重算預估。" % len(self.options))
        else:
            self.info.configure(text="快速啟動完成｜已讀商品摘要快取｜商品數：%d｜未自動重算預估。" % len(self.options))

    def _confirm_ignore_missing_tai_holidays(self):
        """重建EMA快取前，讓使用者把非六日缺日標記為休市忽略。"""
        try:
            missing = tai_nonweekend_missing_dates_from_cache(include_ignored=False)
        except Exception:
            missing = []
        if not missing:
            return True
        show = "、".join(_date_text(d) for d in missing[:20])
        if len(missing) > 20:
            show += "...共%d天" % len(missing)
        ans = messagebox.askyesnocancel(
            "偵測到非六日缺日",
            ("偵測到 TXF/TX 日夜盤資料中有非六日缺日：\n\n%s\n\n"
             "若這些日期是國定假日、補假或休市，按「是」會標記為休市忽略，EMA會把前後交易日直接接起來。\n\n"
             "按「否」表示這些日期應該有資料，請先補匯官方ZIP/CSV。\n"
             "按「取消」取消本次重建。") % show,
            parent=self.root,
        )
        if ans is True:
            n = save_ignored_missing_dates(missing, reason="manual_holiday")
            self.info.configure(text="已標記休市忽略%d天｜%s" % (n, show))
            return True
        if ans is False:
            messagebox.showinfo("請先補匯資料", "本次重建已停止。請先補匯缺少日期的官方 Daily ZIP/CSV，或按「休市忽略」手動標記休市日。", parent=self.root)
        return False

    def open_ignored_holiday_dialog(self):
        try:
            candidates = tai_nonweekend_missing_dates_from_cache(include_ignored=True)
            ignored = load_ignored_missing_dates()
        except Exception as e:
            messagebox.showerror("休市忽略", "讀取缺日資料失敗：%s" % e, parent=self.root)
            return
        win = Toplevel(self.root)
        win.title("休市忽略 / 非六日缺日")
        win.geometry("520x420")
        win.transient(self.root)
        frm = ttk.Frame(win, padding=12)
        frm.pack(fill="both", expand=True)
        ttk.Label(frm, text="勾選確定是休市的非六日缺日。被忽略的日期不會產生假K棒，EMA會由前一交易日直接接到下一交易日。", wraplength=480, justify="left").pack(anchor="w")
        body = ttk.Frame(frm)
        body.pack(fill="both", expand=True, pady=(10, 10))
        checks = []
        if not candidates:
            ttk.Label(body, text="目前沒有偵測到非六日缺日。", foreground="#555555").pack(anchor="w")
        else:
            for d in candidates:
                var = IntVar(value=1 if d in ignored else 0)
                cb = ttk.Checkbutton(body, text=_date_text(d), variable=var)
                cb.pack(anchor="w", pady=2)
                checks.append((d, var))
        ignored_now = sorted(ignored)
        if ignored_now:
            txt = "目前已忽略：" + "、".join(_date_text(d) for d in ignored_now[:30])
            if len(ignored_now) > 30:
                txt += "...共%d天" % len(ignored_now)
            ttk.Label(frm, text=txt, foreground="#0066AA", wraplength=480, justify="left").pack(anchor="w", pady=(0, 8))
        btnbar = ttk.Frame(frm)
        btnbar.pack(fill="x")
        def apply():
            add = [d for d, v in checks if int(v.get() or 0) == 1]
            remove = [d for d, v in checks if int(v.get() or 0) == 0 and d in ignored]
            save_ignored_missing_dates(add, reason="manual_holiday")
            n2 = delete_ignored_missing_dates(remove)
            messagebox.showinfo("休市忽略", "已更新休市忽略設定｜勾選%d天｜移除%d天\n\n請再按「匯入/追加到快取」重建EMA資料庫。" % (len(add), n2), parent=win)
            win.destroy()
        ttk.Button(btnbar, text="套用", command=apply).pack(side="left")
        ttk.Button(btnbar, text="關閉", command=win.destroy).pack(side="right")

    def import_selected_files(self):
        paths = list(self.paths or [])
        if not paths:
            text = self.file_text.get().strip()
            if text and os.path.exists(text):
                paths = [text]

        # v052E：已經有 ticks_cache.db 時，不必重新選官方原始檔；
        # 直接從本機逐筆母資料重建/更新 EMA 專用 TXF K棒快取。
        rebuild_only = False
        if not paths:
            if cache_has_any_ticks():
                rebuild_only = True
            else:
                messagebox.showerror("匯入失敗", "請先選擇官方 Daily ZIP 或 CSV 檔案")
                return

        # v052K：重建EMA快取前先處理國定假日/非六日休市缺日。
        # 使用者可把 2026-06-19 這類休市日標記忽略，EMA序列會直接接續前後交易日。
        if cache_has_any_ticks() and not self._confirm_ignore_missing_tai_holidays():
            return

        def worker():
            if rebuild_only:
                result = {"imported": 0, "skipped": 0, "replaced": 0, "inserted": 0}
            else:
                result = import_sources_to_cache(paths, progress=lambda cur, total, detail: self.progress_update(cur, total, detail))
            ema_summary = rebuild_ema_txf_cache(progress=lambda cur, total, detail: self.progress_update(cur, total, "EMA/SMA快取｜" + detail))
            options = scan_products_from_cache(progress=lambda cur, total, detail: self.progress_update(cur, total, "重算商品｜" + detail))
            return result, ema_summary, options, rebuild_only
        def done(result):
            summary, ema_summary, options, was_rebuild_only = result
            self.raw_options = options
            self.options = self.enrich_options(options)
            self._product_dates_text_cache = {}
            self.apply_hot_ranks()
            save_product_summary_cache(self.options)
            self.primary_month_by_file_code = {}
            self.ticks = []
            self.selected_code = ""
            self.filter_products()
            if was_rebuild_only:
                self.file_text.set("已載入本機快取資料庫｜%s" % os.path.basename(ticks_cache_db_path()))
                self.info.configure(text="EMA/SMA快取重建完成｜來源：既有 ticks_cache.db｜商品數：%d｜高速K棒 %s｜%s" % (
                    len(self.options), f"{int((ema_summary or {}).get('bars', 0)):,}", ema_txf_cache_status_text()
                ))
            else:
                self.info.configure(text="快取更新完成｜新增來源%d｜略過%d｜覆蓋%d｜新增tick %s｜商品數：%d｜高速K棒 %s｜%s" % (
                    summary.get("imported", 0), summary.get("skipped", 0), summary.get("replaced", 0), f"{int(summary.get('inserted', 0)):,}", len(self.options),
                    f"{int((ema_summary or {}).get('bars', 0)):,}", ema_txf_cache_status_text()
                ))
        title = "重建EMA/SMA快取" if rebuild_only else "匯入/追加CSV到快取"
        self.run_background(title, worker, done)

    def read_ticks_for_code(self, code, strategy_name, progress_prefix="讀取", start_date=None, end_date=None):
        if start_date is None and end_date is None:
            d1, d2 = self._parse_date_range()
        else:
            d1, d2 = start_date, end_date
        if cache_has_code(code):
            return read_cached_ticks(code, strategy_name, d1, d2, progress=lambda cur, total, detail: self.progress_update(cur, total, progress_prefix + "｜" + detail), session_mode=("全部" if (is_fast_ma_strategy(strategy_name) and is_tai_index_code(code)) else (self.get_tai_session_mode() if strategy_kind(strategy_name) == "TAI" else "全部")))
        # 匯入功能已移到 TrainMADataCenter；回測版不再直接讀原始 CSV/ZIP，避免回測面板卡住。
        raise ValueError("共用資料庫內沒有 %s。請先用 TrainMADataCenter 原始資料匯入工具匯入該商品資料。" % code)

    def scan_files(self):
        """只從永久快取資料庫重整商品清單/熱門排名；不重新讀原始 CSV。"""
        if not cache_has_any_ticks():
            messagebox.showinfo("尚無快取資料", "請先用 TrainMADataCenter 原始資料匯入工具建立共用資料庫。")
            return

        def worker():
            options = scan_products_from_cache(progress=lambda cur, total, detail: self.progress_update(cur, total, "重整商品｜" + detail))
            if not options:
                raise ValueError("快取資料庫內沒有可用商品。")
            return options

        def done(options):
            self.raw_options = options
            self.options = self.enrich_options(options)
            self._product_dates_text_cache = {}
            self.apply_hot_ranks()
            save_product_summary_cache(self.options)
            self.primary_month_by_file_code = {}
            self.ticks = []
            self.selected_code = ""
            self.filter_products()
            big, small = self.hot_rankings()
            if self.margin_items():
                self.info.configure(text="商品清單/排名已重整｜大股期前15：%d｜小股期前15：%d｜已排除台積電/聯電與非股票期貨｜未重讀原始CSV" % (len(big), len(small)))
            else:
                self.info.configure(text="商品清單已重整｜尚未更新期交所保證金資料，無法自動排除非股票期貨")

        self.run_background("重整商品清單/排名", worker, done)

    def _product_dialog_widget_alive(self, widget):
        try:
            return widget is not None and bool(widget.winfo_exists())
        except Exception:
            return False

    def open_product_dialog(self):
        """把商品選擇與待回測群組移到彈出視窗，避免主面板被商品區塊佔高。"""
        try:
            if self.product_dialog is not None and self.product_dialog.winfo_exists():
                self.product_dialog.lift()
                self.product_dialog.focus_force()
                return
        except Exception:
            pass

        dlg = Toplevel(self.root)
        self.product_dialog = dlg
        dlg.title("商品選擇 / 待回測群組")
        try:
            dlg.geometry(str(self.get_setting("geometry.product_dialog", "1080x520")) or "1080x520")
            dlg.minsize(820, 420)
        except Exception:
            pass

        def _close_dialog():
            try:
                self.set_setting("geometry.product_dialog", dlg.geometry())
                self.save_settings()
            except Exception:
                pass
            self.product_combo = None
            self.group_tree = None
            self.product_status = None
            self.product_dialog = None
            try:
                dlg.destroy()
            except Exception:
                pass

        try:
            dlg.protocol("WM_DELETE_WINDOW", _close_dialog)
        except Exception:
            pass

        product_frame = ttk.LabelFrame(dlg, text="商品選擇", padding=8)
        product_frame.pack(fill="x", padx=8, pady=8)
        try:
            product_frame.columnconfigure(0, weight=0)
            product_frame.columnconfigure(1, weight=1)
            product_frame.columnconfigure(2, weight=0)
        except Exception:
            pass
        ttk.Label(product_frame, text="輸入商品代號關鍵字：").grid(row=0, column=0, sticky="e", padx=4, pady=4)
        keyword_entry = self.register_lock_widget(ttk.Entry(product_frame, textvariable=self.product_keyword, width=20))
        keyword_entry.grid(row=0, column=1, sticky="w", padx=4, pady=4)
        ttk.Label(product_frame, text="選擇商品：").grid(row=1, column=0, sticky="e", padx=4, pady=4)
        self.product_combo = self.register_lock_widget(ttk.Combobox(product_frame, textvariable=self.product_choice, values=[], width=60, state="readonly"))
        self.product_combo.grid(row=1, column=1, sticky="ew", padx=4, pady=4)
        self.product_combo.bind("<<ComboboxSelected>>", lambda _e: self.on_product_selected())
        add_btn = ttk.Button(product_frame, text="加入待回測", command=self.add_selected_product_to_group)
        add_btn.grid(row=1, column=2, sticky="e", padx=4, pady=4)
        self.lock_widgets.append(add_btn)
        self.product_status = ttk.Label(product_frame, textvariable=self.margin_info, anchor="w", justify="left", wraplength=960)
        self.product_status.grid(row=2, column=0, columnspan=3, sticky="ew", padx=4, pady=(6, 2))

        group_frame = ttk.LabelFrame(dlg, text="待回測群組", padding=8)
        group_frame.pack(fill=BOTH, expand=True, padx=8, pady=(0, 8))
        group_frame.columnconfigure(0, weight=1)
        group_frame.rowconfigure(0, weight=1)
        self.group_tree = ttk.Treeview(group_frame, columns=("idx", "name", "rank"), show="headings", height=8)
        for col, title, width in (("idx", "序", 45), ("name", "商品名稱", 280), ("rank", "熱門排名", 90)):
            self.group_tree.heading(col, text=title)
            self.group_tree.column(col, width=width, anchor="center", stretch=True)
        gbar = ttk.Scrollbar(group_frame, orient="vertical", command=self.group_tree.yview)
        self.group_tree.configure(yscrollcommand=gbar.set)
        self.group_tree.grid(row=0, column=0, sticky="nsew")
        gbar.grid(row=0, column=1, sticky="ns")
        group_btns = ttk.Frame(group_frame)
        group_btns.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        remove_btn = ttk.Button(group_btns, text="移除選取商品", command=self.remove_selected_group_products)
        remove_btn.pack(side="left", padx=(0, 5))
        clear_btn = ttk.Button(group_btns, text="清空待回測群組", command=self.clear_backtest_group)
        clear_btn.pack(side="left", padx=5)
        close_btn = ttk.Button(group_btns, text="關閉", command=_close_dialog)
        close_btn.pack(side="left", padx=5)
        self.lock_widgets.extend([remove_btn, clear_btn, close_btn])

        try:
            dlg.bind("<Configure>", lambda _e: self._refresh_product_dialog_wrap(), add="+")
        except Exception:
            pass
        self.filter_products()
        self.render_backtest_group()
        self._refresh_product_dialog_wrap()
        try:
            keyword_entry.focus_set()
        except Exception:
            pass

    def _refresh_product_dialog_wrap(self):
        try:
            lbl = getattr(self, "product_status", None)
            dlg = getattr(self, "product_dialog", None)
            if lbl is not None and lbl.winfo_exists() and dlg is not None and dlg.winfo_exists():
                lbl.configure(wraplength=max(420, int(dlg.winfo_width() or 1080) - 80))
        except Exception:
            pass

    def filter_products(self):
        kw = self.product_keyword.get().strip().upper()
        matches = []
        self.option_map = {}
        for opt in self.options:
            text = opt.display
            if not kw or kw in opt.code or kw in text.upper():
                matches.append(text)
                self.option_map[text] = opt
        combo_alive = self._product_dialog_widget_alive(getattr(self, "product_combo", None))
        if combo_alive:
            try:
                self.product_combo.configure(values=matches[:300])
            except Exception:
                combo_alive = False
        if matches:
            current = self.product_choice.get()
            if current not in matches:
                self.product_choice.set(matches[0])
                if combo_alive:
                    self.on_product_selected()
        else:
            self.product_choice.set("")
            self.selected_code = ""
            self.update_margin_text_for_option(None)

    def on_product_selected(self):
        opt = self.option_map.get(self.product_choice.get())
        if opt:
            self.selected_code = opt.code
            self.ticks = []
            first = opt.first_dt.strftime("%Y-%m-%d %H:%M:%S") if opt.first_dt else ""
            last = opt.last_dt.strftime("%Y-%m-%d %H:%M:%S") if opt.last_dt else ""
            self.info.configure(text="已選商品：%s｜自動主力月份：%s｜總筆數：%s｜時間：%s ～ %s" % (self.option_title(opt), opt.primary_month, f"{opt.total_rows:,}", first, last))
            self.update_margin_text_for_option(opt)
            self.update_ratio_preview()

    def load_ticks(self):
        if self.is_tai_product_mode():
            opt = self.tai_index_option()
        else:
            if not self.options:
                messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再選商品。")
                return
            opt = self.option_map.get(self.product_choice.get())
            if not opt:
                messagebox.showerror("讀取失敗", "請先選擇商品")
                return
        strategy_name = self.auto_strategy_for_option(opt)
        code = opt.code
        try:
            d1, d2, _notes = self.resolve_date_range_for_code(code, self.date_start_text, self.date_end_text, "回測")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return

        def worker():
            ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="讀取", start_date=d1, end_date=d2)
            if not ticks:
                raise ValueError("所選商品在目前日期範圍沒有可用逐筆資料。請確認策略時段或日期範圍。")
            return code, ticks

        def done(result):
            code2, ticks = result
            self.selected_code = code2
            self.ticks = ticks
            sessions = sorted(set(t.session_label for t in self.ticks))
            months = sorted(set(t.month for t in self.ticks))
            prices = [t.price for t in self.ticks]
            data_range, data_days = self.ticks_date_range_text(self.ticks)
            self.info.configure(text="讀取完成｜商品：%s｜自動月份：%s｜逐筆數：%s｜時段數：%d｜實際使用：%s，共%d天｜價格 %.2f ～ %.2f" % (self.option_title(code2), "/".join(months), f"{len(self.ticks):,}", len(sessions), data_range, data_days, min(prices), max(prices)))

        self.run_background("讀取所選商品逐筆", worker, done)

    @staticmethod
    def _parse_manual_ema_closes_text(text):
        values = []
        for part in re.split(r"[\s,，;；]+", str(text or "")):
            raw = part.strip().replace(",", "")
            if not raw:
                continue
            try:
                v = float(raw)
            except Exception:
                raise ValueError("收盤價格式錯誤：%s" % part)
            if v <= 0:
                raise ValueError("收盤價必須大於0：%s" % part)
            values.append(v)
        return values

    def _estimate_ema_completed_k_count(self, ticks, k_minutes):
        try:
            minutes = int(k_minutes or 1)
        except Exception:
            minutes = 1
        if minutes >= 1440:
            keys = set()
            for t in list(ticks or []):
                try:
                    keys.add(str(getattr(t, "session_key", "") or getattr(t, "d", "")))
                except Exception:
                    pass
            return len(keys)
        keys = set()
        for t in list(ticks or []):
            try:
                dt = getattr(t, "dt", None) or getattr(t, "datetime", None)
                if dt is None:
                    dt = RealDateTime.combine(getattr(t, "d"), getattr(t, "tm"))
                total = int(dt.hour) * 60 + int(dt.minute)
                bucket = total // max(1, minutes)
                keys.add((str(getattr(t, "session_key", "") or getattr(t, "d", "")), bucket))
            except Exception:
                pass
        return len(keys)

    def _maybe_prompt_ema_manual_closes_for_backtest(self, ticks, strategy_name, ma_period, k_minutes, product_code=None):
        if not is_ema_strategy(strategy_name):
            return None
        code = clean_code(product_code or (getattr(ticks[0], "code", "TXF") if ticks else "TXF"))
        period = normalize_ema_period(ma_period)
        k = normalize_ema_k_minutes(k_minutes)
        if is_tai_index_code(code):
            cached_bars = ema_txf_seed_bars_for_ticks(
                ticks, code, k, period,
                progress=lambda cur, total, detail: self.progress_update(cur, total, detail),
            )
            if cached_bars:
                return cached_bars
            cached = ema_txf_seed_closes_for_ticks(
                ticks, code, k, period,
                progress=lambda cur, total, detail: self.progress_update(cur, total, detail),
            )
            if cached:
                return cached
        need = max(0, period - 1)
        available = self._estimate_ema_completed_k_count(ticks, k)
        missing = max(0, need - available)
        if missing <= 0:
            return None
        if not messagebox.askyesno("EMA回測資料不足", "EMA%d 需要至少 %d 根完成K棒暖機，目前資料約只有 %d 根，尚缺 %d 根。\n\n要手動輸入缺少的歷史收盤價嗎？\n選否會照目前資料等待暖機，前段可能不進場。" % (period, need, available, missing)):
            return None
        raw = simpledialog.askstring("EMA歷史收盤價", "請輸入缺少的 %d 根收盤價，順序由舊到新；可用換行或逗號分隔。" % missing, parent=self.root)
        if raw is None:
            return None
        values = self._parse_manual_ema_closes_text(raw)
        if len(values) < missing:
            raise ValueError("至少需要 %d 個收盤價，目前只有 %d 個。" % (missing, len(values)))
        return values

    def params(self, tp_override=None):
        opt = self.tai_index_option() if (self.is_fast_ma_mode() or self.is_tai_product_mode()) else self.option_map.get(self.product_choice.get())
        if not self.selected_code:
            self.selected_code = opt.code if opt else ""
        strategy_name = self.auto_strategy_for_option(opt) if opt else self.strategy.get()
        return dict(
            strategy_name=strategy_name,
            lots=self.lots.get(),
            tp_points=self.tp_points.get() if tp_override is None else tp_override,
            sl_points=self.sl_points.get(),
            loss_exit=(0.0 if is_fast_ma_strategy(strategy_name) else self.loss_exit.get()),
            lock_profit_exit=(0.0 if is_fast_ma_strategy(strategy_name) else self.lock_profit_exit.get()),
            product_code=self.selected_code,
            k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period(), entry_mode=self.get_entry_mode(),
            one_way_fee=self.one_way_fee_value(),
        )

    def run_single(self):
        if self.is_tai_product_mode():
            opt = self.tai_index_option()
        else:
            if not self.options:
                messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再選商品。")
                return
            opt = self.option_map.get(self.product_choice.get())
            if not opt:
                messagebox.showerror("回測失敗", "請先選擇商品")
                return
        code = opt.code
        self.save_current_param_texts()
        params = self.params()
        params["product_code"] = code
        strategy_name = self.auto_strategy_for_option(opt)
        tp_points = self.tp_points.get()
        sl_points = self.sl_points.get()
        try:
            d1, d2, _notes = self.resolve_date_range_for_code(code, self.date_start_text, self.date_end_text, "回測")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return
        ticks_snapshot = list(self.ticks) if self.selected_code == code else []

        def worker():
            ticks = ticks_snapshot or self.read_ticks_for_code(code, strategy_name, progress_prefix="讀取", start_date=d1, end_date=d2)
            if not ticks:
                raise ValueError("所選商品在目前日期範圍沒有可用逐筆資料。請確認策略時段或日期範圍。")
            params2 = dict(params)
            manual_closes = self._maybe_prompt_ema_manual_closes_for_backtest(ticks, strategy_name, params2.get("ma_period", 3), params2.get("k_minutes", 1), code)
            if manual_closes:
                params2["manual_ema_closes"] = manual_closes
            params2["progress"] = lambda cur, total, detail: self.progress_update(cur, total, "回測｜" + detail)
            ds, tr, records, events = run_strategy_backtest_ticks(ticks, **params2)
            return code, ticks, ds, tr, records, events

        def done(result):
            code2, ticks, ds, tr, _records, _events = result
            self.selected_code = code2
            self.ticks = ticks
            self.last_day_stats, self.last_trades = ds, tr
            total = sum(x["net"] for x in ds)
            avg, valid_days = self.average_net_for_strategy(ds, strategy_name)
            summary = self.day_stats_summary(ds)
            used_ma = int((params or {}).get("ma_period", self.get_ma_period()) or self.get_ma_period())
            self.info.configure(text="單組回測｜商品 %s｜%s%s｜實際使用：%s，共%d天，有效%d天｜停利/觸發 %.2f 點｜停損 %.2f 點｜總淨利：%s 元｜平均每日損益：%s 元｜平倉次數：%d" % (self.option_title(code2), strategy_name, (("｜%s%d|%s|%s" % (ma_algo_label(strategy_name), used_ma, k_minutes_label(self.get_k_minutes()), self.get_entry_mode())) if is_fast_ma_strategy(strategy_name) else (("｜%dMA|%s" % (used_ma, k_minutes_label(self.get_k_minutes()))) if is_three_ma_strategy(strategy_name) else "")), summary["range"], summary["total_days"], valid_days, tp_points, sl_points, format_money_plain(total), format_money_plain(avg), len(tr)))
            self.render_day_stats(ds)
            self.render_trades(tr)
            self.tabs.select(self.summary_frame)

        self.run_background("執行單組回測", worker, done)

    def run_sweep(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再選商品。")
            return
        opt = self.option_map.get(self.product_choice.get())
        if not opt:
            messagebox.showerror("比例測試失敗", "請先選擇商品")
            return
        code = opt.code
        strategy_name = self.strategy.get()
        lots = self.lots.get()
        ratio_text = str(self.ratio_text.get() or "").strip()
        margin = float(opt.base_margin or 0.0)
        if margin <= 0:
            messagebox.showerror("比例測試失敗", "此商品缺少期交所保證金資料或最新價，請先按「更新期交所保證金資料」並重新掃描商品。")
            return

        # v015：比例測試專用「找最佳日期」，不再使用一般「回測起訖日」。
        # 也不再沿用 self.ticks，避免先前讀過全資料後，比例測試仍拿全資料重跑。
        if not str(self.opt_start_text.get() or "").strip() or not str(self.opt_end_text.get() or "").strip():
            messagebox.showerror("比例測試日期未設定", "比例測試請使用「找最佳起日／找最佳迄日」。\n它不會使用上方的一般回測起訖日。")
            return
        try:
            d1, d2, _notes = self.resolve_date_range_for_code(code, self.opt_start_text, self.opt_end_text, "找最佳")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return

        valid_has_start = bool(str(self.valid_start_text.get() or "").strip())
        valid_has_end = bool(str(self.valid_end_text.get() or "").strip())
        if valid_has_start != valid_has_end:
            messagebox.showerror("驗證日期未完整", "若要驗證，請同時設定「驗證起日」與「驗證迄日」。\n若不驗證，兩格都留空。")
            return
        val_d1 = val_d2 = None
        if valid_has_start and valid_has_end:
            try:
                val_d1, val_d2, _vnotes = self.resolve_date_range_for_code(code, self.valid_start_text, self.valid_end_text, "驗證")
            except Exception as e:
                messagebox.showerror("驗證日期錯誤", str(e))
                return

        def worker():
            ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="找最佳讀取", start_date=d1, end_date=d2)
            if not ticks:
                raise ValueError("所選商品在找最佳日期範圍沒有可用逐筆資料。請確認找最佳起訖日。")
            ticks_val = []
            if val_d1 and val_d2:
                ticks_val = self.read_ticks_for_code(code, strategy_name, progress_prefix="驗證讀取", start_date=val_d1, end_date=val_d2)
                if not ticks_val:
                    raise ValueError("所選商品在驗證日期範圍沒有可用逐筆資料。請確認驗證起訖日。")
            rows = []
            best = None
            multiplier = product_multiplier_from_master_item(self.margin_item_for(code), strategy_name)
            if ratio_text == "":
                ratios = list(range(5, 16))
            else:
                try:
                    r_single = float(ratio_text)
                except Exception:
                    raise ValueError("測試分母請留空，或只填一個數字，例如 10")
                if r_single <= 0:
                    raise ValueError("測試分母必須大於 0")
                ratios = [r_single]
            for r in ratios:
                tp_ntd = margin / float(r)
                tp_points = tp_ntd / multiplier
                sl_points_auto = tp_points
                loss_exit_auto = tp_ntd * 3.0
                lock_profit_exit_auto = tp_ntd * 2.0
                params = dict(
                    strategy_name=strategy_name, lots=lots, tp_points=tp_points, sl_points=sl_points_auto,
                    loss_exit=loss_exit_auto, lock_profit_exit=lock_profit_exit_auto, product_code=code,
                    k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period(), entry_mode=self.get_entry_mode(),
                    one_way_fee=self.one_way_fee_value(),
                )
                ratio_index = len(rows)
                total_work = max(1, len(ratios) * len(ticks))
                def _ratio_progress(cur, total, detail, _idx=ratio_index, _ratio=r):
                    self.progress_update(_idx * len(ticks) + cur, total_work, "找最佳 N=%g｜%s" % (_ratio, detail))
                params2 = dict(params)
                params2["progress"] = _ratio_progress
                ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, **params2)
                total = sum(x["net"] for x in ds)
                avg, valid_days = self.average_net_for_strategy(ds, strategy_name)
                summary = self.day_stats_summary(ds)
                peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                tp_count = sum(x["tp"] for x in ds)
                sl_count = sum(x["sl"] for x in ds)
                rev_count = sum(x["reverse"] for x in ds)

                val_total = val_avg = None
                val_valid_days = 0
                val_range = ""
                val_ds = []
                val_tr = []
                if ticks_val:
                    vparams = dict(params)
                    vparams["progress"] = lambda cur, total, detail, _ratio=r: self.progress_update(cur, total, "驗證 N=%g｜%s" % (_ratio, detail))
                    val_ds, val_tr, _vrecs, _vevents = run_strategy_backtest_ticks(ticks_val, **vparams)
                    val_total = sum(x["net"] for x in val_ds)
                    val_avg, val_valid_days = self.average_net_for_strategy(val_ds, strategy_name)
                    val_summary = self.day_stats_summary(val_ds)
                    val_range = val_summary["range"]

                row = {
                    "ratio": r, "tp_points": tp_points, "tp_ntd": tp_ntd, "sl_points": sl_points_auto,
                    "loss_exit": loss_exit_auto, "lock_exit": lock_profit_exit_auto,
                    "total": total, "avg": avg, "valid_days": valid_days, "total_days": summary["total_days"],
                    "data_range": summary["range"], "trades": len(tr), "tp": tp_count, "sl": sl_count, "reverse": rev_count,
                    "peak": peak, "trough": trough, "ds": ds, "tr": tr,
                    "val_total": val_total, "val_avg": val_avg, "val_valid_days": val_valid_days, "val_range": val_range,
                    "val_ds": val_ds, "val_tr": val_tr,
                }
                rows.append(row)
                if best is None or avg > best["avg"]:
                    best = row
            if not rows:
                raise ValueError("測試分母沒有可用數值")
            return code, ticks, rows, best

        def done(result):
            code2, ticks, rows, best = result
            self.selected_code = code2
            # v015：比例測試只保存本次找最佳日期範圍內的 ticks，避免下一次又被誤當成全範圍資料。
            self.ticks = ticks
            self.clear_tree(self.sweep_tree)
            self.last_sweep = rows
            self.sweep_row_map = {}
            for row in rows:
                tag = "pos" if row["avg"] > 0 else "neg" if row["avg"] < 0 else "zero"
                val_total_text = "" if row.get("val_total") is None else format_money_plain(row.get("val_total", 0))
                val_avg_text = "" if row.get("val_avg") is None else format_money_plain(row.get("val_avg", 0))
                iid = self.sweep_tree.insert("", END, values=(
                    "1/%g" % row["ratio"], "%.2f" % row["tp_points"], "%.0f" % row["tp_ntd"], "%.2f" % row["sl_points"], "%.0f" % row["loss_exit"], "%.0f" % row["lock_exit"],
                    format_money_plain(row["total"]), format_money_plain(row["avg"]), row["valid_days"], row["data_range"],
                    val_total_text, val_avg_text, row.get("val_valid_days", ""), row.get("val_range", ""),
                    row["trades"], row["tp"], row["sl"], row["reverse"], format_money_plain(row["peak"]), format_money_plain(row["trough"])
                ), tags=(tag,))
                self.sweep_row_map[iid] = row
            if best:
                val_part = ""
                if best.get("val_total") is not None:
                    val_part = "｜驗證：%s，有效%d天，平均%s，總淨利%s" % (best.get("val_range", ""), best.get("val_valid_days", 0), format_money_plain(best.get("val_avg", 0)), format_money_plain(best.get("val_total", 0)))
                self.info.configure(text="比例測試完成｜商品 %s｜%s｜找最佳實際使用：%s，共%d天，有效%d天｜基準原始保證金約%s元｜最佳：1/%g｜停利 %.2f 點/%s新台幣｜平均每日損益 %s｜總淨利 %s%s" % (self.option_title(code2), strategy_name, best["data_range"], best["total_days"], best["valid_days"], safe_int_text(margin), best["ratio"], best["tp_points"], safe_int_text(best["tp_ntd"]), format_money_plain(best["avg"]), format_money_plain(best["total"]), val_part))
                self.last_day_stats, self.last_trades = best["ds"], best["tr"]
                self.render_day_stats(best["ds"])
                self.render_trades(best["tr"])
                self.tabs.select(self.sweep_frame)

        self.run_background("執行保證金比例測試", worker, done)

    def on_sweep_selected(self, _event=None):
        try:
            sel = self.sweep_tree.selection()
            if not sel:
                return
            row = self.sweep_row_map.get(sel[0])
            if not row:
                return
            self.last_day_stats, self.last_trades = row.get("ds", []), row.get("tr", [])
            self.render_day_stats(self.last_day_stats)
            self.render_trades(self.last_trades)
            try:
                self.tabs.select(self.summary_frame)
            except Exception:
                pass
            self.info.configure(text="已切換每日總表｜分母 1/%g｜實際使用：%s，有效%d天｜平均每日損益 %s｜總淨利 %s" % (row.get("ratio", 0), row.get("data_range", ""), row.get("valid_days", 0), format_money_plain(row.get("avg", 0)), format_money_plain(row.get("total", 0))))
        except Exception:
            pass

    def hot_top20_options(self):
        big, small = self.hot_rankings()
        return list(big[:10]) + list(small[:10])

    def run_hot_optimize(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再執行熱門商品最佳化。")
            return
        targets = self.hot_top20_options()
        if not targets:
            messagebox.showinfo("沒有熱門商品", "目前沒有可最佳化的大股期/小股期前10名。")
            return
        strategy_by_kind = {"大股期": "大股期策略", "小股期": "小股期策略"}
        ratio_values = list(range(5, 16))
        # v015：熱門最佳化只使用「找最佳日期」，不再退回一般回測日期，避免誤跑全部資料。
        if not str(self.opt_start_text.get() or "").strip() or not str(self.opt_end_text.get() or "").strip():
            messagebox.showerror("找最佳日期未設定", "一鍵最佳化熱門商品請先設定「找最佳起日／找最佳迄日」。\n它不會使用上方的一般回測起訖日。")
            return
        if bool(str(self.valid_start_text.get() or "").strip()) != bool(str(self.valid_end_text.get() or "").strip()):
            messagebox.showerror("驗證日期未完整", "若要驗證，請同時設定「驗證起日」與「驗證迄日」。\n若不驗證，兩格都留空。")
            return
        def worker():
            results = []
            total_jobs = max(1, len(targets) * len(ratio_values))
            job = 0
            for opt in targets:
                strategy_name = strategy_by_kind.get(opt.product_kind, self.strategy.get())
                # 背景執行中只做純解析；比例測試/熱門最佳化不再吃一般回測起訖日。
                opt_d1 = _date_from_text(str(self.opt_start_text.get() or "").strip())
                opt_d2 = _date_from_text(str(self.opt_end_text.get() or "").strip())
                if str(self.valid_start_text.get() or "").strip() and str(self.valid_end_text.get() or "").strip():
                    val_d1 = _date_from_text(str(self.valid_start_text.get() or "").strip())
                    val_d2 = _date_from_text(str(self.valid_end_text.get() or "").strip())
                else:
                    val_d1 = val_d2 = None
                margin = float(opt.base_margin or 0.0)
                if margin <= 0:
                    continue
                item = self.margin_item_for(opt.code)
                multiplier = product_multiplier_from_master_item(item, strategy_name)
                ticks_opt = self.read_ticks_for_code(opt.code, strategy_name, progress_prefix="最佳化讀取", start_date=opt_d1, end_date=opt_d2)
                if not ticks_opt:
                    continue
                best = None
                for r in ratio_values:
                    job += 1
                    tp_ntd = margin / float(r)
                    tp_points = tp_ntd / multiplier
                    params = dict(strategy_name=strategy_name, lots=self.lots.get(), tp_points=tp_points, sl_points=tp_points,
                                  loss_exit=tp_ntd * 3.0, lock_profit_exit=tp_ntd * 2.0, product_code=opt.code)
                    params["progress"] = lambda cur, total, detail, _job=job, _opt=opt, _r=r: self.progress_update((_job-1) * 1000 + (cur/max(1,total))*1000, total_jobs*1000, "熱門商品 %d/%d｜%s｜分母 %g/15｜%s" % (_job, total_jobs, self.option_title(_opt), _r, detail))
                    ds, tr, _records, _events = run_strategy_backtest_ticks(ticks_opt, **params)
                    avg, valid_days = self.average_net_for_strategy(ds, strategy_name)
                    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds)
                    summary = self.day_stats_summary(ds)
                    peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                    trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                    cand = {"ratio": r, "tp_ntd": tp_ntd, "tp_points": tp_points, "avg": avg, "total": total, "valid_days": valid_days, "range": summary["range"], "total_days": summary["total_days"], "peak": peak, "trough": trough, "ds": ds, "tr": tr,
                            "profit_hit": any(bool(x.get("hit_profit_exit")) or int(x.get("profit_exit", 0) or 0) > 0 for x in ds),
                            "loss_hit": any(bool(x.get("hit_loss_exit")) or int(x.get("loss_exit", 0) or 0) > 0 for x in ds)}
                    if best is None or cand["avg"] > best["avg"]:
                        best = cand
                if best is None:
                    continue
                # 驗證同一個最佳分母。
                ticks_val = self.read_ticks_for_code(opt.code, strategy_name, progress_prefix="驗證讀取", start_date=val_d1, end_date=val_d2)
                val = dict(best)
                if ticks_val:
                    r = best["ratio"]
                    tp_ntd = margin / float(r)
                    tp_points = tp_ntd / multiplier
                    params = dict(strategy_name=strategy_name, lots=self.lots.get(), tp_points=tp_points, sl_points=tp_points,
                                  loss_exit=tp_ntd * 3.0, lock_profit_exit=tp_ntd * 2.0, product_code=opt.code)
                    ds, tr, _records, _events = run_strategy_backtest_ticks(ticks_val, **params)
                    avg, valid_days = self.average_net_for_strategy(ds, strategy_name)
                    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds)
                    summary = self.day_stats_summary(ds)
                    val = {"avg": avg, "total": total, "valid_days": valid_days, "range": summary["range"], "total_days": summary["total_days"], "ds": ds, "tr": tr}
                results.append({"opt": opt, "strategy": strategy_name, "best": best, "val": val})
            results.sort(key=lambda x: x["best"].get("avg", 0.0), reverse=True)
            return results
        def done(results):
            self.clear_tree(self.optimize_tree)
            self.last_optimize = results
            for idx, row in enumerate(results, start=1):
                opt = row["opt"]
                best = row["best"]
                val = row["val"]
                tag = "pos" if float(best.get("avg", 0.0)) > 0 else "neg" if float(best.get("avg", 0.0)) < 0 else "zero"
                self.optimize_tree.insert("", END, values=(
                    idx, opt.product_kind, getattr(opt, "hot_rank", ""), getattr(opt, "hot_status", ""), opt.code, opt.stock_name,
                    "1/%g" % best["ratio"], format_money_plain(best["avg"]), format_money_plain(best["total"]), best["valid_days"], best["range"],
                    format_money_plain(val.get("avg", 0)), format_money_plain(val.get("total", 0)), val.get("valid_days", 0), val.get("range", ""),
                    "%.2f" % best["tp_points"], safe_int_text(best["tp_ntd"]), format_money_plain(best["peak"]), format_money_plain(best["trough"])
                ), tags=(tag,))
            if results:
                top = results[0]
                b = top["best"]
                self.info.configure(text="熱門商品最佳化完成｜共%d檔｜最佳排名以平均每日損益排序｜第1名 %s 1/%g｜找最佳：%s，有效%d天，平均%s" % (len(results), self.option_title(top["opt"]), b["ratio"], b["range"], b["valid_days"], format_money_plain(b["avg"])))
            else:
                self.info.configure(text="熱門商品最佳化完成，但沒有可用結果。請確認快取日期、保證金資料與熱門商品資料。")
            self.tabs.select(self.optimize_frame)
        self.run_background("一鍵最佳化熱門商品", worker, done)

    def open_current_table_large(self):
        selected = self.tabs.select()
        if selected == str(getattr(self, "result_frame", "")):
            tree, title = self.result_tree, "回測結果"
        elif selected == str(self.summary_frame):
            tree, title = self.summary_tree, "每日總表"
        elif selected == str(self.detail_frame):
            tree, title = self.detail_tree, "交易明細"
        else:
            tree, title = getattr(self, "result_tree", self.summary_tree), "回測結果"
        original_cols = list(tree["columns"])
        display_cols = list(tree["displaycolumns"])
        if not display_cols or display_cols == ["#all"]:
            display_cols = list(original_cols)
        cols = list(original_cols)
        win = Toplevel(self.root)
        win.title(title + "｜放大檢視")
        self.apply_dialog_geometry(win, "large_table", self.get_setting("geometry.large_table", "1400x850"))
        if not self.get_setting("geometry.large_table", ""):
            try:
                win.state("zoomed")
            except Exception:
                pass
        frame = ttk.Frame(win, padding=8)
        frame.pack(fill=BOTH, expand=True)
        big = ttk.Treeview(frame, columns=cols, show="headings", selectmode="extended")
        try:
            big["displaycolumns"] = display_cols
        except Exception:
            pass
        try:
            big.tag_configure("pos", foreground="#FF0000")
            big.tag_configure("neg", foreground="#008000")
            big.tag_configure("long", foreground="#FF0000")
            big.tag_configure("short", foreground="#008000")
            big.tag_configure("zero", foreground="#333333")
            # 放大交易明細視窗也套用一筆交易上下兩列的分組底色。
            for _bg_idx, _bg in ((0, "#FFFBE6"), (1, "#EAF4FF")):
                big.tag_configure(f"trade_entry_group{_bg_idx}", foreground="#333333", background=_bg)
                big.tag_configure(f"trade_exit_pos_group{_bg_idx}", foreground="#FF0000", background=_bg)
                big.tag_configure(f"trade_exit_neg_group{_bg_idx}", foreground="#008000", background=_bg)
                big.tag_configure(f"trade_exit_zero_group{_bg_idx}", foreground="#333333", background=_bg)
                big.tag_configure(f"trade_pos_day{_bg_idx}", foreground="#FF0000", background=_bg)
                big.tag_configure(f"trade_neg_day{_bg_idx}", foreground="#008000", background=_bg)
                big.tag_configure(f"trade_zero_day{_bg_idx}", foreground="#333333", background=_bg)
            big.tag_configure("day_total_pos", foreground="#FF0000", background="#FFFFFF")
            big.tag_configure("day_total_neg", foreground="#008000", background="#FFFFFF")
            big.tag_configure("day_total_zero", foreground="#333333", background="#FFFFFF")
        except Exception:
            pass
        ybar = ttk.Scrollbar(frame, orient="vertical", command=big.yview)
        xbar = ttk.Scrollbar(frame, orient="horizontal", command=big.xview)
        big.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        for col in cols:
            big.heading(col, text=tree.heading(col, "text"))
            width = int(tree.column(col, "width") or 100)
            big.column(col, width=max(width, 100), anchor=tree.column(col, "anchor") or "center", stretch=True)
        large_result_row_map = {}
        for item in tree.get_children():
            new_iid = big.insert("", END, values=tree.item(item, "values"), tags=tree.item(item, "tags"))
            if tree is getattr(self, "result_tree", None):
                try:
                    row = self.result_row_map.get(item)
                    if row:
                        large_result_row_map[new_iid] = row
                except Exception:
                    pass

        if tree is getattr(self, "result_tree", None):
            hint = ttk.Label(frame, text="提示：點選只選取；Ctrl/Shift可多選後批次存入精選結果；雙擊才載入每日總表與交易明細。", foreground="#005A9E")
            hint.grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 0))
            large_btnbar = ttk.Frame(frame)
            large_btnbar.grid(row=3, column=0, columnspan=2, sticky="w", pady=(6, 0))

            def _open_large_result_detail(_event=None):
                try:
                    iid = ""
                    if _event is not None:
                        iid = big.identify_row(_event.y)
                    if not iid:
                        sel = list(big.selection() or [])
                        iid = sel[0] if sel else ""
                    if not iid:
                        return
                    try:
                        big.selection_set(iid)
                        big.focus(iid)
                    except Exception:
                        pass
                    row = large_result_row_map.get(iid)
                    if not row:
                        return
                    self.load_result_row_detail(row)
                except Exception:
                    pass

            def _save_large_result():
                try:
                    sel = list(big.selection() or [])
                    if not sel:
                        messagebox.showinfo("尚未選取結果", "請先在放大表格選取一列，或用 Ctrl/Shift 多選。", parent=win)
                        return
                    items = []
                    for iid in sorted(sel, key=lambda x: big.index(x)):
                        row = large_result_row_map.get(iid)
                        if row:
                            items.append((iid, row, big.index(iid) + 1))
                    if not items:
                        return
                    self._save_result_row_items_to_selected(items)
                except Exception as exc:
                    messagebox.showerror("存入精選結果失敗", str(exc), parent=win)

            ttk.Button(large_btnbar, text="存入精選結果", command=_save_large_result).pack(side="left", padx=(0, 6))
            ttk.Button(large_btnbar, text="查看精選結果", command=self.open_selected_results_window).pack(side="left", padx=6)
            big.bind("<Double-1>", _open_large_result_detail, add="+")

        big.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

    def render_day_stats(self, ds):
        self.clear_tree(self.summary_tree)
        for x in ds:
            net = float(x.get("net", 0.0) or 0.0)
            tag = "pos" if net > 0 else "neg" if net < 0 else "zero"
            self.summary_tree.insert("", END, values=(
                x["session"], x["month"], x["minutes"], x["ticks"], x["trades"], x.get("win_trades", 0), x.get("loss_trades", 0), format_money_plain(net),
                x["tp"], x["sl"], x["reverse"], x["force"], x["loss_exit"], x["profit_exit"],
                format_money_plain(x.get("peak_pnl", 0.0)), format_money_plain(x.get("trough_pnl", 0.0)), x["stop_reason"]
            ), tags=(tag,))
        if ds:
            valid = [x for x in ds if float(x.get("trades", 0) or 0) > 0]
            n = len(valid) if valid else len(ds)
            base = valid if valid else ds
            avg_trades = sum(float(x["trades"]) for x in base) / n
            avg_win = sum(float(x.get("win_trades", 0) or 0) for x in base) / n
            avg_loss_trade = sum(float(x.get("loss_trades", 0) or 0) for x in base) / n
            avg_net = sum(float(x["net"]) for x in base) / n
            avg_tp = sum(float(x["tp"]) for x in base) / n
            avg_sl = sum(float(x["sl"]) for x in base) / n
            avg_reverse = sum(float(x["reverse"]) for x in base) / n
            avg_force = sum(float(x["force"]) for x in base) / n
            avg_loss_exit = sum(float(x["loss_exit"]) for x in base) / n
            avg_profit_exit = sum(float(x["profit_exit"]) for x in base) / n
            peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
            trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
            tag = "pos" if avg_net > 0 else "neg" if avg_net < 0 else "zero"
            self.summary_tree.insert("", END, values=("平均", "", "", "", "%.2f" % avg_trades, "%.2f" % avg_win, "%.2f" % avg_loss_trade, format_money_plain(avg_net), "%.2f" % avg_tp, "%.2f" % avg_sl, "%.2f" % avg_reverse, "%.2f" % avg_force, "%.2f" % avg_loss_exit, "%.2f" % avg_profit_exit, format_money_plain(peak), format_money_plain(trough), "平均已剔除0平倉日" if valid and len(valid) != len(ds) else ""), tags=(tag,))

    def _trade_session_date_key(self, session_text):
        text = str(session_text or "").strip()
        # 053E：交易明細累計必須與「每日總表」同一顆 session key 對齊。
        # 先前只取日期，會把同一天的日盤與夜盤合併，導致 5/11 夜盤明細最後累計
        # 被 5/11 日盤損益抵銷，與每日總表的夜盤淨利不一致。
        # 常見格式：「2026-06-12 日盤」、「2026-06-12 夜盤」。
        m = re.search(r"(\d{4}-\d{2}-\d{2})(?:\s*([^\s]+盤))?", text)
        if m:
            date_part = m.group(1)
            sess_part = (m.group(2) or "").strip()
            return (date_part + " " + sess_part).strip()
        m = re.search(r"(\d{8})(?:\s*([^\s]+盤))?", text)
        if m:
            raw = m.group(1)
            date_part = raw[:4] + "-" + raw[4:6] + "-" + raw[6:8]
            sess_part = (m.group(2) or "").strip()
            return (date_part + " " + sess_part).strip()
        return text

    def _trade_time_text_for_view(self, dt_value, session_text=""):
        """交易明細顯示用時間。

        台指夜盤本來跨日：例如「2026-06-22 夜盤」包含 06/22 15:00 到
        06/23 04:59。交易明細統一顯示 MM/DD HH:MM:SS，所有商品都能一眼比對實際進出場時間。
        """
        try:
            if isinstance(dt_value, RealDateTime):
                dt = dt_value
            else:
                dt = parse_dt_text(dt_value)
            if not dt:
                return str(dt_value or "")
            return dt.strftime("%m/%d %H:%M:%S")
        except Exception:
            try:
                return dt_value.strftime("%m/%d %H:%M:%S")
            except Exception:
                return str(dt_value or "")

    @staticmethod
    def _trade_time_text_for_csv(dt_value):
        """CSV 匯出保留完整日期時間，避免夜盤跨日被誤判。"""
        try:
            if isinstance(dt_value, RealDateTime):
                return dt_value.strftime("%Y-%m-%d %H:%M:%S")
            dt = parse_dt_text(dt_value)
            return dt.strftime("%Y-%m-%d %H:%M:%S") if dt else str(dt_value or "")
        except Exception:
            return str(dt_value or "")

    def _is_tai_trade_row(self, trade_row):
        try:
            return is_tai_index_code(str((trade_row or {}).get("product_code", "") or ""))
        except Exception:
            return False

    @staticmethod
    def _compact_number_text(value, decimals=2, signed=False):
        try:
            v = float(value or 0.0)
        except Exception:
            return str(value or "")
        sign = "+" if signed and v > 0 else ""
        if abs(v - round(v)) < 1e-9:
            return sign + str(int(round(v)))
        text = (f"{v:.{int(decimals)}f}").rstrip("0").rstrip(".")
        return sign + text

    def _trade_price_text(self, value, trade_row=None):
        try:
            v = float(value or 0.0)
        except Exception:
            return str(value or "")
        if self._is_tai_trade_row(trade_row):
            return str(int(round(v)))
        return self._compact_number_text(v, decimals=2, signed=False)

    def _trade_ma_text(self, trade_row, which="entry"):
        try:
            row = trade_row or {}
            value = row.get(("entry_ma" if which == "entry" else "exit_ma"), 0.0)
            if not value:
                value = row.get(("entry_sma" if which == "entry" else "exit_sma"), 0.0) or row.get(("entry_ema" if which == "entry" else "exit_ema"), 0.0) or row.get("ema", 0.0)
            v = float(value or 0.0)
            if v <= 0:
                return ""
            algo = str(row.get(("entry_ma_algo" if which == "entry" else "exit_ma_algo"), "") or row.get("ma_algo", "") or "MA").upper()
            period = row.get(("entry_ma_period" if which == "entry" else "exit_ma_period"), row.get("ma_period", ""))
            prefix = algo + (str(int(period)) if str(period).strip() not in ("", "0") else "")
            value_text = self._trade_price_text(v, row)
            return "%s %s" % (prefix, value_text)
        except Exception:
            return ""

    def _trade_points_value(self, trade_row):
        try:
            entry = float((trade_row or {}).get("entry", 0.0) or 0.0)
            exit_px = float((trade_row or {}).get("exit", 0.0) or 0.0)
            side = str((trade_row or {}).get("side", "") or "")
            return (exit_px - entry) if "多" in side else (entry - exit_px)
        except Exception:
            return 0.0

    def _trade_points_text(self, trade_row):
        pts = self._trade_points_value(trade_row)
        if self._is_tai_trade_row(trade_row):
            return self._compact_number_text(round(pts), decimals=0, signed=True)
        return self._compact_number_text(pts, decimals=2, signed=True)

    def render_trades(self, tr):
        self.clear_tree(self.detail_tree)
        day_color_index = {}
        next_color_index = 0
        current_day = None
        day_total = 0.0

        def insert_day_total(day_key, total_value):
            if not day_key:
                return
            pnl_key = "pos" if total_value > 0 else "neg" if total_value < 0 else "zero"
            self.detail_tree.insert("", END, values=(
                "時段累計", "", "", "", "", "", "", "", format_money(total_value), ""
            ), tags=("day_total_" + pnl_key,))

        seq = 0
        for t in tr:
            side = str(t.get("side", "") or "")
            session_text = str(t.get("session", "") or "")
            day_key = self._trade_session_date_key(session_text)
            if current_day is None:
                current_day = day_key
            elif day_key != current_day:
                insert_day_total(current_day, day_total)
                day_total = 0.0
                current_day = day_key
            if day_key not in day_color_index:
                day_color_index[day_key] = next_color_index % 2
                next_color_index += 1
            # 同一天內每筆交易仍交錯底色，避免上下組看錯；跨日從目前交錯順序續排。
            seq += 1
            bg_idx = (seq - 1) % 2
            net = float(t.get("net", 0.0) or 0.0)
            day_total += net
            pnl_key = "pos" if net > 0 else "neg" if net < 0 else "zero"
            self.detail_tree.insert("", END, values=(
                f"{seq:03d}", side, "進場",
                self._trade_time_text_for_view(t.get("entry_time"), session_text),
                self._trade_price_text(t.get("entry"), t),
                self._trade_ma_text(t, "entry"),
                "", "", "", str(t.get("entry_reason", "") or "")
            ), tags=(f"trade_entry_group{bg_idx}",))
            self.detail_tree.insert("", END, values=(
                "↳", side, "出場",
                self._trade_time_text_for_view(t.get("exit_time"), session_text),
                self._trade_price_text(t.get("exit"), t),
                self._trade_ma_text(t, "exit"),
                self._trade_points_text(t),
                format_money(net),
                format_money(day_total),
                str(t.get("reason", "") or "")
            ), tags=(f"trade_exit_{pnl_key}_group{bg_idx}",))
        if current_day is not None:
            insert_day_total(current_day, day_total)

    def _selected_summary_session_set(self):
        sessions = set()
        try:
            for iid in list(self.summary_tree.selection() or []):
                vals = self.summary_tree.item(iid, "values")
                if vals and str(vals[0]) not in ("平均", "合計"):
                    sessions.add(str(vals[0]))
        except Exception:
            pass
        return sessions

    def export_csv(self):
        if not self.last_group_results and not self.last_day_stats:
            messagebox.showinfo("沒有結果", "請先執行群組參數回測，或點選一筆回測結果載入明細。")
            return
        p = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if not p:
            return

        result_rows = self._current_result_rows_for_display() if self.last_group_results else []
        selected_sessions = self._selected_summary_session_set()
        day_rows = list(self.last_day_stats or [])
        trade_rows = list(self.last_trades or [])
        if selected_sessions:
            day_rows = [x for x in day_rows if str(x.get("session", "")) in selected_sessions]
            trade_rows = [t for t in trade_rows if str(t.get("session", "")) in selected_sessions]
        result_filter = str(self.result_filter_text.get() or "總表")
        day_filter = "、".join(sorted(selected_sessions)) if selected_sessions else "全部日期"

        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            if result_rows:
                w.writerow(["回測結果", "商品篩選", result_filter, "規則", "每檔商品前10名；排名=平均每日獲利/原始保證金"])
                include_ma = any(self._result_row_uses_ma(r) for r in result_rows)
                header = ["排序", "商品名稱", "保證金", "獲利/原始保證金", "平均每日獲利", "總淨利", "有效天數", "日期範圍"]
                if include_ma:
                    header.append("MA")
                header += ["K棒", "停利/觸發點", "停損點", "認賠", "賺飽", "平倉次數", "停利次數", "停損次數", "認賠次數", "賺飽次數", "最高損益", "最低損益", "狀態"]
                w.writerow(header)
                for idx, row in enumerate(result_rows, start=1):
                    opt = row.get("opt")
                    params = row.get("params") or {}
                    avg = row.get("avg", "")
                    if isinstance(avg, (int, float)) and float(avg) < -1e17:
                        avg = ""
                    score = self.result_rank_score(row)
                    score_text = "" if score < -1e17 else score
                    out_row = [
                        idx, self.product_name_text(opt), float(getattr(opt, "base_margin", 0.0) or 0.0), score_text, avg, row.get("total", 0), row.get("valid_days", 0), row.get("range", "")
                    ]
                    if include_ma:
                        out_row.append(( (ma_algo_label(str(row.get("strategy") or params.get("strategy_name") or "")) + str(normalize_fast_ma_period(params.get("ma_period", 89)))) if is_fast_ma_strategy(str(row.get("strategy") or params.get("strategy_name") or "")) else (str(normalize_ma_period(params.get("ma_period", 3))) + "MA") ) if (params and self._result_row_uses_ma(row)) else "")
                    out_row += [
                        normalize_k_minutes(params.get("k_minutes", 1)) if params else "",
                        params.get("tp_points", ""), params.get("sl_points", ""), params.get("loss_exit", ""), params.get("lock_profit_exit", ""),
                        row.get("trades", 0), row.get("tp", 0), row.get("sl", 0), row.get("loss_exit_count", 0), row.get("profit_exit_count", 0), row.get("peak", 0), row.get("trough", 0), row.get("status", "")
                    ]
                    w.writerow(out_row)
                w.writerow([])
            if day_rows:
                w.writerow(["目前選取參數的每日總表", "日期篩選", day_filter])
                w.writerow(["日期/時段", "自動月份", "分鐘數", "逐筆數", "平倉次數", "賺錢次數", "賠錢次數", "淨利", "停利", "停損", "反手", "時間到", "認賠", "賺飽", "最高損益", "最低損益", "停止原因"])
                for x in day_rows:
                    w.writerow([x["session"], x["month"], x["minutes"], x["ticks"], x["trades"], x.get("win_trades", 0), x.get("loss_trades", 0), x["net"], x["tp"], x["sl"], x["reverse"], x["force"], x["loss_exit"], x["profit_exit"], x.get("peak_pnl", 0.0), x.get("trough_pnl", 0.0), x["stop_reason"]])
                avg_base = [x for x in day_rows if float(x.get("trades", 0) or 0) > 0] or day_rows
                n = len(avg_base)
                if n:
                    w.writerow([
                        "平均", "", "", "",
                        sum(float(x["trades"]) for x in avg_base) / n,
                        sum(float(x.get("win_trades", 0) or 0) for x in avg_base) / n,
                        sum(float(x.get("loss_trades", 0) or 0) for x in avg_base) / n,
                        sum(float(x["net"]) for x in avg_base) / n,
                        sum(float(x["tp"]) for x in avg_base) / n,
                        sum(float(x["sl"]) for x in avg_base) / n,
                        sum(float(x["reverse"]) for x in avg_base) / n,
                        sum(float(x["force"]) for x in avg_base) / n,
                        sum(float(x["loss_exit"]) for x in avg_base) / n,
                        sum(float(x["profit_exit"]) for x in avg_base) / n,
                        max((float(x.get("peak_pnl", 0.0) or 0.0) for x in day_rows), default=0.0),
                        min((float(x.get("trough_pnl", 0.0) or 0.0) for x in day_rows), default=0.0),
                        "平均已剔除0平倉日" if len(avg_base) != len(day_rows) else "",
                    ])
                w.writerow([])
                w.writerow(["目前選取參數的交易明細", "日期篩選", day_filter])
                w.writerow(["筆次", "方向", "動作", "日期時間", "價格", "均線", "損益點數", "淨損益", "時段累計", "原因"])
                cur_day = None
                day_total = 0.0
                seq = 0
                for t in trade_rows:
                    dkey = self._trade_session_date_key(t.get("session", ""))
                    if cur_day is None:
                        cur_day = dkey
                    elif dkey != cur_day:
                        w.writerow(["時段累計", "", "", "", "", "", "", "", day_total, ""])
                        day_total = 0.0
                        cur_day = dkey
                    seq += 1
                    net = float(t.get("net", 0.0) or 0.0)
                    day_total += net
                    w.writerow([f"{seq:03d}", t.get("side", ""), "進場", self._trade_time_text_for_csv(t.get("entry_time")), self._trade_price_text(t.get("entry", t)), self._trade_ma_text(t, "entry"), "", "", "", str(t.get("entry_reason", "") or "")])
                    w.writerow(["↳", t.get("side", ""), "出場", self._trade_time_text_for_csv(t.get("exit_time")), self._trade_price_text(t.get("exit"), t), self._trade_ma_text(t, "exit"), self._trade_points_text(t), net, day_total, t.get("reason", "")])
                if cur_day is not None:
                    w.writerow(["時段累計", "", "", "", "", "", "", "", day_total, ""])
        messagebox.showinfo("匯出完成", p)



def _install_exception_logging():
    def _hook(exc_type, exc, tb):
        log_startup("Unhandled exception:\n" + "".join(traceback.format_exception(exc_type, exc, tb)))
    try:
        sys.excepthook = _hook
    except Exception:
        pass


def main():
    _install_exception_logging()
    try:
        multiprocessing.freeze_support()
    except Exception:
        pass
    try:
        log_startup("Starting TrainBacktester %s | python=%s | cwd=%s" % (APP_VERSION, sys.version.replace("\n", " "), os.getcwd()))
    except Exception:
        pass
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass
    root = None
    try:
        root = Tk()
        app = App(root)
        try:
            root.after(100, app.force_window_visible)
            root.after(1800, app.force_window_visible)
        except Exception:
            pass
        root.mainloop()
    except Exception as exc:
        detail = traceback.format_exc()
        log_startup("Startup failed:\n" + detail)
        try:
            messagebox.showerror("TrainBacktester startup failed", str(exc) + "\n\nLog: " + startup_log_path())
        except Exception:
            pass
        raise

if __name__ == "__main__":
    main()
