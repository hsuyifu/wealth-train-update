# -*- coding: utf-8 -*-
from __future__ import annotations

from dataclasses import asdict, dataclass, field, fields
from datetime import datetime, timedelta
from math import floor
from typing import Any, Callable, Dict, Iterable, List, Optional
import time


# ============================================================
# API 三策略忠實移植引擎｜對齊 XQ 0611 母版
# ============================================================
# 規格來源：台指期僅均線逐筆0611.xs、大股期策略0611.xs、小股期策略0611.xs。
#
# API 與 XQ 的責任分工：
# - XQ FilledRecord             -> TradeCom 成交回報 apply_real_fill
# - XQ Position / FilledAvgPrice -> 券商庫存 reconcile_real_position
# - XQ SetPosition              -> 面板 real_target_callback / TradeCom
# - XQ IntrabarPersist          -> SimState + export_state / import_state
# - XQ 下單補送鎖              -> order_pending + deferred_target
#
# 使用者追加規則：三套策略統一將「等於均價」歸類為多方。
# - OP：第一根收盤 >= 均價，第二根做多；否則做空。
# - Cross Long：前一狀態 < 均價，現在 >= 均價。
# - Cross Short：前一狀態 >= 均價，現在 < 均價。
# - 站上均價判定：>=；跌破均價判定：<。
#
# 開盤限制：
# - 第一分鐘完全禁止策略自動下單。
# - 第二根只允許 OP 進場；若 OP 進場後碰到風控，仍允許風控出場。
# - 第三根開始才允許 Cross / FB / IntraFB。
# - 三套策略均為純價格版；不允許籌碼補進場或籌碼反向平倉。
#
# 平倉當根再進規則：
# - TP：命中瞬間切斷平倉前舊 Pending；平倉鎖期間只接收最新 Tick 新 ARM / 新 FIRE。
# - 一般停損：同樣切斷停損前舊 Pending；平倉鎖期間只接收本根新 ARM / 新 FIRE，歸零後立即補進。
# - OP 與籌碼候選不可在平倉後補回；累積鎖損、累積鎖利、收盤強平、手動平倉亦不自動補回。
# ============================================================


def _f(v: Any, default: float = 0.0) -> float:
    try:
        if hasattr(v, "ToString"):
            v = v.ToString()
        return float(str(v).replace(",", "").strip())
    except Exception:
        return default


def _i(v: Any, default: int = 0) -> int:
    try:
        if hasattr(v, "ToString"):
            v = v.ToString()
        return int(float(str(v).replace(",", "").strip()))
    except Exception:
        return default


def _raw_attr(raw: Any, name: str, default: Any = None) -> Any:
    try:
        if isinstance(raw, dict):
            return raw.get(name, default)
        return getattr(raw, name)
    except Exception:
        return default


def _tick_datetime(raw: Any = None, now: Optional[datetime] = None) -> datetime:
    now = now or datetime.now()
    raw_time = str(_raw_attr(raw, "MatchTime", "") or "").strip()
    digits = "".join(ch for ch in raw_time if ch.isdigit())
    if digits:
        try:
            # QuoteCom PI20020 MatchTime 為 HHmmssSS；凌晨可能遺失前導 0。
            hhmmsscc = digits[-8:].zfill(8)
            hh, mm, ss = int(hhmmsscc[:2]), int(hhmmsscc[2:4]), int(hhmmsscc[4:6])
            if 0 <= hh <= 23 and 0 <= mm <= 59 and 0 <= ss <= 59:
                return now.replace(hour=hh, minute=mm, second=ss, microsecond=0)
        except Exception:
            pass
    return now


def _session(dt: datetime) -> tuple[str, bool, bool]:
    """回傳 session_key、是否在交易時段、是否進入收盤強平分鐘。"""
    hhmm = dt.hour * 100 + dt.minute
    if 845 <= hhmm < 1345:
        return dt.strftime("%Y-%m-%d") + ":DAY", True, 1343 <= hhmm < 1345
    if hhmm >= 1500:
        return dt.strftime("%Y-%m-%d") + ":NIGHT", True, False
    if hhmm < 500:
        return (dt - timedelta(days=1)).strftime("%Y-%m-%d") + ":NIGHT", True, 458 <= hhmm < 500
    return "", False, False


def _stock_session(dt: datetime) -> tuple[str, bool, bool]:
    """股期策略只使用日盤，避免夜盤誤進場或誤判無行情。"""
    hhmm = dt.hour * 100 + dt.minute
    if 845 <= hhmm < 1345:
        return dt.strftime("%Y-%m-%d") + ":DAY", True, 1343 <= hhmm < 1345
    return "", False, False


def _is_three_ma_profile(profile: "StrategyProfile") -> bool:
    kind = str(getattr(profile, "kind", "") or "")
    return kind.startswith("THREE_MA")



def _is_ma_strategy_text(text: Any) -> bool:
    raw_text = str(text or "").strip()
    raw = raw_text.upper().replace(" ", "")
    if not raw:
        return False
    return (
        raw_text == "MA策略"
        or "MA策略" in raw_text
        or ("3" + "MA") in raw
        or any(token in raw for token in ("5MA", "10MA"))
    )


def _normalize_ma_period(value: Any) -> int:
    text = str(value or "").upper().replace("分", "").replace("K", "").replace(" ", "").replace("策略", "").replace("MA", "")
    try:
        period = int(float(text))
    except Exception:
        period = 3
    return period if period in (3, 5, 10) else 3


def _task_ma_period(task: Any) -> int:
    return _normalize_ma_period(getattr(task, "ma_period", 3))


def _profile_session(profile: "StrategyProfile", dt: datetime) -> tuple[str, bool, bool]:
    return _session(dt) if profile.kind in ("TAI", "THREE_MA_TAI") else _stock_session(dt)


def _session_minute(dt: datetime) -> int:
    """本時段開始後的分鐘索引：日盤 08:45=0；夜盤 15:00=0。"""
    minute = dt.hour * 60 + dt.minute
    if minute >= 15 * 60:
        return minute - 15 * 60
    if minute < 5 * 60:
        return minute + 24 * 60 - 15 * 60
    if minute >= 8 * 60 + 45:
        return minute - (8 * 60 + 45)
    return -1


def _bar_key(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M")


def _normalize_three_ma_bar_minutes(value: Any) -> int:
    """MA策略 策略允許的 K 棒週期；舊任務或異常值一律回 1 分 K。"""
    try:
        minutes = int(float(str(value).replace("分", "").replace("K", "").strip()))
    except Exception:
        minutes = 1
    return minutes if minutes in (1, 5, 10) else 1


def _task_bar_minutes(task: Any) -> int:
    if _is_three_ma_profile(_profile(task)):
        return _normalize_three_ma_bar_minutes(getattr(task, "bar_minutes", 1))
    return 1


def _bar_key_for_task(task: Any, dt: datetime) -> str:
    """非 MA策略固定 1 分 K；MA策略依任務保存的 1/5/10 分 K 聚合。"""
    minutes = _task_bar_minutes(task)
    if minutes <= 1:
        return _bar_key(dt)
    session_minute = _session_minute(dt)
    if session_minute < 0:
        return _bar_key(dt)
    offset = session_minute % minutes
    start = dt - timedelta(minutes=offset, seconds=dt.second, microseconds=dt.microsecond)
    return start.strftime("%Y-%m-%d %H:%M")


def _open_segment(dt: datetime) -> int:
    """台指全時段逐筆版的區段：0=非交易時段、1=日盤、2=夜盤。"""
    hhmm = dt.hour * 100 + dt.minute
    if 845 <= hhmm < 1345:
        return 1
    if hhmm >= 1500 or hhmm < 500:
        return 2
    return 0


def _open20_active(dt: datetime) -> bool:
    """台指原指定開盤鎖利時段；僅影響獨立鎖利門檻，不限制逐筆洗價。"""
    sec = dt.hour * 3600 + dt.minute * 60 + dt.second
    return bool(
        8 * 3600 + 45 * 60 <= sec < 9 * 3600 + 15 * 60
        or 15 * 3600 <= sec < 16 * 3600
        or 21 * 3600 <= sec < 22 * 3600
    )


def _direction_reason(kind: str, direction: int) -> str:
    side = "多" if int(direction) > 0 else "空"
    if kind == "OpenWait":
        return "OP" + side
    if kind == "Cross":
        return "穿越" + side
    if kind == "FB":
        return "FB" + side
    if kind == "IntraFB":
        return "IFB" + side
    if kind == "Chip":
        return "籌碼" + side
    return str(kind or "")


def _display_reason(reason: str) -> str:
    text = str(reason or "")
    if not text:
        return ""
    parts = text.split("|")
    head = parts[0]
    mapping = {
        "TPHit": "停利平倉",
        "StopLoss": "停損平倉",
        "LockLossFlat": "認賠下車出場",
        "LockProfitFlat": "賺飽下車出場",
        "FloatProfitPullbackFloor": "浮盈回檔平倉",
        "ReverseFlatBeforeStopCheck": "本時段達標出場",
        "Chip_Exit": "籌碼平倉",
        "Chip_Long": "籌碼多",
        "Chip_Short": "籌碼空",
        "OpenWait": "OP",
        "OpenWait 多": "OP多",
        "OpenWait 空": "OP空",
        "Cross": "穿越",
        "Cross 多": "穿越多",
        "Cross 空": "穿越空",
        "FB": "FB",
        "FB 多": "FB多",
        "FB 空": "FB空",
        "IntraFB_L": "IFB多",
        "IntraFB_S": "IFB空",
        "實單買進": "外部下單",
        "實單賣出": "外部下單",
        "外部買進": "外部下單",
        "外部賣出": "外部下單",
        "停利出場": "停利平倉",
        "停損出場": "停損平倉",
        "浮盈回檔保底出場": "浮盈回檔平倉",
        "浮盈回檔出場": "浮盈回檔平倉",
        "一般鎖利出場": "賺飽下車出場",
        "累積鎖利出場": "賺飽下車出場",
        "累積鎖損出場": "認賠下車出場",
        "收盤強制平倉": "時間到強制出場",
        "收盤前禁入": "時間到強制出場",
    }
    mapped = mapping.get(head, head)
    if len(parts) <= 1:
        return mapped
    return "|".join([mapped] + parts[1:])


# 「出場」固定代表本時段交易結束並鎖車；「平倉」固定代表本筆結束後仍可繼續交易。
EXIT_LOCK_STATUSES = {
    "認賠下車出場",
    "賺飽下車出場",
    "開盤鎖利出場",
    "時間到強制出場",
}

LEGACY_FLAT_REASON_MAP = {
    "停利出場": "停利平倉",
    "停損出場": "停損平倉",
    "浮盈回檔保底出場": "浮盈回檔平倉",
    "浮盈回檔出場": "浮盈回檔平倉",
}

LEGACY_EXIT_REASON_MAP = {
    "一般鎖利出場": "賺飽下車出場",
    "累積鎖利出場": "賺飽下車出場",
    "鎖利停單": "賺飽下車出場",
    "累積鎖損出場": "認賠下車出場",
    "認賠停單": "認賠下車出場",
    "收盤前禁入": "時間到強制出場",
    "收盤強制平倉": "時間到強制出場",
}


def _canonical_flat_reason(reason: str) -> str:
    text = str(reason or "").strip()
    if not text:
        return ""
    for old, new in LEGACY_FLAT_REASON_MAP.items():
        if text.startswith(old):
            return new + text[len(old):]
    for old, new in LEGACY_EXIT_REASON_MAP.items():
        if text.startswith(old):
            return new + text[len(old):]
    return text


def _canonical_exit_status(status: str, *, realized_value: float = 0.0) -> str:
    text = str(status or "").strip()
    if not text:
        return ""
    for old, new in LEGACY_EXIT_REASON_MAP.items():
        if text.startswith(old):
            return new
    if text.startswith("本時段達標停單") or text.startswith("本時段停單") or text.startswith("本時段達標出場"):
        return "賺飽下車出場" if float(realized_value or 0.0) >= 0 else "認賠下車出場"
    return text if text in EXIT_LOCK_STATUSES else ""


def _is_true_second_bar(dt: datetime, first_bar: "Bar") -> bool:
    """OP 只認真正開盤第二根：日盤 08:46；夜盤 15:01。

    API 若盤中才啟動，不可把啟動後看到的第二根 K 棒誤當成 OP。
    第一根也必須分別是 08:45 或 15:00，才允許第二根 OP。
    """
    hhmm = dt.hour * 100 + dt.minute
    if hhmm == 846:
        return first_bar.key == dt.strftime("%Y-%m-%d 08:45")
    if hhmm == 1501:
        return first_bar.key == dt.strftime("%Y-%m-%d 15:00")
    return False


@dataclass(frozen=True)
class StrategyProfile:
    name: str
    kind: str  # TAI / STOCK_BIG / STOCK_SMALL / THREE_MA_TAI / THREE_MA_BIG / THREE_MA_SMALL
    stock_multiplier: int = 0
    gate_mode: int = 1
    pullback_trigger: float = 0.0
    pullback_floor: float = 0.0
    tai_max_profit: float = 0.0
    tai_open20_special: bool = False
    tai_open20_lock_profit: float = 0.0


PROFILES: Dict[str, StrategyProfile] = {
    "台指期策略": StrategyProfile(
        name="台指期策略",
        kind="TAI",
        tai_max_profit=0.0,
        tai_open20_special=True,
        tai_open20_lock_profit=400.0,
    ),
    "大股期策略": StrategyProfile(
        name="大股期策略",
        kind="STOCK_BIG",
        stock_multiplier=2000,
        gate_mode=1,
        # 050A：已停用股期「浮盈回檔平倉」；保留欄位供舊狀態相容，但預設不觸發。
        pullback_trigger=0.0,
        pullback_floor=0.0,
    ),
    "小股期策略": StrategyProfile(
        name="小股期策略",
        kind="STOCK_SMALL",
        stock_multiplier=100,
        gate_mode=1,
        # 050A：已停用股期「浮盈回檔平倉」；保留欄位供舊狀態相容，但預設不觸發。
        pullback_trigger=0.0,
        pullback_floor=0.0,
    ),
    "MA台指策略": StrategyProfile(
        name="MA策略",
        kind="THREE_MA_TAI",
        gate_mode=1,
    ),
    "MA大股期策略": StrategyProfile(
        name="MA策略",
        kind="THREE_MA_BIG",
        stock_multiplier=2000,
        gate_mode=1,
    ),
    "MA小股期策略": StrategyProfile(
        name="MA策略",
        kind="THREE_MA_SMALL",
        stock_multiplier=100,
        gate_mode=1,
    ),
}

# 舊版 tasks_v6.json 可能仍保存「一般股期策略」；只作載入相容，正式名稱固定為「大股期策略」。
PROFILES["一般股期策略"] = PROFILES["大股期策略"]
PROFILES["3" + "MA台指策略"] = PROFILES["MA台指策略"]
PROFILES["3" + "MA大股期策略"] = PROFILES["MA大股期策略"]
PROFILES["3" + "MA小股期策略"] = PROFILES["MA小股期策略"]


def _profile(task: Any) -> StrategyProfile:
    text = str(getattr(task, "strategy", "") or "").strip()
    code = str(getattr(task, "product_code", "") or getattr(task, "product_symbol", "") or "").strip().upper()
    name = str(getattr(task, "product_name", "") or "")
    combined = " ".join(x for x in (text, code, name) if x)
    if _is_ma_strategy_text(text):
        if code.startswith(("TXF", "MXF", "TMF")) or "台指" in combined:
            return PROFILES["MA台指策略"]
        if "小股" in combined or "小型" in combined:
            return PROFILES["MA小股期策略"]
        return PROFILES["MA大股期策略"]
    if text in PROFILES:
        return PROFILES[text]
    if "台指" in text:
        return PROFILES["台指期策略"]
    if "小股" in text:
        return PROFILES["小股期策略"]
    return PROFILES["大股期策略"]


def 計算單邊車票費(task: Any, price: Any) -> float:
    """依商品/策略與實際成交價計算單邊手續費。

    進場與平倉都必須用各自當下的成交價重新計算，不能再沿用任務表手動輸入值。
    車票費以新台幣元為單位四捨五入。
    """
    px = _f(price, 0.0)
    if px <= 0:
        return 0.0
    code = str(getattr(task, "product_code", "") or "").strip().upper()
    symbol = str(getattr(task, "product_symbol", "") or "").strip().upper()
    name = str(getattr(task, "product_name", "") or "")

    def code_is(prefix: str) -> bool:
        prefix = prefix.upper()
        return bool(code == prefix or symbol.startswith(prefix))

    def round_fee(value: float) -> float:
        # 車票費不保留小數；0.5 一律進位，避免 Python round 的銀行家捨入。
        return float(floor(max(0.0, value) + 0.5))

    if code_is("TXF") or "大台" in name:
        return round_fee(px * 200 * 0.00002 + 32)
    if code_is("MXF") or "小台" in name:
        return round_fee(px * 50 * 0.00002 + 18)
    if code_is("TMF") or "微台" in name:
        return round_fee(px * 10 * 0.00002 + 14)

    profile = _profile(task)
    if profile.kind in ("STOCK_SMALL", "THREE_MA_SMALL"):
        return round_fee(px * 100 * 0.00002 + 13)
    if profile.kind in ("STOCK_BIG", "THREE_MA_BIG"):
        return round_fee(px * 2000 * 0.00002 + 15)
    return 0.0


@dataclass
class Bar:
    key: str
    open: float
    high: float
    low: float
    close: float
    avg_close: float
    index: int

    def update(self, price: float, avg: float) -> None:
        price = float(price)
        self.high = max(float(self.high), price)
        self.low = min(float(self.low), price)
        self.close = price
        if float(avg or 0.0) > 0:
            self.avg_close = float(avg)


@dataclass
class Pending:
    kind: str             # Cross / FB / IntraFB / OpenWait
    direction: int
    gate: float
    source: str
    seq: int
    bar_index: int
    session_key: str


@dataclass
class ReEntryCandidate:
    kind: str             # Cross / FB / IntraFB / Chip
    direction: int
    seq: int
    bar_index: int
    session_key: str
    gate: float = 0.0
    from_chip: bool = False


@dataclass
class SimState:
    task_id: int

    # ------------------------------
    # 部位與損益帳本
    # ------------------------------
    position: int = 0
    avg_cost: float = 0.0
    realized_pnl: float = 0.0
    float_pnl: float = 0.0
    total_pnl: float = 0.0
    high_float_pnl: float = 0.0
    gross_realized_pnl: float = 0.0
    gross_float_pnl: float = 0.0
    gross_total_pnl: float = 0.0
    realized_points: float = 0.0
    gross_float_points: float = 0.0
    open_entry_fee: float = 0.0
    # FIFO 持倉批次：多口/分批成交時，平倉依先進先出配對成本。
    # 每筆格式：{"side": 1/-1, "qty": 口數, "price": 成交價, "fee": 進場手續費, "time": 進場時間}
    open_lots: List[Dict[str, Any]] = field(default_factory=list)
    total_fees_paid: float = 0.0
    entry_time: str = ""
    entry_reason: str = ""

    # 來源鎖存：只有明確由籌碼進場者才為 True；未知來源不可 fallback 成籌碼單。
    entry_from_chip: bool = False
    entry_arm_seq: int = 0
    hold_entry_from_chip: bool = False
    hold_entry_side: int = 0
    last_known_entry_from_chip: bool = False
    last_known_entry_side: int = 0
    last_known_entry_cost: float = 0.0

    # 券商同步瞬間洗 0 保護。
    zero_sync_pending_since: float = 0.0
    zero_sync_previous_position: int = 0
    zero_sync_previous_cost: float = 0.0
    zero_sync_grace_seconds: float = 3.0

    # 本次程式執行期間內，TradeCom DEAL_RPT 建立的精確成本。
    # 券商 P001616 彙總若回傳相同部位但成本不同，不可覆蓋真正成交價。
    # 此保護不跨程式重啟；重新開啟面板後仍以券商最新庫存為準。
    real_fill_exact_position: int = 0
    real_fill_exact_cost: float = 0.0
    real_fill_exact_guard_until: float = 0.0

    # ------------------------------
    # 時段與 K 棒
    # ------------------------------
    session_key: str = ""
    current_bar: Optional[Bar] = None
    bars: List[Bar] = field(default_factory=list)
    next_bar_index: int = 0
    session_bar_count: int = 0
    first_tick_seen: bool = False
    # 台指日盤／夜盤區段。0611 母版的 Cross / FB 全時段逐 Tick 重建，
    # 下列 tai_special_* 欄位只保留舊狀態相容，不再參與正式仲裁。
    open_segment: int = 0
    tai_special_cross_active_direction: int = 0
    tai_special_cross_active_bar_index: int = -1
    tai_special_fb_last_direction: int = 0
    tai_special_fb_last_bar_index: int = -1
    # 大股期／小股期 Cross / FB / IntraFB 全部逐 Tick 洗價。
    # 下列 stock_* 欄位僅保留舊狀態載入相容，不再參與正式仲裁。
    stock_cross_active_direction: int = 0
    stock_cross_active_bar_index: int = -1
    stock_fb_last_direction: int = 0
    stock_fb_last_bar_index: int = -1
    # v21：大小股期改為 Cross / FB / IntraFB 全部逐 Tick。
    # 載入舊狀態時，等取得 task 策略名稱後切斷舊 Pending，避免沿用舊世代。
    stock_xq0611_pending_migration_pending: bool = False
    # 新時段開始後，實單任務必須先取得券商庫存確認；確認後才允許策略自動送單。
    session_inventory_sync_pending: bool = False
    # 人工按下「重啟」後，實單任務也必須重新確認券商部位與成本。
    # 確認完成前禁止自動與手動送單，避免剛出場後沿用上一筆交易的舊成本。
    restart_inventory_sync_pending: bool = False
    restart_inventory_candidate_position: int = 0
    restart_inventory_candidate_cost: float = 0.0
    restart_inventory_candidate_count: int = 0
    restart_inventory_candidate_since: float = 0.0
    # 08:30／14:45 固定清空識別；同一個清空區間只執行一次。
    break_clear_key: str = ""

    # ------------------------------
    # ARM / FIRE / Pending
    # ------------------------------
    pending: List[Pending] = field(default_factory=list)
    arm_seq: int = 0
    last_fired_arm_seq: int = 0
    last_fired_bar_index: int = -1
    openwait_done: bool = False
    # XQ sessHadEntry：本時段只要曾經建立過部位，第二根 OP 就不得再次啟動。
    session_had_entry: bool = False
    intra_seen_above: bool = False
    intra_seen_below: bool = False
    intra_ref_high: float = 0.0
    intra_ref_low: float = 0.0
    need_new_signal: bool = True
    boot_allow_event: bool = True
    boot_wait_new_bar: bool = False
    # XQ Restart Init 的兩階段解鎖：重新執行後跨過兩次新 K，第二次才重新接受 fresh ARM。
    boot_unlock_bars_remaining: int = 0
    boot_ref_bar_index: int = -1
    boot_fresh_arm_base: int = 0
    boot_fresh_arm_ready: bool = True
    # 均線校正完成前仍允許建立 K 棒，但不可用未確認均線產生進場訊號。
    quote_avg_ready_seen: bool = False
    avg_entry_wait_bar_index: int = -1

    # 平倉完成同根的新世代放行。
    flat_just_done_bar_index: int = -1
    flat_just_done_base: int = 0
    reentry_block_bar_index: int = -1

    # ------------------------------
    # 舊籌碼相容欄位（0611 三策略純價格版不參與交易）
    # ------------------------------
    chip_arm_seq: int = 0
    chip_arm_bar_index: int = -1
    chip_arm_direction: int = 0
    chip_arm_text: str = ""
    chip_arm_session_key: str = ""
    chip_snapshots: List[Dict[str, float]] = field(default_factory=list)

    # ------------------------------
    # TP / SL / 累積風控
    # ------------------------------
    tp_armed: bool = False
    tp_peak: float = 0.0
    tp_line: float = 0.0
    tp_line_price: float = 0.0
    tp_flat_lock: bool = False
    tp_flat_arm_base: int = 0
    tp_reentry: Optional[ReEntryCandidate] = None
    sl_flat_lock: bool = False
    # 一般停損平倉鎖啟動前的 ARM 基準。只有鎖啟動後新建立、且真正 FIRE 的訊號，
    # 才可在平倉成交後補進；禁止沿用停損前留下的舊 Pending。
    sl_flat_arm_base: int = 0
    lock_profit_armed: bool = False
    lock_profit_high: float = 0.0
    lock_profit_mode: str = ""
    # 鎖利輪次基準：暫停後再執行時，畫面累積損益保留，但開盤鎖利與一般鎖利都從新一輪重新累積。
    lock_profit_cycle_base: float = 0.0
    # 認賠／賺飽下車後按「重啟」的規則。
    # restart_exit_kind = "loss"：上次是認賠下車；認賠門檻改看重啟後新增虧損，賺飽門檻仍看最終總損益。
    # restart_exit_kind = "profit"：上次是賺飽下車；賺飽門檻改看重啟後新增獲利，認賠門檻仍看最終總損益。
    restart_exit_kind: str = ""
    restart_exit_base: float = 0.0
    # 舊補丁相容欄位；正式判斷以 restart_exit_kind / restart_exit_base 為準。
    loss_exit_cycle_base: float = 0.0
    # 暫停時仍有持倉，必須等恢復後第一筆新行情再建立鎖利輪次基準，避免使用暫停前舊價格。
    lock_profit_reset_pending: bool = False
    # v11 前台指新倉曾把元誤寫入點數欄位；載入舊狀態後於下一次風控檢查轉正。
    lock_profit_units_migration_pending: bool = False
    # v13 前曾允許「暫停後再執行」把出場停單文字清掉；升級後只補做一次相容恢復。
    legacy_exit_lock_recovery_pending: bool = False
    session_blocked: bool = False
    session_stop_hit: bool = False
    risk_status: str = "正常"
    flat_reason: str = ""

    # ------------------------------
    # UI 與實單未成交接續
    # ------------------------------
    last_signal: str = "等待新訊號"
    signal_source: str = ""
    resume_reset_required: bool = False
    order_pending: bool = False
    pending_target: Optional[int] = None
    pending_reason: str = ""
    pending_source: str = ""
    pending_signal: str = ""
    pending_since: float = 0.0
    pending_entry_from_chip: bool = False
    pending_entry_arm_seq: int = 0
    # 券商/策略一致性：實單目標委託的進度。
    # pending_target 是策略想要的最終淨部位；下列欄位用來顯示與判斷
    # 多口 IOC 委託的部分成交、剩餘取消與續補/反手接續。
    pending_base_position: int = 0
    pending_requested_qty: int = 0
    pending_filled_qty: int = 0
    pending_retry_count: int = 0
    deferred_target: Optional[int] = None
    deferred_reason: str = ""
    deferred_source: str = ""
    deferred_signal: str = ""
    deferred_entry_from_chip: bool = False
    deferred_entry_arm_seq: int = 0
    deferred_retry_count: int = 0
    force_summary_sent: bool = False
    last_tick_iso: str = ""


class 策略模擬管理器:
    def __init__(
        self,
        logger: Optional[Callable[[str], None]] = None,
        record_callback: Optional[Callable[[dict], None]] = None,
        event_callback: Optional[Callable[[Any, str, str], None]] = None,
        real_target_callback: Optional[Callable[[Any, int, str, str, str], bool]] = None,
    ) -> None:
        self.logger = logger or (lambda _text: None)
        self.record_callback = record_callback or (lambda _rec: None)
        self.event_callback = event_callback or (lambda _task, _key, _detail: None)
        self.real_target_callback = real_target_callback
        self.real_mode = False
        self.states: Dict[int, SimState] = {}
        self.chip_metrics: Dict[str, Dict[str, float]] = {}
        self.chip_metrics_session_key: str = ""

    # ============================================================
    # 基礎狀態與持久化
    # ============================================================
    def set_real_mode(self, enabled: bool) -> None:
        # 保留舊測試與舊呼叫相容；正式面板由每個任務的 execution_mode 決定。
        self.real_mode = bool(enabled)

    def _task_real_mode(self, task: Any) -> bool:
        mode = str(getattr(task, "execution_mode", "") or "").strip().lower()
        if mode in ("real", "實單"):
            return True
        if mode in ("simulation", "sim", "模擬"):
            return False
        return bool(self.real_mode)

    def _emit_event(self, task: Any, event_key: str, detail: str = "") -> None:
        try:
            self.event_callback(task, event_key, detail)
        except Exception:
            pass

    def export_state(self) -> dict:
        return {
            "version": 30,
            "states": {str(k): asdict(v) for k, v in self.states.items()},
            "chip_metrics": self.chip_metrics,
        }

    @staticmethod
    def _load_bar(raw: Any) -> Optional[Bar]:
        if not isinstance(raw, dict):
            return None
        allowed = {f.name for f in fields(Bar)}
        try:
            return Bar(**{k: v for k, v in raw.items() if k in allowed})
        except Exception:
            return None

    @staticmethod
    def _load_pending(raw: Any) -> Optional[Pending]:
        if not isinstance(raw, dict):
            return None
        allowed = {f.name for f in fields(Pending)}
        try:
            return Pending(**{k: v for k, v in raw.items() if k in allowed})
        except Exception:
            return None

    @staticmethod
    def _load_reentry(raw: Any) -> Optional[ReEntryCandidate]:
        if not isinstance(raw, dict):
            return None
        allowed = {f.name for f in fields(ReEntryCandidate)}
        try:
            return ReEntryCandidate(**{k: v for k, v in raw.items() if k in allowed})
        except Exception:
            return None

    @staticmethod
    def _reset_tai_chip_runtime(st: SimState) -> None:
        """切斷不可跨重啟沿用的台指籌碼快照與籌碼 ARM。

        籌碼翻色必須只比較本次程式啟動後、同一套公式產生的連續快照。
        舊版執行狀態內可能仍保存舊公式計算出的成筆差；若直接與新公式比較，
        重啟後會把公式差異誤認成真實翻紅／翻綠。
        """
        st.chip_arm_seq = 0
        st.chip_arm_bar_index = -1
        st.chip_arm_direction = 0
        st.chip_arm_text = ""
        st.chip_arm_session_key = ""
        st.chip_snapshots.clear()
        if st.tp_reentry is not None and bool(getattr(st.tp_reentry, "from_chip", False)):
            st.tp_reentry = None
        if not st.pending:
            st.need_new_signal = True

    def import_state(self, payload: dict) -> None:
        if not isinstance(payload, dict):
            return
        loaded: Dict[int, SimState] = {}
        for raw_id, raw in (payload.get("states", {}) or {}).items():
            if not isinstance(raw, dict):
                continue
            try:
                data = dict(raw)
                data["current_bar"] = self._load_bar(data.get("current_bar"))
                data["bars"] = [b for b in (self._load_bar(x) for x in (data.get("bars", []) or [])) if b]
                data["pending"] = [p for p in (self._load_pending(x) for x in (data.get("pending", []) or [])) if p]
                data["tp_reentry"] = self._load_reentry(data.get("tp_reentry"))
                allowed = {f.name for f in fields(SimState)}
                state = SimState(**{k: v for k, v in data.items() if k in allowed})
                state_version = int(payload.get("version", 0) or 0)
                if state_version < 18:
                    # 舊狀態沒有 XQ sessHadEntry 對應欄位。只要仍有部位、已實現損益、
                    # 手續費或進場時間，就視為本時段曾經進場，避免第二根 OP 誤啟動。
                    state.session_had_entry = bool(
                        int(state.position or 0) != 0
                        or abs(float(state.gross_realized_pnl or 0.0)) > 1e-9
                        or abs(float(state.realized_points or 0.0)) > 1e-9
                        or abs(float(state.total_fees_paid or 0.0)) > 1e-9
                        or bool(str(state.entry_time or "").strip())
                    )
                if state_version < 19:
                    # 舊狀態沒有股期價格 ARM 防重欄位，載入後以全新基準重新觀察。
                    self._reset_stock_intrabar_price_runtime(state)
                if state_version < 21:
                    # v21 起股期 Cross / FB / IntraFB 全部改為逐 Tick 洗價。
                    # import_state 尚不知道每個 task 的策略名稱，延後至 _state(task)
                    # 第一次取得策略名稱時切斷舊世代 Pending，再由最新 Tick 重建。
                    state.stock_xq0611_pending_migration_pending = True
                if state_version < 23:
                    # v23 起禁止 TP / SL 平倉後沿用平倉前留下、尚未重新 FIRE 的舊候選。
                    # 舊狀態檔內若已有 tp_reentry，載入後必須直接切斷。
                    state.tp_reentry = None
                    if state.tp_flat_lock or state.sl_flat_lock:
                        state.pending.clear()
                        state.need_new_signal = True
                    state.sl_flat_arm_base = int(state.arm_seq or 0)
                if state_version < 4:
                    # 舊簡化版 Pending / 鎖狀態不可直接沿用；保留帳本與部位，切斷舊訊號。
                    state.pending.clear()
                    state.chip_snapshots.clear()
                    state.boot_wait_new_bar = state.current_bar is not None
                    state.boot_unlock_bars_remaining = 1 if state.current_bar is not None else 0
                    state.boot_allow_event = not state.boot_wait_new_bar
                    state.boot_fresh_arm_base = state.arm_seq
                    state.boot_fresh_arm_ready = not state.boot_wait_new_bar
                if state_version < 5:
                    # v5 起：TP 同根再進只接受「當根已 FIRE、但因同向持倉未重複下單」的訊號。
                    # 舊版把尚未 FIRE 的 Pending 也當候選，載入時必須切斷。
                    state.tp_reentry = None
                if state_version < 6:
                    # v6 起：尚未 FIRE 的 Pending 保留正常生命週期；只有已 FIRE 候選限制在平倉當根。
                    # 舊版候選語義不同，載入時切斷，避免跨版本誤補進場。
                    state.tp_reentry = None
                if state_version < 7:
                    # v7 起：同一套平倉當根 FIRE 規則同步套用 TP 與一般停損平倉鎖。
                    # 舊版候選不可直接沿用。
                    state.tp_reentry = None
                if state_version < 9 and state.session_blocked and str(state.flat_reason or "").startswith("跨時段"):
                    # 2026.06.09.007 曾把跨時段實單部位封鎖成待平倉。
                    # v9 起改為先查券商庫存，有倉視為外部留存並接回策略。
                    state.session_inventory_sync_pending = True
                    state.session_blocked = False
                    state.session_stop_hit = False
                    state.flat_reason = ""
                    state.risk_status = "等待券商庫存同步"
                    state.last_signal = "等待券商庫存同步"
                    state.signal_source = "券商庫存同步"
                    state.order_pending = False
                    state.pending_target = None
                    state.pending_reason = ""
                    state.pending_source = ""
                    state.pending_signal = ""
                    state.pending_since = 0.0
                    state.pending_entry_from_chip = False
                    state.pending_entry_arm_seq = 0
                    state.deferred_target = None
                    state.deferred_reason = ""
                    state.deferred_source = ""
                    state.deferred_signal = ""
                    state.deferred_entry_from_chip = False
                    state.deferred_entry_arm_seq = 0
                if state_version < 11:
                    # v10 以前台指新倉會將 gross_realized_pnl（元）誤寫入 lock_profit_high（點）。
                    # 先標記，待取得 task 策略型別與最新行情後再用正確單位轉正。
                    state.lock_profit_units_migration_pending = True
                if state_version < 13:
                    # 舊版曾在「暫停後再執行」時錯誤解除自動出場停單。
                    # 面板載入同時段交易紀錄後，只允許補做一次相容恢復。
                    state.legacy_exit_lock_recovery_pending = True
                if state_version < 16:
                    # v16 起嚴格區分「平倉」與「出場」：
                    # - 停利／停損只屬單筆平倉，不可鎖車。
                    # - 只有認賠下車、賺飽下車、開盤鎖利與時間到才屬本時段出場。
                    realized_value = float(state.realized_pnl or 0.0)
                    old_status = str(state.risk_status or "").strip()
                    old_reason = str(state.flat_reason or "").strip()
                    canonical_status = _canonical_exit_status(old_status, realized_value=realized_value)
                    if not canonical_status:
                        canonical_status = _canonical_exit_status(old_reason, realized_value=realized_value)
                    if state.session_blocked and canonical_status:
                        state.risk_status = canonical_status
                        state.flat_reason = canonical_status
                        state.last_signal = canonical_status
                        state.signal_source = "Risk"
                    elif state.session_blocked:
                        # .014～.017 曾把單筆停利／停損誤當成出場鎖車；升級後立即解除。
                        state.session_blocked = False
                        state.session_stop_hit = False
                        state.risk_status = _canonical_flat_reason(old_status or old_reason) or "正常"
                        state.flat_reason = _canonical_flat_reason(old_reason or old_status)
                        if state.last_signal in ("停利出場", "停損出場", "浮盈回檔保底出場"):
                            state.last_signal = state.flat_reason or "等待新訊號"
                    else:
                        state.risk_status = _canonical_flat_reason(old_status) or old_status or "正常"
                        state.flat_reason = _canonical_flat_reason(old_reason)
                if state.restart_inventory_sync_pending:
                    # 關閉面板後重新開啟時，不沿用關閉前已累積的確認次數。
                    # 必須重新收到本次程式執行期間的新庫存回覆後才可恢復送單。
                    state.restart_inventory_candidate_position = 0
                    state.restart_inventory_candidate_cost = 0.0
                    state.restart_inventory_candidate_count = 0
                    state.restart_inventory_candidate_since = 0.0
                    state.risk_status = "等待券商庫存同步"
                    state.last_signal = "等待券商庫存同步"
                    state.signal_source = "券商庫存同步"

                # DEAL_RPT 精確成本保護只限本次程式執行期間。面板重開後無法確認
                # 關閉期間是否曾由其他管道交易，因此必須重新以券商庫存校正。
                state.real_fill_exact_position = 0
                state.real_fill_exact_cost = 0.0
                state.real_fill_exact_guard_until = 0.0

                # 平倉後同根補進候選只屬於本次程式執行期間，不可跨面板重啟沿用。
                # 若重啟時仍處於 TP / SL 平倉鎖，舊 Pending 也必須切斷，改由新 Tick 重建。
                state.tp_reentry = None
                if state.tp_flat_lock or state.sl_flat_lock:
                    state.pending.clear()
                    state.need_new_signal = True
                    state.tp_flat_arm_base = int(state.arm_seq or 0)
                    state.sl_flat_arm_base = int(state.arm_seq or 0)

                # 台指籌碼快照不可跨程式重啟沿用。
                # 尤其成筆公式修正後，舊快照與新快照若直接比較，會產生假翻色。
                self._reset_tai_chip_runtime(state)
                # 特別區段防重狀態也不可跨程式重啟沿用。下一筆行情會重新判斷
                # 所在區段，並自動切斷不可跨區段的 FB / IntraFB；Cross 仍依母版保留。
                self._reset_tai_special_price_runtime(state, reset_segment=True)
                # 大股期／小股期舊版防重相容狀態不跨程式重啟沿用；Pending 仍依狀態檔保留。
                self._reset_stock_intrabar_price_runtime(state)
                loaded[int(raw_id)] = state
            except Exception as exc:
                self.logger(f"[STATE] 任務狀態載入失敗 task={raw_id}: {exc}")
        self.states = loaded

        # 籌碼即時值不從執行狀態檔恢復。
        # 重啟後必須等待 TXF / MXF 新行情重新建立基準，避免舊數值造成假翻色。
        self.chip_metrics = {}
        self.chip_metrics_session_key = ""

    def _state(self, task: Any) -> SimState:
        tid = int(getattr(task, "id", 0))
        if tid not in self.states:
            self.states[tid] = SimState(task_id=tid)
        st = self.states[tid]
        if st.stock_xq0611_pending_migration_pending:
            # v21 切換為股期 Cross / FB / IntraFB 全逐 Tick後，舊世代 Pending
            # 不可直接沿用。升級後先切斷，再由最新行情逐筆重建。
            if _profile(task).kind != "TAI":
                self._clear_pending(st)
                st.tp_reentry = None
                st.intra_seen_above = False
                st.intra_seen_below = False
                st.need_new_signal = True
                self._reset_stock_intrabar_price_runtime(st)
            st.stock_xq0611_pending_migration_pending = False
        return st


    def recover_simulation_position_from_record(self, task: Any, rec: dict, session_key: str = "") -> bool:
        """依交易紀錄修復模擬車號開倉狀態。

        用途：若執行狀態檔被重建／清空，但交易紀錄最後一筆仍顯示有未平倉部位，
        啟動時以交易紀錄把模擬倉位、成本與本時段已實現損益補回。
        不寫入新交易紀錄，避免多出假的平倉或進場。
        """
        if self._task_real_mode(task):
            return False
        if not isinstance(rec, dict):
            return False
        st = self._state(task)
        try:
            pos = int(float(rec.get("position_after", 0) or 0))
        except Exception:
            pos = 0
        if pos == 0:
            return False
        try:
            cost = float(rec.get("cost", rec.get("entry_price", rec.get("price", 0))) or 0.0)
        except Exception:
            cost = 0.0
        if cost <= 0:
            return False
        # 只有狀態檔空倉或與交易紀錄不一致時才修復；避免覆蓋正常持倉。
        if int(st.position or 0) == pos and abs(float(st.avg_cost or 0.0) - cost) <= 1e-9:
            return False

        realized_total = 0.0
        realized_points = 0.0
        try:
            realized_total = float(rec.get("total", 0.0) or 0.0)
        except Exception:
            realized_total = 0.0
        try:
            realized_points = float(rec.get("total_points", 0.0) or 0.0)
        except Exception:
            realized_points = 0.0
        try:
            open_fee = float(rec.get("fee", 0.0) or 0.0)
        except Exception:
            open_fee = 0.0

        st.session_key = str(session_key or rec.get("session_key", "") or st.session_key).strip()
        st.position = pos
        st.avg_cost = cost
        st.realized_pnl = realized_total
        st.gross_realized_pnl = 0.0
        st.realized_points = realized_points
        st.open_entry_fee = max(0.0, open_fee)
        st.total_fees_paid = max(float(st.total_fees_paid or 0.0), open_fee)
        st.entry_time = str(rec.get("entry_time", "") or rec.get("timestamp", "") or "")
        st.entry_reason = _display_reason(str(rec.get("reason", "") or ""))
        st.entry_from_chip = "籌碼" in str(rec.get("signal_source", "") or rec.get("reason", "") or "")
        st.entry_arm_seq = int(st.arm_seq or 0)
        st.hold_entry_from_chip = st.entry_from_chip
        st.hold_entry_side = 1 if pos > 0 else -1
        st.last_known_entry_from_chip = st.entry_from_chip
        st.last_known_entry_side = 1 if pos > 0 else -1
        st.last_known_entry_cost = cost
        st.session_had_entry = True
        st.flat_reason = ""
        st.session_blocked = False
        st.session_stop_hit = False
        st.risk_status = "正常"
        if not str(st.last_signal or "").strip():
            st.last_signal = "交易紀錄修復部位"
        if not str(st.signal_source or "").strip():
            st.signal_source = "交易紀錄"
        self._update_pnl(task, st, float(getattr(task, "last_price", 0.0) or 0.0))
        st.high_float_pnl = max(float(st.high_float_pnl or 0.0), float(st.float_pnl or 0.0), 0.0)
        self.sync_task(task)
        self.logger(f"[STATE][SIM_RECORD_REPAIR] task={st.task_id} position={st.position} cost={st.avg_cost} total={st.total_pnl}")
        return True

    def remove_task(self, task_id: int) -> None:
        self.states.pop(int(task_id), None)

    def prepare_session(self, task: Any, session_key: str) -> bool:
        """交易時段開始時建立新狀態；外部留存必須以券商庫存重新接入。"""
        key = str(session_key or "").strip()
        if not key:
            return False
        st = self._state(task)
        if st.session_key == key:
            return False
        self._reset_session(task, st, key)
        self.sync_task(task)
        return True

    def clear_for_break(self, task: Any, clear_key: str) -> bool:
        """於 08:30／14:45 清空上一時段全部資訊，等待下一時段重新同步。"""
        key = str(clear_key or "").strip()
        if not key:
            return False
        st = self._state(task)
        if st.break_clear_key == key and not st.session_key:
            return False
        self._clear_session_information(st)
        st.break_clear_key = key
        st.risk_status = "非交易時段"
        st.last_signal = ""
        st.signal_source = ""
        self.chip_metrics = {}
        self.chip_metrics_session_key = ""
        self.sync_task(task)
        return True

    @staticmethod
    def _clear_restart_inventory_confirmation(st: SimState) -> None:
        st.restart_inventory_sync_pending = False
        st.restart_inventory_candidate_position = 0
        st.restart_inventory_candidate_cost = 0.0
        st.restart_inventory_candidate_count = 0
        st.restart_inventory_candidate_since = 0.0

    @staticmethod
    def _clear_real_fill_exact_cost(st: SimState) -> None:
        st.real_fill_exact_position = 0
        st.real_fill_exact_cost = 0.0
        st.real_fill_exact_guard_until = 0.0

    @staticmethod
    def _remember_real_fill_exact_cost(st: SimState) -> None:
        """鎖存 TradeCom DEAL_RPT 寫入後的精確部位與成本。"""
        if int(st.position) != 0 and float(st.avg_cost or 0.0) > 0:
            st.real_fill_exact_position = int(st.position)
            st.real_fill_exact_cost = float(st.avg_cost)
            # DEAL_RPT 後數秒內可能仍收到成交前的 P001616 快照。
            st.real_fill_exact_guard_until = time.time() + 15.0
        else:
            策略模擬管理器._clear_real_fill_exact_cost(st)

    def _guard_real_fill_exact_cost(self, st: SimState, position: int, avg_cost: float) -> tuple[int, float, str]:
        """保留本機真實成交價，並短暫忽略 DEAL_RPT 後抵達的舊庫存快照。"""
        exact_position = int(st.real_fill_exact_position or 0)
        exact_cost = float(st.real_fill_exact_cost or 0.0)
        position = int(position or 0)
        avg_cost = float(avg_cost or 0.0)
        if exact_position == 0 or exact_cost <= 0:
            return position, avg_cost, ""
        if position == exact_position:
            if avg_cost > 0 and abs(avg_cost - exact_cost) > 1e-9:
                self.logger(
                    f"[SYNC] task={st.task_id} 保留真實成交成本｜券商彙總={avg_cost} DEAL_RPT={exact_cost}"
                )
            return exact_position, exact_cost, "same_position"
        if time.time() < float(st.real_fill_exact_guard_until or 0.0):
            self.logger(
                f"[SYNC] task={st.task_id} 忽略成交後暫時庫存快照｜"
                f"券商={position}@{avg_cost} DEAL_RPT={exact_position}@{exact_cost}"
            )
            return exact_position, exact_cost, "temporary_snapshot"
        self._clear_real_fill_exact_cost(st)
        return position, avg_cost, "released"

    @staticmethod
    def _reset_tai_special_price_runtime(st: SimState, *, reset_segment: bool = False) -> None:
        """清除台指特別時段逐筆 ARM 的防重狀態；Cross pending 是否保留由呼叫端決定。"""
        if reset_segment:
            st.open_segment = 0
        st.tai_special_cross_active_direction = 0
        st.tai_special_cross_active_bar_index = -1
        st.tai_special_fb_last_direction = 0
        st.tai_special_fb_last_bar_index = -1

    @staticmethod
    def _reset_stock_intrabar_price_runtime(st: SimState) -> None:
        """清除大股期／小股期舊版 Cross / FB 防重相容狀態。

        v21 正式流程為 Cross / FB / IntraFB 全逐 Tick；這些欄位只保留供舊狀態載入。
        Pending 本身是否清除仍由呼叫端決定。
        """
        st.stock_cross_active_direction = 0
        st.stock_cross_active_bar_index = -1
        st.stock_fb_last_direction = 0
        st.stock_fb_last_bar_index = -1

    def _sync_tai_open_segment(self, st: SimState, dt: datetime) -> None:
        """同步台指日／夜盤區段；FB / IntraFB 不可跨日夜盤，Cross 依 XQ 母版保留。"""
        segment = _open_segment(dt)
        if int(st.open_segment) == int(segment):
            return
        self._clear_pending(st, ["FB", "IntraFB"])
        st.intra_seen_above = False
        st.intra_seen_below = False
        st.intra_ref_high = 0.0
        st.intra_ref_low = 0.0
        if st.tp_reentry is not None and st.tp_reentry.kind in ("FB", "IntraFB"):
            st.tp_reentry = None
        self._reset_tai_special_price_runtime(st)
        st.open_segment = int(segment)
        if self._find_pending(st, "Cross") is None and self._find_pending(st, "OpenWait") is None:
            st.need_new_signal = True

    @staticmethod
    def _clear_stale_inventory_sync_for_simulation(st: SimState) -> None:
        """模擬任務不可沿用實單模式留下的券商庫存同步提示。"""
        st.session_inventory_sync_pending = False
        策略模擬管理器._clear_restart_inventory_confirmation(st)
        if st.risk_status == "等待券商庫存同步":
            st.risk_status = "正常"
        if st.last_signal == "等待券商庫存同步":
            st.last_signal = "等待新訊號"
        if st.signal_source == "券商庫存同步":
            st.signal_source = ""

    def inventory_sync_pending(self, task: Any) -> bool:
        """實單任務是否仍在等待券商部位與成本確認。"""
        st = self._state(task)
        if not self._task_real_mode(task):
            return False
        return bool(st.session_inventory_sync_pending or st.restart_inventory_sync_pending)

    def requires_restart(self, task: Any) -> bool:
        """自動出場後維持鎖定；只有使用者按下「重啟」才可解除。"""
        return bool(self._state(task).session_blocked)

    def restart_after_exit(self, task: Any) -> bool:
        """解除自動出場鎖定，但保留本時段損益與交易紀錄。

        只針對「認賠下車」與「賺飽下車」建立專屬重啟基準：
        - 認賠下車後重啟：認賠要再賠面板輸入值；賺飽仍看最終總損益。
        - 賺飽下車後重啟：賺飽要再賺面板輸入值；認賠仍看最終總損益。
        """
        st = self._state(task)
        if not st.session_blocked:
            return False
        if st.position != 0 or st.order_pending:
            return False
        restart_status = _canonical_exit_status(st.risk_status or st.flat_reason, realized_value=self._risk_total_value(task, st)) or _canonical_exit_status(st.flat_reason or st.risk_status, realized_value=self._risk_total_value(task, st))
        restart_base = self._risk_total_value(task, st)
        self._clear_pending(st)
        self._reset_tai_special_price_runtime(st)
        self._reset_stock_intrabar_price_runtime(st)
        self._reset_tai_chip_runtime(st)
        st.tp_reentry = None
        st.tp_flat_lock = False
        st.sl_flat_lock = False
        st.deferred_target = None
        st.deferred_reason = ""
        st.deferred_source = ""
        st.deferred_signal = ""
        st.deferred_entry_from_chip = False
        st.deferred_entry_arm_seq = 0
        st.deferred_retry_count = 0
        st.session_blocked = False
        st.session_stop_hit = False
        st.flat_reason = ""
        st.risk_status = "正常"
        st.last_signal = "等待新訊號"
        st.signal_source = ""
        st.force_summary_sent = False
        st.resume_reset_required = False
        # 已完成平倉後，上一筆交易成本不可在「重啟」後繼續留在畫面或風控帳本。
        # 損益累積保留，但空手成本與舊進場來源必須立即歸零；實單後續再以券商回覆校正。
        st.avg_cost = 0.0
        st.open_entry_fee = 0.0
        st.open_lots = []
        st.entry_time = ""
        st.entry_reason = ""
        st.entry_from_chip = False
        st.entry_arm_seq = 0
        st.hold_entry_from_chip = False
        st.hold_entry_side = 0
        st.last_known_entry_from_chip = False
        st.last_known_entry_side = 0
        st.last_known_entry_cost = 0.0
        st.zero_sync_pending_since = 0.0
        st.zero_sync_previous_position = 0
        st.zero_sync_previous_cost = 0.0
        self._clear_real_fill_exact_cost(st)
        self._reset_trade_tp(st)
        self._reset_lock_profit_cycle(task, st)
        self._set_restart_exit_rule(st, restart_status, restart_base)
        st.session_inventory_sync_pending = False
        self._clear_restart_inventory_confirmation(st)
        if self._task_real_mode(task):
            # 實單重啟不可立即恢復送單。必須先等 TradeCom 回覆目前真實部位與成本，
            # 避免剛平倉後手動或自動進場沿用上一筆交易的舊成本。
            st.restart_inventory_sync_pending = True
            st.risk_status = "等待券商庫存同步"
            st.last_signal = "等待券商庫存同步"
            st.signal_source = "券商庫存同步"
        self.sync_task(task)
        return True

    def recover_legacy_exit_lock(self, task: Any, risk_status: str, flat_reason: str = "") -> bool:
        """升級相容：把舊版誤清掉的自動出場停單恢復一次。"""
        st = self._state(task)
        if not st.legacy_exit_lock_recovery_pending:
            return False
        st.legacy_exit_lock_recovery_pending = False
        realized_value = float(st.realized_pnl)
        status = _canonical_exit_status(risk_status, realized_value=realized_value)
        reason = _canonical_flat_reason(flat_reason or status)
        if st.session_blocked:
            existing = _canonical_exit_status(st.risk_status or st.flat_reason, realized_value=realized_value)
            if existing:
                st.risk_status = existing
                st.flat_reason = existing
            self.sync_task(task)
            return bool(existing)
        if not status or st.position != 0 or st.order_pending:
            self.sync_task(task)
            return False
        st.session_inventory_sync_pending = False
        st.session_blocked = True
        st.session_stop_hit = status in ("認賠下車出場", "賺飽下車出場")
        st.risk_status = status
        st.flat_reason = reason or status
        st.last_signal = st.flat_reason
        st.signal_source = "Risk"
        self.sync_task(task)
        return True

    def activate_task(self, task: Any) -> None:
        st = self._state(task)
        real_task = self._task_real_mode(task)
        if not real_task:
            self._clear_stale_inventory_sync_for_simulation(st)
        if st.resume_reset_required:
            blocked = bool(st.session_blocked)
            blocked_status = str(st.risk_status or "").strip()
            blocked_reason = str(st.flat_reason or "").strip()
            self._clear_pending(st)
            st.intra_seen_above = False
            st.intra_seen_below = False
            st.resume_reset_required = False
            st.tp_flat_lock = False
            st.sl_flat_lock = False
            st.tp_reentry = None
            if blocked:
                # 暫停後再執行不可繞過自動出場停單；必須按「重啟」。
                st.session_blocked = True
                st.risk_status = blocked_status if blocked_status and blocked_status != "正常" else (blocked_reason or "本時段禁入")
                st.flat_reason = blocked_reason or st.risk_status
            else:
                st.session_stop_hit = False
                st.flat_reason = ""
                st.risk_status = "正常"
                # 一般暫停後恢復：損益保留，鎖利輪次重新累積。
                self._reset_lock_profit_cycle(task, st, defer_if_holding=True)
                self._reset_trade_tp(st)
        # 重新啟動不可吃停用前舊 ARM。
        # 實單盤中啟動時，即使目前尚未建立 current_bar，也必須先等啟動後的新 K，
        # 避免把啟動前已存在的穿越／FB 訊號拿來立即下單。
        if real_task:
            st.session_inventory_sync_pending = True
            st.risk_status = "等待券商庫存同步"
            st.last_signal = "等待券商庫存同步"
            st.signal_source = "券商庫存同步"
            st.boot_wait_new_bar = True
            st.boot_unlock_bars_remaining = 1 if st.current_bar is not None else 2
            st.boot_allow_event = False
        else:
            st.boot_wait_new_bar = st.current_bar is not None
            st.boot_unlock_bars_remaining = 1 if st.current_bar is not None else 0
            st.boot_allow_event = not st.boot_wait_new_bar
        st.boot_ref_bar_index = st.current_bar.index if st.current_bar else -1
        st.boot_fresh_arm_base = st.arm_seq
        st.boot_fresh_arm_ready = bool(st.boot_allow_event)
        st.quote_avg_ready_seen = False
        st.avg_entry_wait_bar_index = -1
        self._clear_pending(st)
        self._reset_tai_special_price_runtime(st)
        self._reset_stock_intrabar_price_runtime(st)
        # 暫停後恢復執行也不可沿用暫停前的籌碼 ARM 或快照。
        self._reset_tai_chip_runtime(st)
        if st.session_blocked:
            st.last_signal = st.flat_reason or st.risk_status
            st.signal_source = "Risk"
        else:
            st.last_signal = "等待行情"
            st.signal_source = ""
        self.sync_task(task)

    def pause_task(self, task: Any) -> None:
        st = self._state(task)
        st.resume_reset_required = True
        st.last_signal = ""
        self.sync_task(task)

    def sync_task(self, task: Any) -> None:
        st = self._state(task)
        if not self._task_real_mode(task):
            self._clear_stale_inventory_sync_for_simulation(st)
        task.position = int(st.position)
        task.avg_cost = float(st.avg_cost)
        task.float_pnl = float(st.float_pnl)
        task.realized_pnl = float(st.realized_pnl)
        task.total_pnl = float(st.total_pnl)
        task.high_float_pnl = float(st.high_float_pnl)
        task.entry_reason = st.entry_reason
        task.last_signal = st.last_signal
        task.signal_source = st.signal_source
        task.flat_reason = st.flat_reason
        task.risk_status = st.risk_status
        if hasattr(task, "lock_profit_armed"):
            task.lock_profit_armed = bool(st.lock_profit_armed)
        if hasattr(task, "lock_profit_high"):
            task.lock_profit_high = float(st.lock_profit_high)
        if hasattr(task, "order_pending"):
            task.order_pending = bool(st.order_pending)

    # ============================================================
    # 損益帳本與成交同步
    # ============================================================
    def _multiplier(self, task: Any) -> int:
        profile = _profile(task)
        code = str(getattr(task, "product_code", "") or "").strip().upper()
        symbol = str(getattr(task, "product_symbol", "") or "").strip().upper()
        name = str(getattr(task, "product_name", "") or "")

        def code_is(prefix: str) -> bool:
            prefix = prefix.upper()
            return bool(code == prefix or symbol.startswith(prefix))

        # 056D：風控輸入全部是商品自己的點數；損益與車票費仍以商品乘數換算為新臺幣。
        # 先依商品本身判斷台指類，避免把 TXF/MXF/TMF 在非台指策略下誤當股期乘數。
        if code_is("TXF") or "大台" in name:
            return 200
        if code_is("MXF") or "小台" in name:
            return 50
        if code_is("TMF") or "微台" in name:
            return 10
        if "小型" in name or "小股" in name:
            return 100
        if profile.stock_multiplier:
            return int(profile.stock_multiplier)
        return 1

    def _one_way_fee(self, task: Any, price: Any = None) -> float:
        # 回測版：若面板有輸入單邊手續費，優先使用面板值；未輸入才用商品公式自動估算。
        manual = max(0.0, _f(getattr(task, "one_way_fee", 0.0), 0.0))
        if manual > 0:
            return float(manual)
        auto = 計算單邊車票費(task, price) if price is not None else 0.0
        if auto > 0:
            return float(auto)
        return 0.0

    @staticmethod
    def _gross_points(position: int, entry_price: float, exit_price: float) -> float:
        if position > 0:
            return float(exit_price) - float(entry_price)
        if position < 0:
            return float(entry_price) - float(exit_price)
        return 0.0

    def _update_pnl(self, task: Any, st: SimState, price: float) -> None:
        price = float(price or 0.0)
        qty = abs(int(st.position))
        if st.position and price > 0:
            points = self._gross_points(st.position, st.avg_cost, price)
            st.gross_float_points = points * qty
            st.gross_float_pnl = st.gross_float_points * self._multiplier(task)
        else:
            st.gross_float_points = 0.0
            st.gross_float_pnl = 0.0
        estimated_exit_fee = self._one_way_fee(task, price) * qty
        st.float_pnl = st.gross_float_pnl - st.open_entry_fee - estimated_exit_fee if st.position else 0.0
        st.gross_total_pnl = st.gross_realized_pnl + st.gross_float_pnl
        st.total_pnl = st.realized_pnl + st.float_pnl
        st.high_float_pnl = max(float(st.high_float_pnl), float(st.float_pnl))

    def _record(
        self,
        task: Any,
        event: str,
        direction: str,
        qty: int,
        price: float,
        reason: str,
        *,
        realized: float = 0.0,
        gross_realized: float = 0.0,
        fee: float = 0.0,
        points: Any = "",
        realized_points: Any = "",
        total_points: Any = "",
        net_realized_points: Any = "",
        net_total_points: Any = "",
        entry_price: Any = "",
        entry_time: str = "",
        exit_time: str = "",
        closed_trade: bool = False,
    ) -> None:
        st = self._state(task)
        now_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.record_callback({
            "timestamp": now_text,
            "date": now_text[:10],
            "time": now_text[11:],
            "task_id": int(getattr(task, "id", 0)),
            "session_key": str(st.session_key or ""),
            "account": str(getattr(task, "account", "")),
            "strategy": str(getattr(task, "strategy", "")),
            "execution_mode": "real" if self._task_real_mode(task) else "simulation",
            "mode": "實單" if self._task_real_mode(task) else "模擬",
            "product": str(getattr(task, "product_name", "")),
            "symbol": str(getattr(task, "product_symbol", "")),
            "event": event,
            "direction": direction,
            "qty": int(qty),
            "price": float(price),
            "entry_time": entry_time,
            "entry_price": entry_price,
            "exit_time": exit_time,
            "exit_price": float(price) if closed_trade else "",
            "points": points,
            "realized_points": realized_points,
            "total_points": total_points,
            "net_realized_points": net_realized_points,
            "net_total_points": net_total_points,
            "gross_realized": float(gross_realized),
            "fee": float(fee),
            "realized": float(realized),
            "total": float(st.realized_pnl),
            "cost": float(st.avg_cost),
            "flat": float(price) if closed_trade else "",
            "avg": float(getattr(task, "quote_avg", 0.0) or 0.0),
            "reason": _display_reason(reason),
            "signal_source": str(st.signal_source or getattr(task, "signal_source", "")),
            "closed_trade": bool(closed_trade),
            "position_before": int(st.position),
            "position_after": (
                (1 if int(st.position) > 0 else -1) * max(0, abs(int(st.position)) - abs(int(qty)))
                if closed_trade and int(st.position) != 0
                else int(st.position)
            ),
        })

    def _reset_trade_tp(self, st: SimState) -> None:
        st.tp_armed = False
        st.tp_peak = 0.0
        st.tp_line = 0.0
        st.tp_line_price = 0.0
        st.high_float_pnl = 0.0

    def _mark_strategy_exit_lock(self, st: SimState, risk_status: str, flat_reason: str = "") -> None:
        """本時段出場成立後鎖住車號，等待使用者按下「重啟」。"""
        status = _canonical_exit_status(risk_status) or str(risk_status or "本時段達標出場").strip() or "本時段達標出場"
        reason = _canonical_flat_reason(flat_reason or status) or status
        st.session_blocked = True
        st.risk_status = status
        st.flat_reason = reason
        self._clear_pending(st)
        st.tp_reentry = None
        st.tp_flat_lock = False
        st.sl_flat_lock = False
        st.deferred_target = None
        st.deferred_reason = ""
        st.deferred_source = ""
        st.deferred_signal = ""
        st.deferred_entry_from_chip = False
        st.deferred_entry_arm_seq = 0
        st.deferred_retry_count = 0
        st.need_new_signal = True

    def _lock_profit_realized_value(self, task: Any, st: SimState) -> float:
        """回傳認賠/賺飽使用的已實現淨損益：新台幣，已扣手續費。"""
        return float(st.realized_pnl)

    def _lock_profit_cycle_value(self, task: Any, st: SimState, raw_total: Optional[float] = None) -> float:
        """回傳舊版鎖利輪次損益；新重啟規則另由 _profit_exit_track_value 決定。"""
        if raw_total is None:
            raw_total = self._risk_total_value(task, st)
        return float(raw_total) - float(st.lock_profit_cycle_base)

    @staticmethod
    def _set_restart_exit_rule(st: SimState, status: str, base: float) -> None:
        """按下重啟時，依上一次下車種類建立門檻基準。"""
        if status == "認賠下車出場":
            st.restart_exit_kind = "loss"
            st.restart_exit_base = float(base)
            st.loss_exit_cycle_base = float(base)
            # 認賠下車後重啟：賺飽仍看最終總損益，所以鎖利追蹤基準歸 0。
            st.lock_profit_cycle_base = 0.0
        elif status == "賺飽下車出場":
            st.restart_exit_kind = "profit"
            st.restart_exit_base = float(base)
            st.loss_exit_cycle_base = 0.0
            # 賺飽下車後重啟：下一次賺飽要看重啟後又賺多少。
            st.lock_profit_cycle_base = float(base)
        else:
            st.restart_exit_kind = ""
            st.restart_exit_base = 0.0
            st.loss_exit_cycle_base = 0.0

    @staticmethod
    def _clear_restart_exit_rule(st: SimState) -> None:
        st.restart_exit_kind = ""
        st.restart_exit_base = 0.0
        st.loss_exit_cycle_base = 0.0

    def _loss_exit_cycle_value(self, task: Any, st: SimState, raw_total: Optional[float] = None) -> float:
        """認賠判斷值：只有認賠下車後重啟，才改看重啟後新增損益。"""
        if raw_total is None:
            raw_total = self._risk_total_value(task, st)
        if str(st.restart_exit_kind or "") == "loss":
            return float(raw_total) - float(st.restart_exit_base)
        return float(raw_total)

    def _profit_exit_track_value(self, task: Any, st: SimState, raw_total: Optional[float] = None) -> float:
        """賺飽追蹤值：賺飽重啟看新增獲利；認賠重啟看最終總損益；其餘沿用鎖利輪次。"""
        if raw_total is None:
            raw_total = self._risk_total_value(task, st)
        kind = str(st.restart_exit_kind or "")
        if kind == "profit":
            return float(raw_total) - float(st.restart_exit_base)
        if kind == "loss":
            return float(raw_total)
        return float(raw_total) - float(st.lock_profit_cycle_base)

    def _restart_base_text(self, st: SimState, unit: str, current_value: float) -> str:
        kind = str(st.restart_exit_kind or "")
        if kind not in ("loss", "profit"):
            return ""
        label = "重啟後損益" if kind == "loss" else "重啟後新增獲利"
        return f"\n重啟基準：{float(st.restart_exit_base):.0f} {unit}\n{label}：{float(current_value):.0f} {unit}"

    def _reset_lock_profit_cycle(self, task: Any, st: SimState, *, defer_if_holding: bool = False) -> None:
        """重設開盤鎖利與一般鎖利輪次，不清除畫面損益帳本。"""
        st.lock_profit_armed = False
        st.lock_profit_high = 0.0
        st.lock_profit_mode = ""
        st.lock_profit_units_migration_pending = False
        if defer_if_holding and st.position != 0:
            st.lock_profit_reset_pending = True
            return
        st.lock_profit_cycle_base = self._risk_total_value(task, st)
        st.lock_profit_reset_pending = False

    def _normalize_legacy_lock_profit_units(self, task: Any, st: SimState, raw_total: Optional[float] = None) -> None:
        """修正 v10 以前台指 lock_profit_high 可能混入元而非點的舊狀態。"""
        if not st.lock_profit_units_migration_pending:
            return
        st.lock_profit_units_migration_pending = False
        profile = _profile(task)
        if profile.kind != "TAI":
            return
        if raw_total is None:
            raw_total = self._risk_total_value(task, st)
        high = float(st.lock_profit_high)
        gross_realized = float(st.gross_realized_pnl)
        realized_points = float(st.realized_points)
        plausible_max = max(
            abs(float(profile.tai_max_profit)),
            abs(float(profile.tai_open20_lock_profit)),
            abs(_f(getattr(task, "lock_profit_exit", 0.0), 0.0)),
        )
        looks_like_money = bool(
            abs(high - gross_realized) < 1e-9
            and abs(gross_realized - realized_points) > 1e-9
        )
        if high <= plausible_max and not looks_like_money:
            # 舊狀態本身仍是合理點數，不破壞原本已啟動的追蹤狀態。
            return
        st.lock_profit_cycle_base = 0.0
        st.lock_profit_reset_pending = False
        st.lock_profit_armed = False
        st.lock_profit_mode = ""
        st.lock_profit_high = max(0.0, float(raw_total))

    def _reset_new_entry_risk_state(self, task: Any, st: SimState) -> None:
        """新倉成立時切斷上一筆交易的風控狀態。

        實單成交與券商庫存同步可能在極短時間內交錯回來；若上一筆交易留下
        tp_armed / tp_line_price / lock_profit_armed / lock_profit_high，新倉會被誤判
        已經達到停利或鎖利門檻，造成剛進場就被平倉。
        """
        self._reset_trade_tp(st)
        st.tp_flat_lock = False
        st.sl_flat_lock = False
        st.tp_reentry = None
        self._normalize_legacy_lock_profit_units(task, st, self._lock_profit_realized_value(task, st))
        if st.lock_profit_reset_pending:
            # 新倉建立時浮盈為 0，可直接用已實現值建立本輪基準。
            st.lock_profit_cycle_base = self._lock_profit_realized_value(task, st)
            st.lock_profit_reset_pending = False
        st.lock_profit_armed = False
        st.lock_profit_mode = ""
        # 依最新重啟規則決定賺飽下車追蹤值：認賠重啟看最終總損益；賺飽重啟看新增獲利。
        st.lock_profit_high = max(0.0, self._profit_exit_track_value(task, st, self._lock_profit_realized_value(task, st)))
        st.flat_just_done_bar_index = -1
        st.flat_just_done_base = st.arm_seq

    def _after_close_threshold_check(self, task: Any, st: SimState, reason: str = "") -> None:
        profile = _profile(task)
        if str(reason or "").startswith("手動"):
            return
        total = float(st.realized_pnl)
        max_loss = abs(_f(getattr(task, "loss_exit", 0.0), 0.0))
        max_profit = abs(float(profile.tai_max_profit)) if profile.kind == "TAI" else 0.0
        status = ""
        event_key = ""
        loss_check_value = self._loss_exit_cycle_value(task, st, total)
        profit_check_value = self._profit_exit_track_value(task, st, total)
        if max_loss > 0 and loss_check_value <= -max_loss:
            status = "認賠下車出場"
            event_key = "loss_exit"
        elif max_profit > 0 and profit_check_value >= max_profit:
            status = "賺飽下車出場"
            event_key = "profit_exit"
        if not status:
            return
        st.session_stop_hit = True
        # 若原本已由更具體的出場機制鎖住，例如「開盤鎖利出場」，不可覆蓋文字。
        if not st.session_blocked or not str(st.risk_status or "").strip() or st.risk_status == "正常":
            self._mark_strategy_exit_lock(st, status, status)
            unit = "元"
            if event_key == "loss_exit":
                base_text = self._restart_base_text(st, unit, loss_check_value) if str(st.restart_exit_kind or "") == "loss" else ""
                reason_text = "重啟後新增虧損已達認賠下車門檻" if str(st.restart_exit_kind or "") == "loss" else "累積損益已達認賠下車門檻"
                detail = f"總損益：{total:.0f} {unit}{base_text}\n原因：{reason_text}"
            else:
                base_text = self._restart_base_text(st, unit, profit_check_value) if str(st.restart_exit_kind or "") == "profit" else ""
                reason_text = "重啟後新增獲利已達賺飽下車門檻" if str(st.restart_exit_kind or "") == "profit" else "累積獲利已達賺飽下車門檻"
                detail = f"總損益：{total:.0f} {unit}{base_text}\n原因：{reason_text}"
            self._emit_event(task, event_key, detail)
        else:
            st.session_blocked = True

    def _ensure_fifo_lots(self, st: SimState) -> None:
        """確保舊狀態或異常載入時也有 FIFO 欄位。"""
        if not hasattr(st, "open_lots") or st.open_lots is None:
            st.open_lots = []

    def _rebuild_fifo_lot_from_avg(self, task: Any, st: SimState) -> None:
        """券商庫存只剩彙總成本時，建立單一 FIFO 批次供後續平倉配對。"""
        self._ensure_fifo_lots(st)

        position = int(st.position or 0)
        if position == 0:
            st.open_lots = []
            st.open_entry_fee = 0.0
            return

        if float(st.avg_cost or 0.0) <= 0:
            st.open_lots = []
            st.open_entry_fee = 0.0
            return

        if st.open_lots:
            total_qty = sum(abs(_i(lot.get("qty", 0))) for lot in st.open_lots)
            expected_side = 1 if position > 0 else -1
            same_side = all(
                int(lot.get("side", 0) or 0) == expected_side
                for lot in st.open_lots
                if abs(_i(lot.get("qty", 0))) > 0
            )
            fifo_avg = self._fifo_avg_cost(st)
            if (
                total_qty == abs(position)
                and same_side
                and abs(float(fifo_avg or 0.0) - float(st.avg_cost or 0.0)) <= 1e-6
            ):
                return

        st.open_lots = [{
            "side": 1 if position > 0 else -1,
            "qty": abs(position),
            "price": float(st.avg_cost or 0.0),
            "fee": float(st.open_entry_fee or 0.0),
            "time": st.entry_time or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }]

    def _fifo_avg_cost(self, st: SimState) -> float:
        self._ensure_fifo_lots(st)
        total_qty = sum(abs(_i(lot.get("qty", 0))) for lot in st.open_lots)
        if total_qty <= 0:
            return 0.0
        return sum(
            abs(_i(lot.get("qty", 0))) * float(lot.get("price", 0.0) or 0.0)
            for lot in st.open_lots
        ) / total_qty

    def _close_qty(self, task: Any, st: SimState, qty: int, price: float, event: str, reason: str) -> None:
        qty = min(abs(int(qty)), abs(int(st.position)))
        if qty <= 0 or st.position == 0:
            return
        self._ensure_fifo_lots(st)
        old_pos = int(st.position)
        old_abs = abs(old_pos)
        if not st.open_lots:
            self._rebuild_fifo_lot_from_avg(task, st)
        remaining_to_close = qty
        total_gross = 0.0
        total_points = 0.0
        total_allocated_entry_fee = 0.0
        entry_prices: List[float] = []
        entry_times: List[str] = []
        while remaining_to_close > 0 and st.open_lots:
            lot = st.open_lots[0]
            lot_qty = abs(_i(lot.get("qty", 0)))
            if lot_qty <= 0:
                st.open_lots.pop(0)
                continue
            close_qty = min(lot_qty, remaining_to_close)
            lot_price = float(lot.get("price", st.avg_cost) or 0.0)
            lot_fee = float(lot.get("fee", 0.0) or 0.0)
            lot_time = str(lot.get("time", st.entry_time) or st.entry_time)
            points_each_lot = self._gross_points(old_pos, lot_price, price)
            total_points += points_each_lot * close_qty
            total_gross += points_each_lot * close_qty * self._multiplier(task)
            total_allocated_entry_fee += lot_fee * close_qty / lot_qty if lot_qty else 0.0
            entry_prices.extend([lot_price] * close_qty)
            if lot_time:
                entry_times.append(lot_time)
            lot_qty_after = lot_qty - close_qty
            remaining_to_close -= close_qty
            if lot_qty_after <= 0:
                st.open_lots.pop(0)
            else:
                lot["qty"] = lot_qty_after
                lot["fee"] = max(0.0, lot_fee - (lot_fee * close_qty / lot_qty if lot_qty else 0.0))
        if remaining_to_close > 0:
            fallback_price = float(st.avg_cost or 0.0)
            close_qty = remaining_to_close
            points_each_lot = self._gross_points(old_pos, fallback_price, price)
            total_points += points_each_lot * close_qty
            total_gross += points_each_lot * close_qty * self._multiplier(task)
            total_allocated_entry_fee += st.open_entry_fee * close_qty / old_abs if old_abs else 0.0
            entry_prices.extend([fallback_price] * close_qty)
            remaining_to_close = 0
        exit_fee = self._one_way_fee(task, price) * qty
        fee = total_allocated_entry_fee + exit_fee
        net = total_gross - fee
        net_points_total = net / max(self._multiplier(task), 1)
        avg_entry = sum(entry_prices) / len(entry_prices) if entry_prices else float(st.avg_cost or 0.0)
        old_time = entry_times[0] if entry_times else st.entry_time
        points_each = total_points / qty if qty else 0.0
        st.gross_realized_pnl += total_gross
        st.realized_points += total_points
        st.realized_pnl += net
        st.total_fees_paid += exit_fee
        st.open_entry_fee = max(0.0, st.open_entry_fee - total_allocated_entry_fee)
        self._after_close_threshold_check(task, st, reason)
        self._record(
            task, event, "賣" if old_pos > 0 else "買", qty, price, reason,
            realized=net, gross_realized=total_gross, fee=fee, points=points_each,
            realized_points=total_points, total_points=st.realized_points,
            net_realized_points=net_points_total, net_total_points=st.realized_pnl / max(self._multiplier(task), 1),
            entry_price=avg_entry, entry_time=old_time,
            exit_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"), closed_trade=True,
        )
        remain = old_abs - qty
        if remain <= 0:
            st.position = 0
            st.avg_cost = 0.0
            st.open_entry_fee = 0.0
            st.open_lots = []
            st.entry_time = ""
            st.entry_from_chip = False
            st.entry_arm_seq = 0
            self._reset_trade_tp(st)
        else:
            st.position = remain if old_pos > 0 else -remain
            st.avg_cost = self._fifo_avg_cost(st)

    def _open_qty(
        self,
        task: Any,
        st: SimState,
        direction: int,
        qty: int,
        price: float,
        reason: str,
        *,
        from_chip: bool,
        arm_seq: int,
    ) -> None:
        qty = abs(int(qty))
        if qty <= 0 or direction == 0:
            return
        self._ensure_fifo_lots(st)
        fee = self._one_way_fee(task, price) * qty
        now_text = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if st.position == 0:
            # 新倉建立後，前一筆同根再進候選已完成其用途，不可重複使用。
            st.tp_reentry = None
            st.position = qty if direction > 0 else -qty
            st.session_had_entry = True
            st.avg_cost = float(price)
            st.open_entry_fee = fee
            st.open_lots = [{"side": 1 if direction > 0 else -1, "qty": qty, "price": float(price), "fee": fee, "time": now_text}]
            st.total_fees_paid += fee
            st.entry_time = now_text
            st.entry_reason = reason
            st.entry_from_chip = bool(from_chip)
            st.entry_arm_seq = int(arm_seq or 0)
            st.hold_entry_from_chip = bool(from_chip)
            st.hold_entry_side = 1 if direction > 0 else -1
            st.last_known_entry_from_chip = bool(from_chip)
            st.last_known_entry_side = st.hold_entry_side
            st.last_known_entry_cost = float(price)
            st.flat_reason = ""
            if not st.session_blocked:
                st.risk_status = "正常"
            self._reset_new_entry_risk_state(task, st)
            self._record(task, "進場", "買" if direction > 0 else "賣", qty, price, reason, fee=fee, entry_price=price, entry_time=now_text)
            return
        if st.position * direction <= 0:
            raise RuntimeError("反向建倉前必須先平倉")
        old_abs = abs(int(st.position))
        new_abs = old_abs + qty
        st.avg_cost = (old_abs * st.avg_cost + qty * float(price)) / max(new_abs, 1)
        st.position = new_abs if direction > 0 else -new_abs
        st.open_entry_fee += fee
        st.open_lots.append({"side": 1 if direction > 0 else -1, "qty": qty, "price": float(price), "fee": fee, "time": now_text})
        st.total_fees_paid += fee
        # 混合來源加碼不可視為純籌碼單。
        st.entry_from_chip = bool(st.entry_from_chip and from_chip)
        st.entry_arm_seq = max(int(st.entry_arm_seq), int(arm_seq or 0))
        st.hold_entry_from_chip = st.entry_from_chip
        st.hold_entry_side = 1 if st.position > 0 else -1
        st.last_known_entry_from_chip = st.entry_from_chip
        st.last_known_entry_side = st.hold_entry_side
        st.last_known_entry_cost = st.avg_cost
        self._record(task, "加碼", "買" if direction > 0 else "賣", qty, price, reason, fee=fee, entry_price=price, entry_time=now_text)

    @staticmethod
    def _clear_order_intent_fields(st: SimState, *, clear_order_pending: bool = True) -> None:
        if clear_order_pending:
            st.order_pending = False
        st.pending_target = None
        st.pending_reason = ""
        st.pending_source = ""
        st.pending_signal = ""
        st.pending_since = 0.0
        st.pending_entry_from_chip = False
        st.pending_entry_arm_seq = 0
        st.pending_base_position = 0
        st.pending_requested_qty = 0
        st.pending_filled_qty = 0
        st.pending_retry_count = 0

    @staticmethod
    def _clear_deferred_order_fields(st: SimState) -> None:
        st.deferred_target = None
        st.deferred_reason = ""
        st.deferred_source = ""
        st.deferred_signal = ""
        st.deferred_entry_from_chip = False
        st.deferred_entry_arm_seq = 0
        st.deferred_retry_count = 0

    def real_order_intent_text(self, task: Any) -> str:
        """回傳實單委託進度文字，讓面板可看出策略目標與券商成交進度。"""
        st = self._state(task)
        if not st.order_pending or st.pending_target is None:
            return ""
        requested = abs(int(st.pending_requested_qty or 0))
        filled = max(0, min(abs(int(st.pending_filled_qty or 0)), requested)) if requested else abs(int(st.pending_filled_qty or 0))
        target = int(st.pending_target)
        now_pos = int(st.position)
        if requested > 0:
            progress = f"{filled}/{requested}口"
        else:
            progress = "等待券商回報"
        if st.deferred_target is not None:
            return f"委託中 {progress}｜現倉{now_pos}｜目標{target}｜已保留新目標{int(st.deferred_target)}"
        return f"委託中 {progress}｜現倉{now_pos}｜目標{target}"

    def _refresh_pending_order_state(self, st: SimState) -> bool:
        was_pending = bool(st.order_pending)
        if st.pending_target is None:
            self._clear_order_intent_fields(st, clear_order_pending=True)
        elif int(st.position) == int(st.pending_target):
            self._clear_order_intent_fields(st, clear_order_pending=True)
        else:
            st.order_pending = True
        return was_pending and not st.order_pending

    def _execute_deferred_if_ready(self, task: Any, st: SimState, price: float) -> None:
        if st.order_pending or st.deferred_target is None:
            return
        target = int(st.deferred_target)
        reason = st.deferred_reason
        source = st.deferred_source
        signal = st.deferred_signal
        from_chip = bool(st.deferred_entry_from_chip)
        arm_seq = int(st.deferred_entry_arm_seq)
        retry_count = int(st.deferred_retry_count or 0)
        self._clear_deferred_order_fields(st)
        self.set_target(task, target, price, reason, source, signal, from_chip=from_chip, arm_seq=arm_seq, retry_count=retry_count)

    def release_real_order_pending(
        self,
        task: Any,
        reason: str = "委託已結束未成交",
        source: str = "券商回報",
        *,
        execute_deferred: bool = True,
    ) -> bool:
        """券商回報 IOC 未成交取消、刪單或拒單時，解除實單等待鎖。

        只清掉「正在等這筆委託」的鎖，不清除策略的行情 Pending。
        若等待期間已保留新的 deferred 目標，會在解除後自動補送最新目標。
        """
        st = self._state(task)
        if not st.order_pending:
            self.sync_task(task)
            return False
        old_target = int(st.pending_target) if st.pending_target is not None else None
        old_signal = str(st.pending_signal or st.pending_reason or "實單委託")
        old_reason = str(st.pending_reason or reason or "")
        old_source = str(st.pending_source or source or "券商回報")
        old_requested = abs(int(st.pending_requested_qty or 0))
        old_filled = abs(int(st.pending_filled_qty or 0))
        old_retry = int(st.pending_retry_count or 0)

        # 範圍市價 + IOC：部分成交就是最終結果。不補單、不追單。
        # 只有等待期間已出現的新反向/平倉 deferred 目標，才會在解除舊委託後接手。
        should_reissue_partial = False

        self._clear_order_intent_fields(st, clear_order_pending=True)
        st.risk_status = str(reason or "委託已結束未成交")
        st.last_signal = f"{old_signal}｜{st.risk_status}"
        st.signal_source = str(source or "券商回報")

        if should_reissue_partial:
            pass

        price = float(getattr(task, "last_price", 0.0) or 0.0)
        if price > 0:
            self._update_pnl(task, st, price)
        if execute_deferred and st.deferred_target is not None and price > 0:
            self._execute_deferred_if_ready(task, st, price)
        self.sync_task(task)
        return True

    def real_order_pending_age(self, task: Any, now: Optional[float] = None) -> float:
        st = self._state(task)
        if not st.order_pending or st.pending_since <= 0:
            return 0.0
        return max(0.0, float(now if now is not None else time.time()) - float(st.pending_since))

    def real_order_pending_info(self, task: Any) -> dict:
        """回傳目前實單等待委託的目標資訊，供面板做 IOC 後確認/風控備援。"""
        st = self._state(task)
        if not st.order_pending or st.pending_target is None:
            return {}
        base = int(st.pending_base_position or 0)
        target = int(st.pending_target or 0)
        reason = str(st.pending_reason or "")
        source = str(st.pending_source or "")
        signal = str(st.pending_signal or reason or "")
        return {
            "task_id": int(getattr(task, "id", st.task_id) or st.task_id),
            "base_position": base,
            "target": target,
            "reason": reason,
            "source": source,
            "signal": signal,
            "since": float(st.pending_since or 0.0),
            "requested_qty": abs(int(st.pending_requested_qty or 0)),
            "filled_qty": abs(int(st.pending_filled_qty or 0)),
            "retry_count": int(st.pending_retry_count or 0),
            "is_reverse": bool(base != 0 and target != 0 and base * target < 0),
            "is_flat": bool(target == 0),
        }

    def finalize_real_reversal_confirmation(self, task: Any, price: float, avg: float = 0.0) -> str:
        """一般反手 IOC 結束後，以庫存確認結果收尾。

        規則：
        - 已達目標倉位：解除反手鎖。
        - 變空手：代表 2 口反手大概率只成交平倉 1 口；重新檢查當下價格訊號，只要有有效 FIRE 就依當下方向補開 1 口。
        - 舊倉仍在：視為一般反手失敗，不追價、不補新倉。
        - 其他部分狀態：解除本次反手鎖，交給下一個有效訊號/風控處理。
        """
        st = self._state(task)
        info = self.real_order_pending_info(task)
        if not info or not bool(info.get("is_reverse")):
            return "not_reverse"
        base = int(info.get("base_position", 0) or 0)
        target = int(info.get("target", 0) or 0)
        target_dir = 1 if target > 0 else -1
        old_reason = str(info.get("reason") or "一般反手")
        old_signal = str(info.get("signal") or old_reason)
        price = float(price or getattr(task, "last_price", 0.0) or 0.0)
        avg = float(avg or getattr(task, "quote_avg", 0.0) or 0.0)

        if int(st.position) == target:
            self._refresh_pending_order_state(st)
            st.risk_status = "正常"
            st.last_signal = old_signal
            st.signal_source = "反手確認"
            if price > 0:
                self._update_pnl(task, st, price)
            self.sync_task(task)
            return "target_done"

        # 不論後面是否補開，都先解除上一張 2 口 IOC 的等待鎖；後續若補開會建立新鎖。
        self._clear_order_intent_fields(st, clear_order_pending=True)

        if int(st.position) == 0:
            st.risk_status = "反手只平倉｜重新檢查訊號"
            st.last_signal = "反手只平倉，等待有效新倉訊號"
            st.signal_source = "反手確認"
            self._reset_trade_tp(st)
            # 只用當下重新成立的 FIRE 補開 1 口；不沿用反手前舊訊號。
            # 允許追逐訊號：若檢查期間已翻成反向新訊號，也依當下 FIRE 方向開倉。
            if price > 0 and avg > 0 and not st.session_blocked:
                try:
                    dt = datetime.fromisoformat(str(st.last_tick_iso)) if str(st.last_tick_iso or "").strip() else datetime.now()
                except Exception:
                    dt = datetime.now()
                self._arm_intrabar(task, st, price, avg, dt)
                winner = self._fire_winner(task, st, price, avg, dt)
                if winner is not None and int(getattr(winner, "direction", 0) or 0) != 0:
                    reopen_dir = int(getattr(winner, "direction", 0) or 0)
                    reopen_note = "原目標" if reopen_dir == target_dir else "反向新訊號"
                    ok = self.set_target(
                        task,
                        reopen_dir * int(getattr(task, "lots", 1)),
                        price,
                        f"反手確認後補開({reopen_note})｜{old_reason}",
                        "反手確認",
                        "反手確認補開",
                        from_chip=False,
                        arm_seq=int(getattr(winner, "seq", 0) or 0),
                    )
                    return "flat_then_reopen" if ok else "flat_reopen_failed"
            if price > 0:
                self._update_pnl(task, st, price)
            self.sync_task(task)
            return "flat_only"

        if int(st.position) == base:
            st.risk_status = "反手未成交｜舊倉仍在"
            st.last_signal = "反手未成交，等待下一次有效訊號或風控"
            st.signal_source = "反手確認"
            if price > 0:
                self._update_pnl(task, st, price)
            self.sync_task(task)
            return "old_position_still_open"

        st.risk_status = "反手部分完成｜等待下一訊號"
        st.last_signal = f"反手部分完成｜現倉{int(st.position)}｜目標{target}"
        st.signal_source = "反手確認"
        if price > 0:
            self._update_pnl(task, st, price)
        self.sync_task(task)
        return "partial_position"

    def _finish_flat_transition(self, task: Any, st: SimState, price: float) -> None:
        """部位歸零後執行 TP / SL 的狀態機接續。"""
        if st.position != 0:
            return
        st.flat_just_done_bar_index = st.current_bar.index if st.current_bar else -1
        st.flat_just_done_base = st.arm_seq
        if st.tp_flat_lock:
            st.tp_flat_lock = False
            candidate = self._best_tp_reentry_candidate(task, st)
            st.tp_reentry = candidate
            st.boot_fresh_arm_base = st.tp_flat_arm_base
            st.last_fired_arm_seq = st.tp_flat_arm_base
            st.last_fired_bar_index = -1
            # XQ TP 命中時已清除舊 Pending；只執行母版允許的同根候選。
            st.need_new_signal = candidate is None
            st.boot_fresh_arm_ready = True
            self._reset_trade_tp(st)
            if candidate is not None:
                self._try_execute_tp_reentry(task, st, price)
            return
        if st.sl_flat_lock:
            st.sl_flat_lock = False
            candidate = self._best_tp_reentry_candidate(task, st)
            st.tp_reentry = candidate
            self._reset_trade_tp(st)
            # 一般停損平倉也遵守同一規則：
            # - 平倉當根已 FIRE 候選可立即補進。
            # - 尚未 FIRE 的 Pending 繼續等待 Gate。
            # - 更早 K 已 FIRE 候選不可沿用。
            st.boot_fresh_arm_base = st.arm_seq
            st.boot_fresh_arm_ready = True
            st.need_new_signal = not bool(st.pending)
            st.last_fired_arm_seq = 0
            st.last_fired_bar_index = -1
            if candidate is not None:
                self._try_execute_tp_reentry(task, st, price)
            return

    def _reset_after_external_position_change(self, st: SimState, reason: str) -> None:
        """外部人工操作後切斷所有舊訊號，避免同步校正後自動補回部位。"""
        self._clear_pending(st)
        self._reset_stock_intrabar_price_runtime(st)
        st.tp_reentry = None
        st.tp_flat_lock = False
        st.sl_flat_lock = False
        st.pending_target = None
        st.pending_reason = ""
        st.pending_source = ""
        st.pending_signal = ""
        st.pending_since = 0.0
        st.pending_entry_from_chip = False
        st.pending_entry_arm_seq = 0
        st.pending_base_position = 0
        st.pending_requested_qty = 0
        st.pending_filled_qty = 0
        st.pending_retry_count = 0
        st.deferred_target = None
        st.deferred_reason = ""
        st.deferred_source = ""
        st.deferred_signal = ""
        st.deferred_entry_from_chip = False
        st.deferred_entry_arm_seq = 0
        st.deferred_retry_count = 0
        st.order_pending = False
        st.need_new_signal = True
        st.boot_fresh_arm_base = st.arm_seq
        st.boot_fresh_arm_ready = True
        st.last_fired_arm_seq = 0
        st.last_fired_bar_index = -1
        st.reentry_block_bar_index = st.current_bar.index if st.current_bar else -1
        st.flat_just_done_bar_index = -1
        st.flat_just_done_base = st.arm_seq
        st.zero_sync_pending_since = 0.0
        st.zero_sync_previous_position = 0
        st.zero_sync_previous_cost = 0.0
        self._clear_real_fill_exact_cost(st)
        st.flat_reason = str(reason)
        st.last_signal = str(reason)
        st.signal_source = "券商庫存同步"

    def _finish_cross_session_cleanup(self, st: SimState, *, force: bool = False) -> bool:
        """跨時段殘留確認已清除後，解除新時段封鎖並回到全新起點。"""
        if not force and not (st.session_blocked and str(st.flat_reason or "").startswith("跨時段")):
            return False
        if st.position != 0 or st.order_pending:
            return False
        st.session_blocked = False
        st.session_stop_hit = False
        st.flat_reason = ""
        st.risk_status = "正常"
        st.last_signal = "等待新訊號"
        st.signal_source = ""
        st.need_new_signal = True
        return True

    def _confirm_restart_inventory(
        self,
        task: Any,
        st: SimState,
        position: int,
        avg_cost: float,
        *,
        authoritative_flat: bool = False,
        authoritative_snapshot: bool = False,
    ) -> str:
        """實單按下「重啟」後，先取得穩定的券商部位與成本再恢復送單。

        空手必須由核心明確確認；非空手則要求連續三次相同的可採信券商庫存與成本，
        並至少相隔 2 秒。防洗 0 暫存的本機舊快取不可解除封鎖。
        """
        position = int(position or 0)
        avg_cost = float(avg_cost or 0.0)
        if position == 0 and bool(authoritative_flat) and bool(authoritative_snapshot):
            return self._adopt_new_session_inventory(task, st, 0, 0.0)

        now = time.time()
        valid_nonzero = bool(authoritative_snapshot and position != 0 and avg_cost > 0)
        same_candidate = bool(
            valid_nonzero
            and int(st.restart_inventory_candidate_position) == position
            and abs(float(st.restart_inventory_candidate_cost) - avg_cost) <= 1e-9
        )
        if same_candidate:
            st.restart_inventory_candidate_count += 1
        elif valid_nonzero:
            st.restart_inventory_candidate_position = position
            st.restart_inventory_candidate_cost = avg_cost
            st.restart_inventory_candidate_count = 1
            st.restart_inventory_candidate_since = now
        else:
            st.restart_inventory_candidate_position = 0
            st.restart_inventory_candidate_cost = 0.0
            st.restart_inventory_candidate_count = 0
            st.restart_inventory_candidate_since = 0.0

        elapsed = now - float(st.restart_inventory_candidate_since or now)
        if valid_nonzero and st.restart_inventory_candidate_count >= 3 and elapsed >= 2.0:
            return self._adopt_new_session_inventory(task, st, position, avg_cost)

        st.risk_status = "等待券商庫存同步"
        st.last_signal = "等待券商庫存同步"
        st.signal_source = "券商庫存同步"
        self.sync_task(task)
        return "restart_sync_wait"

    def _adopt_new_session_inventory(self, task: Any, st: SimState, position: int, avg_cost: float) -> str:
        """新時段首次券商庫存確認：空手歸零；有倉視為外部留存並接入策略。"""
        position = int(position or 0)
        avg_cost = float(avg_cost or 0.0)
        st.session_inventory_sync_pending = False
        self._clear_restart_inventory_confirmation(st)
        self._clear_pending(st)
        self._reset_stock_intrabar_price_runtime(st)
        st.tp_reentry = None
        st.tp_flat_lock = False
        st.sl_flat_lock = False
        st.order_pending = False
        st.pending_target = None
        st.pending_reason = ""
        st.pending_source = ""
        st.pending_signal = ""
        st.pending_since = 0.0
        st.pending_entry_from_chip = False
        st.pending_entry_arm_seq = 0
        st.pending_base_position = 0
        st.pending_requested_qty = 0
        st.pending_filled_qty = 0
        st.pending_retry_count = 0
        st.deferred_target = None
        st.deferred_reason = ""
        st.deferred_source = ""
        st.deferred_signal = ""
        st.deferred_entry_from_chip = False
        st.deferred_entry_arm_seq = 0
        st.deferred_retry_count = 0
        st.zero_sync_pending_since = 0.0
        st.zero_sync_previous_position = 0
        st.zero_sync_previous_cost = 0.0
        st.session_blocked = False
        st.session_stop_hit = False
        st.flat_reason = ""
        st.need_new_signal = True

        if position == 0:
            st.position = 0
            st.avg_cost = 0.0
            st.open_entry_fee = 0.0
            st.open_lots = []
            st.entry_time = ""
            st.entry_reason = ""
            st.entry_from_chip = False
            st.entry_arm_seq = 0
            st.hold_entry_from_chip = False
            st.hold_entry_side = 0
            st.last_known_entry_from_chip = False
            st.last_known_entry_side = 0
            st.last_known_entry_cost = 0.0
            st.risk_status = "正常"
            st.last_signal = "等待新訊號"
            st.signal_source = ""
            self._reset_trade_tp(st)
            self._update_pnl(task, st, float(getattr(task, "last_price", 0.0) or 0.0))
            self.sync_task(task)
            return "session_flat"

        st.position = position
        st.session_had_entry = True
        if avg_cost > 0:
            st.avg_cost = avg_cost
        st.open_entry_fee = self._one_way_fee(task, st.avg_cost) * abs(position) if st.avg_cost > 0 else 0.0
        st.entry_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        st.entry_reason = "外部留存"
        st.entry_from_chip = False
        st.entry_arm_seq = 0
        st.hold_entry_from_chip = False
        st.hold_entry_side = 1 if position > 0 else -1
        st.last_known_entry_from_chip = False
        st.last_known_entry_side = st.hold_entry_side
        st.last_known_entry_cost = st.avg_cost
        self._rebuild_fifo_lot_from_avg(task, st)
        st.risk_status = "正常"
        st.last_signal = "外部留存"
        st.signal_source = "券商庫存同步"
        self._reset_new_entry_risk_state(task, st)
        self._update_pnl(task, st, float(getattr(task, "last_price", 0.0) or 0.0))
        self.sync_task(task)
        self.logger(f"[SYNC] task={st.task_id} 外部留存｜position={position} avg={st.avg_cost}")
        return "external_retained"

    def reconcile_real_position(
        self,
        task: Any,
        position: int,
        avg_cost: float,
        *,
        authoritative_flat: bool = False,
        authoritative_snapshot: bool = False,
    ) -> str:
        """以券商庫存校正實單狀態；可辨識外部平倉、外部加減碼與外部反手。

        authoritative_flat=True 表示 TradeCom 已明確確認空手。這種情況通常發生在
        面板重啟後的 RS_DONE count=0；必須立即覆蓋執行狀態檔殘留的舊倉，
        不可再進入一般的短暫洗 0 保護。
        """
        st = self._state(task)
        active_key, in_session, _force_flat = _profile_session(_profile(task), datetime.now())
        # 08:30～08:44 與 14:45～14:59 已進入固定清空區間。
        # 此時收到券商庫存只保留在核心層，不可提前把上一時段資訊重新帶回畫面。
        if not in_session and not st.session_key:
            return "session_wait"
        # 若券商庫存比第一筆 Tick 更早回覆，先建立新時段，再依庫存接入外部留存。
        if in_session and st.session_key != active_key:
            self._reset_session(task, st, active_key)
            self.sync_task(task)

        position = int(position or 0)
        avg_cost = float(avg_cost or 0.0)
        position, avg_cost, exact_guard_mode = self._guard_real_fill_exact_cost(st, position, avg_cost)
        old = int(st.position)
        now = time.time()
        if exact_guard_mode == "temporary_snapshot":
            # DEAL_RPT 後短時間收到成交前舊快照時，不可把正確的新倉洗回舊部位。
            self._update_pnl(task, st, float(getattr(task, "last_price", 0.0) or 0.0))
            self.sync_task(task)
            return "local_fill_guard"
        expected_target = int(st.pending_target) if st.order_pending and st.pending_target is not None else None

        # 日盤／夜盤切換後的首次庫存回覆是新時段起點。
        # 有部位時視為外部留存，接入策略繼續判斷；空手時直接歸零。
        if st.restart_inventory_sync_pending:
            return self._confirm_restart_inventory(
                task,
                st,
                position,
                avg_cost,
                authoritative_flat=authoritative_flat,
                authoritative_snapshot=authoritative_snapshot,
            )
        if st.session_inventory_sync_pending:
            return self._adopt_new_session_inventory(task, st, position, avg_cost)

        # 券商同步瞬間洗 0：沒有本機平倉目標時先保護 3 秒。
        # 核心層也會做多次空庫存確認；此處再保留策略帳本的最後一道保護。
        if old != 0 and position == 0 and expected_target != 0 and not bool(authoritative_flat):
            if st.zero_sync_pending_since <= 0:
                st.zero_sync_pending_since = now
                st.zero_sync_previous_position = old
                st.zero_sync_previous_cost = st.avg_cost
                self.logger(f"[SYNC] task={st.task_id} 庫存暫時洗 0，進入 {st.zero_sync_grace_seconds:.0f} 秒保護")
                self.sync_task(task)
                return "grace"
            if now - st.zero_sync_pending_since < st.zero_sync_grace_seconds:
                self.sync_task(task)
                return "grace"

        # 洗 0 後恢復原方向：完整保留本筆來源與 TP 狀態。
        if st.zero_sync_pending_since > 0 and position == st.zero_sync_previous_position:
            st.zero_sync_pending_since = 0.0
            st.zero_sync_previous_position = 0
            st.zero_sync_previous_cost = 0.0
            if avg_cost > 0:
                st.avg_cost = avg_cost
            self._update_pnl(task, st, float(getattr(task, "last_price", 0.0) or 0.0))
            self.sync_task(task)
            return "recovered"

        changed = position != old or (position != 0 and avg_cost > 0 and abs(avg_cost - st.avg_cost) > 1e-9)
        pending_change = bool(st.order_pending and expected_target is not None and changed)
        # 委託等待中收到「未達目標但部位有變」時，通常是本機 IOC 部分成交，
        # 不可先當外部人工平倉/反手清掉 order_pending；交給反手確認或風控備援收尾。
        external_change = bool(changed and expected_target != position and not pending_change)
        external_flat = bool(external_change and old != 0 and position == 0)

        if changed:
            # 可採信券商部位確實改變時，結束上一筆 DEAL_RPT 成本保護。
            if int(position) != int(st.real_fill_exact_position or 0):
                self._clear_real_fill_exact_cost(st)
            st.position = position
            st.avg_cost = avg_cost if position and avg_cost > 0 else (st.avg_cost if position else 0.0)
            if position and (old == 0 or external_change):
                # 券商庫存同步帶入外部倉位時，必須先建立進場手續費，
                # 再重建 FIFO 批次；否則 open_lots 會保留 fee=0。
                st.open_entry_fee = self._one_way_fee(task, st.avg_cost) * abs(position) if st.avg_cost > 0 else 0.0
            if position:
                self._rebuild_fifo_lot_from_avg(task, st)
            if position == 0:
                st.open_entry_fee = 0.0
                st.open_lots = []
                st.entry_time = ""
                st.entry_from_chip = False
                st.entry_arm_seq = 0
                self._reset_trade_tp(st)
            elif old == 0:
                st.session_had_entry = True
                self._reset_new_entry_risk_state(task, st)
                explicit_chip = bool(st.pending_entry_from_chip and st.order_pending and not external_change)
                st.entry_from_chip = explicit_chip
                st.entry_arm_seq = int(st.pending_entry_arm_seq if explicit_chip else 0)
                st.entry_time = st.entry_time or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                st.hold_entry_from_chip = st.entry_from_chip
                st.hold_entry_side = 1 if position > 0 else -1
                st.last_known_entry_from_chip = st.entry_from_chip
                st.last_known_entry_side = st.hold_entry_side
                st.last_known_entry_cost = st.avg_cost

        if external_change:
            cross_session_cleanup = bool(st.session_blocked and str(st.flat_reason or "").startswith("跨時段"))
            reason = "外部平倉同步" if external_flat else "外部部位同步"
            self._reset_after_external_position_change(st, reason)
            if cross_session_cleanup and position == 0:
                self._finish_cross_session_cleanup(st, force=True)
            self.logger(f"[SYNC] task={st.task_id} {reason}｜old={old} new={position} avg={avg_cost}")
        else:
            st.zero_sync_pending_since = 0.0
            completed = self._refresh_pending_order_state(st)
            price = float(getattr(task, "last_price", 0.0) or 0.0)
            self._update_pnl(task, st, price)
            cleaned = self._finish_cross_session_cleanup(st)
            if st.position == 0 and not cleaned:
                self._finish_flat_transition(task, st, price)
            if completed:
                self._execute_deferred_if_ready(task, st, price)
            self.sync_task(task)
            return "expected_change" if changed else "unchanged"

        price = float(getattr(task, "last_price", 0.0) or 0.0)
        self._update_pnl(task, st, price)
        self.sync_task(task)
        return "external_flat" if external_flat else "external_change"

    def apply_real_fill(self, task: Any, side: int, qty: int, price: float, reason: str = "") -> None:
        """TradeCom 實際成交回報。side: 1=買，-1=賣。"""
        st = self._state(task)
        side = 1 if int(side) > 0 else -1
        qty = abs(int(qty))
        price = float(price or 0.0)
        if qty <= 0 or price <= 0:
            return
        if st.order_pending and st.pending_target is not None:
            st.pending_filled_qty = max(0, int(st.pending_filled_qty or 0)) + int(qty)
        remaining = qty
        reason = str(reason or st.pending_reason or "外部下單")
        from_chip = bool(st.pending_entry_from_chip)
        arm_seq = int(st.pending_entry_arm_seq)
        if st.position and st.position * side < 0:
            close_qty = min(abs(st.position), remaining)
            event = "反手平倉" if remaining > abs(st.position) else "平倉"
            self._close_qty(task, st, close_qty, price, event, reason)
            remaining -= close_qty
        if remaining > 0:
            self._open_qty(task, st, side, remaining, price, reason, from_chip=from_chip, arm_seq=arm_seq)
        completed = self._refresh_pending_order_state(st)
        self._update_pnl(task, st, price)
        self._remember_real_fill_exact_cost(st)
        cleaned = self._finish_cross_session_cleanup(st)
        if st.position == 0 and not cleaned:
            self._finish_flat_transition(task, st, price)
        if completed:
            self._execute_deferred_if_ready(task, st, price)
        self.sync_task(task)

    # ============================================================
    # 目標部位與手動操作
    # ============================================================
    def _projected_reverse_exit_status(self, task: Any, st: SimState, target: int, price: float, source: str) -> str:
        """反手前先以「假設目前部位全數平倉」計算淨損益。

        認賠／賺飽門檻已統一使用淨損益；因此反手路徑也必須扣除
        尚未攤提的進場手續費與本次預估出場手續費，不能沿用毛損益。
        """
        if st.position == 0 or target == 0 or st.position * target >= 0 or str(source) == "手動":
            return ""
        qty = abs(int(st.position))
        points_total = self._gross_points(st.position, st.avg_cost, price) * qty
        multiplier = max(self._multiplier(task), 1)
        gross = points_total * multiplier
        projected_net_twd = (
            float(st.realized_pnl)
            + float(gross)
            - float(st.open_entry_fee)
            - self._one_way_fee(task, price) * qty
        )
        profile = _profile(task)
        projected = projected_net_twd
        max_loss = abs(_f(getattr(task, "loss_exit", 0.0), 0.0))
        max_profit = abs(float(profile.tai_max_profit)) if profile.kind == "TAI" else 0.0
        projected_loss_value = self._loss_exit_cycle_value(task, st, projected)
        projected_profit_value = self._profit_exit_track_value(task, st, projected)
        if max_loss > 0 and projected_loss_value <= -max_loss:
            return "認賠下車出場"
        if max_profit > 0 and projected_profit_value >= max_profit:
            return "賺飽下車出場"
        return ""

    def set_target(
        self,
        task: Any,
        target: int,
        price: float,
        reason: str,
        source: str,
        signal: Optional[str] = None,
        *,
        from_chip: bool = False,
        arm_seq: int = 0,
        retry_count: int = 0,
    ) -> bool:
        st = self._state(task)
        target = int(target)
        old = int(st.position)
        price = float(price or getattr(task, "last_price", 0.0) or 0.0)
        display_signal = str(signal or reason)
        if price <= 0:
            return False
        if self._task_real_mode(task) and (st.session_inventory_sync_pending or st.restart_inventory_sync_pending):
            # 實單庫存與成本尚未確認前，任何自動或手動目標都不可送出。
            return False
        if st.session_blocked and source == "手動":
            return False
        if target != 0 and st.session_blocked:
            return False
        projected_exit_status = self._projected_reverse_exit_status(task, st, target, price, source)
        if projected_exit_status:
            target = 0
            reason = projected_exit_status
            display_signal = f"反手前達{projected_exit_status}門檻，只平倉"
            from_chip = False
            arm_seq = 0
            st.session_stop_hit = True
            self._mark_strategy_exit_lock(st, projected_exit_status, projected_exit_status)
        if target == old:
            # 同方向價格 FIRE 必須把既有籌碼單升級為非籌碼來源。
            if target != 0 and not from_chip and source != "手動":
                st.entry_from_chip = False
                st.hold_entry_from_chip = False
                st.last_known_entry_from_chip = False
            self._update_pnl(task, st, price)
            self.sync_task(task)
            return True

        st.last_signal = display_signal
        st.signal_source = str(source)

        if self._task_real_mode(task):
            if st.order_pending:
                if st.pending_target == target:
                    # 已有籌碼目標、後到價格同方向：來源仍升級為價格。
                    if not from_chip:
                        st.pending_entry_from_chip = False
                    self.sync_task(task)
                    return True
                st.deferred_target = target
                st.deferred_reason = str(reason)
                st.deferred_source = str(source)
                st.deferred_signal = display_signal
                st.deferred_entry_from_chip = bool(from_chip)
                st.deferred_entry_arm_seq = int(arm_seq or 0)
                st.deferred_retry_count = 0
                self.logger(f"[REAL] 任務 {task.id} 尚有未完成委託｜已保留最新目標 {target}")
                self.sync_task(task)
                return True
            if not self.real_target_callback:
                self.logger(f"[REAL] 尚未設定實單執行器，略過 task={task.id} target={target}")
                return False
            ok = bool(self.real_target_callback(task, target, reason, source, display_signal))
            if ok:
                st.order_pending = True
                st.pending_target = target
                st.pending_reason = str(reason)
                st.pending_source = str(source)
                st.pending_signal = display_signal
                st.pending_since = time.time()
                st.pending_entry_from_chip = bool(from_chip)
                st.pending_entry_arm_seq = int(arm_seq or 0)
                st.pending_base_position = int(old)
                st.pending_requested_qty = abs(int(target) - int(old))
                st.pending_filled_qty = 0
                st.pending_retry_count = max(0, int(retry_count or 0))
                self.logger(
                    f"[REAL] 任務 {task.id}｜{display_signal}｜目標部位 {target}｜"
                    f"已送 TradeCom｜基準{old}→目標{target}｜委託{st.pending_requested_qty}口"
                )
            self.sync_task(task)
            return ok

        if old != 0:
            if target == 0:
                self._close_qty(task, st, abs(old), price, "平倉", reason)
            elif old * target < 0:
                self._close_qty(task, st, abs(old), price, "反手平倉", reason)
            elif abs(target) < abs(old):
                self._close_qty(task, st, abs(old) - abs(target), price, "減碼", reason)
        current = int(st.position)
        if target != 0:
            if current == 0:
                self._open_qty(task, st, 1 if target > 0 else -1, abs(target), price, reason, from_chip=from_chip, arm_seq=arm_seq)
            elif current * target > 0 and abs(target) > abs(current):
                self._open_qty(task, st, 1 if target > 0 else -1, abs(target) - abs(current), price, reason, from_chip=from_chip, arm_seq=arm_seq)
        if target == 0:
            st.flat_reason = str(reason)
        self._update_pnl(task, st, price)
        if st.position == 0:
            self._finish_flat_transition(task, st, price)
        self.sync_task(task)
        self.logger(f"[SIM] 任務 {task.id}｜{display_signal}｜目標部位 {target}｜模擬成交 {price}")
        return True

    def manual_target(self, task: Any, direction: int) -> bool:
        direction = int(direction)
        reason = "手動做多" if direction > 0 else "手動放空" if direction < 0 else "手動平倉"
        target = direction * int(getattr(task, "lots", 1))
        st = self._state(task)
        if st.session_blocked:
            return False
        if self._task_real_mode(task) and (st.session_inventory_sync_pending or st.restart_inventory_sync_pending):
            return False
        if target == st.position:
            return True
        event_key = "manual_long" if direction > 0 else "manual_short" if direction < 0 else "manual_flat"
        # 0611 三份 XQ 母版皆為純價格版。面板手動單也不可偽裝成籌碼來源。
        ok = bool(self.set_target(
            task,
            target,
            float(getattr(task, "last_price", 0.0)),
            reason,
            "手動",
            reason,
            from_chip=False,
        ))
        if ok:
            self._emit_event(task, event_key, f"目標部位：{target}")
        return ok

    # ============================================================
    # Session / Pending / ARM
    # ============================================================
    def _clear_pending(self, st: SimState, kinds: Optional[Iterable[str]] = None) -> None:
        if kinds is None:
            st.pending.clear()
            return
        wanted = set(kinds)
        st.pending = [p for p in st.pending if p.kind not in wanted]

    def _find_pending(self, st: SimState, kind: str) -> Optional[Pending]:
        for p in reversed(st.pending):
            if p.kind == kind:
                return p
        return None

    def _arm(self, st: SimState, kind: str, direction: int, gate: float, source: str, bar_index: int) -> Pending:
        direction = 1 if direction > 0 else -1
        st.arm_seq += 1
        p = Pending(kind, direction, float(gate or 0.0), source, st.arm_seq, int(bar_index), st.session_key)
        st.pending = [old for old in st.pending if old.kind != kind]
        st.pending.append(p)
        st.need_new_signal = False
        st.boot_fresh_arm_ready = True
        st.last_signal = f"{kind} {'多' if direction > 0 else '空'} 等待突破"
        st.signal_source = source
        return p

    def _clear_session_information(self, st: SimState) -> None:
        """清空單一車號上一時段全部策略、損益、部位顯示與暫存資訊。"""
        st.session_key = ""
        st.current_bar = None
        st.bars.clear()
        st.next_bar_index = 0
        st.session_bar_count = 0
        st.first_tick_seen = False
        self._reset_tai_special_price_runtime(st, reset_segment=True)
        self._reset_stock_intrabar_price_runtime(st)
        st.stock_xq0611_pending_migration_pending = False
        st.session_inventory_sync_pending = False
        self._clear_restart_inventory_confirmation(st)
        self._clear_pending(st)
        st.arm_seq = 0
        st.last_fired_arm_seq = 0
        st.last_fired_bar_index = -1
        st.openwait_done = False
        st.session_had_entry = False
        st.intra_seen_above = False
        st.intra_seen_below = False
        st.intra_ref_high = 0.0
        st.intra_ref_low = 0.0
        st.need_new_signal = True
        st.boot_allow_event = True
        st.boot_wait_new_bar = False
        st.boot_unlock_bars_remaining = 0
        st.boot_ref_bar_index = -1
        st.boot_fresh_arm_base = 0
        st.boot_fresh_arm_ready = True
        st.quote_avg_ready_seen = False
        st.avg_entry_wait_bar_index = -1
        st.flat_just_done_bar_index = -1
        st.flat_just_done_base = 0
        st.reentry_block_bar_index = -1
        st.chip_arm_seq = 0
        st.chip_arm_bar_index = -1
        st.chip_arm_direction = 0
        st.chip_arm_text = ""
        st.chip_arm_session_key = ""
        st.chip_snapshots.clear()
        st.tp_flat_lock = False
        st.tp_flat_arm_base = 0
        st.sl_flat_lock = False
        st.sl_flat_arm_base = 0
        st.tp_reentry = None
        st.lock_profit_armed = False
        st.lock_profit_high = 0.0
        st.lock_profit_mode = ""
        st.lock_profit_cycle_base = 0.0
        self._clear_restart_exit_rule(st)
        st.lock_profit_reset_pending = False
        st.lock_profit_units_migration_pending = False
        st.legacy_exit_lock_recovery_pending = False
        st.session_blocked = False
        st.session_stop_hit = False
        st.force_summary_sent = False
        st.flat_reason = ""
        self._reset_trade_tp(st)

        st.position = 0
        st.avg_cost = 0.0
        st.realized_pnl = 0.0
        st.float_pnl = 0.0
        st.total_pnl = 0.0
        st.high_float_pnl = 0.0
        st.gross_realized_pnl = 0.0
        st.gross_float_pnl = 0.0
        st.gross_total_pnl = 0.0
        st.realized_points = 0.0
        st.gross_float_points = 0.0
        st.open_entry_fee = 0.0
        st.open_lots = []
        st.total_fees_paid = 0.0
        st.entry_time = ""
        st.entry_reason = ""
        st.entry_from_chip = False
        st.entry_arm_seq = 0
        st.hold_entry_from_chip = False
        st.hold_entry_side = 0
        st.last_known_entry_from_chip = False
        st.last_known_entry_side = 0
        st.last_known_entry_cost = 0.0
        st.zero_sync_pending_since = 0.0
        st.zero_sync_previous_position = 0
        st.zero_sync_previous_cost = 0.0
        self._clear_real_fill_exact_cost(st)
        st.last_tick_iso = ""
        st.resume_reset_required = False
        st.last_signal = "等待新訊號"
        st.signal_source = ""
        st.risk_status = "正常"

        st.order_pending = False
        st.pending_target = None
        st.pending_reason = ""
        st.pending_source = ""
        st.pending_signal = ""
        st.pending_since = 0.0
        st.pending_entry_from_chip = False
        st.pending_entry_arm_seq = 0
        st.pending_base_position = 0
        st.pending_requested_qty = 0
        st.pending_filled_qty = 0
        st.pending_retry_count = 0
        st.deferred_target = None
        st.deferred_reason = ""
        st.deferred_source = ""
        st.deferred_signal = ""
        st.deferred_entry_from_chip = False
        st.deferred_entry_arm_seq = 0
        st.deferred_retry_count = 0

    def _reset_session(self, task: Any, st: SimState, key: str) -> None:
        """建立全新的交易時段狀態。

        上一時段資訊已全部切斷。實單若仍有券商部位，必須等待 TradeCom 庫存
        確認後再以「外部留存」接入，不可沿用本機舊部位自行反手或平倉。
        """
        key = str(key or "").strip()
        if not key:
            return
        profile = _profile(task)
        preserve_trade_state: Dict[str, Any] = {}
        self._clear_session_information(st)
        if preserve_trade_state:
            for _name, _value in preserve_trade_state.items():
                if _name == "open_lots" and isinstance(_value, list):
                    _value = [dict(x) for x in _value]
                setattr(st, _name, _value)
        st.session_key = key
        st.break_clear_key = ""
        if self.chip_metrics_session_key != key:
            self.chip_metrics = {}
            self.chip_metrics_session_key = key

        if not self._task_real_mode(task):
            return

        st.session_inventory_sync_pending = True
        # 新時段第一筆行情建立前就先加啟動鎖：第一根只建立參考，第二根起才可接受新訊號。
        # 這同時避免盤中才啟動實單時補吃啟動前已存在的訊號。
        st.boot_wait_new_bar = True
        st.boot_unlock_bars_remaining = 2
        st.boot_allow_event = False
        st.boot_ref_bar_index = -1
        st.boot_fresh_arm_base = int(st.arm_seq or 0)
        st.boot_fresh_arm_ready = False
        st.quote_avg_ready_seen = False
        st.avg_entry_wait_bar_index = -1
        st.risk_status = "等待券商庫存同步"
        st.last_signal = "等待券商庫存同步"
        st.signal_source = "券商庫存同步"

    @staticmethod
    def _gate_from_bar(profile: StrategyProfile, bar: Bar) -> tuple[float, float]:
        if profile.gate_mode == 2:
            return max(float(bar.open), float(bar.close)), min(float(bar.open), float(bar.close))
        return float(bar.high), float(bar.low)

    @staticmethod
    def _task_quote_avg_ready(task: Any, avg: float) -> bool:
        if _is_three_ma_profile(_profile(task)):
            return True
        if float(avg or 0.0) <= 0:
            return False
        return bool(getattr(task, "quote_avg_ready", True))

    def _try_openwait_second_bar(self, task: Any, st: SimState, price: float, dt: datetime) -> bool:
        """第二根 OP：只認真正的 08:46／15:01，不補做盤中啟動後的 OP。

        050B 修正：OP 必須優先於「均價剛確認後等下一根」與「啟動等新 K」保護。
        但若第一根均價尚未有效，不可把 openwait_done 提前設為 True；同一根 08:46/15:01
        後續 Tick 只要均價補齊，仍要能送出 OP。
        """
        if _session_minute(dt) != 1 or st.openwait_done or st.session_had_entry or st.session_blocked or st.session_inventory_sync_pending or st.restart_inventory_sync_pending:
            return False
        if not st.current_bar or len(st.bars) != 1:
            return False
        previous = st.bars[-1]
        if previous.index != 0 or st.current_bar.index != 1 or not _is_true_second_bar(dt, previous):
            return False
        # 台指 XQ 的 OP ARM 明確要求 pNow = 0；外部留存或人工倉位不可被 OP 反手。
        if _profile(task).kind == "TAI" and st.position != 0:
            return False
        if previous.avg_close <= 0:
            # 尚未取得第一根有效均價時，不可標記 OP 已完成。
            # 等同一根 08:46/15:01 後續 Tick 補齊均價後再嘗試。
            st.risk_status = "第二根OP等待均價"
            st.last_signal = "第二根OP等待均價"
            st.signal_source = "OP"
            return False
        direction = 1 if previous.close >= previous.avg_close else -1
        st.arm_seq += 1
        p = Pending("OpenWait", direction, 0.0, "價格｜OpenWait", st.arm_seq, previous.index, st.session_key)
        st.pending = [old for old in st.pending if old.kind != "OpenWait"] + [p]
        st.need_new_signal = False
        st.boot_fresh_arm_ready = True
        reason = _direction_reason("OpenWait", direction)
        ok = self.set_target(task, direction * int(getattr(task, "lots", 1)), price, reason, "價格｜OpenWait", reason, from_chip=False, arm_seq=p.seq)
        if not ok:
            self._clear_pending(st, ["OpenWait"])
            return False
        st.openwait_done = True
        st.boot_allow_event = True
        st.boot_wait_new_bar = False
        st.boot_unlock_bars_remaining = 0
        self._clear_pending(st, ["OpenWait"])
        # XQ：OP 已真正執行後仍維持有效訊號世代，第三根起可開始 IntraFB 觀察。
        st.need_new_signal = False
        return True

    def _start_new_bar(self, task: Any, st: SimState, price: float, avg: float, dt: datetime) -> None:
        previous: Optional[Bar] = None
        if st.current_bar is not None:
            previous = st.current_bar
            st.bars.append(previous)
            st.bars = st.bars[-20:]
            st.session_bar_count += 1
        current = Bar(_bar_key(dt), price, price, price, price, avg, st.next_bar_index)
        st.next_bar_index += 1
        st.current_bar = current
        # TP 同根再進候選不可跨 K；只保留本根內已成立但因同向持倉未重複下單的訊號。
        if st.tp_reentry is not None and (
            st.tp_reentry.session_key != st.session_key
            or st.tp_reentry.bar_index != current.index
        ):
            st.tp_reentry = None
        st.intra_seen_above = bool(avg > 0 and price > avg)
        st.intra_seen_below = bool(avg > 0 and price < avg)
        if previous is not None:
            high, low = self._gate_from_bar(_profile(task), previous)
            st.intra_ref_high, st.intra_ref_low = high, low
        if st.reentry_block_bar_index >= 0 and st.reentry_block_bar_index != current.index:
            st.reentry_block_bar_index = -1
        self._clear_pending(st, ["IntraFB"])

        if st.boot_unlock_bars_remaining > 0:
            # XQ bootStartLock -> bootPostUnlock：第一個新 K 只跨階段；
            # 第二個新 K 才切斷舊 ARM 並恢復 fresh ARM。
            st.boot_unlock_bars_remaining -= 1
            st.boot_wait_new_bar = st.boot_unlock_bars_remaining > 0
            st.boot_allow_event = st.boot_unlock_bars_remaining == 0
            st.boot_ref_bar_index = previous.index if previous else -1
            st.boot_fresh_arm_base = st.arm_seq
            st.boot_fresh_arm_ready = st.boot_unlock_bars_remaining == 0
            self._clear_pending(st)
            st.need_new_signal = True
            if st.boot_unlock_bars_remaining > 0:
                return
        elif st.boot_wait_new_bar:
            # 相容舊狀態：至少等一根新 K，再切斷舊 pending。
            st.boot_wait_new_bar = False
            st.boot_allow_event = True
            st.boot_ref_bar_index = previous.index if previous else -1
            st.boot_fresh_arm_base = st.arm_seq
            st.boot_fresh_arm_ready = True
            self._clear_pending(st)
            st.need_new_signal = True

        minute = _session_minute(dt)
        if previous is None:
            return

        # 0611 台指母版為純價格版：不建立籌碼 ARM。

        # 第一分鐘完全禁入；第二根的 OP 由 on_tick 在券商庫存確認後處理。
        # 這樣即使新時段庫存回覆稍晚抵達，OP 仍可在第二根後續 Tick 正常執行。
        if minute < 2:
            return
        if st.session_blocked or st.tp_flat_lock:
            return

        profile = _profile(task)
        if profile.kind == "TAI":
            self._arm_tai_newbar(st, profile, price, avg, dt)
        else:
            # v21：大小股期 Cross / FB / IntraFB 全部由盤中逐 Tick 流程判斷。
            # 換 K 僅重設 IntraFB 的本根觀察狀態，不在此處限制 Cross / FB 建立時機。
            pass

    def _three_ma_avg_now(self, task: Any, st: SimState) -> float:
        """MA策略即時均線：MA參數 3/5/10；K棒週期 1/5/10 分。"""
        if not st.current_bar:
            return 0.0
        period = _task_ma_period(task)
        need_completed = max(0, period - 1)
        if len(st.bars) < need_completed:
            return 0.0
        try:
            values = [float(bar.close) for bar in st.bars[-need_completed:]] if need_completed else []
            values.append(float(st.current_bar.close))
            if len(values) != period:
                return 0.0
            return sum(values) / float(period)
        except Exception:
            return 0.0

    def _arm_3ma_intrabar(self, task: Any, st: SimState, price: float, avg3: float) -> None:
        """MA策略：Cross / FB / IntraFB 逐 Tick 建立 ARM，突破前一根高低點才 FIRE。"""
        period = _task_ma_period(task)
        required_prev_bars = max(1, period - 1)
        if not st.current_bar or len(st.bars) < required_prev_bars or avg3 <= 0:
            return
        prev = st.bars[-1]
        if float(prev.avg_close or 0.0) <= 0:
            return
        gate_high, gate_low = float(prev.high), float(prev.low)
        cur_close = float(st.current_bar.close)
        label = f"{period}MA"

        # MA策略母版邏輯：Cross 使用嚴格大於/小於，不把等於歸多方。
        if float(prev.close) < float(prev.avg_close) and cur_close > float(avg3):
            self._arm(st, "Cross", 1, gate_high, f"{label}｜Cross", prev.index)
        elif float(prev.close) > float(prev.avg_close) and cur_close < float(avg3):
            self._arm(st, "Cross", -1, gate_low, f"{label}｜Cross", prev.index)

        # FB：上一根刺穿均線後收回，下一根突破上一根高低點。
        if float(prev.high) > float(prev.avg_close) and float(prev.close) < float(prev.avg_close):
            self._arm(st, "FB", -1, gate_low, f"{label}｜FB", prev.index)
        elif float(prev.low) < float(prev.avg_close) and float(prev.close) > float(prev.avg_close):
            self._arm(st, "FB", 1, gate_high, f"{label}｜FB", prev.index)

        # IntraFB：本根高低點同時跨過目前均線，依目前收盤相對均線決定方向。
        if float(st.current_bar.high) > float(avg3) and float(st.current_bar.low) < float(avg3):
            direction = 1 if cur_close >= float(avg3) else -1
            gate = gate_high if direction > 0 else gate_low
            self._arm(st, "IntraFB", direction, gate, f"{label}｜IntraFB", st.current_bar.index)

        if not st.pending:
            st.need_new_signal = True

    def _on_tick_three_ma(self, task: Any, st: SimState, price: float, dt: datetime) -> None:
        """MA策略主流程：不用 QuoteCom 均價、不做 OP；依任務 MA參數與 K棒週期逐 Tick 計算。"""
        avg3 = self._three_ma_avg_now(task, st)
        period = _task_ma_period(task)
        if st.current_bar is not None and avg3 > 0:
            st.current_bar.avg_close = float(avg3)
            task.quote_avg = float(avg3)

        if st.position == 0 and not st.boot_allow_event:
            st.risk_status = "等待新K棒"
            st.last_signal = "等待新K棒"
            st.signal_source = "新K棒確認"
            self.sync_task(task)
            return

        st.quote_avg_ready_seen = True
        required_prev_bars = max(1, period - 1)
        ma_label = f"{period}MA"
        enough_bars = bool(st.current_bar and len(st.bars) >= required_prev_bars and avg3 > 0)
        if not enough_bars:
            if st.position and not st.order_pending:
                self._apply_risk(task, st, price, dt, None)
            elif st.position == 0:
                st.risk_status = f"等待{ma_label}資料"
                st.last_signal = f"等待{ma_label}資料"
                st.signal_source = ma_label
            self._update_pnl(task, st, price)
            self.sync_task(task)
            return

        if st.tp_flat_lock:
            if st.position:
                self._arm_3ma_intrabar(task, st, price, avg3)
                self._capture_fire_during_flat_lock(task, st, price, avg3, dt)
                self.set_target(task, 0, price, "TPFlatLock", "Risk", "停利鎖定平倉")
            else:
                self._finish_flat_transition(task, st, price)
            self.sync_task(task)
            return

        if st.sl_flat_lock:
            if st.position:
                self._arm_3ma_intrabar(task, st, price, avg3)
                winner = self._fire_winner(task, st, price, avg3, dt)
                if winner is not None and winner.seq <= int(st.sl_flat_arm_base or 0):
                    winner = None
                if winner is not None and st.position * winner.direction < 0:
                    st.sl_flat_lock = False
                    self._execute_price_fire(task, st, winner, price)
                else:
                    if winner is not None and st.position * winner.direction > 0:
                        self._remember_same_bar_reentry(st, winner.kind, winner.direction, winner.seq, from_chip=False, gate=winner.gate)
                        self._clear_pending(st)
                        st.need_new_signal = True
                    self.set_target(task, 0, price, "SLFlatLock", "Risk", "停損鎖定平倉")
            else:
                self._finish_flat_transition(task, st, price)
            self.sync_task(task)
            return

        self._arm_3ma_intrabar(task, st, price, avg3)
        winner = self._fire_winner(task, st, price, avg3, dt)
        reverse = winner if winner and st.position and st.position * winner.direction < 0 else None
        if winner is not None and st.position * winner.direction > 0:
            self._remember_same_bar_reentry(st, winner.kind, winner.direction, winner.seq, from_chip=False, gate=winner.gate)
        if self._apply_risk(task, st, price, dt, reverse):
            self._update_pnl(task, st, price)
            self.sync_task(task)
            return
        if winner is not None:
            self._execute_price_fire(task, st, winner, price)
        self._update_pnl(task, st, price)
        self.sync_task(task)

    def _arm_stock_intrabar(self, st: SimState, profile: StrategyProfile, price: float, avg: float) -> None:
        """大股期／小股期：第三根起 Cross / FB 逐 Tick 建立 ARM。

        使用者指定大小股期全部逐筆洗價。Cross、FB 與 IntraFB 都在同一根 K
        的每一筆行情重新判斷；Pending 由最新同類 ARM 覆蓋，FIRE 仍逐 Tick。
        """
        if not st.current_bar or not st.bars or avg <= 0:
            return
        prev = st.bars[-1]
        if prev.avg_close <= 0:
            return
        gate_high, gate_low = self._gate_from_bar(profile, prev)

        # Cross：等於均價歸多方。
        if prev.close < prev.avg_close and price >= avg:
            self._arm(st, "Cross", 1, gate_high, "價格｜Cross", prev.index)
        elif prev.close >= prev.avg_close and price < avg:
            self._arm(st, "Cross", -1, gate_low, "價格｜Cross", prev.index)

        # FB：前一根刺穿均價後收回；等於均價不建立 FB。
        if prev.high > prev.avg_close and prev.close < prev.avg_close:
            self._arm(st, "FB", -1, gate_low, "價格｜FB", prev.index)
        elif prev.low < prev.avg_close and prev.close > prev.avg_close:
            self._arm(st, "FB", 1, gate_high, "價格｜FB", prev.index)

        # 與 XQ 全逐筆版一致：此 Tick 沒有任何等待訊號時，回到等待新訊號。
        if not st.pending:
            st.need_new_signal = True

    def _arm_tai_newbar(self, st: SimState, profile: StrategyProfile, price: float, avg: float, dt: datetime) -> None:
        """台指一般時段：XQ 原版 2，N 收盤確認後於 N+1 建立 Cross pending。"""
        if not st.bars:
            return
        # 0611 母版為全時段逐筆；此舊版收盤確認分支保留作相容，不由正式流程呼叫。
        if profile.tai_open20_special:
            return
        if len(st.bars) < 2:
            return
        old, crossed = st.bars[-2], st.bars[-1]
        if old.avg_close <= 0 or crossed.avg_close <= 0:
            return
        if old.close < old.avg_close and crossed.close >= crossed.avg_close:
            self._arm(st, "Cross", 1, old.high, "價格｜Cross", old.index)
        if old.close >= old.avg_close and crossed.close < crossed.avg_close:
            self._arm(st, "Cross", -1, old.low, "價格｜Cross", old.index)

    def _arm_tai_special_intrabar(self, st: SimState, price: float, avg: float) -> None:
        """台指期：全交易時段逐 Tick 建立 Cross / FB ARM。

        0611 XQ 母版在每個 Tick 都重新跑 Cross / FB 條件；條件持續成立時，
        ARM 序號也會持續更新。這會影響 Cross、FB、IntraFB 同時成立時的
        最新 ARM 優先順序，因此每一筆行情都必須重新建立最新同類 ARM。
        """
        if not st.current_bar or not st.bars or avg <= 0:
            return
        prev = st.bars[-1]
        if prev.avg_close <= 0:
            return

        if prev.close < prev.avg_close and price >= avg:
            self._arm(st, "Cross", 1, prev.high, "價格｜Cross", prev.index)
        elif prev.close >= prev.avg_close and price < avg:
            self._arm(st, "Cross", -1, prev.low, "價格｜Cross", prev.index)

        if prev.high > prev.avg_close and prev.close < prev.avg_close:
            self._arm(st, "FB", -1, prev.low, "價格｜FB", prev.index)
        elif prev.low < prev.avg_close and prev.close > prev.avg_close:
            self._arm(st, "FB", 1, prev.high, "價格｜FB", prev.index)

    def _arm_intra(self, st: SimState, price: float, avg: float) -> None:
        if avg <= 0 or not st.current_bar:
            return
        if price > avg:
            st.intra_seen_above = True
        if price < avg:
            st.intra_seen_below = True
        if self._find_pending(st, "IntraFB") is not None:
            return
        direction = 0
        gate = 0.0
        if st.intra_seen_above and st.intra_seen_below:
            direction = 1 if price >= avg else -1
        elif st.intra_seen_below:
            direction = 1
        elif st.intra_seen_above:
            direction = -1
        if direction > 0:
            gate = st.intra_ref_high
        elif direction < 0:
            gate = st.intra_ref_low
        if direction:
            self._arm(st, "IntraFB", direction, gate, "價格｜IntraFB", st.current_bar.index)

    def _arm_intrabar(
        self,
        task: Any,
        st: SimState,
        price: float,
        avg: float,
        dt: datetime,
        *,
        allow_during_tp_flat_lock: bool = False,
    ) -> None:
        if (
            not st.current_bar
            or _session_minute(dt) < 2
            or st.session_blocked
            or (st.tp_flat_lock and not allow_during_tp_flat_lock)
        ):
            return
        if not st.boot_allow_event or not self._task_quote_avg_ready(task, avg):
            return
        if st.reentry_block_bar_index == st.current_bar.index:
            return
        profile = _profile(task)
        if profile.kind == "TAI":
            # 0611 純價格全時段逐筆版：日盤、夜盤第三根起，Cross / FB / IntraFB 全部逐 Tick。
            # 原三段時間只保留獨立鎖利門檻用途，不再限制訊號判斷。
            self._arm_tai_special_intrabar(st, price, avg)
            self._arm_intra(st, price, avg)
            return
        # v21 大股期／小股期：第三根起 Cross / FB / IntraFB 全部逐 Tick 洗價。
        self._arm_stock_intrabar(st, profile, price, avg)
        # IntraFB 仍沿用原本規則：已有 OP / Cross / FB 等有效訊號世代後才觀察。
        if not st.need_new_signal:
            self._arm_intra(st, price, avg)

    # ============================================================
    # FIRE 與價格優先仲裁
    # ============================================================
    def _fire_candidates(self, task: Any, st: SimState, price: float, avg: float, dt: datetime) -> List[Pending]:
        out: List[Pending] = []
        if not self._task_quote_avg_ready(task, avg):
            return out
        profile = _profile(task)
        for p in st.pending:
            if p.session_key != st.session_key:
                continue
            ok = False
            if p.kind == "OpenWait":
                ok = True
            elif p.kind == "Cross":
                ok = price > p.gate if p.direction > 0 else price < p.gate
            elif p.kind == "FB":
                ok = price > p.gate if p.direction > 0 else price < p.gate
            elif p.kind == "IntraFB":
                ok = (price > avg and price > p.gate) if p.direction > 0 else (price < avg and price < p.gate)
            if ok:
                out.append(p)
        return out

    def _fire_winner(self, task: Any, st: SimState, price: float, avg: float, dt: datetime) -> Optional[Pending]:
        candidates = self._fire_candidates(task, st, price, avg, dt)
        if not candidates:
            return None
        winner = max(candidates, key=lambda p: p.seq)
        if st.last_fired_bar_index == (st.current_bar.index if st.current_bar else -1) and st.last_fired_arm_seq == winner.seq:
            return None
        return winner

    @staticmethod
    def _reason_from_kind(kind: str, direction: int) -> str:
        return _direction_reason(kind, direction)

    def _remember_same_bar_reentry(
        self,
        st: SimState,
        kind: str,
        direction: int,
        seq: int,
        *,
        from_chip: bool = False,
        require_same_direction_position: bool = True,
        gate: float = 0.0,
    ) -> None:
        """記住平倉當根已 FIRE、可在歸零後立即執行的訊號。

        一般情況只記錄「已有同向持倉，所以 FIRE 後未重複加碼」的訊號。
        TP 實單平倉委託尚未成交期間，部位仍未歸零；此時若 Pending 才突破 Gate，
        FIRE 也發生在平倉當根，因此可暫存，待歸零後立即進場。

        尚未 FIRE 的 Pending 不放進此候選，但仍保留其正常生命週期。
        候選不可跨 K 使用。若同根有多個 FIRE，保留較新的 ARM；同世代價格優先於籌碼。
        """
        if not st.current_bar or st.position == 0:
            return
        direction = 1 if int(direction) > 0 else -1
        if require_same_direction_position and st.position * direction <= 0:
            return
        candidate = ReEntryCandidate(
            kind=str(kind),
            direction=direction,
            seq=int(seq or 0),
            bar_index=st.current_bar.index,
            session_key=st.session_key,
            gate=float(gate or 0.0),
            from_chip=bool(from_chip),
        )
        old = st.tp_reentry
        replace = old is None
        if old is not None:
            if old.session_key != candidate.session_key or old.bar_index != candidate.bar_index:
                replace = True
            elif candidate.seq > old.seq:
                replace = True
            elif candidate.seq == old.seq and old.from_chip and not candidate.from_chip:
                replace = True
        if replace:
            st.tp_reentry = candidate

    def _remember_same_bar_chip_if_valid(self, task: Any, st: SimState, price: float, avg: float, dt: datetime) -> None:
        """舊版相容函式。0611 純價格正式流程不再呼叫。"""
        if _profile(task).kind != "TAI" or not st.current_bar:
            return
        if _session_minute(dt) < 2 or st.session_blocked or st.tp_flat_lock or st.sl_flat_lock:
            return
        if st.chip_arm_bar_index != st.current_bar.index or st.chip_arm_session_key != st.session_key or st.chip_arm_seq <= 0:
            return
        direction = int(st.chip_arm_direction)
        if st.position * direction <= 0:
            return
        if (direction > 0 and price > avg) or (direction < 0 and price < avg):
            self._remember_same_bar_reentry(st, "Chip", direction, st.chip_arm_seq, from_chip=True)

    def _capture_fire_during_flat_lock(self, task: Any, st: SimState, price: float, avg: float, dt: datetime) -> None:
        """TP 或一般停損的實單平倉尚未成交時，持續監看本根 Pending。

        Pending 尚未突破 Gate 時不是舊訊號，必須保留。若它在平倉委託過程中於同根 FIRE，
        就記成平倉當根候選；平倉成交歸零後立即進場。價格訊號優先於籌碼。
        """
        if not st.current_bar or st.position == 0 or st.session_blocked:
            return
        # TP 啟動時已切斷平倉前舊 Pending。平倉委託尚未成交期間，
        # 仍允許依最新 Tick 重新建立 ARM，但只接受 TP 鎖啟動後新 FIRE 的訊號。
        self._arm_intrabar(task, st, price, avg, dt, allow_during_tp_flat_lock=True)
        winner = self._fire_winner(task, st, price, avg, dt)
        if winner is not None and winner.seq > int(st.tp_flat_arm_base or 0):
            st.last_fired_bar_index = st.current_bar.index
            st.last_fired_arm_seq = winner.seq
            self._remember_same_bar_reentry(
                st,
                winner.kind,
                winner.direction,
                winner.seq,
                from_chip=False,
                require_same_direction_position=False,
                gate=winner.gate,
            )
            # 本次 Pending 已正式 FIRE；依一般 winner 規則切斷其餘等待訊號。
            self._clear_pending(st)
            st.intra_seen_above = False
            st.intra_seen_below = False
            st.need_new_signal = True
            return

        # 0611 三份 XQ 母版皆為純價格版；沒有籌碼候選。

    def _execute_price_fire(self, task: Any, st: SimState, winner: Pending, price: float) -> bool:
        if st.session_blocked or not st.current_bar:
            return False
        if st.reentry_block_bar_index == st.current_bar.index:
            return False
        st.last_fired_bar_index = st.current_bar.index
        st.last_fired_arm_seq = winner.seq
        # FIRE 已成立但目前已有同向持倉：XQ 不會重複下單，也不會清除 Pending。
        # 只記住為本根盤中若稍後平倉，可依母版規則立即補進的候選。
        if st.position * winner.direction > 0:
            self._remember_same_bar_reentry(st, winner.kind, winner.direction, winner.seq, from_chip=False, gate=winner.gate)
            return False
        reason = self._reason_from_kind(winner.kind, winner.direction)
        ok = self.set_target(
            task,
            winner.direction * int(getattr(task, "lots", 1)),
            price,
            reason,
            winner.source,
            f"{winner.kind} {'多' if winner.direction > 0 else '空'}",
            from_chip=False,
            arm_seq=winner.seq,
        )
        if ok:
            self._clear_pending(st)
            st.intra_seen_above = False
            st.intra_seen_below = False
            # XQ：真正執行 winner 後維持有效訊號世代；股期可在同根後續 Tick 建立 Cross / FB / IntraFB。
            st.need_new_signal = False
        return ok

    # ============================================================
    # 舊台指籌碼相容入口：保留供外層行情程式呼叫，但 0611 正式流程不執行籌碼 ARM / 下單
    # ============================================================
    def on_chip(self, symbol: str, data: dict, tasks: List[Any]) -> None:
        """保留外層呼叫相容；0611 純價格正式流程只暫存資料，不建立 ARM 或交易。"""
        symbol = str(symbol or "").strip().upper()
        if not symbol:
            return
        self.chip_metrics[symbol] = {
            # 委買委賣口數差：沿用 PI20030 的累計委託量。
            "口數差": _f(data.get("BUY_QUANTITY")) - _f(data.get("SELL_QUANTITY")),
            # XQ 指標定義：委買委賣成筆差 = 累賣成筆 - 累買成筆。
            # 累買／累賣成筆來自 PI20020 MatchBuyCnt / MatchSellCnt，
            # 不是 PI20030 的 BUY_ORDER / SELL_ORDER。
            "成筆差": _f(data.get("MATCH_SELL_CNT")) - _f(data.get("MATCH_BUY_CNT")),
        }

    def _aggregate_chip_metrics(self) -> Dict[str, float]:
        out = {"大委": 0.0, "大成": 0.0, "小委": 0.0, "小成": 0.0}
        for symbol, metric in self.chip_metrics.items():
            upper = str(symbol).upper()
            if upper.startswith("TXF"):
                out["大委"] = float(metric.get("口數差", 0.0))
                out["大成"] = float(metric.get("成筆差", 0.0))
            elif upper.startswith("MXF"):
                out["小委"] = float(metric.get("口數差", 0.0))
                out["小成"] = float(metric.get("成筆差", 0.0))
        return out

    def _tai_chip_metrics_ready(self) -> bool:
        """TXF 與 MXF 都收到本次啟動後的新籌碼行情，才可建立翻色基準。"""
        has_txf = False
        has_mxf = False
        for symbol in self.chip_metrics:
            upper = str(symbol).upper()
            if upper.startswith("TXF"):
                has_txf = True
            elif upper.startswith("MXF"):
                has_mxf = True
        return bool(has_txf and has_mxf)

    def _snapshot_tai_chip_arm(self, st: SimState, minute: int) -> None:
        """每根新 K 建立一次籌碼快照；第三根開始才可建立籌碼 ARM。"""
        # 重啟後先等待 TXF 與 MXF 都收到新行情。缺一邊時不可用 0 當作基準，
        # 否則另一邊稍後補到正值或負值時，會被誤判成翻紅／翻綠。
        if not self._tai_chip_metrics_ready():
            st.chip_snapshots.clear()
            return
        snap = self._aggregate_chip_metrics()
        st.chip_snapshots.append(snap)
        st.chip_snapshots = st.chip_snapshots[-4:]
        if minute < 2 or len(st.chip_snapshots) < 2 or not st.current_bar:
            return
        previous, current = st.chip_snapshots[-2], st.chip_snapshots[-1]
        flips: List[tuple[int, str]] = []
        for key in ("大委", "大成", "小委", "小成"):
            before, after = float(previous.get(key, 0.0)), float(current.get(key, 0.0))
            if after > 0 and before <= 0:
                flips.append((1, key + "紅"))
            elif after < 0 and before >= 0:
                flips.append((-1, key + "綠"))
        if not flips or len({d for d, _ in flips}) != 1:
            return
        # XQ：同一根 K 只建立一次籌碼 ARM。
        if st.chip_arm_bar_index == st.current_bar.index:
            return
        direction = flips[0][0]
        st.arm_seq += 1
        st.chip_arm_seq = st.arm_seq
        st.chip_arm_bar_index = st.current_bar.index
        st.chip_arm_direction = direction
        st.chip_arm_text = "|".join(label for _, label in flips) + "|"
        st.chip_arm_session_key = st.session_key
        st.need_new_signal = False
        st.boot_fresh_arm_ready = True
        st.last_signal = f"籌碼翻{'多' if direction > 0 else '空'}"
        st.signal_source = st.chip_arm_text

    def _process_chip_assist(self, task: Any, st: SimState, price: float, avg: float, dt: datetime, *, price_action: bool) -> bool:
        if price_action or _profile(task).kind != "TAI" or not st.current_bar:
            return False
        if st.reentry_block_bar_index == st.current_bar.index:
            return False
        if _session_minute(dt) < 2 or st.session_blocked or st.tp_flat_lock or st.sl_flat_lock:
            return False
        if st.chip_arm_bar_index != st.current_bar.index or st.chip_arm_session_key != st.session_key or st.chip_arm_seq <= 0:
            return False
        direction = st.chip_arm_direction
        # 空手：籌碼補進場；價格訊號永遠先仲裁。
        if st.position == 0:
            if (direction > 0 and price > avg) or (direction < 0 and price < avg):
                ok = self.set_target(
                    task,
                    direction * int(getattr(task, "lots", 1)),
                    price,
                    ("Chip_Long|" if direction > 0 else "Chip_Short|") + st.chip_arm_text,
                    st.chip_arm_text,
                    "籌碼翻多" if direction > 0 else "籌碼翻空",
                    from_chip=True,
                    arm_seq=st.chip_arm_seq,
                )
                if ok:
                    st.need_new_signal = True
                return ok
            return False
        # 有倉且籌碼與既有部位同向：不加碼，但保留為本根盤中平倉後可立即再進的有效訊號。
        if st.position * direction > 0 and ((direction > 0 and price > avg) or (direction < 0 and price < avg)):
            self._remember_same_bar_reentry(st, "Chip", direction, st.chip_arm_seq, from_chip=True)
            return False
        # 有倉：只有籌碼來源持倉才受反向籌碼平倉；非籌碼單不受影響。
        if st.entry_from_chip and ((st.position > 0 and direction < 0) or (st.position < 0 and direction > 0)):
            st.reentry_block_bar_index = st.current_bar.index
            ok = self.set_target(task, 0, price, "籌碼平倉|" + st.chip_arm_text, st.chip_arm_text, "籌碼反向出場", from_chip=False, arm_seq=st.chip_arm_seq)
            if ok:
                st.need_new_signal = True
            return ok
        return False

    # ============================================================
    # TP / SL / 累積風控
    # ============================================================
    def _risk_float_value(self, task: Any, st: SimState) -> float:
        # v042 Backtester：認賠下車/賺飽下車固定使用新台幣淨損益；浮動損益已扣進場與預估出場手續費。
        return float(st.float_pnl) if st.position else 0.0

    def _tp_sl_float_value(self, task: Any, st: SimState) -> float:
        """停利/停損判斷用粗損益：四個策略全部回傳每口商品點數，不扣手續費。"""
        qty = max(abs(int(st.position)), 1)
        return float(st.gross_float_points) / qty if st.position else 0.0

    def _risk_total_value(self, task: Any, st: SimState) -> float:
        # v042 Backtester：認賠下車/賺飽下車固定使用扣完手續費後的新台幣累積淨損益。
        return float(st.realized_pnl) + self._risk_float_value(task, st)

    def _update_tp_line(self, task: Any, st: SimState) -> None:
        if st.position == 0:
            return
        threshold = abs(_f(getattr(task, "take_profit", 0.0), 0.0))
        if threshold <= 0 or st.tp_peak < threshold:
            return
        profile = _profile(task)
        first = not st.tp_armed
        st.tp_armed = True
        if _is_three_ma_profile(profile):
            # MA策略：停利達標後一律以最高浮盈 0.2 回檔停利，鎖住 80%。
            # st.tp_peak / st.tp_line 在 MA策略 都是每口商品點數，不是新台幣。
            locked = floor(st.tp_peak * 0.80)
            distance = locked
            unit = "點"
        elif profile.kind == "TAI":
            if st.tp_peak >= 300:
                locked = floor(st.tp_peak * 0.90)
            elif st.tp_peak >= 150:
                locked = floor(st.tp_peak * 0.80)
            else:
                locked = floor(st.tp_peak * 0.70)
            distance = locked
            unit = "元"
        else:
            # 股期原策略保留原本停利縮緊概念，但 056D 起門檻與保底值都用商品點數。
            money_equiv = float(st.tp_peak) * max(self._multiplier(task) * abs(st.position), 1)
            locked = floor(st.tp_peak * (0.90 if money_equiv >= 20000 else 0.80))
            distance = locked
            unit = "元"
        st.tp_line = max(float(st.tp_line), float(locked))
        candidate = st.avg_cost + distance if st.position > 0 else st.avg_cost - distance
        if st.tp_line_price == 0:
            st.tp_line_price = candidate
        elif st.position > 0:
            st.tp_line_price = max(st.tp_line_price, candidate)
        else:
            st.tp_line_price = min(st.tp_line_price, candidate)
        st.risk_status = "準備停利"
        if first:
            self._emit_event(task, "tp_ready", f"浮盈高點：{st.tp_peak:.0f} {unit}｜保底：{st.tp_line:.0f} {unit}")

    @staticmethod
    def _tp_hit(st: SimState, price: float) -> bool:
        if not st.tp_armed or st.tp_line_price == 0 or st.position == 0:
            return False
        return bool(price <= st.tp_line_price if st.position > 0 else price >= st.tp_line_price)

    def _capture_tp_reentry(self, task: Any, st: SimState, reason: str = "停利平倉") -> Optional[ReEntryCandidate]:
        """回傳已鎖存、且仍屬於目前 K 棒的同根補進場候選。"""
        candidate = st.tp_reentry
        if candidate is None or not self._tp_reentry_valid(task, st, candidate):
            return None
        return candidate

    def _capture_xq_tp_reentry_on_trigger(self, task: Any, st: SimState, status: str) -> Optional[ReEntryCandidate]:
        """TP 命中時不可把尚未 FIRE 的舊 Pending 直接變成補進候選。

        v22 以前會在平倉前掃描 Pending，將仍在等待突破的 Cross / FB / IntraFB
        直接保存成 tp_reentry。這會造成價格已離開有效條件後，平倉成交仍立即假反手。
        v23 起一律切斷；只有平倉委託等待期間，由最新 Tick 重新建立並真正 FIRE
        的訊號，才可透過 _capture_fire_during_flat_lock 保存。
        """
        return None

    def _best_tp_reentry_candidate(self, task: Any, st: SimState) -> Optional[ReEntryCandidate]:
        return self._capture_tp_reentry(task, st)

    def _tp_reentry_valid(self, task: Any, st: SimState, candidate: ReEntryCandidate) -> bool:
        return bool(
            st.current_bar
            and not st.session_blocked
            and not candidate.from_chip
            and candidate.session_key == st.session_key
            and candidate.bar_index == st.current_bar.index
            and candidate.seq > 0
        )

    @staticmethod
    def _reentry_candidate_still_fires(candidate: ReEntryCandidate, price: float, avg: float) -> bool:
        """平倉成交回報抵達時，再以最新行情驗證候選仍有效。

        API 平倉委託與成交回報之間存在時間差。即使候選曾於平倉等待期間真正 FIRE，
        成交回報抵達時若價格已退回 Gate 內或 IFB 已回到均線另一側，也不可補進。
        """
        price = float(price or 0.0)
        avg = float(avg or 0.0)
        gate = float(candidate.gate or 0.0)
        if price <= 0 or gate <= 0:
            return False
        direction = 1 if int(candidate.direction) > 0 else -1
        if candidate.kind in ("Cross", "FB"):
            return bool(price > gate if direction > 0 else price < gate)
        if candidate.kind == "IntraFB":
            if avg <= 0:
                return False
            return bool((price > avg and price > gate) if direction > 0 else (price < avg and price < gate))
        return False

    def _try_execute_tp_reentry(self, task: Any, st: SimState, price: float) -> bool:
        """TP 或一般停損平倉完成後，候選仍符合最新行情時才立即再進。"""
        candidate = self._best_tp_reentry_candidate(task, st)
        st.tp_reentry = candidate
        if candidate is None:
            return False
        latest_price = float(getattr(task, "last_price", 0.0) or price or 0.0)
        latest_avg = float(getattr(task, "quote_avg", 0.0) or 0.0)
        if not self._reentry_candidate_still_fires(candidate, latest_price, latest_avg):
            st.tp_reentry = None
            st.need_new_signal = True
            return False
        st.tp_reentry = None
        return self.set_target(
            task,
            candidate.direction * int(getattr(task, "lots", 1)),
            latest_price,
            self._reason_from_kind(candidate.kind, candidate.direction),
            "價格｜" + candidate.kind,
            "平倉後同根新訊號仍有效再進",
            from_chip=False,
            arm_seq=candidate.seq,
        )

    def _trigger_tp(self, task: Any, st: SimState, price: float, reason: str = "停利平倉") -> bool:
        status = "浮盈回檔平倉" if str(reason) in ("浮盈回檔平倉", "浮盈回檔保底出場", "浮盈回檔出場") else "停利平倉"
        st.tp_flat_arm_base = st.arm_seq
        # v23：TP 成立時，一律切斷平倉前留下的舊 Pending 與舊候選。
        # 實單平倉尚未成交期間，後續最新 Tick 仍可重新 ARM / FIRE，再保存為有效候選。
        st.tp_reentry = None
        self._clear_pending(st)
        st.intra_seen_above = False
        st.intra_seen_below = False
        st.need_new_signal = True
        st.tp_flat_lock = True
        st.risk_status = status
        st.flat_reason = status
        return self.set_target(task, 0, price, status, "Risk", status, from_chip=False)

    def _apply_force_flat(self, task: Any, st: SimState, price: float) -> bool:
        # 已先由其他本時段出場機制鎖住時，保留原本原因，不以時間到文字覆蓋。
        if not st.session_blocked:
            self._mark_strategy_exit_lock(st, "時間到強制出場", "時間到強制出場")
        if st.position:
            reason = st.flat_reason or "時間到強制出場"
            signal = st.risk_status or "時間到強制出場"
            if not st.force_summary_sent:
                self._emit_event(task, "force_flat", "原因：已到本時段收盤強制出場時間")
                st.force_summary_sent = True
            return self.set_target(task, 0, price, reason, "ForceFlat", signal)
        return True

    def _apply_risk(self, task: Any, st: SimState, price: float, dt: datetime, reverse_fire: Optional[Pending]) -> bool:
        if st.position == 0:
            return False
        profile = _profile(task)
        risk_float = self._tp_sl_float_value(task, st)
        risk_total = self._risk_total_value(task, st)
        self._normalize_legacy_lock_profit_units(task, st, risk_total)
        if st.lock_profit_reset_pending:
            # 暫停或重啟時仍持倉：以最新規則重新建立鎖利追蹤，不改變重啟門檻種類。
            st.lock_profit_cycle_base = float(risk_total)
            st.lock_profit_reset_pending = False
            st.lock_profit_armed = False
            st.lock_profit_high = 0.0
            st.lock_profit_mode = ""
        profit_track_total = self._profit_exit_track_value(task, st, risk_total)
        loss_check_value = self._loss_exit_cycle_value(task, st, risk_total)
        st.tp_peak = max(float(st.tp_peak), float(risk_float))
        st.lock_profit_high = max(float(st.lock_profit_high), float(profit_track_total))


        if profile.kind == "TAI" or _is_three_ma_profile(profile):
            # 認賠下車：只有「認賠下車後重啟」才看新增虧損；其他情況看最終總損益。
            # v042 Backtester：認賠/賺飽門檻固定使用新台幣淨損益；MA策略 不啟用台指原策略的開盤鎖利特規。
            loss_limit = abs(_f(getattr(task, "loss_exit", 0.0), 0.0))
            exit_status = ""
            event_key = ""
            if loss_limit > 0 and loss_check_value <= -loss_limit:
                exit_status = "認賠下車出場"
                event_key = "loss_exit"
            if exit_status:
                st.session_stop_hit = True
                self._mark_strategy_exit_lock(st, exit_status, exit_status)
                base_text = self._restart_base_text(st, "元", loss_check_value) if str(st.restart_exit_kind or "") == "loss" else ""
                reason_text = "重啟後新增虧損已達認賠下車門檻" if str(st.restart_exit_kind or "") == "loss" else "累積損益已達認賠下車門檻"
                self._emit_event(task, event_key, f"總損益：{risk_total:.0f} 元{base_text}\n原因：{reason_text}")
                return self.set_target(task, 0, price, exit_status, "Risk", exit_status)
            if st.session_stop_hit:
                status = _canonical_exit_status(st.risk_status or st.flat_reason, realized_value=risk_total) or "認賠下車出場"
                self._mark_strategy_exit_lock(st, status, status)
                return self.set_target(task, 0, price, status, "Risk", status)

            # 鎖利只看按下「重啟」後的新輪次；一般鎖利出場統一稱為「賺飽下車出場」。
            threshold = abs(_f(getattr(task, "lock_profit_exit", 0.0), 0.0))
            mode = "一般鎖利"
            if profile.kind == "TAI" and profile.tai_open20_special and _open20_active(dt) and profile.tai_open20_lock_profit > 0:
                threshold = profile.tai_open20_lock_profit
                mode = "開盤鎖利"
            qualified = bool(threshold > 0 and st.lock_profit_high >= threshold)
            if not qualified:
                # XQ：離開指定開盤鎖利時段後，立即改用一般門檻；未達一般門檻時不可保留先前資格。
                st.lock_profit_armed = False
                st.lock_profit_mode = ""
            else:
                if not st.lock_profit_armed or st.lock_profit_mode != mode:
                    st.lock_profit_armed = True
                    st.lock_profit_mode = mode
                    key = "open_lock_profit_ready" if mode == "開盤鎖利" else "lock_profit_ready"
                    ready_name = "重啟後最高新增獲利" if str(st.restart_exit_kind or "") == "profit" else "本輪最高總損益"
                    self._emit_event(task, key, f"{ready_name}：{st.lock_profit_high:.0f} 元｜門檻：{threshold:.0f} 元")
                if mode == "開盤鎖利":
                    st.risk_status = "開盤鎖利啟動"
                if profit_track_total <= floor(st.lock_profit_high * 0.8):
                    status = "開盤鎖利出場" if mode == "開盤鎖利" else "賺飽下車出場"
                    self._mark_strategy_exit_lock(st, status, status)
                    key = "open_lock_profit_exit" if mode == "開盤鎖利" else "lock_profit_exit"
                    pullback = max(0.0, float(st.lock_profit_high) - float(profit_track_total))
                    trigger_text = "開盤鎖利出場" if mode == "開盤鎖利" else "賺飽下車"
                    if str(st.restart_exit_kind or "") == "profit" and mode != "開盤鎖利":
                        detail = (
                            f"重啟基準：{float(st.restart_exit_base):.0f} 元\n"
                            f"重啟後最高新增獲利：{st.lock_profit_high:.0f} 元\n"
                            f"回吐金額：{pullback:.0f} 元\n"
                            f"出場時重啟後新增獲利：{profit_track_total:.0f} 元\n"
                            f"出場時總損益：{risk_total:.0f} 元\n"
                            f"原因：最高獲利回吐 20%，已觸發{trigger_text}"
                        )
                    else:
                        detail = (
                            f"最高總損益：{st.lock_profit_high:.0f} 元\n"
                            f"回吐金額：{pullback:.0f} 元\n"
                            f"出場時總損益：{profit_track_total:.0f} 元\n"
                            f"原因：最高獲利回吐 20%，已觸發{trigger_text}"
                        )
                    self._emit_event(task, key, detail)
                    return self.set_target(task, 0, price, status, "Risk", status)
            # 同一 Tick 若已有真正 FIRE 的反向價格訊號，反手優先於單筆 TP / SL。
            # 累積認賠、賺飽與鎖利出場仍維持更高優先級。
            if reverse_fire is not None:
                return self._execute_price_fire(task, st, reverse_fire, price)
            self._update_tp_line(task, st)
            if mode == "開盤鎖利" and st.lock_profit_armed:
                st.risk_status = "開盤鎖利啟動"
            if self._tp_hit(st, price):
                self._emit_event(task, "take_profit_exit", f"浮盈高點：{st.tp_peak:.0f} 點｜保底：{st.tp_line:.0f} 點")
                return self._trigger_tp(task, st, price, "停利平倉")
            stop = abs(_f(getattr(task, "stop_loss", 0.0), 0.0))
            if stop > 0 and risk_float <= -stop:
                if reverse_fire is not None:
                    return self._execute_price_fire(task, st, reverse_fire, price)
                st.sl_flat_arm_base = st.arm_seq
                st.sl_flat_lock = True
                # 停損平倉後只接受鎖啟動後新 ARM / 新 FIRE；禁止沿用停損前舊 Pending。
                st.tp_reentry = None
                self._clear_pending(st)
                st.intra_seen_above = False
                st.intra_seen_below = False
                st.need_new_signal = True
                st.risk_status = "停損平倉"
                st.flat_reason = "停損平倉"
                self._emit_event(task, "stop_loss_exit", f"浮盈：{risk_float:.0f} 點")
                return self.set_target(task, 0, price, "停損平倉", "Risk", "停損平倉")
            return False

        # 股期：策略訊號照舊；認賠/賺飽門檻 v042 Backtester 固定使用新台幣淨損益。
        loss_limit = abs(_f(getattr(task, "loss_exit", 0.0), 0.0))
        if loss_limit > 0 and loss_check_value <= -loss_limit:
            st.session_stop_hit = True
            self._mark_strategy_exit_lock(st, "認賠下車出場", "認賠下車出場")
            base_text = self._restart_base_text(st, "元", loss_check_value) if str(st.restart_exit_kind or "") == "loss" else ""
            reason_text = "重啟後新增虧損已達認賠下車門檻" if str(st.restart_exit_kind or "") == "loss" else "累積損益已達認賠下車門檻"
            self._emit_event(task, "loss_exit", f"總損益：{risk_total:.0f} 元{base_text}\n原因：{reason_text}")
            return self.set_target(task, 0, price, "認賠下車出場", "Risk", "認賠下車出場")
        threshold = abs(_f(getattr(task, "lock_profit_exit", 0.0), 0.0))
        if threshold > 0 and st.lock_profit_high >= threshold:
            if not st.lock_profit_armed:
                st.lock_profit_armed = True
                st.lock_profit_mode = "一般鎖利"
                ready_name = "重啟後最高新增獲利" if str(st.restart_exit_kind or "") == "profit" else "本輪最高總損益"
                self._emit_event(task, "lock_profit_ready", f"{ready_name}：{st.lock_profit_high:.0f} 元｜門檻：{threshold:.0f} 元")
            if profit_track_total <= floor(st.lock_profit_high * 0.8):
                self._mark_strategy_exit_lock(st, "賺飽下車出場", "賺飽下車出場")
                pullback = max(0.0, float(st.lock_profit_high) - float(profit_track_total))
                if str(st.restart_exit_kind or "") == "profit":
                    detail = (
                        f"重啟基準：{float(st.restart_exit_base):.0f} 元\n"
                        f"重啟後最高新增獲利：{st.lock_profit_high:.0f} 元\n"
                        f"回吐金額：{pullback:.0f} 元\n"
                        f"出場時重啟後新增獲利：{profit_track_total:.0f} 元\n"
                        f"出場時總損益：{risk_total:.0f} 元\n"
                        "原因：最高獲利回吐 20%，已觸發賺飽下車"
                    )
                else:
                    detail = (
                        f"最高總損益：{st.lock_profit_high:.0f} 元\n"
                        f"回吐金額：{pullback:.0f} 元\n"
                        f"出場時總損益：{profit_track_total:.0f} 元\n"
                        "原因：最高獲利回吐 20%，已觸發賺飽下車"
                    )
                self._emit_event(task, "lock_profit_exit", detail)
                return self.set_target(task, 0, price, "賺飽下車出場", "Risk", "賺飽下車出場")
        # 同一 Tick 若已有真正 FIRE 的反向價格訊號，反手優先於單筆 TP / SL。
        # 累積認賠與賺飽下車仍維持更高優先級。
        if reverse_fire is not None:
            return self._execute_price_fire(task, st, reverse_fire, price)
        # 050A：使用者要求取消股期「浮盈回檔平倉」。
        # 保留停利／停損／反手／認賠下車／賺飽下車；不再用浮盈高點回落到保底值自動平倉。
        self._update_tp_line(task, st)
        if self._tp_hit(st, price):
            self._emit_event(task, "take_profit_exit", f"浮盈高點：{st.tp_peak:.0f} 點｜保底：{st.tp_line:.0f} 點")
            return self._trigger_tp(task, st, price, "停利平倉")
        stop = abs(_f(getattr(task, "stop_loss", 0.0), 0.0))
        if stop > 0 and risk_float <= -stop:
            if reverse_fire is not None:
                return self._execute_price_fire(task, st, reverse_fire, price)
            st.sl_flat_arm_base = st.arm_seq
            st.sl_flat_lock = True
            # 停損平倉後只接受鎖啟動後新 ARM / 新 FIRE；禁止沿用停損前舊 Pending。
            st.tp_reentry = None
            self._clear_pending(st)
            st.intra_seen_above = False
            st.intra_seen_below = False
            st.need_new_signal = True
            st.risk_status = "停損平倉"
            st.flat_reason = "停損平倉"
            self._emit_event(task, "stop_loss_exit", f"浮盈：{risk_float:.0f} 點")
            return self.set_target(task, 0, price, "停損平倉", "Risk", "停損平倉")
        return False

    # ============================================================
    # Tick 主流程
    # ============================================================
    def on_tick(self, task: Any, price: float, avg: float, raw: Any = None) -> None:
        st = self._state(task)
        if not self._task_real_mode(task):
            self._clear_stale_inventory_sync_for_simulation(st)
        price, avg = float(price or 0.0), float(avg or 0.0)
        if price <= 0:
            return
        dt = _tick_datetime(raw)
        st.last_tick_iso = dt.isoformat()
        key, in_session, force_flat = _profile_session(_profile(task), dt)
        if not in_session:
            if not st.session_blocked:
                st.risk_status = "非交易時段"
            self._update_pnl(task, st, price)
            self.sync_task(task)
            return
        if st.session_key != key:
            self._reset_session(task, st, key)

        # 台指日／夜盤區段切換：FB / IntraFB 不可跨日夜盤；Cross 依 XQ 母版保留。
        if _profile(task).kind in ("TAI", "THREE_MA_TAI"):
            self._sync_tai_open_segment(st, dt)

        bar_key = _bar_key_for_task(task, dt)
        is_new_bar = st.current_bar is None or st.current_bar.key != bar_key
        if is_new_bar:
            self._start_new_bar(task, st, price, avg, dt)
        elif st.current_bar:
            st.current_bar.update(price, avg)
        self._update_pnl(task, st, price)

        # 盤中啟動第一筆 Tick 只建立參考，不可直接用可能尚未回補完成的均價進場。
        if not st.first_tick_seen:
            st.first_tick_seen = True
            # 若上方 _start_new_bar 已經依重開面板鎖跨過新 K 並解除 boot_allow_event，
            # 不可在同一筆 Tick 又重新加鎖，否則會多等一根甚至卡住。
            if st.current_bar is not None and st.position == 0 and not bool(st.boot_allow_event):
                st.boot_wait_new_bar = True
                st.boot_unlock_bars_remaining = max(int(st.boot_unlock_bars_remaining or 0), 1)
                st.boot_allow_event = False
                st.boot_ref_bar_index = st.current_bar.index
                st.boot_fresh_arm_base = st.arm_seq
                st.boot_fresh_arm_ready = False
                st.quote_avg_ready_seen = False
                st.avg_entry_wait_bar_index = -1
                self._clear_pending(st)

        # 新時段實單先等待券商庫存確認。確認有倉後視為「外部留存」，
        # 接著照一般策略進出；確認空手則由全新空手狀態開始。
        # 庫存尚未確認前，連收盤強平也不可用本機舊狀態送單。
        if (st.session_inventory_sync_pending or st.restart_inventory_sync_pending) and self._task_real_mode(task):
            st.risk_status = "等待券商庫存同步"
            st.last_signal = "等待券商庫存同步"
            st.signal_source = "券商庫存同步"
            self.sync_task(task)
            return

        # 最後一分鐘強平最高優先。
        if force_flat:
            self._apply_force_flat(task, st, price)
            self.sync_task(task)
            return

        # 任何自動出場機制成立後都維持鎖定；不可被第一分鐘或第二根文字覆蓋。
        if st.session_blocked:
            if st.position:
                self.set_target(task, 0, price, st.flat_reason or "本時段禁入平倉", "Risk", st.risk_status or "本時段禁入")
            self.sync_task(task)
            return

        minute = _session_minute(dt)
        # 第一分鐘完全禁止策略自動下單。
        if minute == 0:
            st.risk_status = "第一分鐘禁止自動交易"
            self.sync_task(task)
            return

        if _is_three_ma_profile(_profile(task)):
            self._on_tick_three_ma(task, st, price, dt)
            return

        # 050B：真正開盤第二分鐘只有 OP 進場，而且 OP 必須優先於
        # 「均價剛確認後等下一根」與「啟動等新K棒」保護。
        # 固定只認日盤 08:46、夜盤 15:01；盤中才啟動不補做 OP。
        avg_ready = self._task_quote_avg_ready(task, avg)
        if minute == 1:
            if st.position == 0 and not avg_ready:
                st.quote_avg_ready_seen = False
                st.avg_entry_wait_bar_index = -1
                st.risk_status = "第二根OP等待均價"
                st.last_signal = "第二根OP等待均價"
                st.signal_source = "OP"
            elif st.position == 0:
                st.quote_avg_ready_seen = True
                # 不沿用第一根以前的任何舊 pending；08:46/15:01 只允許 OP。
                self._clear_pending(st)
                self._try_openwait_second_bar(task, st, price, dt)
            if st.position and not st.order_pending:
                self._apply_risk(task, st, price, dt, None)
            self.sync_task(task)
            return

        # 均價尚未完成校正、或盤中啟動後尚未跨過新的 K 棒前，空手不得進場；持倉仍允許風控平倉。
        # 先看均線正不正確，再看是否已解除舊訊號保護；解除後才回到「正常」。
        if st.position == 0 and not avg_ready:
            st.quote_avg_ready_seen = False
            st.avg_entry_wait_bar_index = -1
        if st.position == 0 and (not avg_ready or not st.boot_allow_event):
            if not avg_ready:
                wait_text = "等待均價正確"
                wait_source = "均價回補"
            else:
                wait_text = "等待新K棒"
                wait_source = "新K棒確認"
            st.risk_status = wait_text
            st.last_signal = wait_text
            st.signal_source = wait_source
            self.sync_task(task)
            return

        if st.position == 0 and avg_ready and not bool(st.quote_avg_ready_seen):
            st.quote_avg_ready_seen = True
            # 均價剛確認完成時，仍不可在同一根 K 直接使用既有形態下單。
            # 必須先讓目前這根成為新的參考根，下一根開始才接受真正的新訊號。
            if st.current_bar is not None:
                st.avg_entry_wait_bar_index = int(st.current_bar.index)
            else:
                st.avg_entry_wait_bar_index = -1
            self._clear_pending(st)
            st.need_new_signal = True
            st.intra_seen_above = bool(avg > 0 and price > avg)
            st.intra_seen_below = bool(avg > 0 and price < avg)
            st.risk_status = "正常"
            st.last_signal = "等待新訊號"
            st.signal_source = ""
            self.sync_task(task)
            return

        if st.position == 0 and st.avg_entry_wait_bar_index >= 0:
            current_index = int(st.current_bar.index) if st.current_bar is not None else -1
            if current_index == int(st.avg_entry_wait_bar_index):
                st.risk_status = "正常"
                st.last_signal = "等待新訊號"
                st.signal_source = ""
                self.sync_task(task)
                return
            st.avg_entry_wait_bar_index = -1
            self._clear_pending(st)
            st.need_new_signal = True

        if st.position == 0 and st.risk_status in ("等待新K棒", "等待均價正確", "等待均線回補", "第二根OP等待均價"):
            st.risk_status = "正常"
            st.last_signal = "等待新訊號"
            st.signal_source = ""

        if st.tp_flat_lock:
            if st.position:
                # 實單平倉尚未成交時，Pending 仍可能在同根後續 Tick 才突破 Gate。
                # 這種 FIRE 發生於平倉當根，必須保留，待歸零後立即進場。
                self._capture_fire_during_flat_lock(task, st, price, avg, dt)
                self.set_target(task, 0, price, "TPFlatLock", "Risk", "停利鎖定平倉")
            else:
                self._finish_flat_transition(task, st, price)
            self.sync_task(task)
            return

        if st.sl_flat_lock:
            # XQ：停損平倉尚未成交時仍繼續觀察本根價格訊號。
            # - 反向 FIRE：立即取消單純平倉鎖，直接改送反手目標。
            # - 同向 FIRE：保留為平倉完成後同根可再進候選，平倉目標仍維持 0。
            # - 尚未 FIRE 的 Pending：保留原本 Gate 等待，不可提前清除。
            if st.position:
                self._arm_intrabar(task, st, price, avg, dt)
                winner = self._fire_winner(task, st, price, avg, dt)
                if winner is not None and winner.seq <= int(st.sl_flat_arm_base or 0):
                    winner = None
                if winner is not None and st.position * winner.direction < 0:
                    st.sl_flat_lock = False
                    self._execute_price_fire(task, st, winner, price)
                else:
                    if winner is not None and st.position * winner.direction > 0:
                        self._remember_same_bar_reentry(st, winner.kind, winner.direction, winner.seq, from_chip=False, gate=winner.gate)
                        self._clear_pending(st)
                        st.intra_seen_above = False
                        st.intra_seen_below = False
                        st.need_new_signal = True
                    self.set_target(task, 0, price, "SLFlatLock", "Risk", "停損鎖定平倉")
            else:
                self._finish_flat_transition(task, st, price)
            self.sync_task(task)
            return

        self._arm_intrabar(task, st, price, avg, dt)
        winner = self._fire_winner(task, st, price, avg, dt)
        reverse = winner if winner and st.position and st.position * winner.direction < 0 else None

        # 風控可能在本 tick 先平倉，因此先記住本 tick 已成立、但被同向持倉擋住的價格訊號。
        if winner is not None and st.position * winner.direction > 0:
            self._remember_same_bar_reentry(st, winner.kind, winner.direction, winner.seq, from_chip=False, gate=winner.gate)

        # 先跑風控；停損若同時存在反向價格 FIRE，直接反手。
        if self._apply_risk(task, st, price, dt, reverse):
            self._update_pnl(task, st, price)
            self.sync_task(task)
            return

        # 0611 三份 XQ 母版皆為純價格版，不執行籌碼補進場或籌碼平倉。
        if winner is not None:
            self._execute_price_fire(task, st, winner, price)

        self._update_pnl(task, st, price)
        self.sync_task(task)
