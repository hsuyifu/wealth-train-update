# -*- coding: utf-8 -*-
# 小火車回測器 v034
# 獨立版：可直接讀官方 Daily CSV 或每日 ZIP 壓縮檔；指定商品代號後自動選每日主力月份，直接餵小火車策略核心。

from __future__ import annotations

import csv
import io
import os
import json
import math
import re
import html
import urllib.request
import urllib.error
import urllib.parse
import zipfile
import sqlite3
import hashlib
import pickle
import tempfile
import subprocess
import shutil
import threading
import time as time_module
import itertools
import concurrent.futures
import multiprocessing
import sys
import traceback
from dataclasses import dataclass
from datetime import datetime as RealDateTime, date, time, timedelta
from types import SimpleNamespace
from tkinter import Tk, Toplevel, StringVar, DoubleVar, IntVar, filedialog, messagebox, ttk, BOTH, END
import tkinter.font as tkfont

import strategy_core

# ---------------------------------------------------------------------
# 讓 strategy_core 內部 datetime.now() 使用回測 tick 時間。
# ---------------------------------------------------------------------
_CURRENT_BACKTEST_DT = RealDateTime.now()

class BacktestDateTime(RealDateTime):
    @classmethod
    def now(cls, tz=None):
        if tz is not None:
            try:
                return _CURRENT_BACKTEST_DT.astimezone(tz)
            except Exception:
                return _CURRENT_BACKTEST_DT
        return _CURRENT_BACKTEST_DT

strategy_core.datetime = BacktestDateTime

def _tick_datetime_patch(raw=None, now=None):
    # 回測熱路徑最佳化：feed() 直接把 datetime 當 raw 傳進來，
    # 避免每筆 tick 建立 SimpleNamespace / 字串 MatchTime，275 組回測可省掉大量物件配置。
    if isinstance(raw, RealDateTime):
        return raw
    dt = getattr(raw, "BacktestDateTime", None)
    if isinstance(dt, RealDateTime):
        return dt
    return BacktestDateTime.now()

strategy_core._tick_datetime = _tick_datetime_patch


# 回測專用：策略核心每筆 tick 會多次呼叫 _profile(task)。
# task 的策略在單組回測期間不會改變，因此把 profile 直接掛在 task 上，減少字串判斷成本。
_STRATEGY_CORE_PROFILE_ORIG = getattr(strategy_core, "_profile", None)

def _strategy_core_profile_fast(task):
    prof = getattr(task, "_bt_profile", None)
    if prof is not None:
        return prof
    if callable(_STRATEGY_CORE_PROFILE_ORIG):
        return _STRATEGY_CORE_PROFILE_ORIG(task)
    text = str(getattr(task, "strategy", "") or "")
    if "台指" in text:
        return strategy_core.PROFILES["台指期策略"]
    if "小股" in text:
        return strategy_core.PROFILES["小股期策略"]
    return strategy_core.PROFILES["大股期策略"]

strategy_core._profile = _strategy_core_profile_fast

# ---------------------------------------------------------------------
# 官方 Daily CSV 欄位
# ---------------------------------------------------------------------
HEADER_ALIASES = {
    "trade_date": ["成交日期", "日期", "交易日期", "date"],
    "product_code": ["商品代號", "商品", "代號", "product", "product_code"],
    "month": ["到期月份(週別)", "到期月份", "月份", "contract", "month"],
    "trade_time": ["成交時間", "時間", "time"],
    "price": ["成交價格", "價格", "price"],
    "qty": ["成交數量(B+S)", "成交數量", "數量", "volume", "qty"],
}

@dataclass
class ProductOption:
    code: str
    display: str
    total_rows: int
    total_qty: float
    primary_month: str
    months: str
    first_dt: RealDateTime | None
    last_dt: RealDateTime | None
    data_days: int = 0
    date_start: date | None = None
    date_end: date | None = None
    missing_dates: str = ""
    avg_daily_qty: float = 0.0
    last_price: float = 0.0
    product_kind: str = "UNKNOWN"
    stock_no: str = ""
    stock_name: str = ""
    margin_percent: float = 0.0
    base_margin: float = 0.0

@dataclass
class OfficialTick:
    dt: RealDateTime
    d: date
    price: float
    qty: float
    avg: float
    code: str
    month: str
    session_key: str
    session_label: str


def norm_header(x):
    return str(x or "").strip().lower().replace(" ", "").replace("_", "")


TEXT_EXTS = (".csv", ".rpt", ".txt")

APP_VERSION = "v049"
TAIFEX_STOCK_MARGIN_URL = "https://www.taifex.com.tw/cht/5/stockMargining"
EXCLUDE_UNDERLYING_STOCKS = {"2330", "2303"}  # 台積電、聯電

THREE_MA_STRATEGY_DISPLAY = "MA策略"
TRAIN_STRATEGY_DISPLAY = "小火車策略"
STRATEGY_MODE_VALUES = [TRAIN_STRATEGY_DISPLAY, THREE_MA_STRATEGY_DISPLAY]
MA_PERIOD_VALUES = ["3", "5", "10"]
K_MINUTE_VALUES = ["1", "5", "10"]

# ---------------------------------------------------------------------
# 小火車回測器線上更新
# ---------------------------------------------------------------------
# 更新 manifest 支援 JSON 欄位：
# {
#   "app": "TrainBacktester",
#   "version": "v039",
#   "package_url": "train_backtester_v039_safe_update_patch.zip",
#   "sha256": "...",
#   "title": "...",
#   "message": "...",
#   "required": false
# }
# package_url 可為絕對網址，也可為相對 manifest 所在目錄的檔名。
BACKTESTER_UPDATE_URL_FILE = "backtester_update_url.txt"
BACKTESTER_DEFAULT_UPDATE_MANIFEST_URLS = [
    "https://hsuyifu.github.io/wealth-train-update/backtester/backtester_update.json",
    "https://hsuyifu.github.io/KGI_AutoTrader/backtester_update.json",
    "https://hsuyifu.github.io/KGI_AutoTrader/train_backtester_update.json",
]


def is_three_ma_strategy(strategy_name):
    raw = str(strategy_name or "").strip()
    text = raw.upper().replace(" ", "")
    return raw == "MA策略" or "MA策略" in raw or ("3" + "MA") in text or any(token in text for token in ("5MA", "10MA"))

def normalize_ma_period(value):
    text = str(value or "3").upper().replace("分", "").replace("K", "").replace(" ", "").replace("策略", "").replace("MA", "")
    try:
        n = int(float(text))
    except Exception:
        n = 3
    return n if n in (3, 5, 10) else 3

def normalize_k_minutes(value):
    try:
        k = int(float(str(value or "1").strip()))
    except Exception:
        k = 1
    # MA策略 策略核心目前只支援 1 / 5 / 10 分 K；異常值回 1 分 K，避免畫面顯示與實際回測不一致。
    return k if k in (1, 5, 10) else 1

class OperationCancelled(Exception):
    pass

def app_dir():
    try:
        return os.path.dirname(os.path.abspath(__file__))
    except Exception:
        return os.getcwd()

def cache_dir():
    d = os.path.join(app_dir(), "data_cache")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d

def logs_dir():
    d = os.path.join(app_dir(), "logs")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return d


def startup_log_path():
    return os.path.join(logs_dir(), "backtester_startup_log.txt")


def log_startup(message):
    try:
        with open(startup_log_path(), "a", encoding="utf-8") as f:
            f.write("[%s] %s\n" % (RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"), str(message)))
    except Exception:
        pass



def _version_key(value):
    """把 v039 / 2026.06.22.039 轉成可比較的數字 tuple。"""
    nums = re.findall(r"\d+", str(value or ""))
    if not nums:
        return (0,)
    try:
        return tuple(int(x) for x in nums)
    except Exception:
        return (0,)


def _is_newer_version(remote_version, local_version=APP_VERSION):
    rv = _version_key(remote_version)
    lv = _version_key(local_version)
    n = max(len(rv), len(lv))
    rv = rv + (0,) * (n - len(rv))
    lv = lv + (0,) * (n - len(lv))
    return rv > lv


def _read_update_url_file():
    urls = []
    p = os.path.join(app_dir(), BACKTESTER_UPDATE_URL_FILE)
    if not os.path.exists(p):
        return urls
    try:
        with open(p, "r", encoding="utf-8") as f:
            for line in f:
                text = str(line or "").strip()
                if not text or text.startswith("#") or text.startswith("//"):
                    continue
                urls.append(text)
    except Exception as exc:
        log_startup("Read update url file failed: %s" % exc)
    return urls


def backtester_update_manifest_urls():
    urls = []
    env = str(os.environ.get("TRAIN_BACKTESTER_UPDATE_MANIFEST_URL", "") or "").strip()
    if env:
        urls.append(env)
    urls.extend(_read_update_url_file())
    # 保留預設候選；若網址不存在，啟動時靜默略過，手動檢查時會顯示原因。
    urls.extend(BACKTESTER_DEFAULT_UPDATE_MANIFEST_URLS)
    out = []
    seen = set()
    for u in urls:
        u = str(u or "").strip()
        if not u or u in seen:
            continue
        if not (u.lower().startswith("http://") or u.lower().startswith("https://")):
            continue
        seen.add(u)
        out.append(u)
    return out


def _http_get_bytes(url, timeout=20, progress=None):
    req = urllib.request.Request(str(url), headers={
        "User-Agent": "TrainBacktester/%s" % APP_VERSION,
        "Cache-Control": "no-cache",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        total = 0
        try:
            total = int(resp.headers.get("Content-Length") or 0)
        except Exception:
            total = 0
        chunks = []
        done = 0
        while True:
            chunk = resp.read(1024 * 256)
            if not chunk:
                break
            chunks.append(chunk)
            done += len(chunk)
            if progress:
                try:
                    progress(done, total or max(done, 1), "下載 %.1f MB" % (done / 1024 / 1024), stage="下載更新")
                except Exception:
                    pass
        return b"".join(chunks)


def fetch_update_manifest(url):
    raw = _http_get_bytes(url, timeout=12)
    try:
        text = raw.decode("utf-8-sig")
    except Exception:
        text = raw.decode("utf-8", errors="replace")
    data = json.loads(text)
    if not isinstance(data, dict):
        raise ValueError("更新 manifest 格式不是 JSON 物件")
    return data


def _manifest_package_url(manifest, manifest_url):
    for key in ("package_url", "patch_url", "url", "download_url"):
        value = str((manifest or {}).get(key) or "").strip()
        if value:
            return urllib.parse.urljoin(str(manifest_url), value)
    raise ValueError("更新 manifest 缺少 package_url")


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_update_relative_name(name):
    n = str(name or "").replace("\\", "/").strip()
    while n.startswith("./"):
        n = n[2:]
    if not n or n.endswith("/"):
        return ""
    parts = [x for x in n.split("/") if x]
    if not parts:
        return ""
    if any(x in (".", "..") for x in parts):
        raise ValueError("更新包含不安全路徑：%s" % name)
    if n.startswith("/") or re.match(r"^[A-Za-z]:", n):
        raise ValueError("更新包含絕對路徑：%s" % name)
    lowered = [x.lower() for x in parts]
    if "__pycache__" in lowered or parts[-1].lower().endswith((".pyc", ".pyo")):
        return ""
    if lowered[0] in ("data_cache", "logs", "update_backups"):
        return ""
    return "/".join(parts)


def _zip_common_root_to_strip(names):
    clean = []
    for n in names:
        try:
            rn = _safe_update_relative_name(n)
        except Exception:
            continue
        if rn:
            clean.append(rn)
    if not clean:
        return ""
    first_parts = [x.split("/", 1)[0] for x in clean]
    root = first_parts[0]
    if not root or any(x != root for x in first_parts):
        return ""
    # 若壓縮包是一層資料夾包住完整檔案，更新時自動剝掉外層資料夾。
    root_lower = root.lower()
    if root_lower in ("train_backtester", "backtester", "release", "update", "小火車回測器", "新增資料夾") or root.startswith("#U"):
        return root + "/"
    return ""


def apply_update_zip(zip_path, progress=None):
    target_dir = app_dir()
    if not zipfile.is_zipfile(zip_path):
        raise ValueError("下載檔不是有效 ZIP：%s" % zip_path)
    stamp = RealDateTime.now().strftime("%Y%m%d_%H%M%S")
    backup_dir = os.path.join(target_dir, "update_backups", "%s_%s" % (APP_VERSION, stamp))
    temp_dir = tempfile.mkdtemp(prefix="train_backtester_update_extract_")
    extracted = []
    try:
        with zipfile.ZipFile(zip_path, "r") as zf:
            strip_prefix = _zip_common_root_to_strip([x.filename for x in zf.infolist()])
            members = [x for x in zf.infolist() if not x.is_dir()]
            total = max(1, len(members))
            for idx, info in enumerate(members, start=1):
                rel = _safe_update_relative_name(info.filename)
                if not rel:
                    continue
                if strip_prefix and rel.startswith(strip_prefix):
                    rel = rel[len(strip_prefix):]
                rel = _safe_update_relative_name(rel)
                if not rel:
                    continue
                src = zf.open(info, "r")
                dst = os.path.join(temp_dir, *rel.split("/"))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                with src, open(dst, "wb") as f:
                    shutil.copyfileobj(src, f)
                extracted.append(rel)
                if progress:
                    progress(idx, total, "解壓 %s" % rel, stage="套用更新")
        if not extracted:
            raise ValueError("更新包沒有可套用的檔案")
        total = max(1, len(extracted))
        for idx, rel in enumerate(extracted, start=1):
            src = os.path.join(temp_dir, *rel.split("/"))
            dst = os.path.join(target_dir, *rel.split("/"))
            if os.path.exists(dst):
                bak = os.path.join(backup_dir, *rel.split("/"))
                os.makedirs(os.path.dirname(bak), exist_ok=True)
                try:
                    shutil.copy2(dst, bak)
                except Exception:
                    shutil.copy(dst, bak)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            try:
                shutil.copy2(src, dst)
            except Exception:
                shutil.copy(src, dst)
            if progress:
                progress(idx, total, "覆蓋 %s" % rel, stage="套用更新")
        return {"updated_files": extracted, "backup_dir": backup_dir}
    finally:
        try:
            shutil.rmtree(temp_dir, ignore_errors=True)
        except Exception:
            pass


def download_and_apply_update_manifest(manifest, manifest_url, progress=None):
    pkg_url = _manifest_package_url(manifest, manifest_url)
    tmp_dir = tempfile.mkdtemp(prefix="train_backtester_update_download_")
    try:
        zip_path = os.path.join(tmp_dir, "update.zip")
        raw = _http_get_bytes(pkg_url, timeout=60, progress=progress)
        with open(zip_path, "wb") as f:
            f.write(raw)
        expected_sha = str((manifest or {}).get("sha256") or "").strip().lower()
        actual_sha = _sha256_file(zip_path)
        if expected_sha and actual_sha.lower() != expected_sha:
            raise ValueError("更新包 SHA256 不一致，已停止更新。\n預期：%s\n實際：%s" % (expected_sha, actual_sha))
        result = apply_update_zip(zip_path, progress=progress)
        result["package_url"] = pkg_url
        result["sha256"] = actual_sha
        return result
    finally:
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass

def _parse_geometry_bounds(geo):
    """Return (width, height, x, y) for Tk geometry like 1440x850+0+0."""
    m = re.match(r"^\s*(\d+)x(\d+)([+-]\d+)([+-]\d+)\s*$", str(geo or ""))
    if not m:
        return None
    try:
        return int(m.group(1)), int(m.group(2)), int(m.group(3)), int(m.group(4))
    except Exception:
        return None


def _default_root_geometry(root, width=1440, height=850):
    try:
        sw = max(800, int(root.winfo_screenwidth() or 1440))
        sh = max(600, int(root.winfo_screenheight() or 850))
        w = min(int(width), max(760, sw - 80))
        h = min(int(height), max(560, sh - 80))
        x = max(0, int((sw - w) / 2))
        y = max(0, int((sh - h) / 2))
        return "%dx%d+%d+%d" % (w, h, x, y)
    except Exception:
        return "1200x760+20+20"


def _geometry_is_visible_on_screen(root, geo):
    bounds = _parse_geometry_bounds(geo)
    if not bounds:
        return False
    w, h, x, y = bounds
    if w < 360 or h < 260:
        return False
    try:
        sw = int(root.winfo_screenwidth() or 0)
        sh = int(root.winfo_screenheight() or 0)
    except Exception:
        sw, sh = 0, 0
    if sw <= 0 or sh <= 0:
        return True
    # At least a practical area must remain reachable inside the current remote desktop.
    visible_w = min(x + w, sw) - max(x, 0)
    visible_h = min(y + h, sh) - max(y, 0)
    return visible_w >= 220 and visible_h >= 160

def margin_master_path():
    return os.path.join(cache_dir(), "taifex_stock_margin_master.json")

def ticks_cache_db_path():
    return os.path.join(cache_dir(), "ticks_cache.db")

def product_summary_cache_path():
    return os.path.join(cache_dir(), "product_summary_cache.json")

def ui_settings_path():
    return os.path.join(cache_dir(), "ui_settings.json")

def load_ui_settings():
    p = ui_settings_path()
    if not os.path.exists(p):
        return {}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}

def save_ui_settings(data):
    try:
        os.makedirs(cache_dir(), exist_ok=True)
        tmp = ui_settings_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data if isinstance(data, dict) else {}, f, ensure_ascii=False, indent=2)
        os.replace(tmp, ui_settings_path())
    except Exception:
        pass


def _option_to_json(opt):
    data = {}
    for key in ProductOption.__dataclass_fields__:
        v = getattr(opt, key, None)
        if isinstance(v, RealDateTime):
            data[key] = {"__type__": "datetime", "value": v.isoformat()}
        elif isinstance(v, date):
            data[key] = {"__type__": "date", "value": v.isoformat()}
        else:
            data[key] = v
    # 熱門排名是執行期附加欄位，不在 dataclass 內，也一併保存。
    data["hot_rank"] = int(getattr(opt, "hot_rank", 0) or 0)
    data["hot_status"] = str(getattr(opt, "hot_status", "") or "")
    return data

def _option_from_json(data):
    if not isinstance(data, dict):
        return None
    kwargs = {}
    for key in ProductOption.__dataclass_fields__:
        v = data.get(key)
        if isinstance(v, dict) and v.get("__type__") == "datetime":
            try:
                v = RealDateTime.fromisoformat(str(v.get("value") or ""))
            except Exception:
                v = None
        elif isinstance(v, dict) and v.get("__type__") == "date":
            try:
                v = date.fromisoformat(str(v.get("value") or ""))
            except Exception:
                v = None
        kwargs[key] = v
    try:
        opt = ProductOption(**kwargs)
        opt.hot_rank = int(data.get("hot_rank", 0) or 0)
        opt.hot_status = str(data.get("hot_status", "") or "")
        return opt
    except Exception:
        return None

def save_product_summary_cache(options):
    try:
        payload = {
            "version": APP_VERSION,
            "saved_at": RealDateTime.now().isoformat(timespec="seconds"),
            "db_path": ticks_cache_db_path(),
            "options": [_option_to_json(o) for o in (options or [])],
        }
        tmp = product_summary_cache_path() + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False, indent=2)
        os.replace(tmp, product_summary_cache_path())
    except Exception:
        pass

def load_product_summary_cache():
    p = product_summary_cache_path()
    if not os.path.exists(p):
        return []
    try:
        with open(p, "r", encoding="utf-8") as f:
            payload = json.load(f)
        opts = [_option_from_json(x) for x in (payload.get("options", []) or [])]
        return [o for o in opts if o is not None]
    except Exception:
        return []

def db_connect():
    conn = sqlite3.connect(ticks_cache_db_path())
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA temp_store=MEMORY")
    return conn


def init_tick_cache_db():
    conn = db_connect()
    try:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS source_files (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_key TEXT UNIQUE,
                path TEXT,
                member TEXT,
                display TEXT,
                size INTEGER,
                mtime REAL,
                crc TEXT,
                sha256 TEXT,
                imported_at TEXT,
                rows_total INTEGER DEFAULT 0,
                rows_inserted INTEGER DEFAULT 0
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS ticks (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source_file_id INTEGER NOT NULL,
                code TEXT NOT NULL,
                month TEXT NOT NULL,
                dt TEXT NOT NULL,
                trade_date TEXT NOT NULL,
                price REAL NOT NULL,
                qty REAL NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS primary_months (
                source_file_id INTEGER NOT NULL,
                code TEXT NOT NULL,
                primary_month TEXT NOT NULL,
                rows_count INTEGER DEFAULT 0,
                qty_sum REAL DEFAULT 0,
                PRIMARY KEY (source_file_id, code)
            )
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticks_code_date ON ticks(code, trade_date)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticks_code_dt ON ticks(code, dt)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_ticks_source_code_month ON ticks(source_file_id, code, month)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_pm_source_code ON primary_months(source_file_id, code)")
        conn.commit()
    finally:
        conn.close()


def cache_has_any_ticks():
    init_tick_cache_db()
    conn = db_connect()
    try:
        row = conn.execute("SELECT COUNT(1) FROM ticks LIMIT 1").fetchone()
        return bool(row and int(row[0] or 0) > 0)
    finally:
        conn.close()


def cache_has_code(code):
    init_tick_cache_db()
    conn = db_connect()
    try:
        row = conn.execute("SELECT COUNT(1) FROM ticks WHERE code=? LIMIT 1", (clean_code(code),)).fetchone()
        return bool(row and int(row[0] or 0) > 0)
    finally:
        conn.close()


def _quick_source_key(info):
    path = os.path.abspath(str(info.get("path") or ""))
    member = str(info.get("member") or "")
    return "%s::%s" % (path, member) if member else path


def _open_info_text_stream(info):
    if info.get("is_zip"):
        zf = zipfile.ZipFile(info["path"], "r")
        f = _zip_text_stream(zf, info["member"])
        # 讓呼叫端 close 文字流時，也關閉 zipfile。
        old_close = f.close
        def _close():
            try:
                old_close()
            finally:
                try:
                    zf.close()
                except Exception:
                    pass
        f.close = _close
        return f
    return open_csv_rows(info["path"])


def _source_fingerprint(info):
    path = str(info.get("path") or "")
    member = str(info.get("member") or "")
    size = int(info.get("size") or 0)
    mtime = float(info.get("mtime") or 0.0)
    crc = str(info.get("crc") or "")
    # SHA256 只在檔案不大或 ZIP member 需要穩定識別時算；已匯入過且大小/mtime/CRC一樣會先略過。
    h = hashlib.sha256()
    try:
        if info.get("is_zip"):
            with zipfile.ZipFile(path, "r") as zf, zf.open(member, "r") as bf:
                for chunk in iter(lambda: bf.read(1024 * 1024), b""):
                    h.update(chunk)
        else:
            with open(path, "rb") as bf:
                for chunk in iter(lambda: bf.read(1024 * 1024), b""):
                    h.update(chunk)
        sha = h.hexdigest()
    except Exception:
        sha = ""
    return size, mtime, crc, sha


def _date_from_text(x):
    if isinstance(x, date) and not isinstance(x, RealDateTime):
        return x
    s = str(x or "").strip()
    if not s:
        return None
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%Y%m%d"):
        try:
            return RealDateTime.strptime(s, fmt).date()
        except Exception:
            pass
    return None


def _date_text(d):
    if isinstance(d, date):
        return d.strftime("%Y-%m-%d")
    return str(d or "")


def import_sources_to_cache(paths, progress=None):
    """把官方 Daily ZIP/CSV 增量匯入 SQLite。已匯入且未變更的來源會略過；同路徑內容變更則先刪後重匯。"""
    init_tick_cache_db()
    infos = daily_source_infos(paths)
    if not infos:
        raise ValueError("沒有可匯入的官方 Daily CSV/ZIP。")
    total_units = sum(max(1, int(i.get("size", 1))) for i in infos) or 1
    done_units = 0
    imported = skipped = replaced = inserted_total = 0
    source_total = len(infos)
    conn = db_connect()
    try:
        for idx, info in enumerate(infos, start=1):
            source_key = _quick_source_key(info)
            size0 = int(info.get("size") or 0)
            mtime0 = float(info.get("mtime") or 0.0)
            crc0 = str(info.get("crc") or "")
            row = conn.execute("SELECT id, size, mtime, crc, sha256 FROM source_files WHERE source_key=?", (source_key,)).fetchone()
            if row and int(row[1] or 0) == size0 and abs(float(row[2] or 0.0) - mtime0) < 0.0001 and str(row[3] or "") == crc0:
                skipped += 1
                done_units += max(1, size0)
                _safe_progress(progress, done_units, total_units, "第 %d/%d 檔已匯入，略過｜%s" % (idx, source_total, info.get("display", "")))
                continue
            # 內容可能變更：算 SHA 後再確認；若不同或缺舊 SHA，就覆蓋該來源。
            size, mtime, crc, sha = _source_fingerprint(info)
            row = conn.execute("SELECT id, sha256 FROM source_files WHERE source_key=?", (source_key,)).fetchone()
            if row and sha and str(row[1] or "") == sha:
                # SHA 一樣但 mtime 不同，更新 metadata 後略過。
                conn.execute("UPDATE source_files SET size=?, mtime=?, crc=?, sha256=? WHERE id=?", (size, mtime, crc, sha, int(row[0])))
                conn.commit()
                skipped += 1
                done_units += max(1, size0)
                _safe_progress(progress, done_units, total_units, "第 %d/%d 檔內容相同，略過｜%s" % (idx, source_total, info.get("display", "")))
                continue
            if row:
                sid_old = int(row[0])
                conn.execute("DELETE FROM ticks WHERE source_file_id=?", (sid_old,))
                conn.execute("DELETE FROM primary_months WHERE source_file_id=?", (sid_old,))
                conn.execute("DELETE FROM source_files WHERE id=?", (sid_old,))
                conn.commit()
                replaced += 1
            cur = conn.execute(
                "INSERT INTO source_files(source_key,path,member,display,size,mtime,crc,sha256,imported_at,rows_total,rows_inserted) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (source_key, os.path.abspath(str(info.get("path") or "")), str(info.get("member") or ""), str(info.get("display") or ""), size, mtime, crc, sha,
                 RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"), 0, 0)
            )
            sid = int(cur.lastrowid)
            f = _open_info_text_stream(info)
            month_rows = {}
            month_qty = {}
            tick_rows = []
            total_rows = 0
            inserted_rows = 0
            approx = 0
            try:
                reader = csv.reader(f)
                try:
                    headers = next(reader)
                except StopIteration:
                    headers = []
                if headers:
                    m = map_official_headers(headers)
                    approx += _row_approx_bytes(headers)
                    batch = []
                    for raw_row in reader:
                        total_rows += 1
                        approx += _row_approx_bytes(raw_row)
                        if not raw_row:
                            continue
                        try:
                            code = clean_code(raw_row[m["product_code"]])
                            month = clean_month(raw_row[m["month"]])
                            if not code or not month:
                                continue
                            dt = parse_official_dt(raw_row[m["trade_date"]], raw_row[m["trade_time"]])
                            price = to_float(raw_row[m["price"]], 0.0)
                            qty = to_float(raw_row[m["qty"]], 0.0)
                            if price <= 0 or qty <= 0:
                                continue
                        except Exception:
                            continue
                        month_rows[(code, month)] = month_rows.get((code, month), 0) + 1
                        month_qty[(code, month)] = month_qty.get((code, month), 0.0) + qty
                        batch.append((sid, code, month, dt.strftime("%Y-%m-%d %H:%M:%S"), dt.date().strftime("%Y-%m-%d"), price, qty))
                        if len(batch) >= 5000:
                            conn.executemany("INSERT INTO ticks(source_file_id,code,month,dt,trade_date,price,qty) VALUES(?,?,?,?,?,?,?)", batch)
                            inserted_rows += len(batch)
                            batch.clear()
                            cur_units = done_units + min(max(1, size0), max(1, approx))
                            _safe_progress(progress, cur_units, total_units, "第 %d/%d 檔匯入中｜%s｜%s 筆" % (idx, source_total, info.get("display", ""), f"{inserted_rows:,}"))
                    if batch:
                        conn.executemany("INSERT INTO ticks(source_file_id,code,month,dt,trade_date,price,qty) VALUES(?,?,?,?,?,?,?)", batch)
                        inserted_rows += len(batch)
            finally:
                try:
                    f.close()
                except Exception:
                    pass
            codes = sorted(set(c for c, _m in month_rows.keys()))
            pm_rows = []
            for code in codes:
                normal = [(month_qty.get((code, mo), 0.0), month_rows.get((code, mo), 0), mo) for c, mo in month_rows if c == code and month_is_normal(mo)]
                fallback = [(month_qty.get((code, mo), 0.0), month_rows.get((code, mo), 0), mo) for c, mo in month_rows if c == code]
                cand = normal or fallback
                cand.sort(reverse=True)
                if cand:
                    qty_sum, rows_count, primary = cand[0]
                    pm_rows.append((sid, code, primary, int(rows_count or 0), float(qty_sum or 0.0)))
            if pm_rows:
                conn.executemany("INSERT OR REPLACE INTO primary_months(source_file_id,code,primary_month,rows_count,qty_sum) VALUES(?,?,?,?,?)", pm_rows)
            conn.execute("UPDATE source_files SET rows_total=?, rows_inserted=? WHERE id=?", (total_rows, inserted_rows, sid))
            conn.commit()
            imported += 1
            inserted_total += inserted_rows
            done_units += max(1, size0)
            _safe_progress(progress, done_units, total_units, "第 %d/%d 檔完成｜新增 %s 筆｜%s" % (idx, source_total, f"{inserted_rows:,}", info.get("display", "")))
        _safe_progress(progress, total_units, total_units, "匯入完成｜新增%d｜略過%d｜覆蓋%d｜新增tick %s" % (imported, skipped, replaced, f"{inserted_total:,}"))
        return {"imported": imported, "skipped": skipped, "replaced": replaced, "inserted": inserted_total}
    finally:
        conn.close()


def scan_products_from_cache(progress=None):
    init_tick_cache_db()
    conn = db_connect()
    try:
        # 只用每個來源檔該商品的自動主力月份，避免價差或遠月干擾統計。
        global_dates = [r[0] for r in conn.execute("""
            SELECT DISTINCT t.trade_date
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            ORDER BY t.trade_date
        """).fetchall()]
        rows = conn.execute("""
            SELECT t.code, COUNT(*), SUM(t.qty), MIN(t.dt), MAX(t.dt), COUNT(DISTINCT t.trade_date)
            FROM ticks t JOIN primary_months pm
              ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
            GROUP BY t.code
            ORDER BY t.code
        """).fetchall()
        options = []
        for i, (code, cnt, qty_sum, first_dt, last_dt, data_days) in enumerate(rows, start=1):
            _safe_progress(progress, i, max(1, len(rows)), "讀取快取商品 %d/%d" % (i, len(rows)))
            code = clean_code(code)
            dates = [r[0] for r in conn.execute("""
                SELECT DISTINCT t.trade_date
                FROM ticks t JOIN primary_months pm
                  ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
                WHERE t.code=?
                ORDER BY t.trade_date
            """, (code,)).fetchall()]
            dstart = _date_from_text(dates[0]) if dates else None
            dend = _date_from_text(dates[-1]) if dates else None
            # 缺少日期以「官方 Daily 已匯入的交易日期」為準，不用自然日補滿；
            # 同時排除週六日，避免把沒有下載項目的例假日誤判為缺資料。
            expected = []
            for d in global_dates:
                dd = _date_from_text(d)
                if not (dstart and dend and dd and dstart <= dd <= dend):
                    continue
                if dd.weekday() >= 5:
                    continue
                expected.append(d)
            have = set(dates)
            missing = [d for d in expected if d not in have]
            mon_rows = conn.execute("""
                SELECT t.month, COUNT(*), SUM(t.qty)
                FROM ticks t JOIN primary_months pm
                  ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
                WHERE t.code=?
                GROUP BY t.month
                ORDER BY SUM(t.qty) DESC, COUNT(*) DESC
                LIMIT 4
            """, (code,)).fetchall()
            months_sorted = [r[0] for r in mon_rows]
            primary = months_sorted[0] if months_sorted else ""
            month_text = ",".join(months_sorted)
            last_price_row = conn.execute("""
                SELECT t.price
                FROM ticks t JOIN primary_months pm
                  ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
                WHERE t.code=? ORDER BY t.dt DESC LIMIT 1
            """, (code,)).fetchone()
            last_price = float(last_price_row[0]) if last_price_row else 0.0
            first_obj = RealDateTime.fromisoformat(first_dt) if first_dt else None
            last_obj = RealDateTime.fromisoformat(last_dt) if last_dt else None
            avg_qty = float(qty_sum or 0.0) / max(1, int(data_days or 0))
            display = "%s｜快取｜%s天｜均量%s｜%s筆｜月份%s" % (code, int(data_days or 0), f"{avg_qty:,.0f}", f"{int(cnt or 0):,}", month_text)
            options.append(ProductOption(
                code=code, display=display, total_rows=int(cnt or 0), total_qty=float(qty_sum or 0.0),
                primary_month=primary, months=month_text, first_dt=first_obj, last_dt=last_obj,
                data_days=int(data_days or 0), date_start=dstart, date_end=dend,
                missing_dates="、".join(missing), avg_daily_qty=avg_qty, last_price=last_price,
            ))
        _safe_progress(progress, 1, 1, "快取商品讀取完成｜%d 個" % len(options))
        return options
    finally:
        conn.close()


def read_cached_ticks(code, strategy_name, start_date=None, end_date=None, progress=None):
    init_tick_cache_db()
    code = clean_code(code)
    d1 = _date_text(start_date) if start_date else ""
    d2 = _date_text(end_date) if end_date else ""
    where = ["t.code=?"]
    args = [code]
    if d1:
        where.append("t.trade_date>=?")
        args.append(d1)
    if d2:
        where.append("t.trade_date<=?")
        args.append(d2)
    sql = """
        SELECT t.dt, t.trade_date, t.price, t.qty, t.code, t.month
        FROM ticks t JOIN primary_months pm
          ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
        WHERE %s
        ORDER BY t.dt
    """ % (" AND ".join(where))
    conn = db_connect()
    try:
        rows = conn.execute(sql, args).fetchall()
    finally:
        conn.close()
    total = len(rows) or 1
    raw_rows = []
    for i, (dt_text, _trade_date, price, qty, row_code, month) in enumerate(rows, start=1):
        try:
            dt = RealDateTime.fromisoformat(dt_text)
        except Exception:
            continue
        skey, slabel, in_session, _force_dt = session_for(strategy_name, dt)
        if not in_session:
            continue
        raw_rows.append((dt, float(price), float(qty), row_code, month, skey, slabel))
        if i % 20000 == 0:
            _safe_progress(progress, i, total, "從快取讀取 %s｜%s/%s" % (code, f"{i:,}", f"{total:,}"))
    ticks = []
    accum_amt = {}
    accum_qty = {}
    for dt, price, qty, row_code, month, skey, slabel in raw_rows:
        accum_amt[skey] = accum_amt.get(skey, 0.0) + price * qty
        accum_qty[skey] = accum_qty.get(skey, 0.0) + qty
        avg = accum_amt[skey] / accum_qty[skey] if accum_qty[skey] > 0 else price
        ticks.append(OfficialTick(dt, dt.date(), price, qty, avg, row_code, month, skey, slabel))
    _safe_progress(progress, total, total, "快取讀取完成｜%s %s 筆" % (code, f"{len(ticks):,}"))
    return ticks


def count_cached_ticks_for_code(code, start_date=None, end_date=None):
    """估算指定商品與日期區間的主力月份逐筆數，用於群組回測預估時間。"""
    init_tick_cache_db()
    code = clean_code(code)
    if not code:
        return 0
    d1 = _date_text(start_date) if start_date else ""
    d2 = _date_text(end_date) if end_date else ""
    where = ["t.code=?"]
    args = [code]
    if d1:
        where.append("t.trade_date>=?")
        args.append(d1)
    if d2:
        where.append("t.trade_date<=?")
        args.append(d2)
    sql = """
        SELECT COUNT(*)
        FROM ticks t JOIN primary_months pm
          ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
        WHERE %s
    """ % (" AND ".join(where))
    conn = db_connect()
    try:
        row = conn.execute(sql, args).fetchone()
        return int(row[0] or 0) if row else 0
    finally:
        conn.close()

def safe_int_text(x):
    try:
        return f"{int(round(float(x or 0))):,}"
    except Exception:
        return "0"

def extract_text_from_html(raw):
    raw = re.sub(r"<script.*?</script>", " ", raw, flags=re.I | re.S)
    raw = re.sub(r"<style.*?</style>", " ", raw, flags=re.I | re.S)
    raw = re.sub(r"<[^>]+>", " ", raw)
    raw = html.unescape(raw)
    raw = re.sub(r"\s+", " ", raw)
    return raw.strip()

def parse_taifex_stock_margin_html(raw):
    text = extract_text_from_html(raw)
    mdate = re.search(r"標的證券為股票之股票期貨契約.*?更新日期[:：]\s*(\d{4}/\d{2}/\d{2})", text)
    source_date = mdate.group(1) if mdate else ""
    start = text.find("標的證券為股票之股票期貨契約")
    end = text.find("標的證券為受益憑證之股票期貨契約", start + 1 if start >= 0 else 0)
    section = text[start:end] if start >= 0 and end > start else text
    pattern = re.compile(
        r"(\d+)\s+([A-Z]{2,4}F)\s+([0-9A-Z]{4,6})\s+(.{1,30}?期貨)\s+(.{1,80}?)\s+(?:級距([123])\s+)?([0-9.]+)%\s+([0-9.]+)%\s+([0-9.]+)%"
    )
    items = {}
    for m in pattern.finditer(section):
        code = m.group(2).strip().upper()
        stock_no = m.group(3).strip()
        short_name = m.group(4).strip()
        stock_name = m.group(5).strip()
        items[code] = {
            "code": code,
            "stock_no": stock_no,
            "short_name": short_name,
            "stock_name": stock_name,
            "is_small": short_name.startswith("小型") or "小型" in short_name,
            "tier": ("級距" + m.group(6)) if m.group(6) else "",
            "clearing_margin_percent": float(m.group(7)),
            "maintenance_margin_percent": float(m.group(8)),
            "initial_margin_percent": float(m.group(9)),
            "is_excluded_underlying": stock_no in EXCLUDE_UNDERLYING_STOCKS,
        }
    if not items:
        raise RuntimeError("無法從期交所網頁解析股票期貨保證金資料。")
    return {
        "source_url": TAIFEX_STOCK_MARGIN_URL,
        "source_date": source_date,
        "updated_at": RealDateTime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "items": items,
    }

def download_taifex_stock_margin_master(timeout=20):
    req = urllib.request.Request(TAIFEX_STOCK_MARGIN_URL, headers={
        "User-Agent": "Mozilla/5.0 TrainBacktester/013",
        "Accept-Language": "zh-TW,zh;q=0.9,en;q=0.5",
    })
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        data = resp.read()
    for enc in ("utf-8", "utf-8-sig", "cp950", "big5"):
        try:
            raw = data.decode(enc)
            break
        except Exception:
            raw = data.decode("utf-8", errors="ignore")
    master = parse_taifex_stock_margin_html(raw)
    with open(margin_master_path(), "w", encoding="utf-8") as f:
        json.dump(master, f, ensure_ascii=False, indent=2)
    return master

def load_cached_margin_master():
    p = margin_master_path()
    if not os.path.exists(p):
        return {"items": {}}
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        if "items" not in data:
            return {"items": {}}
        return data
    except Exception:
        return {"items": {}}

def product_multiplier_from_master_item(item, strategy_name=""):
    if item and bool(item.get("is_small")):
        return 100
    if "小股" in str(strategy_name):
        return 100
    return 2000

def margin_base_from_price(price, percent, multiplier=2000):
    # 依契約乘數估算原始保證金：大股期乘數 2000，小股期乘數 100。
    # 舊版固定用 2000，會讓同一標的的大股期/小股期顯示幾乎相同保證金。
    try:
        value = float(price or 0) * float(multiplier or 2000) * float(percent or 0) / 100.0
    except Exception:
        value = 0.0
    if value <= 0:
        return 0.0
    return float(math.ceil(value / 1000.0) * 1000.0)


def open_csv_rows(path):
    last_err = None
    for enc in ("utf-8-sig", "cp950", "big5", "utf-8"):
        try:
            f = open(path, "r", encoding=enc, newline="")
            # 先嘗試讀一小段，確認編碼可用。
            f.read(4096)
            f.seek(0)
            return f
        except Exception as e:
            last_err = e
            try:
                f.close()
            except Exception:
                pass
    raise RuntimeError("無法讀取 CSV 編碼：%s" % last_err)


def _zip_text_stream(zf, member_name):
    last_err = None
    for enc in ("utf-8-sig", "cp950", "big5", "utf-8"):
        try:
            bf = zf.open(member_name, "r")
            tf = io.TextIOWrapper(bf, encoding=enc, newline="")
            tf.read(4096)
            tf.close()
            bf = zf.open(member_name, "r")
            return io.TextIOWrapper(bf, encoding=enc, newline="")
        except Exception as e:
            last_err = e
            try:
                tf.close()
            except Exception:
                pass
            try:
                bf.close()
            except Exception:
                pass
    raise RuntimeError("ZIP 內檔案無法讀取編碼：%s｜%s" % (member_name, last_err))


def daily_source_infos(paths):
    """列出可讀取的官方 Daily 文字來源；ZIP 內檔案以未壓縮大小估算進度。"""
    infos = []
    for path in paths:
        path = str(path)
        ext = os.path.splitext(path)[1].lower()
        try:
            outer_mtime = os.path.getmtime(path)
        except Exception:
            outer_mtime = 0.0
        if ext == ".zip":
            with zipfile.ZipFile(path, "r") as zf:
                members = [i for i in zf.infolist() if (not i.is_dir()) and os.path.splitext(i.filename)[1].lower() in TEXT_EXTS]
                members.sort(key=lambda i: i.filename)
                for info in members:
                    infos.append({
                        "path": path,
                        "member": info.filename,
                        "source_id": "%s::%s" % (path, info.filename),
                        "display": "%s/%s" % (os.path.basename(path), info.filename),
                        "size": max(1, int(info.file_size or 0)),
                        "mtime": outer_mtime,
                        "crc": str(info.CRC),
                        "is_zip": True,
                    })
        elif ext in TEXT_EXTS or not ext:
            try:
                size = os.path.getsize(path)
            except Exception:
                size = 1
            infos.append({
                "path": path,
                "member": "",
                "source_id": path,
                "display": os.path.basename(path),
                "size": max(1, int(size or 0)),
                "mtime": outer_mtime,
                "crc": "",
                "is_zip": False,
            })
    return infos


def iter_daily_sources(paths, with_size=False):
    """逐一開啟使用者選擇的 CSV/RPT/TXT 或 ZIP 內的每日檔。

    預設產生 (source_id, display_name, text_file)。with_size=True 時多回傳 source_size。
    source_id 會用於每個檔案、每個商品的主力月份判斷；ZIP 內多個檔案也可獨立判斷。
    """
    for info in daily_source_infos(paths):
        if info["is_zip"]:
            with zipfile.ZipFile(info["path"], "r") as zf:
                f = _zip_text_stream(zf, info["member"])
                try:
                    if with_size:
                        yield info["source_id"], info["display"], f, info["size"]
                    else:
                        yield info["source_id"], info["display"], f
                finally:
                    try:
                        f.close()
                    except Exception:
                        pass
        else:
            f = open_csv_rows(info["path"])
            try:
                if with_size:
                    yield info["source_id"], info["display"], f, info["size"]
                else:
                    yield info["source_id"], info["display"], f
            finally:
                try:
                    f.close()
                except Exception:
                    pass


def _row_approx_bytes(row):
    try:
        return sum(len(str(x)) for x in row) + len(row) + 2
    except Exception:
        return 80


def _safe_progress(progress, current, total, detail=""):
    if progress is None:
        return
    try:
        progress(max(0, float(current or 0)), max(1, float(total or 1)), str(detail or ""))
    except Exception:
        pass


def map_official_headers(headers):
    normalized = [norm_header(h) for h in headers]
    result = {}
    for key, aliases in HEADER_ALIASES.items():
        alias_norm = [norm_header(a) for a in aliases]
        for idx, h in enumerate(normalized):
            if h in alias_norm:
                result[key] = idx
                break
    missing = [k for k in ("trade_date", "product_code", "month", "trade_time", "price", "qty") if k not in result]
    if missing:
        raise ValueError("不是可辨識的官方 Daily CSV，缺少欄位：%s\n讀到表頭：%s" % (", ".join(missing), headers))
    return result


def to_float(x, default=0.0):
    try:
        return float(str(x).replace(",", "").strip())
    except Exception:
        return default


def clean_code(x):
    return str(x or "").strip().upper()


def clean_month(x):
    return str(x or "").strip()


def month_is_normal(month):
    """單一契約月份，例如 202606。官方檔也可能有 202606/202607 價差商品，回測期貨本身時不列入主力月份。"""
    s = clean_month(month)
    return s.isdigit() and len(s) >= 6 and "/" not in s


def parse_official_dt(dv, tv):
    ds = "".join(ch for ch in str(dv or "").strip() if ch.isdigit())
    if len(ds) < 8:
        raise ValueError("成交日期格式錯誤：%s" % dv)
    base_date = RealDateTime.strptime(ds[:8], "%Y%m%d").date()
    ts = "".join(ch for ch in str(tv or "").strip() if ch.isdigit())
    # 官方常見為 HMMSS / HHMMSS；不足 6 碼補前導 0。
    ts = ts[-6:].zfill(6)
    hh, mm, ss = int(ts[:2]), int(ts[2:4]), int(ts[4:6])
    return RealDateTime.combine(base_date, time(hh, mm, ss))


def strategy_kind(strategy_name):
    text = str(strategy_name or "")
    if is_three_ma_strategy(text):
        if "台指" in text:
            return "TAI"
        if "小股" in text or "小型" in text:
            return "SMALL"
        return "BIG"
    if "台指" in text:
        return "TAI"
    if "小股" in text:
        return "SMALL"
    return "BIG"


def default_multiplier(strategy_name, product_code=""):
    k = strategy_kind(strategy_name)
    code = str(product_code or "").strip().upper()
    if k == "SMALL":
        return 100
    if k == "BIG":
        return 2000
    if code == "MXF":
        return 50
    if code == "TMF":
        return 10
    return 200


def session_for(strategy_name, dt: RealDateTime):
    """回傳 session_key, session_label, in_session, force_dt。"""
    k = strategy_kind(strategy_name)
    hhmm = dt.hour * 100 + dt.minute
    if k == "TAI":
        if 845 <= hhmm < 1345:
            d = dt.date()
            return dt.strftime("%Y-%m-%d") + ":DAY", dt.strftime("%Y-%m-%d 日盤"), True, RealDateTime.combine(d, time(13, 43, 0))
        if hhmm >= 1500:
            d = dt.date()
            return dt.strftime("%Y-%m-%d") + ":NIGHT", dt.strftime("%Y-%m-%d 夜盤"), True, RealDateTime.combine(d + timedelta(days=1), time(4, 58, 0))
        if hhmm < 500:
            d = dt.date() - timedelta(days=1)
            return d.strftime("%Y-%m-%d") + ":NIGHT", d.strftime("%Y-%m-%d 夜盤"), True, RealDateTime.combine(dt.date(), time(4, 58, 0))
        return "", "非交易時段", False, None
    # 股期只跑日盤。
    if 845 <= hhmm < 1345:
        d = dt.date()
        return dt.strftime("%Y-%m-%d") + ":DAY", dt.strftime("%Y-%m-%d 日盤"), True, RealDateTime.combine(d, time(13, 43, 0))
    return "", "非交易時段", False, None


def scan_products(paths, progress=None):
    """掃描官方 Daily CSV，回傳商品代號清單；月份只作自動主力判斷，不需使用者輸入。"""
    code_rows = {}
    code_qty = {}
    code_month_rows = {}
    code_month_qty = {}
    code_first = {}
    code_last = {}
    code_last_price = {}
    code_dates = {}
    code_daily_qty = {}
    source_trading_dates = set()
    primary_month_by_file_code = {}

    sources = daily_source_infos(paths)
    total_bytes = sum(max(1, int(i.get("size", 1))) for i in sources) or 1
    done_bytes = 0
    source_count = len(sources) or 1
    _safe_progress(progress, 0, total_bytes, "準備掃描")

    for source_index, (source_id, _display_name, f, source_size) in enumerate(iter_daily_sources(paths, with_size=True), start=1):
        month_rows_this_file = {}
        month_qty_this_file = {}
        reader = csv.reader(f)
        try:
            headers = next(reader)
        except StopIteration:
            done_bytes += source_size
            _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔｜空檔案" % (source_index, source_count))
            continue
        m = map_official_headers(headers)
        approx = _row_approx_bytes(headers)
        row_count = 0
        for row in reader:
                row_count += 1
                approx += _row_approx_bytes(row)
                if not row:
                    continue
                try:
                    code = clean_code(row[m["product_code"]])
                    month = clean_month(row[m["month"]])
                    if not code or not month:
                        continue
                    qty = to_float(row[m["qty"]], 0.0)
                    price = to_float(row[m["price"]], 0.0)
                    dt = parse_official_dt(row[m["trade_date"]], row[m["trade_time"]])
                except Exception:
                    continue
                source_trading_dates.add(dt.date())
                code_dates.setdefault(code, set()).add(dt.date())
                code_daily_qty[(code, dt.date())] = code_daily_qty.get((code, dt.date()), 0.0) + qty
                if price > 0 and (code not in code_last or dt >= code_last.get(code, dt)):
                    code_last_price[code] = price
                code_rows[code] = code_rows.get(code, 0) + 1
                code_qty[code] = code_qty.get(code, 0.0) + qty
                code_month_rows[(code, month)] = code_month_rows.get((code, month), 0) + 1
                code_month_qty[(code, month)] = code_month_qty.get((code, month), 0.0) + qty
                code_first[code] = min(code_first.get(code, dt), dt)
                code_last[code] = max(code_last.get(code, dt), dt)
                month_rows_this_file[(code, month)] = month_rows_this_file.get((code, month), 0) + 1
                month_qty_this_file[(code, month)] = month_qty_this_file.get((code, month), 0.0) + qty
                if row_count % 10000 == 0:
                    cur = done_bytes + min(float(source_size), float(approx))
                    _safe_progress(progress, cur, total_bytes, "第 %d/%d 檔｜已找到 %d 個商品" % (source_index, source_count, len(code_rows)))
        # 每個來源檔案、每個商品，自動選成交量最大的月份當主力。
        codes_in_file = sorted(set(k[0] for k in month_rows_this_file))
        for code in codes_in_file:
            normal_candidates = [(month_qty_this_file.get((code, month), 0.0), month_rows_this_file.get((code, month), 0), month)
                                 for c, month in month_rows_this_file if c == code and month_is_normal(month)]
            fallback_candidates = [(month_qty_this_file.get((code, month), 0.0), month_rows_this_file.get((code, month), 0), month)
                                   for c, month in month_rows_this_file if c == code]
            candidates = normal_candidates or fallback_candidates
            candidates.sort(reverse=True)
            if candidates:
                primary_month_by_file_code[(source_id, code)] = candidates[0][2]
        done_bytes += source_size
        _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔完成｜已找到 %d 個商品" % (source_index, source_count, len(code_rows)))

    options = []
    for code in sorted(code_rows):
        all_months = [month for c, month in code_month_rows if c == code]
        normal_months = [month for month in all_months if month_is_normal(month)]
        months = normal_months or all_months
        months_sorted = sorted(months, key=lambda mo: (code_month_qty.get((code, mo), 0.0), code_month_rows.get((code, mo), 0)), reverse=True)
        primary = months_sorted[0] if months_sorted else ""
        month_text = ",".join(months_sorted[:4])
        if len(months_sorted) > 4:
            month_text += "..."
        dates = sorted(code_dates.get(code, set()))
        dstart = dates[0] if dates else None
        dend = dates[-1] if dates else None
        # 缺少日期以官方 Daily 檔案實際提供的交易日期為準，排除週六日。
        expected = [d for d in sorted(source_trading_dates) if dstart and dend and dstart <= d <= dend and d.weekday() < 5]
        missing = [d.strftime("%Y-%m-%d") for d in expected if d not in set(dates)]
        avg_qty = code_qty.get(code, 0.0) / max(1, len(dates))
        display = "%s｜主力%s｜%s天｜均量%s｜%s筆｜月份%s" % (
            code,
            primary,
            len(dates),
            f"{avg_qty:,.0f}",
            f"{code_rows.get(code, 0):,}",
            month_text,
        )
        options.append(ProductOption(
            code=code,
            display=display,
            total_rows=code_rows.get(code, 0),
            total_qty=code_qty.get(code, 0.0),
            primary_month=primary,
            months=month_text,
            first_dt=code_first.get(code),
            last_dt=code_last.get(code),
            data_days=len(dates),
            date_start=dstart,
            date_end=dend,
            missing_dates="、".join(missing),
            avg_daily_qty=avg_qty,
            last_price=code_last_price.get(code, 0.0),
        ))
    _safe_progress(progress, total_bytes, total_bytes, "掃描完成｜商品 %d 個" % len(options))
    return options, primary_month_by_file_code


def read_official_ticks(paths, code, strategy_name, primary_month_by_file_code, progress=None):
    code = clean_code(code)
    raw_rows = []
    sources = daily_source_infos(paths)
    total_bytes = sum(max(1, int(i.get("size", 1))) for i in sources) or 1
    done_bytes = 0
    source_count = len(sources) or 1
    _safe_progress(progress, 0, total_bytes, "準備讀取 %s" % code)
    for source_index, (source_id, _display_name, f, source_size) in enumerate(iter_daily_sources(paths, with_size=True), start=1):
        auto_month = primary_month_by_file_code.get((source_id, code), "")
        if not auto_month:
            done_bytes += source_size
            _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔｜無 %s 主力月份" % (source_index, source_count, code))
            continue
        reader = csv.reader(f)
        try:
            headers = next(reader)
        except StopIteration:
            done_bytes += source_size
            _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔｜空檔案" % (source_index, source_count))
            continue
        m = map_official_headers(headers)
        approx = _row_approx_bytes(headers)
        row_count = 0
        for row in reader:
                row_count += 1
                approx += _row_approx_bytes(row)
                if not row:
                    continue
                try:
                    row_code = clean_code(row[m["product_code"]])
                    if row_code != code:
                        if row_count % 20000 == 0:
                            cur = done_bytes + min(float(source_size), float(approx))
                            _safe_progress(progress, cur, total_bytes, "第 %d/%d 檔｜已讀到 %s %s 筆" % (source_index, source_count, code, f"{len(raw_rows):,}"))
                        continue
                    month = clean_month(row[m["month"]])
                    if month != auto_month:
                        continue
                    dt = parse_official_dt(row[m["trade_date"]], row[m["trade_time"]])
                    skey, slabel, in_session, _force_dt = session_for(strategy_name, dt)
                    if not in_session:
                        continue
                    price = to_float(row[m["price"]], 0.0)
                    qty = to_float(row[m["qty"]], 0.0)
                    if price <= 0 or qty <= 0:
                        continue
                    raw_rows.append((dt, price, qty, row_code, month, skey, slabel))
                except Exception:
                    continue
                if row_count % 10000 == 0:
                    cur = done_bytes + min(float(source_size), float(approx))
                    _safe_progress(progress, cur, total_bytes, "第 %d/%d 檔｜已讀到 %s %s 筆" % (source_index, source_count, code, f"{len(raw_rows):,}"))
        done_bytes += source_size
        _safe_progress(progress, done_bytes, total_bytes, "第 %d/%d 檔完成｜已讀到 %s %s 筆" % (source_index, source_count, code, f"{len(raw_rows):,}"))
    raw_rows.sort(key=lambda x: x[0])

    ticks = []
    accum_amt = {}
    accum_qty = {}
    for dt, price, qty, row_code, month, skey, slabel in raw_rows:
        accum_amt[skey] = accum_amt.get(skey, 0.0) + price * qty
        accum_qty[skey] = accum_qty.get(skey, 0.0) + qty
        avg = accum_amt[skey] / accum_qty[skey] if accum_qty[skey] > 0 else price
        ticks.append(OfficialTick(dt, dt.date(), price, qty, avg, row_code, month, skey, slabel))
    _safe_progress(progress, total_bytes, total_bytes, "讀取完成｜%s %s 筆" % (code, f"{len(ticks):,}"))
    return ticks


def format_money(x):
    return "%+.0f" % float(x or 0.0)

def format_money_plain(x):
    try:
        return "%.0f" % float(x or 0.0)
    except Exception:
        return "0"

def format_money_signed_negative(x):
    try:
        v = float(x or 0.0)
        return "%.0f" % v
    except Exception:
        return "0"


def parse_dt_text(text):
    if isinstance(text, RealDateTime):
        return text
    s = str(text or "").strip()
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y/%m/%d %H:%M:%S", "%H:%M:%S"):
        try:
            return RealDateTime.strptime(s, fmt)
        except Exception:
            pass
    return None


def side_from_close_direction(direction):
    # 平倉紀錄 direction 是平倉動作：賣=平多，買=平空。
    return "做多" if str(direction) == "賣" else "放空" if str(direction) == "買" else str(direction)


def build_task(strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, one_way_fee=0.0, k_minutes=1, ma_period=3):
    k = strategy_kind(strategy_name)
    code = clean_code(product_code)
    if k == "TAI" and not code:
        code = "TXF"
    multiplier = default_multiplier(strategy_name, code)
    qty = max(1, int(lots or 1))
    # v044 修正：strategy_core 的 TP/SL 判斷固定使用「每口商品點數」。
    # 不論台指期、大股期、小股期，這裡都不可先乘商品乘數或口數；
    # 新台幣損益與手續費由策略核心依成交價、乘數與口數另行換算。
    take_profit = abs(float(tp_points or 0.0))
    stop_loss = abs(float(sl_points or 0.0))
    return SimpleNamespace(
        id=1,
        account="BACKTEST",
        strategy=strategy_name,
        execution_mode="simulation",
        product_name=code,
        product_symbol=code,
        product_code=code,
        lots=qty,
        take_profit=take_profit,
        stop_loss=stop_loss,
        loss_exit=abs(float(loss_exit or 0.0)),
        lock_profit_exit=abs(float(lock_profit_exit or 0.0)),
        one_way_fee=max(0.0, float(one_way_fee or 0.0)),
        ma_period=normalize_ma_period(ma_period),
        bar_minutes=normalize_k_minutes(k_minutes),
        quote_avg_ready=True,
        quote_avg=0.0,
        last_price=0.0,
        position=0,
        avg_cost=0.0,
        float_pnl=0.0,
        realized_pnl=0.0,
        total_pnl=0.0,
        high_float_pnl=0.0,
        entry_reason="",
        last_signal="",
        signal_source="",
        flat_reason="",
        risk_status="正常",
        lock_profit_armed=False,
        lock_profit_high=0.0,
        order_pending=False,
        _bt_profile=(_STRATEGY_CORE_PROFILE_ORIG(SimpleNamespace(strategy=strategy_name, product_code=code, product_symbol=code, product_name=code)) if callable(_STRATEGY_CORE_PROFILE_ORIG) else None),
    )



def _floor_dt_to_k_start(dt, k_minutes):
    k = normalize_k_minutes(k_minutes)
    minute_of_day = dt.hour * 60 + dt.minute
    base_minute = (minute_of_day // k) * k
    return dt.replace(hour=base_minute // 60, minute=base_minute % 60, second=0, microsecond=0)


def _build_3ma_k_bars(rows, k_minutes):
    """把 session 逐筆列聚合成 N 分K；每根K保留 OHLC 與筆數。"""
    k = normalize_k_minutes(k_minutes)
    bars = []
    cur = None
    for row in list(rows or []):
        try:
            dt, price, _avg = row
            price = float(price)
        except Exception:
            continue
        start = _floor_dt_to_k_start(dt, k)
        if cur is None or start != cur["start"]:
            if cur is not None:
                bars.append(cur)
            cur = {
                "start": start,
                "end": dt,
                "open": price,
                "high": price,
                "low": price,
                "close": price,
                "ticks": 1,
            }
        else:
            cur["end"] = dt
            cur["high"] = max(float(cur["high"]), price)
            cur["low"] = min(float(cur["low"]), price)
            cur["close"] = price
            cur["ticks"] = int(cur.get("ticks", 0) or 0) + 1
    if cur is not None:
        bars.append(cur)
    return bars


def _last_k_bar_dict(rows, k_minutes):
    """回傳該時段最後一根 1/5/10 分K，供 MA策略 開盤第一根使用上一時段最後K判斷。"""
    bars = _build_3ma_k_bars(rows, k_minutes)
    if not bars:
        return None
    b = dict(bars[-1])
    try:
        b["key"] = b.get("start").strftime("%Y-%m-%d %H:%M")
    except Exception:
        b["key"] = "PREV"
    return b


def _bar_fill_price(bar, direction, gate_price):
    """K棒回測無法知道精確成交tick；若開盤已跳過gate用開盤，否則用gate。"""
    gate = float(gate_price or 0.0)
    op = float(bar.get("open", gate) or gate)
    hi = float(bar.get("high", op) or op)
    lo = float(bar.get("low", op) or op)
    if direction > 0:
        if op >= gate:
            return op
        if hi >= gate:
            return gate
        return float(bar.get("close", op) or op)
    else:
        if op <= gate:
            return op
        if lo <= gate:
            return gate
        return float(bar.get("close", op) or op)


def _three_ma_bar_path(bar):
    op = float(bar.get("open", 0.0) or 0.0)
    hi = float(bar.get("high", op) or op)
    lo = float(bar.get("low", op) or op)
    cl = float(bar.get("close", op) or op)
    # 上漲K假設先下洗再上攻；下跌K假設先上拉再下殺。只用於停損/保底線同棒判定的近似。
    if cl >= op:
        return [op, lo, hi, cl]
    return [op, hi, lo, cl]


def run_3ma0413_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=1, progress=None):
    """MA策略 回測引擎。

    對應使用者提供的 XQ MA策略：N=3、Cross / FB / IntraFB、ModeSide=0、
    StopLossP=sl_points、FloatProfitTrigger=tp_points；認賠/賺飽不是原策略輸入，故不主動觸發。
    """
    n = 3
    k_minutes = normalize_k_minutes(k_minutes)
    qty = max(1, int(lots or 1))
    multiplier = default_multiplier(strategy_name, product_code)
    stop_loss_p = abs(float(sl_points or 0.0))
    float_trigger = abs(float(tp_points or 0.0))
    all_day_stats = []
    all_closed = []
    all_records = []
    all_events = []
    total_units = sum(len(item[1]) for item in list(session_items or [])) or 1
    done_units = 0
    _safe_progress(progress, 0, total_units, "準備MA策略回測｜%d分K" % k_minutes)

    def trade_net(entry, exit_px, side):
        if side > 0:
            pts = float(exit_px) - float(entry)
        else:
            pts = float(entry) - float(exit_px)
        gross = pts * multiplier * qty
        return gross, gross

    for skey, arr, session_label, month_text, _unique_minutes in list(session_items or []):
        bars = _build_3ma_k_bars(arr, k_minutes)
        done_units += len(arr)
        if not bars:
            continue
        closes = []
        avgs = []
        position = 0
        entry_px = 0.0
        entry_dt = None
        entry_bar_idx = -1
        peak_points = 0.0
        tp_armed = False
        tp_line = 0.0
        realized_total = 0.0
        peak_equity = 0.0
        trough_equity = 0.0
        running_peak = 0.0
        max_dd = 0.0
        session_closed = []

        def update_equity(mark_price):
            nonlocal peak_equity, trough_equity, running_peak, max_dd
            floating = 0.0
            if position != 0 and entry_px > 0:
                if position > 0:
                    floating = (float(mark_price) - entry_px) * multiplier * qty
                else:
                    floating = (entry_px - float(mark_price)) * multiplier * qty
            equity = realized_total + floating
            if equity > peak_equity:
                peak_equity = equity
            if equity < trough_equity:
                trough_equity = equity
            if equity > running_peak:
                running_peak = equity
            dd = equity - running_peak
            if dd < max_dd:
                max_dd = dd

        def reset_position_state():
            nonlocal peak_points, tp_armed, tp_line
            peak_points = 0.0
            tp_armed = False
            tp_line = 0.0

        def close_position(exit_dt, exit_px, event, reason):
            nonlocal position, entry_px, entry_dt, realized_total, entry_bar_idx
            if position == 0 or entry_px <= 0:
                return None
            side = 1 if position > 0 else -1
            gross, net = trade_net(entry_px, exit_px, side)
            realized_total += net
            row = {
                "session": session_label,
                "month": month_text,
                "entry_time": entry_dt or exit_dt,
                "exit_time": exit_dt,
                "side": "做多" if side > 0 else "放空",
                "entry": float(entry_px),
                "exit": float(exit_px),
                "event": event,
                "reason": reason,
                "gross": float(gross),
                "fee": 0.0,
                "net": float(net),
            }
            session_closed.append(row)
            all_closed.append(row)
            all_records.append(dict(row, closed_trade=True, realized=net, gross_realized=gross, price=float(exit_px)))
            position = 0
            entry_px = 0.0
            entry_dt = None
            entry_bar_idx = -1
            reset_position_state()
            return row

        def open_position(open_dt, open_px, direction, bar_idx):
            nonlocal position, entry_px, entry_dt, entry_bar_idx
            position = qty if direction > 0 else -qty
            entry_px = float(open_px)
            entry_dt = open_dt
            entry_bar_idx = bar_idx
            reset_position_state()

        def update_tp_for_price(price):
            nonlocal peak_points, tp_armed, tp_line
            if position == 0 or entry_px <= 0:
                return
            if position > 0:
                fp = float(price) - entry_px
            else:
                fp = entry_px - float(price)
            if fp > peak_points:
                peak_points = fp
            if (not tp_armed) and peak_points >= float_trigger and float_trigger > 0:
                tp_armed = True
            if tp_armed:
                if peak_points <= 800:
                    lock_pts = math.floor(peak_points * 0.70)
                elif peak_points <= 1200:
                    lock_pts = math.floor(peak_points * 0.80)
                else:
                    lock_pts = math.floor(peak_points * 0.90)
                new_line = entry_px + lock_pts if position > 0 else entry_px - lock_pts
                if tp_line == 0:
                    tp_line = new_line
                elif position > 0 and new_line > tp_line:
                    tp_line = new_line
                elif position < 0 and new_line < tp_line:
                    tp_line = new_line

        def check_exit_by_price(bar, price):
            if position == 0 or entry_px <= 0:
                return False
            update_tp_for_price(price)
            update_equity(price)
            exit_dt = bar.get("end") or bar.get("start")
            if position > 0:
                if tp_armed and tp_line > 0 and float(price) <= tp_line:
                    close_position(exit_dt, tp_line, "停利平倉", "停利平倉")
                    update_equity(tp_line)
                    return True
                if stop_loss_p > 0 and float(price) <= entry_px - stop_loss_p:
                    close_position(exit_dt, entry_px - stop_loss_p, "停損平倉", "停損平倉")
                    update_equity(entry_px - stop_loss_p)
                    return True
            else:
                if tp_armed and tp_line > 0 and float(price) >= tp_line:
                    close_position(exit_dt, tp_line, "停利平倉", "停利平倉")
                    update_equity(tp_line)
                    return True
                if stop_loss_p > 0 and float(price) >= entry_px + stop_loss_p:
                    close_position(exit_dt, entry_px + stop_loss_p, "停損平倉", "停損平倉")
                    update_equity(entry_px + stop_loss_p)
                    return True
            return False

        for i, bar in enumerate(bars):
            cl = float(bar["close"])
            # 先建立本根K的即時均線：目前Close + 前N-1根已完成K Close。
            if len(closes) >= n - 1:
                avg_now = (sum(closes[-(n - 1):]) + cl) / float(n)
            else:
                avg_now = None

            # MA策略 啟動保護近似：至少等到第3根K且均線有資料，才接受 fresh signal。
            if avg_now is not None and i >= max(2, n - 1) and avgs:
                prev_close = closes[-1]
                prev_avg = avgs[-1]
                prev_bar = bars[i - 1]
                arms = []
                arm_seq = 0
                # Cross ↑ / ↓
                if prev_close < prev_avg and cl > avg_now:
                    arm_seq += 1
                    arms.append((arm_seq, 1, 1, float(prev_bar["high"]), "Cross"))
                if prev_close > prev_avg and cl < avg_now:
                    arm_seq += 1
                    arms.append((arm_seq, 1, -1, float(prev_bar["low"]), "Cross"))
                # FB ↓ / ↑
                if float(prev_bar["high"]) > prev_avg and prev_close < prev_avg:
                    arm_seq += 1
                    arms.append((arm_seq, 2, -1, float(prev_bar["low"]), "FB"))
                if float(prev_bar["low"]) < prev_avg and prev_close > prev_avg:
                    arm_seq += 1
                    arms.append((arm_seq, 2, 1, float(prev_bar["high"]), "FB"))
                # IntraFB 近似：本K同時看過均線上下，或只洗過單側後反向。
                seen_above = float(bar["high"]) > avg_now
                seen_below = float(bar["low"]) < avg_now
                want_dir = 0
                if seen_above and seen_below:
                    want_dir = 1 if cl >= avg_now else -1
                elif seen_below:
                    want_dir = 1
                elif seen_above:
                    want_dir = -1
                if want_dir != 0:
                    arm_seq += 1
                    gate = float(prev_bar["high"] if want_dir > 0 else prev_bar["low"])
                    arms.append((arm_seq, 3, want_dir, gate, "IntraFB_L" if want_dir > 0 else "IntraFB_S"))

                winner = None
                for seq, typ, direction, gate, reason in arms:
                    fired = False
                    if direction > 0:
                        if typ == 3:
                            fired = float(bar["high"]) > avg_now and float(bar["high"]) > gate
                        else:
                            fired = float(bar["high"]) > gate
                    else:
                        if typ == 3:
                            fired = float(bar["low"]) < avg_now and float(bar["low"]) < gate
                        else:
                            fired = float(bar["low"]) < gate
                    if fired and (winner is None or seq > winner[0]):
                        winner = (seq, typ, direction, gate, reason)

                if winner is not None:
                    _seq, _typ, direction, gate, reason = winner
                    fill = _bar_fill_price(bar, direction, gate)
                    if position == 0:
                        open_position(bar["end"], fill, direction, i)
                    elif (position > 0 and direction < 0) or (position < 0 and direction > 0):
                        close_position(bar["end"], fill, "反手平倉", "反手平倉")
                        open_position(bar["end"], fill, direction, i)

            # 已持倉時跑保底停利/停損；進場當根不做同棒出場，避免K棒順序不明導致假洗價。
            if position != 0 and i != entry_bar_idx:
                for px in _three_ma_bar_path(bar):
                    if check_exit_by_price(bar, px):
                        break
            else:
                update_equity(cl)

            # 本根K收盤後，保存 close 與該收盤均線供下一根使用。
            closes.append(cl)
            if len(closes) >= n:
                avgs.append(sum(closes[-n:]) / float(n))
            else:
                avgs.append(cl)

        if position != 0 and bars:
            last_bar = bars[-1]
            close_position(last_bar.get("end") or last_bar.get("start"), float(last_bar["close"]), "時間到強制出場", "時間到強制出場")
            update_equity(float(last_bar["close"]))

        total_net = sum(float(x.get("net", 0.0) or 0.0) for x in session_closed)
        all_day_stats.append({
            "session": session_label,
            "month": month_text,
            "minutes": "%d分K/%d根" % (k_minutes, len(bars)),
            "ticks": sum(int(b.get("ticks", 0) or 0) for b in bars),
            "trades": len(session_closed),
            "win_trades": sum(1 for x in session_closed if float(x.get("net", 0.0) or 0.0) > 0),
            "loss_trades": sum(1 for x in session_closed if float(x.get("net", 0.0) or 0.0) < 0),
            "net": total_net,
            "tp": sum(1 for x in session_closed if "停利" in x["reason"]),
            "sl": sum(1 for x in session_closed if "停損" in x["reason"]),
            "reverse": sum(1 for x in session_closed if x["event"] == "反手平倉"),
            "force": sum(1 for x in session_closed if "時間到" in x["reason"]),
            "loss_exit": 0,
            "profit_exit": 0,
            "max_dd": max_dd,
            "peak_pnl": peak_equity,
            "trough_pnl": trough_equity,
            "hit_profit_exit": bool(lock_profit_exit and peak_equity >= abs(float(lock_profit_exit or 0.0))),
            "hit_loss_exit": bool(loss_exit and trough_equity <= -abs(float(loss_exit or 0.0))),
            "hit_20000": total_net >= 20000,
            "stop_reason": "",
        })
        _safe_progress(progress, min(done_units, total_units), total_units, "%s｜MA策略 %d分K完成" % (session_label, k_minutes))

    _safe_progress(progress, total_units, total_units, "MA策略回測完成")
    return all_day_stats, all_closed, all_records, all_events


def _session_op_boundary_dt(strategy_name, session_key):
    """回測專用：OP 用開盤第一根收盤，固定在第二根開頭成交。

    官方 tick 檔若第二根 08:46/15:01 沒有成交，不能等到 08:47 才進 OP；
    應用第一根最後價格與均價，在 08:46:00 / 15:01:00 補一筆合成 tick，
    對齊小火車/XQ 的 OP 進場時間。
    """
    try:
        day_text, segment = str(session_key or "").split(":", 1)
        base_day = RealDateTime.strptime(day_text, "%Y-%m-%d").date()
    except Exception:
        return None
    k = strategy_kind(strategy_name)
    if segment == "DAY":
        return RealDateTime.combine(base_day, time(8, 46, 0))
    if k == "TAI" and segment == "NIGHT":
        return RealDateTime.combine(base_day, time(15, 1, 0))
    return None

def _prepare_session_items_from_ticks(ticks):
    """把 ticks 依 session 預分組，並壓成回測熱路徑用的三欄 tuple。

    v029 速度重點：多參數回測時每組都重建 by_session / 月份 / 分鐘集合很浪費。
    這裡一次預處理成：[(session_key, rows, label, month_text, unique_minutes)]。
    rows 只保留 (dt, price, avg)，策略核心逐 tick 只需要這三個欄位。
    """
    buckets = {}
    meta = {}
    for t in list(ticks or []):
        try:
            skey = str(t.session_key)
            dt = t.dt
            price = float(t.price)
            avg = float(t.avg)
            month = str(t.month)
            label = str(t.session_label)
        except Exception:
            continue
        buckets.setdefault(skey, []).append((dt, price, avg))
        m = meta.setdefault(skey, {"label": label, "months": set(), "minutes": set(), "first_dt": dt})
        m["months"].add(month)
        try:
            m["minutes"].add(dt.strftime("%Y-%m-%d %H:%M"))
        except Exception:
            pass
        if dt < m["first_dt"]:
            m["first_dt"] = dt
    items = []
    for skey, rows in buckets.items():
        if not rows:
            continue
        rows.sort(key=lambda x: x[0])
        m = meta.get(skey, {})
        month_text = "/".join(sorted(m.get("months") or []))
        items.append((skey, rows, str(m.get("label") or skey), month_text, int(len(m.get("minutes") or [])), rows[0][0]))
    items.sort(key=lambda x: x[5] if x and len(x) > 5 else RealDateTime.min)
    return [(skey, rows, label, month_text, minutes) for skey, rows, label, month_text, minutes, _first_dt in items]


def _prepare_session_items_from_packed_rows(rows):
    """worker initializer 使用：直接從 pickle rows 預分組，不再建立 OfficialTick 物件。"""
    buckets = {}
    meta = {}
    for row in list(rows or []):
        try:
            dt, _d, price, _qty, avg, _code, month, skey, slabel = row
            skey = str(skey)
            dt = dt
            price = float(price)
            avg = float(avg)
            month = str(month)
            label = str(slabel)
        except Exception:
            continue
        buckets.setdefault(skey, []).append((dt, price, avg))
        m = meta.setdefault(skey, {"label": label, "months": set(), "minutes": set(), "first_dt": dt})
        m["months"].add(month)
        try:
            m["minutes"].add(dt.strftime("%Y-%m-%d %H:%M"))
        except Exception:
            pass
        if dt < m["first_dt"]:
            m["first_dt"] = dt
    items = []
    for skey, arr in buckets.items():
        if not arr:
            continue
        arr.sort(key=lambda x: x[0])
        m = meta.get(skey, {})
        items.append((skey, arr, str(m.get("label") or skey), "/".join(sorted(m.get("months") or [])), int(len(m.get("minutes") or [])), arr[0][0]))
    items.sort(key=lambda x: x[5] if x and len(x) > 5 else RealDateTime.min)
    return [(skey, arr, label, month_text, minutes) for skey, arr, label, month_text, minutes, _first_dt in items]


def run_strategy_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=1, ma_period=3, one_way_fee=0.0, progress=None):
    # v046：MA策略改用 API 版 strategy_core 逐 Tick 回測；MA參數與K棒週期分開設定。
    all_day_stats = []
    all_closed = []
    all_records = []
    all_events = []
    total_ticks = sum(len(item[1]) for item in list(session_items or [])) or 1
    processed_ticks = 0
    last_progress_tick = 0
    _safe_progress(progress, 0, total_ticks, "準備回測")

    for skey, arr, session_label, month_text, unique_minutes in list(session_items or []):
        if not arr:
            continue
        records = []
        events = []
        feed_count = 0
        peak = 0.0
        trough = 0.0
        max_dd = 0.0
        running_peak = 0.0

        def logger(_text):
            return None

        def record_callback(rec):
            records.append(dict(rec))

        def event_callback(task, key, detail):
            events.append({"session": session_label, "key": key, "detail": detail, "status": getattr(task, "risk_status", "")})

        manager = strategy_core.策略模擬管理器(logger=logger, record_callback=record_callback, event_callback=event_callback)
        manager.set_real_mode(False)
        # v029 熱路徑：回測永遠是模擬、均價由官方逐筆累計得出、UI 同步不需要。
        manager.sync_task = lambda _task: None
        manager._task_real_mode = lambda _task: False
        manager._task_quote_avg_ready = lambda _task, _avg: float(_avg or 0.0) > 0.0
        task = build_task(
            strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code,
            one_way_fee=one_way_fee, k_minutes=k_minutes, ma_period=ma_period,
        )
        def feed(dt, price, avg):
            global _CURRENT_BACKTEST_DT
            nonlocal feed_count, peak, trough, max_dd, running_peak
            _CURRENT_BACKTEST_DT = dt
            task.last_price = price
            task.quote_avg = avg
            manager.on_tick(task, price, avg, dt)
            feed_count += 1
            st = manager.states.get(1)
            v = float(st.total_pnl or 0.0) if st is not None else 0.0
            if v > peak:
                peak = v
            if v < trough:
                trough = v
            if v > running_peak:
                running_peak = v
            dd = v - running_peak
            if dd < max_dd:
                max_dd = dd

        op_boundary = _session_op_boundary_dt(strategy_name, skey)
        op_injected = False
        last_before_op = None
        for dt, price, avg in arr:
            if op_boundary is not None and not op_injected and dt >= op_boundary:
                if last_before_op is not None and last_before_op[0] < op_boundary:
                    feed(op_boundary, last_before_op[1], last_before_op[2])
                op_injected = True
            feed(dt, price, avg)
            if op_boundary is not None and dt < op_boundary:
                last_before_op = (dt, price, avg)
            processed_ticks += 1
            if progress is not None and (processed_ticks - last_progress_tick >= 3000 or processed_ticks == total_ticks):
                last_progress_tick = processed_ticks
                _safe_progress(progress, processed_ticks, total_ticks, "%s｜%s / %s 筆" % (session_label, f"{processed_ticks:,}", f"{total_ticks:,}"))

        st = manager._state(task)
        if int(getattr(st, "position", 0) or 0) != 0:
            last_dt, last_price, last_avg = arr[-1]
            _skey, _slabel, _in_session, force_dt = session_for(strategy_name, last_dt)
            if force_dt and last_dt < force_dt:
                feed(force_dt, last_price, last_avg)

        closed = []
        for rec in records:
            if not rec.get("closed_trade"):
                continue
            exit_dt = parse_dt_text(rec.get("exit_time")) or parse_dt_text(rec.get("timestamp")) or arr[0][0]
            entry_dt = parse_dt_text(rec.get("entry_time")) or exit_dt
            event = str(rec.get("event", ""))
            reason = str(rec.get("reason", ""))
            show_reason = "反手平倉" if event == "反手平倉" else reason
            row = {
                "session": session_label,
                "month": month_text,
                "entry_time": entry_dt,
                "exit_time": exit_dt,
                "side": side_from_close_direction(rec.get("direction", "")),
                "entry": float(rec.get("entry_price", 0.0) or 0.0),
                "exit": float(rec.get("exit_price", rec.get("price", 0.0)) or 0.0),
                "event": event,
                "reason": show_reason,
                "gross": float(rec.get("gross_realized", 0.0) or 0.0),
                "fee": float(rec.get("fee", 0.0) or 0.0),
                "net": float(rec.get("realized", 0.0) or 0.0),
            }
            closed.append(row)
            all_closed.append(row)

        total_net = sum(x["net"] for x in closed)
        stop_reason = ""
        for x in closed:
            if "認賠" in x["reason"]:
                stop_reason = "認賠下車出場"
            if "賺飽" in x["reason"]:
                stop_reason = "賺飽下車出場"
        if not stop_reason and events:
            for e in events:
                if e["key"] in ("loss_exit", "lock_profit_exit", "force_flat"):
                    if e["key"] == "loss_exit":
                        stop_reason = "認賠下車出場"
                    elif e["key"] == "lock_profit_exit":
                        stop_reason = "賺飽下車出場"
                    elif e["key"] == "force_flat":
                        stop_reason = "時間到強制出場"

        all_day_stats.append({
            "session": session_label,
            "month": month_text,
            "minutes": unique_minutes,
            "ticks": feed_count,
            "trades": len(closed),
            "win_trades": sum(1 for x in closed if float(x.get("net", 0.0) or 0.0) > 0),
            "loss_trades": sum(1 for x in closed if float(x.get("net", 0.0) or 0.0) < 0),
            "net": total_net,
            "tp": sum(1 for x in closed if "停利" in x["reason"]),
            "sl": sum(1 for x in closed if "停損" in x["reason"]),
            "reverse": sum(1 for x in closed if x["event"] == "反手平倉"),
            "force": sum(1 for x in closed if "時間到" in x["reason"]),
            "loss_exit": sum(1 for x in closed if "認賠" in x["reason"]),
            "profit_exit": sum(1 for x in closed if "賺飽" in x["reason"]),
            "max_dd": max_dd,
            "peak_pnl": peak,
            "trough_pnl": trough,
            "hit_profit_exit": bool(peak >= abs(float(lock_profit_exit or 0.0))),
            "hit_loss_exit": bool(trough <= -abs(float(loss_exit or 0.0))),
            "hit_20000": total_net >= 20000,
            "stop_reason": stop_reason,
        })
        all_records.extend(records)
        all_events.extend(events)


    _safe_progress(progress, total_ticks, total_ticks, "回測完成")
    return all_day_stats, all_closed, all_records, all_events


def run_strategy_backtest_ticks(ticks, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=1, ma_period=3, one_way_fee=0.0, progress=None):
    session_items = _prepare_session_items_from_ticks(ticks)
    return run_strategy_backtest_session_items(session_items, strategy_name, lots, tp_points, sl_points, loss_exit, lock_profit_exit, product_code, k_minutes=k_minutes, ma_period=ma_period, one_way_fee=one_way_fee, progress=progress)

def _average_net_excluding_zero_trade_days_static(ds):
    rows = list(ds or [])
    active = [x for x in rows if int(x.get("trades", 0) or 0) > 0]
    base = active or rows
    if not base:
        return 0.0, 0
    total = sum(float(x.get("net", 0.0) or 0.0) for x in base)
    return total / max(1, len(base)), len(base)


def _day_stats_summary_static(ds):
    rows = list(ds or [])
    if not rows:
        return {"total_days": 0, "range": "無資料"}
    sessions = [str(x.get("session", "")) for x in rows if str(x.get("session", ""))]
    return {"total_days": len(rows), "range": ("%s ~ %s" % (sessions[0], sessions[-1])) if sessions else ""}


def _summarize_combo_result(ds, tr, params):
    """把單組回測結果壓成排行榜摘要；避免多核心回傳大量每日明細。"""
    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds)
    avg, valid_days = _average_net_excluding_zero_trade_days_static(ds)
    summary = _day_stats_summary_static(ds)
    peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
    trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
    tp_count = sum(int(x.get("tp", 0) or 0) for x in ds)
    sl_count = sum(int(x.get("sl", 0) or 0) for x in ds)
    rev_count = sum(int(x.get("reverse", 0) or 0) for x in ds)
    return {
        "strategy": params.get("strategy_name", ""), "status": "完成", "avg": avg, "total": total,
        "valid_days": valid_days, "total_days": summary.get("total_days", 0), "range": summary.get("range", ""),
        "trades": len(tr), "tp": tp_count, "sl": sl_count, "reverse": rev_count,
        "peak": peak, "trough": trough, "params": params,
    }


def _combo_params(strategy_name, lots, product_code, combo, k_minutes=1, ma_period=3, one_way_fee=0.0):
    tp, sl, loss_exit, profit_exit = combo
    if not is_three_ma_strategy(strategy_name):
        ma_period = 3
        k_minutes = 1
    return dict(
        strategy_name=strategy_name,
        lots=int(lots or 1),
        tp_points=round(float(tp), 2),
        sl_points=round(float(sl), 2),
        loss_exit=float(loss_exit),
        lock_profit_exit=float(profit_exit),
        product_code=clean_code(product_code or ""),
        ma_period=normalize_ma_period(ma_period),
        k_minutes=normalize_k_minutes(k_minutes),
        one_way_fee=max(0.0, float(one_way_fee or 0.0)),
    )


def _pack_ticks_for_worker(ticks):
    """把 dataclass tick 壓成內建型別，避免 Windows ProcessPool pickling 類別失敗。"""
    packed = []
    for t in list(ticks or []):
        try:
            packed.append((t.dt, t.d, float(t.price), float(t.qty), float(t.avg), str(t.code), str(t.month), str(t.session_key), str(t.session_label)))
        except Exception:
            pass
    return packed


def _unpack_ticks_for_worker(rows):
    return [OfficialTick(dt, d, price, qty, avg, code, month, session_key, session_label)
            for dt, d, price, qty, avg, code, month, session_key, session_label in list(rows or [])]


_WORKER_TICKS_CACHE = None
_WORKER_SESSION_ITEMS = None
_WORKER_STRATEGY_NAME = "大股期策略"
_WORKER_LOTS = 1
_WORKER_PRODUCT_CODE = ""
_WORKER_K_MINUTES = 1
_WORKER_MA_PERIOD = 3
_WORKER_ONE_WAY_FEE = 0.0


def _init_backtest_worker_from_file(ticks_file, strategy_name, lots, product_code, k_minutes=1, ma_period=3, one_way_fee=0.0):
    """ProcessPool initializer：每個 worker 只載入一次同商品 ticks。"""
    global _WORKER_TICKS_CACHE, _WORKER_SESSION_ITEMS, _WORKER_STRATEGY_NAME, _WORKER_LOTS, _WORKER_PRODUCT_CODE, _WORKER_K_MINUTES, _WORKER_MA_PERIOD, _WORKER_ONE_WAY_FEE
    _WORKER_STRATEGY_NAME = strategy_name or "大股期策略"
    _WORKER_LOTS = int(lots or 1)
    _WORKER_PRODUCT_CODE = clean_code(product_code or "")
    _WORKER_K_MINUTES = normalize_k_minutes(k_minutes)
    _WORKER_MA_PERIOD = normalize_ma_period(ma_period)
    _WORKER_ONE_WAY_FEE = max(0.0, float(one_way_fee or 0.0))
    with open(ticks_file, "rb") as f:
        rows = pickle.load(f)
    # v029：worker 只預分組一次；每一組參數直接重用同一份 session_items。
    _WORKER_TICKS_CACHE = None
    _WORKER_SESSION_ITEMS = _prepare_session_items_from_packed_rows(rows)


def _run_backtest_combo_worker(combo):
    """ProcessPool worker：ticks 已在 initializer 載入，不再每組重複傳輸。"""
    params = _combo_params(_WORKER_STRATEGY_NAME, _WORKER_LOTS, _WORKER_PRODUCT_CODE, combo, k_minutes=_WORKER_K_MINUTES, ma_period=_WORKER_MA_PERIOD, one_way_fee=_WORKER_ONE_WAY_FEE)
    session_items = _WORKER_SESSION_ITEMS or _prepare_session_items_from_ticks(_WORKER_TICKS_CACHE or [])
    ds, tr, _records, _events = run_strategy_backtest_session_items(session_items, progress=None, **params)
    return _summarize_combo_result(ds, tr, params)

def _run_backtest_combo_chunk_worker(combos):
    """v029：一個 future 連跑多組，降低 ProcessPool 排程/IPC 成本。"""
    out = []
    session_items = _WORKER_SESSION_ITEMS or _prepare_session_items_from_ticks(_WORKER_TICKS_CACHE or [])
    for combo in list(combos or []):
        params = _combo_params(_WORKER_STRATEGY_NAME, _WORKER_LOTS, _WORKER_PRODUCT_CODE, combo, k_minutes=_WORKER_K_MINUTES, ma_period=_WORKER_MA_PERIOD, one_way_fee=_WORKER_ONE_WAY_FEE)
        ds, tr, _records, _events = run_strategy_backtest_session_items(session_items, progress=None, **params)
        out.append(_summarize_combo_result(ds, tr, params))
    return out


def _run_backtest_combo_chunk(payload):
    """舊入口保留相容；新版群組回測改用 initializer，避免每批重複傳 ticks。"""
    ticks = payload.get("ticks") or []
    combos = payload.get("combos") or []
    strategy_name = payload.get("strategy_name") or "大股期策略"
    lots = int(payload.get("lots") or 1)
    code = clean_code(payload.get("product_code") or "")
    out = []
    for combo in combos:
        params = _combo_params(strategy_name, lots, code, combo, k_minutes=payload.get("k_minutes", 1), ma_period=payload.get("ma_period", 3), one_way_fee=payload.get("one_way_fee", 0.0))
        ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, progress=None, **params)
        out.append(_summarize_combo_result(ds, tr, params))
    return out


def _adaptive_parallel_workers(requested_workers, combo_count, tick_count):
    """避免少量參數卻開太多 process，造成大量 tick 複製與啟動成本。"""
    requested_workers = max(1, int(requested_workers or 1))
    combo_count = max(1, int(combo_count or 1))
    tick_count = max(0, int(tick_count or 0))
    if combo_count <= 1 or requested_workers <= 1:
        return 1
    # v030 追求最快：大多數情況盡量照使用者指定核心跑；只在組數明顯少於核心時縮小。
    if combo_count <= 4:
        return max(1, min(requested_workers, combo_count))
    if combo_count <= 12:
        return max(1, min(requested_workers, combo_count, max(4, requested_workers)))
    return max(1, min(requested_workers, combo_count))


def _terminate_process_pool(executor):
    """取消時主動終止已在跑的 worker；比等待 as_completed 回來快很多。"""
    if executor is None:
        return
    # Python 3.14+ 有正式 API；Python 3.11 走底層 _processes。
    for method_name in ("terminate_workers", "kill_workers"):
        method = getattr(executor, method_name, None)
        if callable(method):
            try:
                method()
                return
            except Exception:
                pass
    try:
        procs = getattr(executor, "_processes", None) or {}
        for proc in list(procs.values()):
            try:
                if proc.is_alive():
                    proc.terminate()
            except Exception:
                pass
        # terminate 可能對正在純 CPU 迴圈的 Windows 子行程不夠即時，再補 kill。
        deadline = time_module.time() + 0.8
        while time_module.time() < deadline:
            alive = []
            for proc in list(procs.values()):
                try:
                    if proc.is_alive():
                        alive.append(proc)
                except Exception:
                    pass
            if not alive:
                break
            time_module.sleep(0.05)
        for proc in list(procs.values()):
            try:
                if proc.is_alive():
                    proc.kill()
            except Exception:
                pass
    except Exception:
        pass


def _force_exit_current_process_tree():
    """關閉視窗時使用：殺掉目前 Python 與其 ProcessPool 子行程。

    這只在使用者關閉整個面板時呼叫；一般「取消」不會殺掉主程式。
    """
    if os.name == "nt":
        try:
            creationflags = 0x08000000  # CREATE_NO_WINDOW
            subprocess.Popen(
                ["taskkill", "/PID", str(os.getpid()), "/T", "/F"],
                stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                close_fds=True, creationflags=creationflags,
            )
            return True
        except Exception:
            return False
    return False


def _chunk_list_even(items, parts):
    items = list(items or [])
    parts = max(1, int(parts or 1))
    if not items:
        return []
    parts = min(parts, len(items))
    base = len(items) // parts
    extra = len(items) % parts
    chunks = []
    start = 0
    for i in range(parts):
        n = base + (1 if i < extra else 0)
        chunk = items[start:start+n]
        if chunk:
            chunks.append(chunk)
        start += n
    return chunks

class App:
    def __init__(self, root):
        self.root = root
        self.ui_settings = load_ui_settings()
        root.title(f"小火車回測器 {APP_VERSION}（MA策略）")
        saved_root_geo = self.get_setting("geometry.root", "")
        self._apply_safe_root_geometry(saved_root_geo)
        try:
            root.protocol("WM_DELETE_WINDOW", self.on_close)
        except Exception:
            pass
        self.file_text = StringVar(value="")
        self.strategy = StringVar(value="大股期策略")  # 舊單組相容用；實際回測由 strategy_mode + 商品類型解析。
        self.strategy_mode = StringVar(value=str(self.get_setting("defaults.strategy_mode", TRAIN_STRATEGY_DISPLAY) or TRAIN_STRATEGY_DISPLAY))
        if self.strategy_mode.get() not in STRATEGY_MODE_VALUES:
            self.strategy_mode.set(THREE_MA_STRATEGY_DISPLAY if is_three_ma_strategy(self.strategy_mode.get()) else TRAIN_STRATEGY_DISPLAY)
        self.ma_period_text = StringVar(value=str(self.get_setting("defaults.ma_period", "3") or "3"))
        self.k_minutes_text = StringVar(value=str(self.get_setting("defaults.k_minutes", "1") or "1"))
        self.stock_size_mode = StringVar(value=str(self.get_setting("defaults.stock_size_mode", "大股期") or "大股期"))
        self.result_filter_text = StringVar(value="總表")
        self.result_filter_code_map = {}
        self.product_keyword = StringVar(value="")
        self.product_choice = StringVar(value="")
        self.lots = IntVar(value=int(self.get_setting("defaults.lots", 1) or 1))
        self.one_way_fee_text = StringVar(value="0")  # v041：手續費固定自動計算；舊設定不再沿用。v042：認賠/賺飽依新台幣淨損益判斷。
        self.tp_points = DoubleVar(value=5.0)
        self.sl_points = DoubleVar(value=0.0)
        self.loss_exit = DoubleVar(value=30000)
        self.lock_profit_exit = DoubleVar(value=25000)
        self.margin = DoubleVar(value=110000)
        self.ratio_text = StringVar(value="")  # 保留給舊函式相容；v019 介面不再使用保證金比例測試。
        self.date_start_text = StringVar(value="")
        self.date_end_text = StringVar(value="")
        self.opt_start_text = StringVar(value="")  # 保留給舊函式相容；v019 介面不再顯示找最佳/驗證。
        self.opt_end_text = StringVar(value="")
        self.valid_start_text = StringVar(value="")
        self.valid_end_text = StringVar(value="")
        self.tp_start_text = StringVar(value=str(self.get_setting("defaults.tp_start", "5") or "5"))
        self.tp_end_text = StringVar(value=str(self.get_setting("defaults.tp_end", "20") or "20"))
        self.tp_step_text = StringVar(value=str(self.get_setting("defaults.tp_step", "1") or "1"))
        self.sl_start_text = StringVar(value=str(self.get_setting("defaults.sl_start", "10") or "10"))
        self.sl_end_text = StringVar(value=str(self.get_setting("defaults.sl_end", "10") or "10"))
        self.sl_step_text = StringVar(value=str(self.get_setting("defaults.sl_step", "1") or "1"))
        self.loss_start_text = StringVar(value=str(self.get_setting("defaults.loss_start", "30000") or "30000"))
        self.loss_end_text = StringVar(value=str(self.get_setting("defaults.loss_end", "45000") or "45000"))
        self.loss_step_text = StringVar(value=str(self.get_setting("defaults.loss_step", "2500") or "2500"))
        self.profit_start_text = StringVar(value=str(self.get_setting("defaults.profit_start", "30000") or "30000"))
        self.profit_end_text = StringVar(value=str(self.get_setting("defaults.profit_end", "45000") or "45000"))
        self.profit_step_text = StringVar(value=str(self.get_setting("defaults.profit_step", "2500") or "2500"))
        self.cpu_workers_text = StringVar(value=self._initial_cpu_workers_text())
        self.estimate_text = StringVar(value="預估：請先加入待回測商品並設定範圍")
        self.ratio_preview = StringVar(value="")
        self.margin_info = StringVar(value="尚未更新期交所保證金資料")
        self.margin_master = load_cached_margin_master()
        self.paths = []
        self.raw_options = []
        self.options = []
        self.option_map = {}
        self.primary_month_by_file_code = {}
        self.ticks = []
        self.selected_code = ""
        self.last_day_stats = []
        self.last_trades = []
        self.last_sweep = []
        self.last_optimize = []
        self.last_group_results = []
        self.result_row_map = {}
        self.result_detail_cache = {}
        self.backtest_group = []
        self.backtest_group_codes = set()
        self.group_summary_text = StringVar(value="待回測商品：0 檔")
        self.product_dialog = None
        self.product_combo = None
        self.group_tree = None
        self.product_status = None
        self.sweep_row_map = {}
        self.busy = False
        self.busy_action = ""
        self.cancel_requested = False
        self.pause_requested = False
        self._active_executor = None
        self._active_executor_lock = threading.Lock()
        self.action_widgets = []
        self.lock_widgets = []
        self.build_ui()
        try:
            # v040：若使用者已輸入過四項停利參數，不再於啟動時覆蓋；首次使用才套用預設範圍。
            if not bool(self.get_setting("defaults.param_texts_saved", False)):
                self.apply_stock_size_defaults()
        except Exception as exc:
            log_startup("Apply startup default ranges failed: %s" % exc)
        try:
            self.root.after(50, self.force_window_visible)
            self.root.after(1200, self.force_window_visible)
        except Exception:
            pass
        try:
            init_tick_cache_db()
            self.root.after(250, self.load_cache_products_on_start)
            self.root.after(3000, lambda: self.check_online_update(silent=True))
        except Exception as exc:
            log_startup("Startup cache init failed: %s" % exc)

    def get_setting(self, key, default=None):
        try:
            cur = self.ui_settings
            for part in str(key).split("."):
                if not isinstance(cur, dict) or part not in cur:
                    return default
                cur = cur[part]
            return cur
        except Exception:
            return default

    def set_setting(self, key, value):
        try:
            cur = self.ui_settings
            parts = str(key).split(".")
            for part in parts[:-1]:
                cur = cur.setdefault(part, {})
            cur[parts[-1]] = value
        except Exception:
            pass

    def _apply_safe_root_geometry(self, saved_root_geo=""):
        geo = str(saved_root_geo or "").strip()
        ok = False
        try:
            if geo and _geometry_is_visible_on_screen(self.root, geo):
                self.root.geometry(geo)
                ok = True
            else:
                self.root.geometry(_default_root_geometry(self.root))
                if geo:
                    self.set_setting("geometry.root", "")
                    log_startup("Reset off-screen root geometry: %s" % geo)
        except Exception as exc:
            try:
                self.root.geometry(_default_root_geometry(self.root))
            except Exception:
                pass
            log_startup("Root geometry fallback: %s" % exc)
        if (not geo) or (not ok):
            try:
                self.root.state("zoomed")
            except Exception:
                pass

    def force_window_visible(self):
        """Bring the main window back on screen after AnyDesk/RDP resolution changes."""
        try:
            if str(self.root.state()) == "iconic":
                self.root.state("normal")
        except Exception:
            pass
        try:
            self.root.update_idletasks()
        except Exception:
            pass
        try:
            geo = self.root.geometry()
            if not _geometry_is_visible_on_screen(self.root, geo):
                self.root.geometry(_default_root_geometry(self.root))
                self.set_setting("geometry.root", "")
                log_startup("Force visible reset geometry: %s" % geo)
        except Exception:
            pass
        try:
            self.root.deiconify()
            self.root.lift()
            self.root.focus_force()
        except Exception:
            pass
        try:
            self.root.attributes("-topmost", True)
            self.root.after(900, lambda: self.root.attributes("-topmost", False))
        except Exception:
            pass

    def save_settings(self):
        save_ui_settings(self.ui_settings)

    def _param_preset_key(self):
        mode = "three_ma" if self.is_three_ma_mode() else ("train_small" if str(self.stock_size_mode.get() or "") == "小股期" else "train_big")
        return mode

    def _current_param_texts(self):
        return {
            "tp_start": str(self.tp_start_text.get() or ""),
            "tp_end": str(self.tp_end_text.get() or ""),
            "tp_step": str(self.tp_step_text.get() or ""),
            "sl_start": str(self.sl_start_text.get() or ""),
            "sl_end": str(self.sl_end_text.get() or ""),
            "sl_step": str(self.sl_step_text.get() or ""),
            "loss_start": str(self.loss_start_text.get() or ""),
            "loss_end": str(self.loss_end_text.get() or ""),
            "loss_step": str(self.loss_step_text.get() or ""),
            "profit_start": str(self.profit_start_text.get() or ""),
            "profit_end": str(self.profit_end_text.get() or ""),
            "profit_step": str(self.profit_step_text.get() or ""),
        }

    def save_current_param_texts(self):
        try:
            data = self._current_param_texts()
            for k, v in data.items():
                self.set_setting("defaults." + k, v)
            self.set_setting("defaults.lots", int(self.lots.get() or 1))
            self.set_setting("defaults.param_texts_saved", True)
            self.set_setting("param_presets." + self._param_preset_key(), data)
            self.save_settings()
        except Exception:
            pass

    def _load_param_preset(self, key):
        data = self.get_setting("param_presets." + str(key), None)
        if not isinstance(data, dict):
            return False
        mapping = {
            "tp_start": self.tp_start_text, "tp_end": self.tp_end_text, "tp_step": self.tp_step_text,
            "sl_start": self.sl_start_text, "sl_end": self.sl_end_text, "sl_step": self.sl_step_text,
            "loss_start": self.loss_start_text, "loss_end": self.loss_end_text, "loss_step": self.loss_step_text,
            "profit_start": self.profit_start_text, "profit_end": self.profit_end_text, "profit_step": self.profit_step_text,
        }
        for k, var in mapping.items():
            if k in data:
                var.set(str(data.get(k) or ""))
        return True

    def one_way_fee_value(self):
        """v041：回測手續費固定自動計算。

        傳 0 給 strategy_core，核心會依商品種類與每筆進出成交價
        自動計算單邊車票費；進場扣一次、平倉再扣一次。
        舊版 defaults.one_way_fee 僅保留相容，不再參與回測。
        """
        return 0.0

    def save_root_geometry(self):
        try:
            geo = self.root.geometry()
            if _geometry_is_visible_on_screen(self.root, geo):
                self.set_setting("geometry.root", geo)
            else:
                self.set_setting("geometry.root", "")
            self.save_settings()
        except Exception:
            pass

    def on_close(self):
        # v028：視窗右上角 X 必須同步停止背景回測與 ProcessPool。
        # 舊版只 destroy Tk 視窗；背景 thread / python 子行程仍會繼續把 CPU 吃滿。
        self.cancel_requested = True
        self.pause_requested = False
        self.save_current_param_texts()
        self.save_all_column_widths()
        self.save_root_geometry()
        try:
            self._cancel_active_executor()
        except Exception:
            pass
        if bool(getattr(self, "busy", False)) or getattr(self, "_active_executor", None) is not None:
            try:
                self.info.configure(text="正在關閉：已停止回測核心與背景 Python。", foreground="red")
                self.root.update_idletasks()
            except Exception:
                pass
            # Windows 使用 taskkill /T /F 連同 ProcessPool 子行程一起清掉，
            # 避免關閉面板後 python.exe / pythonw.exe 還在 97% CPU 運算。
            if _force_exit_current_process_tree():
                return
            try:
                self.root.destroy()
            except Exception:
                pass
            try:
                os._exit(0)
            except Exception:
                pass
            return
        try:
            self.root.destroy()
        except Exception:
            pass

    def apply_dialog_geometry(self, win, key, default_geo=None):
        geo = self.get_setting("geometry." + key, "")
        try:
            if geo and _geometry_is_visible_on_screen(win, geo):
                win.geometry(geo)
            elif default_geo:
                win.geometry(default_geo)
            else:
                win.geometry(_default_root_geometry(win, 1000, 700))
        except Exception:
            pass
        try:
            win.after(80, lambda: (win.deiconify(), win.lift(), win.focus_force()))
        except Exception:
            pass
        def _save(event=None):
            if event is not None and getattr(event, "widget", None) is not win:
                return
            try:
                geo_now = win.geometry()
                if _geometry_is_visible_on_screen(win, geo_now):
                    self.set_setting("geometry." + key, geo_now)
                else:
                    self.set_setting("geometry." + key, "")
                self.save_settings()
            except Exception:
                pass
        try:
            win.bind("<Destroy>", _save, add="+")
        except Exception:
            pass

    def save_tree_column_widths(self, tree):
        key = getattr(tree, "_settings_key", "")
        if not key:
            return
        try:
            data = {col: int(tree.column(col, "width") or 0) for col in list(tree["columns"])}
            self.set_setting("columns." + key, data)
            try:
                self.set_setting("column_order." + key, list(tree["displaycolumns"]))
            except Exception:
                pass
            self.save_settings()
        except Exception:
            pass

    def enable_tree_column_drag(self, tree):
        tree._drag_col = None
        def displayed_cols():
            cols = list(tree["displaycolumns"])
            if not cols or cols == ["#all"]:
                cols = list(tree["columns"])
            return cols
        def col_from_event(event):
            try:
                if tree.identify_region(event.x, event.y) != "heading":
                    return None
                col_id = tree.identify_column(event.x)
                if not col_id.startswith("#"):
                    return None
                idx = int(col_id[1:]) - 1
                cols = displayed_cols()
                if 0 <= idx < len(cols):
                    return cols[idx]
            except Exception:
                return None
            return None
        def start(event):
            tree._drag_col = col_from_event(event)
        def motion(event):
            src = getattr(tree, "_drag_col", None)
            dst = col_from_event(event)
            if not src or not dst or src == dst:
                return
            cols = displayed_cols()
            if src not in cols or dst not in cols:
                return
            cols.remove(src)
            cols.insert(cols.index(dst), src)
            tree["displaycolumns"] = cols
        def end(event):
            if getattr(tree, "_drag_col", None):
                self.save_tree_column_widths(tree)
            tree._drag_col = None
        try:
            tree.bind("<ButtonPress-1>", start, add="+")
            tree.bind("<B1-Motion>", motion, add="+")
            tree.bind("<ButtonRelease-1>", end, add="+")
        except Exception:
            pass

    def save_all_column_widths(self):
        for name in ("result_tree", "summary_tree", "detail_tree", "sweep_tree", "optimize_tree"):
            tree = getattr(self, name, None)
            if tree is not None:
                self.save_tree_column_widths(tree)

    def available_trade_dates_for_code(self, code):
        code = clean_code(code)
        if not code or not cache_has_code(code):
            return []
        conn = db_connect()
        try:
            rows = conn.execute("""
                SELECT DISTINCT t.trade_date
                FROM ticks t JOIN primary_months pm
                  ON t.source_file_id=pm.source_file_id AND t.code=pm.code AND t.month=pm.primary_month
                WHERE t.code=?
                ORDER BY t.trade_date
            """, (code,)).fetchall()
        finally:
            conn.close()
        return [_date_from_text(r[0]) for r in rows if _date_from_text(r[0])]

    def resolve_date_range_for_code(self, code, start_var, end_var, label="回測"):
        d1 = _date_from_text(str(start_var.get() or "").strip()) if str(start_var.get() or "").strip() else None
        d2 = _date_from_text(str(end_var.get() or "").strip()) if str(end_var.get() or "").strip() else None
        if str(start_var.get() or "").strip() and not d1:
            raise ValueError("%s起日格式錯誤，請用 YYYY-MM-DD。" % label)
        if str(end_var.get() or "").strip() and not d2:
            raise ValueError("%s迄日格式錯誤，請用 YYYY-MM-DD。" % label)
        if d1 and d2 and d1 > d2:
            raise ValueError("%s起日不可晚於迄日。" % label)
        dates = self.available_trade_dates_for_code(code)
        notes = []
        if dates:
            if d1 and d1 not in dates:
                cand = [d for d in dates if d >= d1]
                nd = cand[0] if cand else dates[-1]
                notes.append("%s起日 %s 無資料，已改用 %s" % (label, _date_text(d1), _date_text(nd)))
                d1 = nd
                try: start_var.set(_date_text(d1))
                except Exception: pass
            if d2 and d2 not in dates:
                cand = [d for d in dates if d <= d2]
                nd = cand[-1] if cand else dates[0]
                notes.append("%s迄日 %s 無資料，已改用 %s" % (label, _date_text(d2), _date_text(nd)))
                d2 = nd
                try: end_var.set(_date_text(d2))
                except Exception: pass
            if d1 and d2 and d1 > d2:
                # 起迄修正後仍交錯時，縮成最近同一天，避免空資料。
                nd = d1 if d1 in dates else dates[0]
                d2 = nd
                try: end_var.set(_date_text(d2))
                except Exception: pass
                notes.append("%s日期區間無交集，已縮成 %s" % (label, _date_text(nd)))
        if notes:
            try:
                self.info.configure(text="｜".join(notes), foreground="#B00020")
            except Exception:
                pass
            try:
                messagebox.showinfo("日期已自動修正", "\n".join(notes))
            except Exception:
                pass
        return d1, d2, notes

    @staticmethod
    def ticks_date_range_text(ticks):
        dates = sorted(set((_date_from_text(str(t.session_key).split(":")[0]) or t.d) for t in ticks))
        dates = [d for d in dates if d]
        if not dates:
            return "無資料", 0
        return "%s～%s" % (_date_text(dates[0]), _date_text(dates[-1])), len(dates)

    @staticmethod
    def day_stats_summary(ds):
        sessions = [str(x.get("session", "")) for x in ds]
        date_texts = []
        for s0 in sessions:
            m = re.search(r"\d{4}-\d{2}-\d{2}", s0)
            if m:
                date_texts.append(m.group(0))
        uniq = sorted(set(date_texts))
        total_days = len(uniq) if uniq else len(ds)
        valid = [x for x in ds if float(x.get("trades", 0) or 0) > 0]
        valid_days = len(valid)
        rng = "%s～%s" % (uniq[0], uniq[-1]) if uniq else "無資料"
        return {"range": rng, "total_days": total_days, "valid_days": valid_days, "valid_stats": valid}

    @staticmethod
    def average_net_excluding_zero_trade_days(ds):
        valid = [x for x in ds if float(x.get("trades", 0) or 0) > 0]
        if not valid:
            return 0.0, 0
        return sum(float(x.get("net", 0.0) or 0.0) for x in valid) / len(valid), len(valid)

    def open_date_picker(self, var, title="選擇日期"):
        base = _date_from_text(var.get()) or date.today()
        win = Toplevel(self.root)
        win.title(title)
        self.apply_dialog_geometry(win, "date_picker", "360x320")
        cur = {"year": base.year, "month": base.month}
        head = ttk.Frame(win, padding=8)
        head.pack(fill="x")
        body = ttk.Frame(win, padding=8)
        body.pack(fill=BOTH, expand=True)
        title_var = StringVar(value="")
        def draw():
            for w in body.winfo_children():
                w.destroy()
            y, m = cur["year"], cur["month"]
            title_var.set("%04d-%02d" % (y, m))
            week_names = ["一", "二", "三", "四", "五", "六", "日"]
            for c, name in enumerate(week_names):
                ttk.Label(body, text=name, anchor="center").grid(row=0, column=c, sticky="nsew", padx=2, pady=2)
            first = date(y, m, 1)
            if m == 12:
                next_month = date(y+1, 1, 1)
            else:
                next_month = date(y, m+1, 1)
            days = (next_month - first).days
            r = 1
            c = first.weekday()
            for day in range(1, days+1):
                d = date(y, m, day)
                def pick(dd=d):
                    var.set(_date_text(dd))
                    try: win.destroy()
                    except Exception: pass
                ttk.Button(body, text=str(day), command=pick, width=4).grid(row=r, column=c, sticky="nsew", padx=2, pady=2)
                c += 1
                if c >= 7:
                    c = 0
                    r += 1
            for cc in range(7):
                body.columnconfigure(cc, weight=1)
        def prev_month():
            if cur["month"] == 1:
                cur["year"] -= 1; cur["month"] = 12
            else:
                cur["month"] -= 1
            draw()
        def next_month():
            if cur["month"] == 12:
                cur["year"] += 1; cur["month"] = 1
            else:
                cur["month"] += 1
            draw()
        ttk.Button(head, text="<", command=prev_month, width=4).pack(side="left")
        ttk.Label(head, textvariable=title_var, anchor="center").pack(side="left", fill="x", expand=True)
        ttk.Button(head, text=">", command=next_month, width=4).pack(side="left")
        bottom = ttk.Frame(win, padding=(8, 0, 8, 8))
        bottom.pack(fill="x")
        ttk.Button(bottom, text="清空", command=lambda: (var.set(""), win.destroy())).pack(side="left")
        ttk.Button(bottom, text="今天", command=lambda: (var.set(_date_text(date.today())), win.destroy())).pack(side="right")
        draw()

    def on_root_configure(self, event=None):
        try:
            width = max(520, int(self.root.winfo_width()) - 60)
            if hasattr(self, "estimate_label"):
                self.estimate_label.configure(wraplength=width)
            if hasattr(self, "info"):
                self.info.configure(wraplength=width)
        except Exception:
            pass

    def product_name_text(self, opt_or_code):
        opt = None
        if isinstance(opt_or_code, ProductOption):
            opt = opt_or_code
        else:
            code = clean_code(str(opt_or_code or ""))
            for o in self.options:
                if clean_code(o.code) == code:
                    opt = o
                    break
        if not opt:
            return clean_code(str(opt_or_code or ""))
        name = str(getattr(opt, "stock_name", "") or "").strip()
        if name:
            if not name.endswith("期貨"):
                name = name + "期貨"
            return name
        return clean_code(str(getattr(opt, "code", "") or opt_or_code or ""))

    def option_title(self, opt_or_code):
        # 介面顯示只保留中文商品名稱；商品代號仍保留在內部供查詢與回測。
        return self.product_name_text(opt_or_code)

    def _set_active_executor(self, executor):
        try:
            with self._active_executor_lock:
                self._active_executor = executor
        except Exception:
            self._active_executor = executor

    def _cancel_active_executor(self):
        try:
            with self._active_executor_lock:
                ex = self._active_executor
        except Exception:
            ex = getattr(self, "_active_executor", None)
        if ex is not None:
            try:
                _terminate_process_pool(ex)
            except Exception:
                pass
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                try:
                    ex.shutdown(wait=False)
                except Exception:
                    pass
            except Exception:
                pass

    def request_cancel(self):
        if self.busy:
            self.cancel_requested = True
            self._cancel_active_executor()
            try:
                self.info.configure(text="取消中：%s｜正在停止回測核心，不等待整批跑完" % self.busy_action, foreground="red")
            except Exception:
                pass

    def toggle_pause(self):
        if not self.busy:
            return
        self.pause_requested = not bool(self.pause_requested)
        try:
            self.pause_btn.configure(text="繼續" if self.pause_requested else "暫停")
            self.info.configure(text=("已暫停：" if self.pause_requested else "繼續執行：") + self.busy_action, foreground="red")
        except Exception:
            pass

    def register_lock_widget(self, widget):
        self.lock_widgets.append(widget)
        return widget

    def action_button(self, parent, text, command, **pack_kwargs):
        btn = ttk.Button(parent, text=text, command=command)
        self.action_widgets.append(btn)
        self.lock_widgets.append(btn)
        btn.pack(**pack_kwargs)
        return btn

    @staticmethod
    def _format_seconds(seconds):
        try:
            seconds = int(max(0, float(seconds)))
        except Exception:
            seconds = 0
        if seconds < 60:
            return "%d秒" % seconds
        minutes, sec = divmod(seconds, 60)
        if minutes < 60:
            return "%d分%02d秒" % (minutes, sec)
        hours, minutes = divmod(minutes, 60)
        return "%d小時%02d分" % (hours, minutes)

    def progress_update(self, current, total, detail="", stage="回測運算"):
        if not self.busy:
            return
        while bool(getattr(self, "pause_requested", False)) and not bool(getattr(self, "cancel_requested", False)):
            time_module.sleep(0.2)
        if bool(getattr(self, "cancel_requested", False)):
            raise OperationCancelled("使用者已取消本次背景作業")
        now = time_module.time()
        if now - getattr(self, "_last_progress_update", 0.0) < 0.85 and float(current or 0) < float(total or 1):
            return
        self._last_progress_update = now
        start = getattr(self, "progress_start", now) or now
        elapsed = max(0.0, now - start)
        total = max(1.0, float(total or 1))
        current = max(0.0, min(float(current or 0), total))
        ratio = current / total
        percent = ratio * 100.0
        if ratio >= 0.999:
            eta_text = "0秒"
        elif elapsed < 3.0 or ratio <= 0.005:
            eta_text = "正在即時估算..."
        else:
            remaining = elapsed * (1.0 - ratio) / max(ratio, 0.0001)
            eta_text = self._format_seconds(remaining)
        msg = "背景執行中：%s｜%s｜%s %.1f%%｜即時剩餘 %s" % (self.busy_action, str(detail or "處理中"), str(stage or "回測運算"), percent, eta_text)
        def _apply():
            if self.busy:
                try:
                    self.info.configure(text=msg, foreground="red")
                except Exception:
                    pass
        try:
            self.root.after(0, _apply)
        except Exception:
            pass

    def status_update(self, detail, foreground="red"):
        msg = str(detail or "")
        def _apply():
            if self.busy:
                try:
                    self.info.configure(text=msg, foreground=foreground)
                except Exception:
                    pass
        try:
            self.root.after(0, _apply)
        except Exception:
            pass

    def set_busy(self, busy, action=""):
        self.busy = bool(busy)
        self.busy_action = str(action or "")
        if self.busy:
            self.progress_start = time_module.time()
            self._last_progress_update = 0.0
            self.cancel_requested = False
            self.pause_requested = False
        else:
            self._set_active_executor(None)
        state = "disabled" if self.busy else "normal"
        for widget in self.lock_widgets:
            try:
                # Combobox 在忙碌結束後恢復 readonly；其他 widget 恢復 normal。
                if not self.busy and isinstance(widget, ttk.Combobox):
                    widget.configure(state="readonly")
                else:
                    widget.configure(state=state)
            except Exception:
                pass
        try:
            if not self.busy:
                self._update_strategy_parameter_controls()
        except Exception:
            pass
        try:
            if hasattr(self, "pause_btn"):
                self.pause_btn.configure(state=("normal" if self.busy else "disabled"), text="暫停")
            if hasattr(self, "cancel_btn"):
                self.cancel_btn.configure(state=("normal" if self.busy else "disabled"))
        except Exception:
            pass
        try:
            self.root.configure(cursor="watch" if self.busy else "")
        except Exception:
            pass
        if self.busy:
            self.info.configure(text="背景執行中：%s，請稍候。" % self.busy_action, foreground="red")
        else:
            try:
                self.info.configure(foreground="#333333")
            except Exception:
                pass
        self.root.update_idletasks()

    def _should_show_backtest_done_popup(self, action):
        """回測類背景作業成功完成後，跳出提醒；取消/失敗/非回測作業不提醒。"""
        text = str(action or "")
        if not text or "載入該列" in text:
            return False
        return any(key in text for key in ("回測", "精跑", "比例測試", "最佳化熱門商品"))

    def _backtest_done_popup_text(self, action, result):
        """依不同回測結果組成簡短完成訊息；失敗時回傳通用文字。"""
        lines = ["%s已完成。" % str(action or "回測")]
        try:
            if isinstance(result, dict):
                products = int(result.get("products", 0) or 0)
                jobs = int(result.get("jobs", 0) or 0)
                elapsed = float(result.get("elapsed", 0.0) or 0.0)
                if products > 0:
                    lines.append("商品：%d 檔" % products)
                if jobs > 0:
                    lines.append("完成組數：%s 組" % f"{jobs:,}")
                if elapsed > 0:
                    lines.append("耗時：%s" % self._format_seconds(elapsed))
                return "\n".join(lines)

            if isinstance(result, tuple) and len(result) >= 4:
                code = result[0]
                ds = result[2] if isinstance(result[2], list) else []
                tr = result[3] if isinstance(result[3], list) else []
                if ds:
                    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds if isinstance(x, dict))
                    avg, valid_days = self.average_net_excluding_zero_trade_days(ds)
                    summary = self.day_stats_summary(ds)
                    lines.append("商品：%s" % self.option_title(code))
                    lines.append("區間：%s｜有效 %d 天" % (summary.get("range", ""), valid_days))
                    lines.append("總淨利：%s 元｜平均每日：%s 元" % (format_money_plain(total), format_money_plain(avg)))
                    lines.append("平倉次數：%d" % len(tr))
                    return "\n".join(lines)

            if isinstance(result, list):
                lines.append("結果筆數：%s" % f"{len(result):,}")
                return "\n".join(lines)
        except Exception:
            pass
        return "\n".join(lines)

    def _show_backtest_done_popup(self, action, result):
        try:
            messagebox.showinfo("回測完成", self._backtest_done_popup_text(action, result))
        except Exception:
            pass

    def run_background(self, action, worker, on_done):
        if self.busy:
            messagebox.showinfo("背景執行中", "目前正在執行：%s，請等它完成。" % self.busy_action)
            return
        self.set_busy(True, action)

        def _thread_main():
            try:
                result = worker()
                error = None
            except Exception as exc:
                result = None
                error = exc

            def _finish():
                success = False
                try:
                    if error is not None:
                        if isinstance(error, OperationCancelled):
                            self.info.configure(text="已取消：%s｜已完成的畫面結果保留，不寫入新結果。" % action, foreground="red")
                        else:
                            messagebox.showerror("%s失敗" % action, str(error))
                    else:
                        on_done(result)
                        success = True
                finally:
                    self.set_busy(False)
                if success and self._should_show_backtest_done_popup(action):
                    self._show_backtest_done_popup(action, result)

            try:
                self.root.after(0, _finish)
            except Exception:
                # 視窗已關閉時，不讓背景 thread 繼續拖住 python。
                try:
                    self._cancel_active_executor()
                except Exception:
                    pass

        threading.Thread(target=_thread_main, daemon=True).start()

    def _find_online_update_manifest(self):
        urls = backtester_update_manifest_urls()
        if not urls:
            return {"status": "no_url", "errors": []}
        errors = []
        for url in urls:
            try:
                manifest = fetch_update_manifest(url)
                app_name = str(manifest.get("app") or manifest.get("name") or "").strip()
                if app_name and app_name not in ("TrainBacktester", "小火車回測器", "train_backtester"):
                    raise ValueError("manifest app 不符：%s" % app_name)
                version = str(manifest.get("version") or "").strip()
                if not version:
                    raise ValueError("manifest 缺少 version")
                if _is_newer_version(version, APP_VERSION):
                    return {"status": "update", "manifest": manifest, "manifest_url": url}
                return {"status": "latest", "manifest": manifest, "manifest_url": url}
            except Exception as exc:
                errors.append("%s -> %s" % (url, exc))
                log_startup("Update check failed: %s -> %s" % (url, exc))
        return {"status": "failed", "errors": errors}

    def _update_prompt_text(self, manifest):
        version = str((manifest or {}).get("version") or "").strip()
        title = str((manifest or {}).get("title") or "小火車回測器線上更新").strip()
        message = str((manifest or {}).get("message") or (manifest or {}).get("notes") or "").strip()
        required = bool((manifest or {}).get("required", False))
        lines = [
            "%s" % title,
            "目前版本：%s" % APP_VERSION,
            "線上版本：%s" % version,
        ]
        if required:
            lines.append("此更新標記為必要更新。")
        if message:
            lines.append("")
            lines.append(message)
        lines.append("")
        lines.append("是否立即下載並套用？套用完成後會自動關閉並重開小火車回測器。")
        return "\n".join(lines)

    def _schedule_restart_after_update(self):
        """線上更新完成後，啟動新的回測面板，再關閉目前舊行程。"""
        target_dir = app_dir()
        try:
            self.save_current_param_texts()
            self.save_all_column_widths()
            self.save_root_geometry()
        except Exception:
            pass

        if os.name == "nt":
            try:
                bat_path = os.path.join(tempfile.gettempdir(), "restart_train_backtester_after_update_%s.bat" % os.getpid())
                vbs_path = os.path.join(target_dir, "start_backtester.vbs")
                pyw_path = os.path.join(target_dir, "train_backtester.pyw")
                py_path = os.path.join(target_dir, "train_backtester.py")
                lines = [
                    "@echo off",
                    "setlocal",
                    "cd /d \"%s\"" % target_dir,
                    "timeout /t 1 /nobreak >nul",
                    "if exist \"%s\" (" % vbs_path,
                    "  wscript.exe \"%s\"" % vbs_path,
                    ") else if exist \"%s\" (" % pyw_path,
                    "  start \"\" pyw -3.11 \"%s\"" % pyw_path,
                    ") else (",
                    "  start \"\" py -3.11 \"%s\"" % py_path,
                    ")",
                    "del \"%~f0\" >nul 2>nul",
                    "exit /b 0",
                ]
                with open(bat_path, "w", encoding="mbcs", errors="ignore") as f:
                    f.write("\r\n".join(lines) + "\r\n")
                creationflags = 0x08000000  # CREATE_NO_WINDOW
                subprocess.Popen(["cmd", "/c", bat_path], cwd=target_dir,
                                 stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 close_fds=True, creationflags=creationflags)
                return True
            except Exception as exc:
                log_startup("Restart after update scheduling failed: %s" % exc)
                return False

        try:
            target = os.path.join(target_dir, "train_backtester.pyw")
            if not os.path.exists(target):
                target = os.path.join(target_dir, "train_backtester.py")
            subprocess.Popen([sys.executable, target], cwd=target_dir, start_new_session=True)
            return True
        except Exception as exc:
            log_startup("Restart after update scheduling failed: %s" % exc)
            return False

    def restart_after_online_update(self):
        if bool(getattr(self, "_restart_in_progress", False)):
            return
        self._restart_in_progress = True
        ok = self._schedule_restart_after_update()
        if not ok:
            try:
                messagebox.showwarning("自動重開失敗", "線上更新已套用，但自動重開失敗。請手動關閉並重新開啟小火車回測器。")
            except Exception:
                pass
            return
        try:
            self.info.configure(text="線上更新已完成｜正在關閉並自動重開小火車回測器...", foreground="#B00020")
            self.root.update_idletasks()
        except Exception:
            pass
        try:
            self.root.destroy()
        except Exception:
            pass
        try:
            os._exit(0)
        except Exception:
            pass

    def _prompt_apply_online_update(self, manifest, manifest_url, startup=False):
        if bool(getattr(self, "busy", False)) and str(getattr(self, "busy_action", "")) != "檢查線上更新":
            # 回測運算中不打斷；等使用者手動按檢查更新。
            if not startup:
                messagebox.showinfo("背景執行中", "目前正在執行：%s，請完成或取消後再更新。" % self.busy_action)
            return
        try:
            ok = messagebox.askyesno("發現小火車回測器更新", self._update_prompt_text(manifest))
        except Exception:
            ok = False
        if ok:
            self.root.after(50, lambda: self.apply_online_update(manifest, manifest_url))

    def check_online_update(self, silent=False):
        """檢查小火車回測器線上更新。silent=True 用於啟動後自動檢查。"""
        if silent:
            def _thread_main():
                try:
                    result = self._find_online_update_manifest()
                    if result.get("status") == "update":
                        self.root.after(0, lambda: self._prompt_apply_online_update(result.get("manifest"), result.get("manifest_url"), startup=True))
                except Exception as exc:
                    log_startup("Silent update check failed: %s" % exc)
            try:
                threading.Thread(target=_thread_main, daemon=True).start()
            except Exception:
                pass
            return

        def worker():
            return self._find_online_update_manifest()

        def done(result):
            status = (result or {}).get("status")
            if status == "update":
                self.info.configure(text="發現線上更新｜目前%s → 線上%s" % (APP_VERSION, str((result.get("manifest") or {}).get("version") or "")), foreground="#B00020")
                self._prompt_apply_online_update(result.get("manifest"), result.get("manifest_url"), startup=False)
            elif status == "latest":
                self.info.configure(text="小火車回測器已是最新版：%s" % APP_VERSION, foreground="#333333")
                messagebox.showinfo("檢查線上更新", "目前已是最新版：%s" % APP_VERSION)
            elif status == "no_url":
                messagebox.showinfo(
                    "尚未設定更新網址",
                    "請在小火車回測器資料夾建立或編輯 %s，放入 backtester_update.json 的網址。\n\n"
                    "也可用環境變數 TRAIN_BACKTESTER_UPDATE_MANIFEST_URL 指定。" % BACKTESTER_UPDATE_URL_FILE,
                )
            else:
                detail = "\n".join((result or {}).get("errors") or [])
                if len(detail) > 1600:
                    detail = detail[:1600] + "\n..."
                messagebox.showerror("檢查線上更新失敗", detail or "無法讀取線上更新資訊。")

        self.run_background("檢查線上更新", worker, done)

    def apply_online_update(self, manifest, manifest_url):
        if not manifest or not manifest_url:
            messagebox.showerror("線上更新失敗", "缺少更新資訊。")
            return

        def worker():
            return download_and_apply_update_manifest(manifest, manifest_url, progress=self.progress_update)

        def done(result):
            files = (result or {}).get("updated_files") or []
            backup = (result or {}).get("backup_dir") or ""
            self.info.configure(text="線上更新已套用｜%d個檔案｜準備自動重開小火車回測器" % len(files), foreground="#B00020")
            msg = "線上更新已完成。\n\n已更新檔案：%d 個\n備份位置：%s\n\n按確定後會自動關閉並重開小火車回測器，讓新版生效。" % (len(files), backup or "未建立")
            messagebox.showinfo("線上更新完成", msg)
            try:
                self.root.after(100, self.restart_after_online_update)
            except Exception:
                self.restart_after_online_update()

        self.run_background("下載並套用線上更新", worker, done)

    def margin_items(self):
        try:
            return dict(self.margin_master.get("items", {}) or {})
        except Exception:
            return {}

    def margin_item_for(self, code):
        return self.margin_items().get(clean_code(code), {})

    def enrich_options(self, options):
        items = self.margin_items()
        enriched = []
        for opt in options:
            item = items.get(clean_code(opt.code), {}) if items else {}
            # 期交所保證金資料存在時，只納入股票期貨，並排除台積電/聯電。
            if items:
                if not item:
                    continue
                if item.get("is_excluded_underlying") or item.get("stock_no") in EXCLUDE_UNDERLYING_STOCKS:
                    continue
            if item:
                opt.product_kind = "小股期" if item.get("is_small") else "大股期"
                opt.stock_no = str(item.get("stock_no", ""))
                opt.stock_name = str(item.get("short_name") or item.get("stock_name") or "")
                opt.margin_percent = float(item.get("initial_margin_percent", 0.0) or 0.0)
                multiplier = product_multiplier_from_master_item(item)
                opt.base_margin = margin_base_from_price(opt.last_price, opt.margin_percent, multiplier)
            else:
                opt.product_kind = "UNKNOWN"
                opt.base_margin = 0.0
            opt.display = self.product_display_text(opt)
            enriched.append(opt)
        return enriched

    def product_display_text(self, opt):
        d1 = opt.date_start.strftime("%Y-%m-%d") if opt.date_start else ""
        d2 = opt.date_end.strftime("%Y-%m-%d") if opt.date_end else ""
        miss_count = len([x for x in str(opt.missing_dates or "").split("、") if x.strip()])
        kind = opt.product_kind if opt.product_kind != "UNKNOWN" else "未分類"
        margin = "約%s元" % safe_int_text(opt.base_margin) if opt.base_margin else "保證金待更新"
        rank = int(getattr(opt, "hot_rank", 0) or 0)
        status = str(getattr(opt, "hot_status", "") or "")
        rank_text = "#%d%s｜" % (rank, status) if rank > 0 else ""
        name = self.product_name_text(opt)
        return "%s%s｜%s｜%s天｜平均每日成交量%s口｜%s～%s｜缺%d天｜%s" % (
            rank_text, name, kind, opt.data_days,
            f"{opt.avg_daily_qty:,.0f}", d1, d2, miss_count, margin
        )

    def current_option(self):
        return self.option_map.get(self.product_choice.get())

    def update_margin_text_for_option(self, opt):
        if not opt:
            source_date = self.margin_master.get("source_date", "") if isinstance(self.margin_master, dict) else ""
            if source_date:
                self.margin_info.set("期交所股票期貨保證金資料日期：%s" % source_date)
            else:
                self.margin_info.set("尚未更新期交所保證金資料，請先按「更新期交所保證金資料」。")
            return
        d1 = opt.date_start.strftime("%Y-%m-%d") if opt.date_start else ""
        d2 = opt.date_end.strftime("%Y-%m-%d") if opt.date_end else ""
        missing = opt.missing_dates or "無"
        if len(missing) > 80:
            missing = missing[:80] + "..."
        source_date = self.margin_master.get("source_date", "") if isinstance(self.margin_master, dict) else ""
        rank = int(getattr(opt, "hot_rank", 0) or 0)
        status = str(getattr(opt, "hot_status", "") or "")
        rank_text = "｜熱門排名：#%d %s" % (rank, status) if rank > 0 else "｜熱門排名：未進前15"
        self.margin_info.set(
            "商品資料狀態：%s｜%s%s｜日盤資料%d天｜期交所日期%s～%s｜缺少日期：%s｜最新價%.2f｜保證金資料%s｜基準原始保證金約%s元" % (
                self.product_name_text(opt), opt.product_kind, rank_text, opt.data_days, d1, d2, missing, opt.last_price or 0.0,
                source_date or "未更新", safe_int_text(opt.base_margin)
            )
        )

    def update_ratio_preview(self):
        opt = self.current_option()
        ratio_text = str(self.ratio_text.get() or "").strip()
        if not opt:
            self.ratio_preview.set("請先選擇商品")
            return
        if not opt.base_margin:
            self.ratio_preview.set("缺少期交所保證金資料或商品最新價，無法換算。")
            return
        item = self.margin_item_for(opt.code)
        multiplier = product_multiplier_from_master_item(item, self.strategy.get())
        if not ratio_text:
            r1, r2 = 5.0, 15.0
            tp1 = opt.base_margin / r1
            tp2 = opt.base_margin / r2
            self.ratio_preview.set("空白=測試 1/5～1/15｜停利約 %s～%s 元｜%s 約 %.2f～%.2f 點" % (
                safe_int_text(tp1), safe_int_text(tp2), opt.product_kind, tp1 / multiplier, tp2 / multiplier
            ))
            return
        try:
            ratio = float(ratio_text)
            if ratio <= 0:
                raise ValueError()
        except Exception:
            self.ratio_preview.set("分母請輸入正數，例如 5、10、15。")
            return
        tp_ntd = opt.base_margin / ratio
        tp_points = tp_ntd / multiplier
        self.ratio_preview.set("1/%g｜停利約 %s 元｜%s %.2f 點｜認賠預設可設 %.0f 元｜賺飽預設可設 %.0f 元" % (
            ratio, safe_int_text(tp_ntd), opt.product_kind, tp_points, tp_ntd * 3.0, tp_ntd * 2.0
        ))

    def update_margin_master(self):
        def worker():
            return download_taifex_stock_margin_master()
        def done(master):
            self.margin_master = master
            if self.raw_options:
                self.options = self.enrich_options(self.raw_options)
                self.apply_hot_ranks()
                save_product_summary_cache(self.options)
                self.filter_products()
            count = len(master.get("items", {}) or {})
            self.info.configure(text="期交所股票期貨保證金資料更新完成｜資料日期：%s｜商品數：%d" % (master.get("source_date", ""), count))
            self.update_margin_text_for_option(self.current_option())
            self.update_ratio_preview()
        self.run_background("更新期交所保證金資料", worker, done)

    def hot_rankings(self):
        big = [o for o in self.options if o.product_kind == "大股期"]
        small = [o for o in self.options if o.product_kind == "小股期"]
        big.sort(key=lambda o: o.avg_daily_qty, reverse=True)
        small.sort(key=lambda o: o.avg_daily_qty, reverse=True)
        return big[:15], small[:15]

    def apply_hot_ranks(self):
        """將大股期/小股期熱門排名寫回商品顯示文字。
        每類第1~10名為正式熱門；第11~15名為觀察緩衝。
        """
        for opt in self.options:
            try:
                opt.hot_rank = 0
                opt.hot_status = ""
            except Exception:
                pass
        big = [o for o in self.options if o.product_kind == "大股期"]
        small = [o for o in self.options if o.product_kind == "小股期"]
        for group in (big, small):
            group.sort(key=lambda o: o.avg_daily_qty, reverse=True)
            for i, opt in enumerate(group[:15], start=1):
                opt.hot_rank = i
                opt.hot_status = "前10" if i <= 10 else "觀察"
        for opt in self.options:
            opt.display = self.product_display_text(opt)

    def open_hot_ranking(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「更新期交所保證金資料」，再按「重整商品清單/排名」。")
            return
        win = Toplevel(self.root)
        win.title("股票期貨熱門商品排名｜大股期/小股期")
        self.apply_dialog_geometry(win, "hot_ranking", "1250x760")
        note = ttk.Label(win, text="規則：只納入股票期貨；台積電、聯電自動跳過；每類第1～10名為正式熱門，第11～15名為觀察緩衝。可在此一鍵加入待回測群組，再回主畫面刪除不用的商品。", anchor="w")
        note.pack(fill="x", padx=10, pady=(10, 4))
        nb = ttk.Notebook(win)
        nb.pack(fill=BOTH, expand=True, padx=10, pady=8)
        big, small = self.hot_rankings()
        self._build_rank_tab(nb, "大股期前10＋緩衝15", big)
        self._build_rank_tab(nb, "小股期前10＋緩衝15", small)

    def _build_rank_tab(self, notebook, title, options):
        frame = ttk.Frame(notebook)
        notebook.add(frame, text=title)
        btnbar = ttk.Frame(frame)
        btnbar.pack(fill="x", padx=4, pady=(4, 4))
        option_by_iid = {}
        ttk.Button(btnbar, text="加入選取到待回測", command=lambda: self.add_hot_tree_selection_to_group(tree, option_by_iid, title + "選取")).pack(side="left", padx=(0, 6))
        ttk.Button(btnbar, text="加入本頁前10", command=lambda opts=list(options[:10]): self.add_options_to_group(opts, title + "前10")).pack(side="left", padx=6)
        ttk.Button(btnbar, text="加入本頁全部15", command=lambda opts=list(options): self.add_options_to_group(opts, title + "全部15")).pack(side="left", padx=6)
        ttk.Label(btnbar, text="提示：可先加入前10或全部15，再回主畫面刪除不用的。雙擊單列也會加入該商品。", foreground="#555555").pack(side="left", padx=12)
        cols = [
            ("rank", "排名", 60), ("status", "狀態", 90), ("code", "商品代號", 90),
            ("name", "商品", 160), ("avg_qty", "平均每日成交量", 140),
            ("days", "資料天數", 90), ("range", "日期範圍", 190), ("missing", "缺少日期", 250),
            ("margin", "基準原始保證金", 140), ("tp5", "1/5停利", 110), ("point", "點數", 90)
        ]
        tree = self.make_tree(frame, cols, settings_key="hot_" + title)
        for i, opt in enumerate(options, start=1):
            status = "前10" if i <= 10 else "觀察"
            d1 = opt.date_start.strftime("%Y-%m-%d") if opt.date_start else ""
            d2 = opt.date_end.strftime("%Y-%m-%d") if opt.date_end else ""
            tp5 = (opt.base_margin or 0.0) / 5.0 if opt.base_margin else 0.0
            item = self.margin_item_for(opt.code)
            mult = product_multiplier_from_master_item(item, self.strategy.get())
            points = tp5 / mult if mult else 0.0
            iid = tree.insert("", END, values=(i, status, opt.code, opt.stock_name, f"{opt.avg_daily_qty:,.0f}", opt.data_days,
                                               "%s～%s" % (d1, d2), opt.missing_dates or "無", safe_int_text(opt.base_margin),
                                               safe_int_text(tp5), "%.2f" % points))
            option_by_iid[iid] = opt
        tree.bind("<Double-1>", lambda _e: self.add_hot_tree_selection_to_group(tree, option_by_iid, title + "雙擊"), add="+")

    def build_ui(self):
        style = ttk.Style()
        try:
            base_font = tkfont.nametofont("TkDefaultFont")
            base_font.configure(family="Microsoft JhengHei UI", size=11)
            tkfont.nametofont("TkTextFont").configure(family="Microsoft JhengHei UI", size=11)
            tkfont.nametofont("TkHeadingFont").configure(family="Microsoft JhengHei UI", size=11, weight="bold")
        except Exception:
            pass
        try:
            style.configure("Treeview", rowheight=30, font=("Microsoft JhengHei UI", 10))
            style.configure("Treeview.Heading", font=("Microsoft JhengHei UI", 10, "bold"))
            style.map("Treeview", foreground=[], background=[("selected", "#DCEBFF")])
        except Exception:
            pass

        top = ttk.Frame(self.root, padding=8)
        top.pack(fill="x")

        # v021：右側控制鍵固定靠右，避免視窗寬度不足時「取消」被擠出畫面。
        top_right = ttk.Frame(top)
        top_right.pack(side="right", padx=(8, 0))
        self.cancel_btn = ttk.Button(top_right, text="取消", command=self.request_cancel, state="disabled", width=8)
        self.cancel_btn.pack(side="right", padx=(3, 0))
        self.pause_btn = ttk.Button(top_right, text="暫停", command=self.toggle_pause, state="disabled", width=8)
        self.pause_btn.pack(side="right", padx=(0, 3))

        top_left = ttk.Frame(top)
        top_left.pack(side="left", fill="x", expand=True)
        ttk.Label(top_left, text="官方 Daily ZIP/CSV 檔案：").pack(side="left")
        self.file_entry = self.register_lock_widget(ttk.Entry(top_left, textvariable=self.file_text, width=52))
        self.file_entry.pack(side="left", padx=5, fill="x", expand=True)
        self.action_button(top_left, text="選擇檔案（可多選）", command=self.browse, side="left")
        self.action_button(top_left, text="匯入/追加到快取", command=self.import_selected_files, side="left", padx=5)
        self.action_button(top_left, text="重整商品清單/排名", command=self.scan_files, side="left", padx=5)
        self.action_button(top_left, text="熱門排名", command=self.open_hot_ranking, side="left", padx=5)
        self.action_button(top_left, text="更新期交所保證金資料", command=self.update_margin_master, side="left", padx=5)
        self.action_button(top_left, text="檢查線上更新", command=lambda: self.check_online_update(silent=False), side="left", padx=5)

        product_bar = ttk.LabelFrame(self.root, text="待回測商品", padding=8)
        product_bar.pack(fill="x", padx=8, pady=4)
        ttk.Label(product_bar, textvariable=self.group_summary_text, anchor="w", justify="left").pack(side="left", fill="x", expand=True, padx=(0, 8))
        manage_btn = ttk.Button(product_bar, text="選擇商品 / 管理群組", command=self.open_product_dialog)
        manage_btn.pack(side="left", padx=4)
        clear_main_btn = ttk.Button(product_bar, text="清空待回測", command=self.clear_backtest_group)
        clear_main_btn.pack(side="left", padx=4)
        self.lock_widgets.extend([manage_btn, clear_main_btn])
        try:
            self.product_keyword.trace_add("write", lambda *_: self.filter_products())
        except Exception:
            pass
        self.render_backtest_group()

        p = ttk.LabelFrame(self.root, text="群組回測參數", padding=8)
        p.pack(fill="x", padx=8, pady=4)
        for _c in range(12):
            try:
                p.columnconfigure(_c, weight=(1 if _c == 11 else 0))
            except Exception:
                pass
        ttk.Label(p, text="策略").grid(row=0, column=0, sticky="e", padx=4, pady=4)
        strategy_mode_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.strategy_mode, values=STRATEGY_MODE_VALUES, width=13, state="readonly"))
        strategy_mode_box.grid(row=0, column=1, sticky="w", padx=4, pady=4)
        strategy_mode_box.bind("<<ComboboxSelected>>", lambda _e: self.on_strategy_mode_changed())
        ttk.Label(p, text="MA參數").grid(row=0, column=2, sticky="e", padx=4, pady=4)
        self.ma_period_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.ma_period_text, values=MA_PERIOD_VALUES, width=5, state="readonly"))
        self.ma_period_box.grid(row=0, column=3, sticky="w", padx=4, pady=4)
        self.ma_period_box.bind("<<ComboboxSelected>>", lambda _e: self.on_ma_period_changed())
        ttk.Label(p, text="K棒").grid(row=0, column=4, sticky="e", padx=4, pady=4)
        self.k_minutes_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.k_minutes_text, values=K_MINUTE_VALUES, width=5, state="readonly"))
        self.k_minutes_box.grid(row=0, column=5, sticky="w", padx=4, pady=4)
        self.k_minutes_box.bind("<<ComboboxSelected>>", lambda _e: self.on_k_minutes_changed())
        ttk.Label(p, text="商品類型").grid(row=0, column=6, sticky="e", padx=4, pady=4)
        stock_mode_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.stock_size_mode, values=["大股期", "小股期"], width=8, state="readonly"))
        stock_mode_box.grid(row=0, column=7, sticky="w", padx=4, pady=4)
        stock_mode_box.bind("<<ComboboxSelected>>", lambda _e: self.apply_stock_size_defaults())
        apply_default_btn = ttk.Button(p, text="套用預設範圍", command=self.apply_stock_size_defaults)
        apply_default_btn.grid(row=0, column=8, sticky="w", padx=4, pady=4)
        self.lock_widgets.append(apply_default_btn)
        ttk.Label(p, text="口數").grid(row=0, column=7, sticky="e", padx=4, pady=4)
        lots_entry = self.register_lock_widget(ttk.Entry(p, textvariable=self.lots, width=7))
        lots_entry.grid(row=0, column=8, sticky="w", padx=4, pady=4)
        fee_box_frame = ttk.Frame(p)
        fee_box_frame.grid(row=0, column=11, sticky="w", padx=4, pady=4)
        ttk.Label(fee_box_frame, text="手續費：自動").pack(side="left", padx=(0, 4))
        ttk.Label(fee_box_frame, text="依商品/成交價扣進出場").pack(side="left", padx=(3, 0))
        ttk.Label(p, text="回測核心數").grid(row=0, column=9, sticky="e", padx=(12, 4), pady=4)
        cpu_values = ["最快", "自動"] + [str(i) for i in range(1, max(17, min(33, int(os.cpu_count() or 16) + 1)))]
        cpu_box = self.register_lock_widget(ttk.Combobox(p, textvariable=self.cpu_workers_text, values=cpu_values, width=6, state="readonly"))
        cpu_box.grid(row=0, column=10, sticky="w", padx=4, pady=4)
        try:
            self.cpu_workers_text.trace_add("write", lambda *_: self.on_cpu_workers_changed())
        except Exception:
            pass

        def date_field(label, var, row, col):
            ttk.Label(p, text=label).grid(row=row, column=col, sticky="e", padx=4, pady=4)
            df = ttk.Frame(p)
            df.grid(row=row, column=col + 1, sticky="w", padx=4, pady=4)
            ent = self.register_lock_widget(ttk.Entry(df, textvariable=var, width=13))
            ent.pack(side="left")
            btn = ttk.Button(df, text="選", width=3, command=lambda v=var, lb=label: self.open_date_picker(v, lb))
            btn.pack(side="left", padx=(2, 0))
            self.lock_widgets.append(btn)

        date_field("回測起日", self.date_start_text, 1, 0)
        date_field("回測迄日", self.date_end_text, 1, 2)

        ttk.Label(p, text="變數").grid(row=2, column=0, sticky="e", padx=4, pady=(8, 2))
        ttk.Label(p, text="起始").grid(row=2, column=1, sticky="w", padx=4, pady=(8, 2))
        ttk.Label(p, text="結束").grid(row=2, column=2, sticky="w", padx=4, pady=(8, 2))
        ttk.Label(p, text="每次增加").grid(row=2, column=3, sticky="w", padx=4, pady=(8, 2))
        ttk.Label(p, text="說明").grid(row=2, column=4, columnspan=4, sticky="w", padx=4, pady=(8, 2))

        def range_row(row, label, start_var, end_var, step_var, note):
            ttk.Label(p, text=label).grid(row=row, column=0, sticky="e", padx=4, pady=3)
            for col, var in ((1, start_var), (2, end_var), (3, step_var)):
                ent = self.register_lock_widget(ttk.Entry(p, textvariable=var, width=12))
                ent.grid(row=row, column=col, sticky="w", padx=4, pady=3)
            ttk.Label(p, text=note, foreground="#555555").grid(row=row, column=4, columnspan=4, sticky="w", padx=4, pady=3)

        range_row(3, "每次停利（點）", self.tp_start_text, self.tp_end_text, self.tp_step_text, "大股期預設 5 到 20；小股期停利點數為大股期x20")
        range_row(4, "每次停損（點）", self.sl_start_text, self.sl_end_text, self.sl_step_text, "0 代表不用停損；小股期停損點數為大股期x20")
        range_row(5, "認賠下車（新台幣）", self.loss_start_text, self.loss_end_text, self.loss_step_text, "例：30000 到 50000，每次增加 5000")
        range_row(6, "賺飽下車（新台幣）", self.profit_start_text, self.profit_end_text, self.profit_step_text, "例：25000 到 45000，每次增加 5000")
        self.estimate_label = ttk.Label(p, textvariable=self.estimate_text, foreground="#005A9E", anchor="w", justify="left", wraplength=1200)
        self.estimate_label.grid(row=7, column=0, columnspan=8, sticky="ew", padx=4, pady=(8, 2))

        for var in (self.date_start_text, self.date_end_text, self.tp_start_text, self.tp_end_text, self.tp_step_text,
                    self.sl_start_text, self.sl_end_text, self.sl_step_text, self.loss_start_text, self.loss_end_text,
                    self.loss_step_text, self.profit_start_text, self.profit_end_text, self.profit_step_text,
                    self.strategy_mode, self.ma_period_text, self.k_minutes_text):
            try:
                var.trace_add("write", lambda *_: self.mark_estimate_dirty())
            except Exception:
                pass
        self._update_strategy_parameter_controls()

        buttons = ttk.Frame(self.root, padding=(8, 2))
        buttons.pack(fill="x")
        self.action_button(buttons, text="重新計算預估時間", command=self.update_group_estimate, side="left", padx=4)
        self.action_button(buttons, text="執行群組參數回測", command=self.run_group_backtest, side="left", padx=4)
        self.action_button(buttons, text="以選取結果精跑", command=self.run_fine_backtest_selected, side="left", padx=4)
        self.action_button(buttons, text="以前5名精跑", command=self.run_fine_backtest_top5, side="left", padx=4)
        self.action_button(buttons, text="匯出結果 CSV", command=self.export_csv, side="left", padx=4)
        self.action_button(buttons, text="放大目前表格", command=self.open_current_table_large, side="left", padx=4)

        self.info = ttk.Label(self.root, text="就緒", anchor="w", justify="left", wraplength=1200)
        self.info.pack(fill="x", padx=10, pady=(4, 0))
        try:
            self.root.bind("<Configure>", self.on_root_configure, add="+")
        except Exception:
            pass

        self.tabs = ttk.Notebook(self.root)
        self.tabs.pack(fill=BOTH, expand=True, padx=8, pady=8)

        self.result_frame = ttk.Frame(self.tabs)
        self.summary_frame = ttk.Frame(self.tabs)
        self.detail_frame = ttk.Frame(self.tabs)
        self.tabs.add(self.result_frame, text="回測結果")
        self.tabs.add(self.summary_frame, text="每日總表")
        self.tabs.add(self.detail_frame, text="交易明細")

        result_filter_bar = ttk.Frame(self.result_frame, padding=(0, 0, 0, 6))
        result_filter_bar.pack(fill="x")
        ttk.Label(result_filter_bar, text="結果商品：").pack(side="left", padx=(0, 4))
        self.result_filter_box = ttk.Combobox(result_filter_bar, textvariable=self.result_filter_text, values=["總表"], width=28, state="readonly")
        self.result_filter_box.pack(side="left", padx=(0, 10))
        self.result_filter_box.bind("<<ComboboxSelected>>", lambda _e: self.render_result_view())
        ttk.Label(result_filter_bar, text="總表與各商品頁均只顯示該商品前10名；排名依『平均每日獲利 ÷ 原始保證金』。", foreground="#555555").pack(side="left")

        self.result_tree = self.make_tree(self.result_frame, [
            ("rank", "排序", 60), ("name", "商品名稱", 160), ("score", "獲利/保證金", 120),
            ("avg", "平均每日獲利", 130), ("total", "總淨利", 115), ("days", "有效天數", 90), ("range", "日期範圍", 180),
            ("ma_period", "MA", 60), ("k_minutes", "K棒", 70), ("tp_points", "停利/觸發", 95), ("sl_points", "停損點", 90), ("loss_exit", "認賠", 105), ("profit_exit", "賺飽", 105),
            ("trades", "平倉次數", 90), ("tp", "停利次數", 90), ("sl", "停損次數", 90), ("reverse", "反手次數", 90),
            ("peak", "最高損益", 105), ("trough", "最低損益", 105), ("status", "狀態", 120)
        ], settings_key="result")
        self.result_tree.bind("<<TreeviewSelect>>", self.on_result_selected, add="+")

        self.summary_tree = self.make_tree(self.summary_frame, [
            ("session", "日期/時段", 125), ("month", "自動月份", 95), ("minutes", "分鐘數", 80),
            ("ticks", "逐筆數", 90), ("trades", "平倉次數", 90), ("win_trades", "賺錢次數", 90), ("loss_trades", "賠錢次數", 90), ("net", "淨利", 110),
            ("tp", "停利", 70), ("sl", "停損", 70), ("reverse", "反手", 70),
            ("force", "時間到", 80), ("loss_exit", "認賠", 70), ("profit_exit", "賺飽", 70),
            ("peak", "最高損益", 110), ("trough", "最低損益", 110), ("stop", "停止原因", 150)
        ], settings_key="summary")
        self.detail_tree = self.make_tree(self.detail_frame, [
            ("side", "方向", 70), ("entry_time", "進場時間", 95), ("entry", "進場價", 90),
            ("exit_time", "出場時間", 95), ("exit", "出場價", 90), ("net", "淨損益", 100),
            ("session", "日期/時段", 125), ("month", "月份", 85), ("event", "事件", 95),
            ("reason", "原因", 130), ("gross", "毛損益", 100), ("fee", "手續費", 80)
        ], settings_key="detail")

    def make_tree(self, parent, cols, settings_key=""):
        frame = ttk.Frame(parent)
        frame.pack(fill=BOTH, expand=True)
        tree = ttk.Treeview(frame, columns=[c[0] for c in cols], show="headings")
        ybar = ttk.Scrollbar(frame, orient="vertical", command=tree.yview)
        xbar = ttk.Scrollbar(frame, orient="horizontal", command=tree.xview)
        tree.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        tree._sort_reverse = {}
        tree._settings_key = settings_key or ""
        saved_widths = self.get_setting("columns." + tree._settings_key, {}) if tree._settings_key else {}
        saved_order = self.get_setting("column_order." + tree._settings_key, []) if tree._settings_key else []
        try:
            tree.tag_configure("pos", foreground="#FF0000")
            tree.tag_configure("neg", foreground="#008000")
            tree.tag_configure("long", foreground="#FF0000")
            tree.tag_configure("short", foreground="#008000")
            tree.tag_configure("zero", foreground="#333333")
            # 交易明細專用：同一交易日底色一致，淺黃/淺藍交錯；文字色依淨損益。
            for _bg_idx, _bg in ((0, "#FFFBE6"), (1, "#EAF4FF")):
                tree.tag_configure(f"trade_pos_day{_bg_idx}", foreground="#FF0000", background=_bg)
                tree.tag_configure(f"trade_neg_day{_bg_idx}", foreground="#008000", background=_bg)
                tree.tag_configure(f"trade_zero_day{_bg_idx}", foreground="#333333", background=_bg)
            tree.tag_configure("day_total_pos", foreground="#FF0000", background="#FFFFFF")
            tree.tag_configure("day_total_neg", foreground="#008000", background="#FFFFFF")
            tree.tag_configure("day_total_zero", foreground="#333333", background="#FFFFFF")
        except Exception:
            pass
        for key, title, width in cols:
            tree.heading(key, text=title, command=lambda k=key, t=tree: self.sort_tree(t, k))
            use_width = int(saved_widths.get(key, width)) if isinstance(saved_widths, dict) else width
            tree.column(key, width=use_width, minwidth=45, anchor="center", stretch=True)
        try:
            default_cols = [c[0] for c in cols]
            if isinstance(saved_order, list):
                order = [c for c in saved_order if c in default_cols] + [c for c in default_cols if c not in saved_order]
                if order:
                    tree["displaycolumns"] = order
        except Exception:
            pass
        tree.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        try:
            tree.bind("<ButtonRelease-1>", lambda _e, t=tree: self.save_tree_column_widths(t), add="+")
            self.enable_tree_column_drag(tree)
        except Exception:
            pass
        return tree

    def _sort_value(self, value):
        s = str(value or "").strip()
        if not s:
            return (1, "")
        raw = s.replace(",", "").replace("元", "").replace("點", "").replace("%", "").strip()
        if raw.startswith("1/"):
            raw = raw[2:]
        raw = raw.replace("+", "")
        try:
            return (0, float(raw))
        except Exception:
            return (1, s)

    def sort_tree(self, tree, col):
        cols = list(tree["columns"])
        try:
            idx = cols.index(col)
        except ValueError:
            return
        if col in getattr(tree, "_sort_reverse", {}):
            reverse = bool(tree._sort_reverse.get(col, False))
        else:
            # 數值欄第一次點擊先由大到小，總淨利、平倉次數等排序較直覺。
            reverse = col not in ("session", "month", "entry_time", "exit_time", "side", "event", "reason", "stop")
        items = list(tree.get_children(""))
        footer = []
        sortable = []
        for item in items:
            vals = tree.item(item, "values")
            if vals and str(vals[0]) in ("平均", "合計"):
                footer.append(item)
            else:
                sortable.append(item)
        sortable.sort(key=lambda item: self._sort_value(tree.item(item, "values")[idx] if idx < len(tree.item(item, "values")) else ""), reverse=reverse)
        for pos, item in enumerate(sortable + footer):
            tree.move(item, "", pos)
        tree._sort_reverse[col] = not reverse

    def clear_tree(self, tree):
        for item in tree.get_children():
            tree.delete(item)

    def mark_estimate_dirty(self):
        try:
            self.estimate_text.set("預估：參數或日期已變更，按『重新計算預估時間』更新")
        except Exception:
            pass

    def is_three_ma_mode(self):
        return str(self.strategy_mode.get() or "") == THREE_MA_STRATEGY_DISPLAY


    def get_ma_period(self):
        if not self.is_three_ma_mode():
            return 3
        return normalize_ma_period(self.ma_period_text.get())

    def on_ma_period_changed(self):
        try:
            if not self.is_three_ma_mode():
                self.ma_period_text.set("3")
            else:
                self.ma_period_text.set(str(normalize_ma_period(self.ma_period_text.get())))
                self.set_setting("defaults.ma_period", str(self.ma_period_text.get()))
                self.save_settings()
        except Exception:
            pass
        self.update_group_estimate(silent=True)

    def get_k_minutes(self):
        if not self.is_three_ma_mode():
            return 1
        return normalize_k_minutes(self.k_minutes_text.get())

    def on_k_minutes_changed(self):
        try:
            if not self.is_three_ma_mode():
                self.k_minutes_text.set("1")
            else:
                self.k_minutes_text.set(str(normalize_k_minutes(self.k_minutes_text.get())))
                self.set_setting("defaults.k_minutes", str(self.k_minutes_text.get()))
                self.save_settings()
        except Exception:
            pass
        self.update_group_estimate(silent=True)

    def _update_strategy_parameter_controls(self):
        is_ma = self.is_three_ma_mode()
        try:
            if is_ma:
                self.ma_period_text.set(str(normalize_ma_period(self.get_setting("defaults.ma_period", self.ma_period_text.get() or "3"))))
                self.k_minutes_text.set(str(normalize_k_minutes(self.get_setting("defaults.k_minutes", self.k_minutes_text.get() or "1"))))
            else:
                self.ma_period_text.set("3")
                self.k_minutes_text.set("1")
            state = "readonly" if (is_ma and not bool(getattr(self, "busy", False))) else "disabled"
            if hasattr(self, "ma_period_box"):
                self.ma_period_box.configure(state=state)
            if hasattr(self, "k_minutes_box"):
                self.k_minutes_box.configure(state=state)
        except Exception:
            pass

    def on_strategy_mode_changed(self):
        mode = str(self.strategy_mode.get() or TRAIN_STRATEGY_DISPLAY)
        if mode not in STRATEGY_MODE_VALUES:
            mode = TRAIN_STRATEGY_DISPLAY
            self.strategy_mode.set(mode)
        try:
            self.set_setting("defaults.strategy_mode", mode)
            self.save_settings()
        except Exception:
            pass
        if mode == THREE_MA_STRATEGY_DISPLAY:
            preset_key = "ma"
            if not self._load_param_preset(preset_key):
                # MA策略預設：停利觸發400點、停損300點；認賠/賺飽依原MA策略邏輯。
                self.tp_start_text.set("400")
                self.tp_end_text.set("400")
                self.tp_step_text.set("50")
                self.sl_start_text.set("300")
                self.sl_end_text.set("300")
                self.sl_step_text.set("50")
                self.loss_start_text.set("0")
                self.loss_end_text.set("0")
                self.loss_step_text.set("1")
                self.profit_start_text.set("0")
                self.profit_end_text.set("0")
                self.profit_step_text.set("1")
            try:
                self.info.configure(text="已切換MA策略：可選MA參數3/5/10與K棒1/5/10分；四項參數會記憶，手續費自動依商品/成交價扣除。")
            except Exception:
                pass
        else:
            key = "train_small" if str(self.stock_size_mode.get() or "") == "小股期" else "train_big"
            if not self._load_param_preset(key):
                self.apply_stock_size_defaults()
            try:
                self.info.configure(text="已切換小火車原策略：固定使用 1分K；MA參數與K棒選項已反灰，只有 MA策略可選。")
            except Exception:
                pass
        self._update_strategy_parameter_controls()
        self.update_group_estimate(silent=True)

    def apply_stock_size_defaults(self):
        """依大股期/小股期套用群組回測預設範圍。

        大股期預設：停利 5~20、停損 10、認賠/賺飽 30000~45000 每 2500。
        小股期：停利/停損點數為大股期的 20 倍；認賠/賺飽金額與大股期相同。
        """
        if self.is_three_ma_mode():
            preset_key = "ma"
            if not self._load_param_preset(preset_key):
                self.tp_start_text.set("400"); self.tp_end_text.set("400"); self.tp_step_text.set("50")
                self.sl_start_text.set("300"); self.sl_end_text.set("300"); self.sl_step_text.set("50")
                self.loss_start_text.set("0"); self.loss_end_text.set("0"); self.loss_step_text.set("1")
                self.profit_start_text.set("0"); self.profit_end_text.set("0"); self.profit_step_text.set("1")
            self.save_current_param_texts()
            self.update_group_estimate(silent=True)
            return
        mode = str(self.stock_size_mode.get() or "大股期").strip()
        vals = {
            "tp_start": 5.0, "tp_end": 20.0, "tp_step": 1.0,
            "sl_start": 10.0, "sl_end": 10.0, "sl_step": 1.0,
            "loss_start": 30000.0, "loss_end": 45000.0, "loss_step": 2500.0,
            "profit_start": 30000.0, "profit_end": 45000.0, "profit_step": 2500.0,
        }
        if mode == "小股期":
            for key in ("tp_start", "tp_end", "tp_step", "sl_start", "sl_end", "sl_step"):
                vals[key] = vals[key] * 20.0
            # 認賠/賺飽是新台幣門檻，與大股期相同，不再除以 20。

        def _txt(v):
            try:
                v = float(v)
                if abs(v - round(v)) < 1e-9:
                    return str(int(round(v)))
                return ("%.2f" % v).rstrip("0").rstrip(".")
            except Exception:
                return str(v)

        self.tp_start_text.set(_txt(vals["tp_start"]))
        self.tp_end_text.set(_txt(vals["tp_end"]))
        self.tp_step_text.set(_txt(vals["tp_step"]))
        self.sl_start_text.set(_txt(vals["sl_start"]))
        self.sl_end_text.set(_txt(vals["sl_end"]))
        self.sl_step_text.set(_txt(vals["sl_step"]))
        self.loss_start_text.set(_txt(vals["loss_start"]))
        self.loss_end_text.set(_txt(vals["loss_end"]))
        self.loss_step_text.set(_txt(vals["loss_step"]))
        self.profit_start_text.set(_txt(vals["profit_start"]))
        self.profit_end_text.set(_txt(vals["profit_end"]))
        self.profit_step_text.set(_txt(vals["profit_step"]))
        try:
            self.set_setting("defaults.stock_size_mode", mode)
            self.save_current_param_texts()
        except Exception:
            pass
        self.update_group_estimate(silent=True)
        try:
            self.info.configure(text="已套用%s預設範圍。" % mode)
        except Exception:
            pass

    def auto_strategy_for_option(self, opt):
        kind = str(getattr(opt, "product_kind", "") or "")
        name = str(getattr(opt, "stock_name", "") or "") + str(getattr(opt, "display", "") or "")
        if self.is_three_ma_mode():
            prefix = "MA策略"
            if "台指" in kind or "台指" in name:
                return prefix + "-台指期"
            if "小股期" in kind or "小型" in name:
                return prefix + "-小股期"
            return prefix + "-大股期"
        if "台指" in kind or "台指" in name:
            return "台指期策略"
        if "小股期" in kind or "小型" in name:
            return "小股期策略"
        return "大股期策略"

    def current_product_option(self):
        """取得目前下拉選到的商品。

        v019 修正：不要只依賴 option_map 的完整顯示字串。使用者搜尋後，
        下拉文字或排名資訊可能重建，這裡改用代號回查，避免選到 KCF
        但按加入時仍抓不到商品。
        """
        text = str(self.product_choice.get() or "").strip()
        opt = self.option_map.get(text)
        if opt:
            return opt
        code_guess = clean_code(text.split("｜")[0].split("|")[0].strip())
        if code_guess:
            for item in list(self.options or []):
                if clean_code(getattr(item, "code", "")) == code_guess:
                    return item
        return None

    def group_codes_text(self, max_items=8):
        names = []
        for opt in list(self.backtest_group or [])[:max_items]:
            names.append(self.product_name_text(opt))
        if len(self.backtest_group or []) > max_items:
            names.append("...共%d檔" % len(self.backtest_group))
        return "、".join(x.strip() for x in names if x.strip())

    def add_selected_product_to_group(self):
        opt = self.current_product_option()
        if not opt:
            messagebox.showinfo("尚未選擇商品", "請先在商品下拉選單選擇商品。")
            return
        code = clean_code(opt.code)
        if code in self.backtest_group_codes:
            self.info.configure(text="待回測群組已包含：%s｜目前群組：%s" % (self.option_title(opt), self.group_codes_text()))
            return
        self.backtest_group.append(opt)
        self.backtest_group_codes.add(code)
        self.render_backtest_group()
        estimate = self.update_group_estimate(silent=True) or {}
        self.info.configure(text="已加入待回測：%s｜目前%d檔：%s%s" % (
            self.option_title(opt),
            len(self.backtest_group),
            self.group_codes_text(),
            "｜" + estimate.get("eta_text", "") if estimate.get("eta_text") else ""
        ))

    def remove_selected_group_products(self):
        try:
            selected = list(self.group_tree.selection())
        except Exception:
            selected = []
        if not selected:
            return
        remove_codes = set()
        for iid in selected:
            code = clean_code(iid)
            if code:
                remove_codes.add(code)
        self.backtest_group = [o for o in self.backtest_group if clean_code(o.code) not in remove_codes]
        self.backtest_group_codes = set(clean_code(o.code) for o in self.backtest_group)
        self.render_backtest_group()
        self.update_group_estimate(silent=True)

    def clear_backtest_group(self):
        self.backtest_group = []
        self.backtest_group_codes = set()
        self.render_backtest_group()
        self.update_group_estimate(silent=True)

    def render_backtest_group(self):
        count = len(self.backtest_group or [])
        summary = self.group_codes_text(max_items=10)
        try:
            self.group_summary_text.set("待回測商品：%d 檔%s" % (count, "｜" + summary if summary else ""))
        except Exception:
            pass
        try:
            tree = getattr(self, "group_tree", None)
            if tree is None or not tree.winfo_exists():
                return
            for item in tree.get_children():
                tree.delete(item)
            for idx, opt in enumerate(self.backtest_group, start=1):
                rank = getattr(opt, "hot_rank", "") or ""
                code = clean_code(getattr(opt, "code", ""))
                tree.insert("", END, iid=code or "row_%d" % idx, values=(idx, self.product_name_text(opt), rank))
        except Exception:
            pass

    def add_options_to_group(self, options, source_text=""):
        if self.busy:
            messagebox.showinfo("背景執行中", "目前正在執行：%s，請等它完成後再修改待回測群組。" % self.busy_action)
            return 0
        added = 0
        skipped = 0
        for opt in list(options or []):
            if not opt:
                continue
            code = clean_code(getattr(opt, "code", ""))
            if not code:
                continue
            if code in self.backtest_group_codes:
                skipped += 1
                continue
            self.backtest_group.append(opt)
            self.backtest_group_codes.add(code)
            added += 1
        self.render_backtest_group()
        estimate = self.update_group_estimate(silent=True) or {}
        label = (str(source_text or "熱門排名").strip() or "熱門排名")
        if added:
            self.info.configure(text="已由%s加入%d檔到待回測｜略過重複%d檔｜目前%d檔：%s%s" % (
                label, added, skipped, len(self.backtest_group), self.group_codes_text(),
                "｜" + estimate.get("eta_text", "") if estimate.get("eta_text") else ""
            ))
        else:
            self.info.configure(text="%s沒有新增商品｜略過重複%d檔｜目前%d檔：%s" % (
                label, skipped, len(self.backtest_group), self.group_codes_text()
            ))
        return added

    def add_hot_tree_selection_to_group(self, tree, option_by_iid, source_text="熱門排名選取"):
        try:
            selected = list(tree.selection())
        except Exception:
            selected = []
        if not selected:
            messagebox.showinfo("尚未選取商品", "請先在熱門排名表格選取一列或多列，或直接按『加入本頁前10』。")
            return 0
        opts = [option_by_iid.get(iid) for iid in selected if option_by_iid.get(iid) is not None]
        return self.add_options_to_group(opts, source_text)


    def _initial_cpu_workers_text(self):
        saved = str(self.get_setting("backtest.cpu_workers", "最快") or "最快").strip()
        logical = int(os.cpu_count() or 1)
        # 舊版常保存 8/12，會讓 16 邏輯核心只吃 50%~75%。
        # v030 是最快結果版：若舊設定低於「最快」核心數，自動切到最快；使用者仍可手動改回自動/固定核心。
        if logical >= 12:
            if saved in ("", "自動", "auto", "AUTO"):
                return "最快"
            try:
                if int(float(saved)) < max(1, logical - 1):
                    return "最快"
            except Exception:
                pass
        return saved

    def on_cpu_workers_changed(self):
        try:
            self.set_setting("backtest.cpu_workers", str(self.cpu_workers_text.get() or "8"))
            self.save_settings()
        except Exception:
            pass
        self.update_group_estimate(silent=True)

    def get_backtest_workers(self):
        logical = max(1, int(os.cpu_count() or 1))
        raw = str(self.cpu_workers_text.get() or "最快").strip()
        if raw in ("最快", "max", "MAX", "fast", "FAST"):
            # 最快模式：保留 1 個邏輯核心給 Windows / Tkinter，其餘全部給回測。
            return max(1, min(logical, logical - 1 if logical >= 4 else logical))
        if raw in ("自動", "auto", "AUTO", ""):
            # 穩定模式：保留 2 個邏輯核心。
            return max(1, min(logical, max(1, logical - 2)))
        try:
            val = int(float(raw))
        except Exception:
            val = max(1, logical - 1 if logical >= 4 else logical)
        return max(1, min(logical, val))

    def _round_point2(self, value):
        return round(float(value or 0.0) + 0.0, 2)

    @staticmethod
    def _parse_float_text(text, label):
        raw = str(text or "").strip().replace(",", "")
        if raw == "":
            raise ValueError("%s不可空白。" % label)
        try:
            return float(raw)
        except Exception:
            raise ValueError("%s格式錯誤，請輸入數字。" % label)

    def _range_values(self, start_var, end_var, step_var, label, allow_zero=False, max_values=500):
        start_raw = str(start_var.get() or "").strip()
        end_raw = str(end_var.get() or "").strip()
        step_raw = str(step_var.get() or "").strip()
        start = self._parse_float_text(start_raw, label + "起始")
        end = self._parse_float_text(end_raw, label + "結束") if end_raw else start
        if start < 0 or end < 0:
            raise ValueError("%s不可小於 0。" % label)
        if not allow_zero and (start <= 0 or end <= 0):
            raise ValueError("%s必須大於 0。" % label)
        if end < start:
            raise ValueError("%s結束不可小於起始。" % label)
        if abs(end - start) < 1e-9:
            return [round(start, 2)]
        step = self._parse_float_text(step_raw, label + "每次增加") if step_raw else 0.0
        if step <= 0:
            raise ValueError("%s每次增加必須大於 0。" % label)
        vals = []
        cur = start
        guard = 0
        while cur <= end + 1e-9:
            vals.append(round(cur, 2))
            cur += step
            guard += 1
            if guard > max_values:
                raise ValueError("%s產生超過 %d 組，請加大『每次增加』或縮小範圍。" % (label, max_values))
        return vals

    def get_group_param_ranges(self):
        tp_label = "FloatProfitTrigger" if self.is_three_ma_mode() else "每次停利"
        sl_label = "StopLossP" if self.is_three_ma_mode() else "每次停損"
        tp_values = self._range_values(self.tp_start_text, self.tp_end_text, self.tp_step_text, tp_label, allow_zero=False)
        sl_values = self._range_values(self.sl_start_text, self.sl_end_text, self.sl_step_text, sl_label, allow_zero=True)
        # v042：MA策略策略四項風控中，認賠/賺飽固定依扣完手續費後的新台幣累積淨損益判斷。
        loss_values = self._range_values(self.loss_start_text, self.loss_end_text, self.loss_step_text, "認賠下車", allow_zero=True)
        profit_values = self._range_values(self.profit_start_text, self.profit_end_text, self.profit_step_text, "賺飽下車", allow_zero=True)
        return tp_values, sl_values, loss_values, profit_values

    def group_combo_count(self):
        tp_values, sl_values, loss_values, profit_values = self.get_group_param_ranges()
        return len(tp_values) * len(sl_values) * len(loss_values) * len(profit_values)

    def _estimate_tick_count_for_group(self, d1=None, d2=None):
        total = 0
        per_code = {}
        for opt in self.backtest_group:
            code = clean_code(opt.code)
            cnt = 0
            try:
                if cache_has_code(code):
                    cnt = count_cached_ticks_for_code(code, d1, d2)
                else:
                    cnt = int(getattr(opt, "total_rows", 0) or 0)
            except Exception:
                cnt = int(getattr(opt, "total_rows", 0) or 0)
            per_code[code] = max(0, int(cnt or 0))
            total += per_code[code]
        return total, per_code

    def update_group_estimate(self, silent=False):
        try:
            if not self.backtest_group:
                self.estimate_text.set("預估：待回測群組 0 檔，請先選商品後按『加入待回測』")
                return None
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                self.estimate_text.set("預估：請先填完整回測起日與回測迄日")
                return None
            tp_values, sl_values, loss_values, profit_values = self.get_group_param_ranges()
            combo_count = len(tp_values) * len(sl_values) * len(loss_values) * len(profit_values)
            if self.is_three_ma_mode():
                combo_desc = "MA策略｜MA=%d × K=%d分｜停利%d × 停損%d × 認賠%d × 賺飽%d = 每檔 %s 組" % (self.get_ma_period(), self.get_k_minutes(), len(tp_values), len(sl_values), len(loss_values), len(profit_values), f"{combo_count:,}")
            else:
                combo_desc = "停利%d × 停損%d × 認賠%d × 賺飽%d = 每檔 %s 組" % (len(tp_values), len(sl_values), len(loss_values), len(profit_values), f"{combo_count:,}")
            products = len(self.backtest_group)
            total_jobs = products * combo_count
            ticks_one_round, per_code = self._estimate_tick_count_for_group(d1, d2)
            total_tick_units = ticks_one_round * combo_count
            default_speed = 35000.0
            speed = float(self.get_setting("benchmark.tick_units_per_sec", default_speed) or default_speed)
            # v018 初始預設 450 tick-units/sec 太保守，會把十幾分鐘誤估成二十幾小時。
            # 若舊設定檔已存到過低速度，v019 直接拉回合理下限；跑完後仍會用本機實測速度校正。
            if speed < 5000.0:
                speed = default_speed
            workers = self.get_backtest_workers() if hasattr(self, "get_backtest_workers") else 1
            effective_speed = speed * max(1, workers) * 0.75
            eta_text = self._format_seconds(total_tick_units / effective_speed) if total_tick_units > 0 else "無資料"
            detail = (
                "預估：%d檔商品｜%s｜共 %s 次回測｜"
                "逐筆運算約 %s 筆｜估計約 %s｜核心%d/%d｜速度基準約 %s 筆/秒｜"
                "執行後改用即時速度；完成後先顯示前1000名，CSV仍含全部。"
            ) % (
                products, combo_desc, f"{total_jobs:,}",
                f"{int(total_tick_units):,}", eta_text, workers, max(1, int(os.cpu_count() or 1)), f"{int(speed):,}"
            )
            self.estimate_text.set(detail)
            return {"products": products, "combo_count": combo_count, "total_jobs": total_jobs, "tick_units": total_tick_units, "per_code": per_code, "eta_text": eta_text}
        except Exception as e:
            msg = "預估失敗：%s" % e
            self.estimate_text.set(msg)
            if not silent:
                messagebox.showerror("預估失敗", str(e))
            return None

    def _estimate_tick_units_for_job_groups(self, job_groups, d1=None, d2=None):
        total = 0
        per_code = {}
        for group in list(job_groups or []):
            opt = group.get("opt")
            combos = list(group.get("combos") or [])
            code = clean_code(getattr(opt, "code", ""))
            if not code:
                continue
            try:
                cnt = count_cached_ticks_for_code(code, d1, d2) if cache_has_code(code) else int(getattr(opt, "total_rows", 0) or 0)
            except Exception:
                cnt = int(getattr(opt, "total_rows", 0) or 0)
            per_code[code] = max(0, int(cnt or 0))
            total += per_code[code] * max(1, len(combos))
        return total, per_code

    def _run_group_job_groups(self, job_groups, d1, d2, lots, action_name="群組參數回測", mode_note="v030最快結果模式+預分組Tick+高核心+Top快速出表", k_minutes=None, ma_period=None):
        k_minutes = self.get_k_minutes() if k_minutes is None else normalize_k_minutes(k_minutes)
        ma_period = self.get_ma_period() if ma_period is None else normalize_ma_period(ma_period)
        job_groups = [g for g in list(job_groups or []) if g.get("opt") is not None and list(g.get("combos") or [])]
        if not job_groups:
            messagebox.showinfo("沒有可執行的參數", "沒有產生任何回測參數組。")
            return
        total_jobs = sum(len(g.get("combos") or []) for g in job_groups)
        targets_count = len(job_groups)
        total_tick_units_est, _per_code = self._estimate_tick_units_for_job_groups(job_groups, d1, d2)
        if total_jobs > 20000:
            ok = messagebox.askyesno("回測組數很多", "這次會執行 %s 次回測，可能非常久。\n確定要開始嗎？" % f"{total_jobs:,}")
            if not ok:
                return
        started_at = time_module.time()

        def worker():
            results = []
            done_units = 0
            processed_jobs = 0
            total_units = max(1, int(total_tick_units_est or 0))
            workers = max(1, self.get_backtest_workers())
            logical = max(1, int(os.cpu_count() or 1))
            parallel_enabled = workers > 1 and total_jobs > 1
            mode_text = "%s｜使用核心%d/%d%s" % (mode_note, workers, logical, "｜多核心平行" if parallel_enabled else "｜單核心")

            def _runtime_suffix():
                elapsed2 = max(0.01, time_module.time() - started_at)
                if processed_jobs <= 0:
                    return "即時速度估算中"
                jobs_per_sec = processed_jobs / elapsed2
                remain_jobs = max(0, total_jobs - processed_jobs)
                return "即時速度 %.2f 組/秒｜即時剩餘 %s" % (jobs_per_sec, self._format_seconds(remain_jobs / max(jobs_per_sec, 0.0001)))

            self.status_update("背景執行中：%s｜準備開始｜共%s組｜使用核心%d/%d｜理論預估僅供參考，執行中改用即時速度" % (action_name, f"{total_jobs:,}", workers, logical))

            for pidx, group in enumerate(job_groups, start=1):
                if self.cancel_requested:
                    raise OperationCancelled()
                opt = group.get("opt")
                combos = list(group.get("combos") or [])
                code = clean_code(getattr(opt, "code", ""))
                strategy_name = self.auto_strategy_for_option(opt)
                self.progress_update(done_units, total_units, "準備讀取 %d/%d｜%s｜%d組參數｜使用核心%d/%d" % (
                    pidx, targets_count, self.option_title(opt), len(combos), workers, logical
                ))
                ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="讀取 %d/%d" % (pidx, targets_count), start_date=d1, end_date=d2)
                if self.cancel_requested:
                    raise OperationCancelled()
                if not ticks:
                    results.append({"opt": opt, "strategy": strategy_name, "status": "無逐筆資料", "avg": -1e18, "total": 0.0, "valid_days": 0, "range": "無資料", "ds": [], "tr": [], "params": {}})
                    continue
                product_units = max(1, len(ticks))
                combo_count = len(combos)

                if parallel_enabled:
                    # v026：同商品 tick 只寫入暫存檔一次；每個回測核心在 initializer 載入一次後共用。
                    # 舊版把整份 ticks 塞進每個 payload，11組參數就會重複序列化/複製11次，取消也要等整批跑完。
                    run_workers = _adaptive_parallel_workers(workers, combo_count, product_units)
                    packed_file = None
                    completed_jobs_for_product = 0
                    try:
                        fd, packed_file = tempfile.mkstemp(prefix="train_ticks_%s_" % code, suffix=".pkl")
                        with os.fdopen(fd, "wb") as f:
                            pickle.dump(_pack_ticks_for_worker(ticks), f, protocol=pickle.HIGHEST_PROTOCOL)
                        self.progress_update(done_units, total_units, "商品 %d/%d｜%s｜已載入 %s 筆Tick｜啟動核心%d/%d" % (
                            pidx, targets_count, self.option_title(opt), f"{product_units:,}", run_workers, logical
                        ))
                        ex = concurrent.futures.ProcessPoolExecutor(
                            max_workers=run_workers,
                            initializer=_init_backtest_worker_from_file,
                            initargs=(packed_file, strategy_name, lots, code, k_minutes, ma_period, self.one_way_fee_value()),
                        )
                        try:
                            self._set_active_executor(ex)
                            # v029：每個 future 連跑多組，減少 275 個 future 的排程/IPC 成本；
                            # chunks 約為核心數的 3 倍，兼顧負載平衡與進度更新。
                            # v043：不可用 ProcessPoolExecutor 的 with 區塊收尾。Windows 上有機率
                            # 在所有 future 已回收、進度已到 100%% 後，卡在 shutdown(wait=True)。
                            # 因此結果一取回就主動 non-blocking shutdown，再補終止子核心，避免面板停在 100%%。
                            chunk_count = max(run_workers, min(combo_count, run_workers * 3))
                            combo_chunks = _chunk_list_even(combos, chunk_count)
                            pending = set(ex.submit(_run_backtest_combo_chunk_worker, chunk) for chunk in combo_chunks if chunk)
                            last_ui_update = 0.0
                            while pending:
                                if self.cancel_requested:
                                    for f in list(pending):
                                        f.cancel()
                                    self._cancel_active_executor()
                                    raise OperationCancelled()
                                done_set, pending = concurrent.futures.wait(
                                    pending, timeout=0.20, return_when=concurrent.futures.FIRST_COMPLETED
                                )
                                if not done_set:
                                    continue
                                if self.cancel_requested:
                                    for f in list(pending) + list(done_set):
                                        f.cancel()
                                    self._cancel_active_executor()
                                    raise OperationCancelled()
                                for fut in done_set:
                                    try:
                                        chunk_results = fut.result()
                                    except Exception:
                                        if self.cancel_requested:
                                            self._cancel_active_executor()
                                            raise OperationCancelled()
                                        raise
                                    for rr in list(chunk_results or []):
                                        rr["opt"] = opt
                                        results.append(rr)
                                    n_done = len(chunk_results or [])
                                    completed_jobs_for_product += n_done
                                    processed_jobs += n_done
                                    done_units += product_units * n_done
                                now_ui = time_module.time()
                                if now_ui - last_ui_update >= 0.35 or completed_jobs_for_product >= combo_count:
                                    last_ui_update = now_ui
                                    self.progress_update(done_units, total_units, "商品 %d/%d｜%s｜完成 %d/%d 組｜總組 %d/%d｜核心%d/%d｜%s" % (
                                        pidx, targets_count, self.option_title(opt), completed_jobs_for_product, combo_count,
                                        processed_jobs, total_jobs, run_workers, logical, _runtime_suffix()
                                    ))
                            self.status_update("背景執行中：%s｜多核心結果已回收｜正在關閉子核心..." % action_name)
                        finally:
                            self._set_active_executor(None)
                            try:
                                ex.shutdown(wait=False, cancel_futures=True)
                            except Exception:
                                pass
                            try:
                                _terminate_process_pool(ex)
                            except Exception:
                                pass
                    finally:
                        self._set_active_executor(None)
                        if packed_file:
                            try:
                                os.remove(packed_file)
                            except Exception:
                                pass
                else:
                    for cidx, (tp, sl, loss_exit, profit_exit) in enumerate(combos, start=1):
                        if self.cancel_requested:
                            raise OperationCancelled()
                        params = dict(
                            strategy_name=strategy_name,
                            lots=lots,
                            tp_points=round(float(tp), 2),
                            sl_points=round(float(sl), 2),
                            loss_exit=float(loss_exit),
                            lock_profit_exit=float(profit_exit),
                            product_code=code,
                            ma_period=ma_period,
                            k_minutes=k_minutes,
                            one_way_fee=self.one_way_fee_value(),
                        )
                        params2 = dict(params)
                        if total_jobs <= 3:
                            base_units = done_units
                            def _progress(cur, total, detail, _pidx=pidx, _cidx=cidx, _opt=opt, _tp=tp, _sl=sl, _loss=loss_exit, _profit=profit_exit, _base=base_units, _combo_count=combo_count):
                                self.progress_update(_base + min(float(cur or 0), product_units), total_units,
                                                     "商品 %d/%d｜組 %d/%d｜%s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f｜%s" % (
                                                         _pidx, targets_count, _cidx, _combo_count, self.option_title(_opt), _tp, _sl, _loss, _profit, detail
                                                     ))
                            params2["progress"] = _progress
                        else:
                            params2["progress"] = None
                        ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, **params2)
                        total = sum(float(x.get("net", 0.0) or 0.0) for x in ds)
                        avg, valid_days = self.average_net_excluding_zero_trade_days(ds)
                        summary = self.day_stats_summary(ds)
                        peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                        trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                        tp_count = sum(int(x.get("tp", 0) or 0) for x in ds)
                        sl_count = sum(int(x.get("sl", 0) or 0) for x in ds)
                        rev_count = sum(int(x.get("reverse", 0) or 0) for x in ds)
                        result = {
                            "opt": opt, "strategy": strategy_name, "status": "完成", "avg": avg, "total": total,
                            "valid_days": valid_days, "total_days": summary.get("total_days", 0), "range": summary.get("range", ""),
                            "trades": len(tr), "tp": tp_count, "sl": sl_count, "reverse": rev_count, "peak": peak, "trough": trough,
                            "params": params,
                        }
                        results.append(result)
                        processed_jobs += 1
                        done_units += product_units
                        if processed_jobs == 1 or processed_jobs % 3 == 0 or processed_jobs == total_jobs:
                            self.progress_update(done_units, total_units, "已完成 %d/%d 組回測｜%s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f｜使用核心%d/%d｜%s" % (
                                processed_jobs, total_jobs, self.option_title(opt), tp, sl, loss_exit, profit_exit, workers, logical, _runtime_suffix()
                            ))
            self.status_update("背景執行中：%s｜回測運算100%%｜結果排序/整理中...｜完成%s組｜使用核心%d/%d" % (action_name, f"{processed_jobs:,}", workers, logical))
            for _row in results:
                try:
                    _row["rank_score"] = self.result_rank_score(_row)
                except Exception:
                    _row["rank_score"] = -1e18
            results.sort(key=lambda x: (float(x.get("rank_score", -1e18) or -1e18), float(x.get("avg", -1e18) or -1e18)), reverse=True)
            elapsed = max(0.01, time_module.time() - started_at)
            actual_units = max(1, done_units or total_tick_units_est)
            return {"results": results, "elapsed": elapsed, "tick_units": actual_units, "jobs": processed_jobs, "products": targets_count, "mode_note": mode_text, "workers": workers, "logical": logical}

        def done(payload):
            results = payload.get("results", []) if isinstance(payload, dict) else []
            elapsed = float(payload.get("elapsed", 0.0) or 0.0) if isinstance(payload, dict) else 0.0
            tick_units = float(payload.get("tick_units", 0.0) or 0.0) if isinstance(payload, dict) else 0.0
            jobs = int(payload.get("jobs", 0) or 0) if isinstance(payload, dict) else 0
            products = int(payload.get("products", targets_count) or targets_count) if isinstance(payload, dict) else targets_count
            note = str(payload.get("mode_note", mode_note) or mode_note) if isinstance(payload, dict) else mode_note
            if elapsed > 0 and tick_units > 0:
                speed = tick_units / elapsed
                old = float(self.get_setting("benchmark.tick_units_per_sec", speed) or speed)
                self.set_setting("benchmark.tick_units_per_sec", max(1.0, old * 0.4 + speed * 0.6))
                self.save_settings()
            self.status_update("背景執行中：%s｜結果排序完成｜正在快速出表...｜共%s組" % (action_name, f"{len(results):,}"))
            self.render_group_results(results)
            if results:
                best = results[0]
                show_note = "｜總表/分商品均顯示每檔前10名｜排序依平均每日獲利/原始保證金"
                self.info.configure(text="%s完成｜商品%d檔｜完成%d組｜耗時%s｜%s%s｜最佳 %s｜平均每日獲利 %s｜參數：停利%.2f 停損%.2f 認賠%.0f 賺飽%.0f" % (
                    action_name, products, jobs, self._format_seconds(elapsed), note, show_note, self.option_title(best.get("opt")), format_money_plain(best.get("avg", 0)),
                    best.get("params", {}).get("tp_points", 0.0), best.get("params", {}).get("sl_points", 0.0),
                    best.get("params", {}).get("loss_exit", 0.0), best.get("params", {}).get("lock_profit_exit", 0.0)
                ))
            else:
                self.info.configure(text="%s完成，但沒有可用結果。" % action_name)
            self.tabs.select(self.result_frame)

        self.run_background(action_name, worker, done)

    def run_group_backtest(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再加入待回測商品。")
            return
        if not self.backtest_group:
            messagebox.showinfo("待回測群組是空的", "請先選商品，按「加入待回測」。")
            return
        try:
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                raise ValueError("請填完整回測起日與回測迄日。")
            tp_values, sl_values, loss_values, profit_values = self.get_group_param_ranges()
        except Exception as e:
            messagebox.showerror("參數錯誤", str(e))
            return
        combos = list(itertools.product(tp_values, sl_values, loss_values, profit_values))
        self.save_current_param_texts()
        combo_count = len(combos)
        targets = list(self.backtest_group)
        total_jobs = combo_count * len(targets)
        self.update_group_estimate(silent=True)
        try:
            self.info.configure(text="本次回測清單已鎖定：%s｜共%d檔｜%d組參數/檔｜共%d次回測" % (
                self.group_codes_text(), len(targets), combo_count, total_jobs
            ) + ("｜%dMA|%d分K" % (self.get_ma_period(), self.get_k_minutes()) if self.is_three_ma_mode() else ""), foreground="red")
        except Exception:
            pass
        lots = int(self.lots.get() or 1)
        job_groups = [{"opt": opt, "combos": combos} for opt in targets]
        self._run_group_job_groups(job_groups, d1, d2, lots, action_name="群組參數回測", mode_note="v030最快結果模式+預分組Tick+高核心+Top快速出表", k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period())

    def _current_numeric_step(self, var, default_value):
        try:
            val = float(str(var.get() or "").strip().replace(",", ""))
            if val > 0:
                return val
        except Exception:
            pass
        return float(default_value)

    def _fine_point_values(self, center, coarse_step, allow_zero=False):
        center = float(center or 0.0)
        coarse_step = max(0.01, float(coarse_step or 1.0))
        if coarse_step >= 5.0:
            fine_step = 1.0
        elif coarse_step > 1.0:
            fine_step = 0.5
        else:
            fine_step = max(0.25, coarse_step)
        span = max(coarse_step, fine_step * 2.0)
        start = center - span
        end = center + span
        if allow_zero:
            start = max(0.0, start)
        else:
            start = max(fine_step, start)
        vals = []
        cur = start
        guard = 0
        while cur <= end + 1e-9:
            vals.append(round(cur, 2))
            cur += fine_step
            guard += 1
            if guard > 200:
                break
        if round(center, 6) not in vals and (allow_zero or center > 0):
            vals.append(round(center, 6))
        return sorted(set(vals))

    def _fine_money_values(self, center, coarse_step, allow_zero=False):
        center = float(center or 0.0)
        coarse_step = max(1.0, float(coarse_step or 1000.0))
        if coarse_step >= 5000:
            fine_step = 1000.0
        elif coarse_step >= 1000:
            fine_step = 1000.0
        else:
            fine_step = max(100.0, coarse_step)
        span = max(coarse_step, fine_step * 2.0)
        start = center - span
        end = center + span
        if allow_zero:
            start = max(0.0, start)
        else:
            start = max(fine_step, start)
        # 新台幣門檻以整數處理，避免出現 24999.999 類型的顯示。
        vals = []
        cur = start
        guard = 0
        while cur <= end + 1e-9:
            vals.append(float(round(cur)))
            cur += fine_step
            guard += 1
            if guard > 300:
                break
        c = float(round(center))
        if c not in vals and (allow_zero or c > 0):
            vals.append(c)
        return sorted(set(vals))

    def _fine_combos_for_result_row(self, row):
        params = row.get("params") or {}
        if not params:
            return []
        tp = float(params.get("tp_points", 0.0) or 0.0)
        sl = float(params.get("sl_points", 0.0) or 0.0)
        loss = float(params.get("loss_exit", 0.0) or 0.0)
        profit = float(params.get("lock_profit_exit", 0.0) or 0.0)
        tp_step = self._current_numeric_step(self.tp_step_text, 1.0)
        sl_step = self._current_numeric_step(self.sl_step_text, 1.0)
        loss_step = self._current_numeric_step(self.loss_step_text, 1000.0)
        profit_step = self._current_numeric_step(self.profit_step_text, 1000.0)
        tp_values = self._fine_point_values(tp, tp_step, allow_zero=False)
        sl_values = self._fine_point_values(sl, sl_step, allow_zero=True)
        loss_values = self._fine_money_values(loss, loss_step, allow_zero=False)
        profit_values = self._fine_money_values(profit, profit_step, allow_zero=False)
        return list(itertools.product(tp_values, sl_values, loss_values, profit_values))

    def _build_fine_job_groups(self, seed_rows):
        groups = {}
        for row in list(seed_rows or []):
            if not row or row.get("status") != "完成":
                continue
            opt = row.get("opt")
            code = clean_code(getattr(opt, "code", ""))
            if not code:
                continue
            combos = self._fine_combos_for_result_row(row)
            if not combos:
                continue
            if code not in groups:
                groups[code] = {"opt": opt, "combo_set": set(), "combos": []}
            for combo in combos:
                key = tuple(round(float(x), 6) for x in combo)
                if key in groups[code]["combo_set"]:
                    continue
                groups[code]["combo_set"].add(key)
                groups[code]["combos"].append(combo)
        return [{"opt": data["opt"], "combos": data["combos"]} for data in groups.values()]

    def _fine_job_count_text(self, job_groups):
        products = len(job_groups or [])
        total = sum(len(g.get("combos") or []) for g in list(job_groups or []))
        return "%d檔商品｜共%d組精跑參數" % (products, total)

    def run_fine_backtest_selected(self):
        if not self.last_group_results:
            messagebox.showinfo("尚無回測結果", "請先執行群組參數回測，再點選一筆結果精跑。")
            return
        try:
            sel = list(self.result_tree.selection())
        except Exception:
            sel = []
        if not sel:
            messagebox.showinfo("尚未選取結果", "請先在『回測結果』表格點選一筆結果，再按精跑。")
            return
        row = self.result_row_map.get(sel[0])
        if not row:
            messagebox.showinfo("尚未選取結果", "請先在『回測結果』表格點選一筆有效結果。")
            return
        try:
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                raise ValueError("請填完整回測起日與回測迄日。")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return
        job_groups = self._build_fine_job_groups([row])
        if not job_groups:
            messagebox.showinfo("無法精跑", "選取結果沒有可用參數。")
            return
        self.info.configure(text="準備以選取結果精跑｜%s" % self._fine_job_count_text(job_groups), foreground="red")
        self._run_group_job_groups(job_groups, d1, d2, int(self.lots.get() or 1), action_name="選取結果精跑", mode_note="v026自動細化", k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period())

    def run_fine_backtest_top5(self):
        rows = [r for r in list(self.last_group_results or []) if r.get("status") == "完成"][:5]
        if not rows:
            messagebox.showinfo("尚無回測結果", "請先執行群組參數回測，產生排名後再以前5名精跑。")
            return
        try:
            d1, d2 = self._parse_date_range()
            if not d1 or not d2:
                raise ValueError("請填完整回測起日與回測迄日。")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return
        job_groups = self._build_fine_job_groups(rows)
        if not job_groups:
            messagebox.showinfo("無法精跑", "前5名結果沒有可用參數。")
            return
        total_jobs = sum(len(g.get("combos") or []) for g in job_groups)
        ok = messagebox.askyesno("確認以前5名精跑", "將以前5名結果各自展開附近參數並去除重複。\n%s\n是否開始？" % self._fine_job_count_text(job_groups))
        if not ok:
            return
        self.info.configure(text="準備以前5名精跑｜%s" % self._fine_job_count_text(job_groups), foreground="red")
        self._run_group_job_groups(job_groups, d1, d2, int(self.lots.get() or 1), action_name="前5名精跑", mode_note="v026自動細化", k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period())

    def result_rank_score(self, row):
        try:
            avg = float(row.get("avg", -1e18) or -1e18)
            if avg < -1e17:
                return -1e18
            opt = row.get("opt")
            margin = float(getattr(opt, "base_margin", 0.0) or 0.0)
            if margin <= 0:
                return -1e18
            return avg / margin
        except Exception:
            return -1e18

    def result_product_key(self, row):
        try:
            opt = row.get("opt")
            return clean_code(getattr(opt, "code", ""))
        except Exception:
            return ""

    def _sort_result_rows_by_score(self, rows):
        return sorted(list(rows or []), key=lambda x: (self.result_rank_score(x), float(x.get("avg", -1e18) or -1e18)), reverse=True)

    def _top10_each_product(self, rows):
        grouped = {}
        for row in list(rows or []):
            if row.get("status") != "完成":
                continue
            code = self.result_product_key(row)
            if not code:
                code = "UNKNOWN"
            grouped.setdefault(code, []).append(row)
        picked = []
        for code in grouped:
            picked.extend(self._sort_result_rows_by_score(grouped[code])[:10])
        return self._sort_result_rows_by_score(picked)

    def _current_result_rows_for_display(self):
        rows = list(self.last_group_results or [])
        filt = str(self.result_filter_text.get() or "總表")
        code = self.result_filter_code_map.get(filt, "")
        if code:
            rows = [r for r in rows if self.result_product_key(r) == code]
            return self._sort_result_rows_by_score([r for r in rows if r.get("status") == "完成"])[:10]
        return self._top10_each_product(rows)

    def update_result_filter_options(self, results):
        code_to_name = {}
        for row in list(results or []):
            opt = row.get("opt")
            code = clean_code(getattr(opt, "code", ""))
            if not code or code in code_to_name:
                continue
            code_to_name[code] = self.product_name_text(opt)
        values = ["總表"] + [code_to_name[c] for c in sorted(code_to_name, key=lambda k: code_to_name[k])]
        self.result_filter_code_map = {code_to_name[c]: c for c in code_to_name}
        try:
            self.result_filter_box.configure(values=values)
        except Exception:
            pass
        cur = str(self.result_filter_text.get() or "")
        if cur not in values:
            self.result_filter_text.set("總表")

    def render_result_view(self):
        self.clear_tree(self.result_tree)
        self.result_row_map = {}
        rows_to_show = self._current_result_rows_for_display()
        for idx, row in enumerate(rows_to_show, start=1):
            opt = row.get("opt")
            params = row.get("params") or {}
            avg = float(row.get("avg", 0.0) or 0.0)
            status = row.get("status", "")
            avg_text = "" if avg < -1e17 else format_money_plain(avg)
            score = self.result_rank_score(row)
            score_text = "" if score < -1e17 else ("%.2f%%" % (score * 100.0))
            # ttk Treeview 不支援單一儲存格上色；結果列先維持黑字，避免整列紅/綠。
            iid = self.result_tree.insert("", END, values=(
                idx,
                self.product_name_text(opt),
                score_text,
                avg_text,
                format_money_plain(row.get("total", 0)),
                row.get("valid_days", 0),
                row.get("range", ""),
                (str(normalize_ma_period(params.get("ma_period", 3))) + "MA") if params else "",
                (str(normalize_k_minutes(params.get("k_minutes", 1))) + "分") if params else "",
                "%.2f" % float(params.get("tp_points", 0.0) or 0.0) if params else "",
                "%.2f" % float(params.get("sl_points", 0.0) or 0.0) if params else "",
                safe_int_text(params.get("loss_exit", 0.0)) if params else "",
                safe_int_text(params.get("lock_profit_exit", 0.0)) if params else "",
                row.get("trades", 0),
                row.get("tp", 0),
                row.get("sl", 0),
                row.get("reverse", 0),
                format_money_plain(row.get("peak", 0.0)),
                format_money_plain(row.get("trough", 0.0)),
                status,
            ), tags=("zero",))
            self.result_row_map[iid] = row
        try:
            self.status_update("回測結果已依平均每日獲利/原始保證金排序｜目前顯示%s｜%d列" % (str(self.result_filter_text.get() or "總表"), len(rows_to_show)))
        except Exception:
            pass

    def render_group_results(self, results):
        """大量參數回測完成後出榜。

        v032：總表與各商品頁都只顯示每檔商品前10名；排名依
        平均每日獲利 / 原始保證金，由大到小。完整資料仍保留在
        self.last_group_results 供精跑與匯出依目前篩選使用。
        """
        self.last_group_results = self._sort_result_rows_by_score(list(results or []))
        for row in self.last_group_results:
            try:
                row["rank_score"] = self.result_rank_score(row)
            except Exception:
                row["rank_score"] = -1e18
        self.result_detail_cache = {}
        self.update_result_filter_options(self.last_group_results)
        self.render_result_view()

    def _result_detail_cache_key(self, row):
        opt = row.get("opt")
        params = row.get("params") or {}
        return (
            clean_code(getattr(opt, "code", "") or params.get("product_code", "")),
            str(row.get("strategy", "") or params.get("strategy_name", "")),
            float(params.get("tp_points", 0.0) or 0.0),
            float(params.get("sl_points", 0.0) or 0.0),
            float(params.get("loss_exit", 0.0) or 0.0),
            float(params.get("lock_profit_exit", 0.0) or 0.0),
            int(params.get("lots", self.lots.get() or 1) or 1),
            normalize_k_minutes(params.get("k_minutes", self.get_k_minutes() if hasattr(self, "get_k_minutes") else 1)),
            normalize_ma_period(params.get("ma_period", self.get_ma_period() if hasattr(self, "get_ma_period") else 3)),
            float(params.get("one_way_fee", 0.0) or 0.0),
            str(row.get("range", "")),
        )

    def load_result_row_detail(self, row):
        try:
            if not row:
                return
            params = dict(row.get("params") or {})
            opt = row.get("opt")
            code = clean_code(getattr(opt, "code", "") or params.get("product_code", ""))
            strategy_name = str(row.get("strategy", "") or params.get("strategy_name", "") or strategy_for_option(opt, self.strategy.get()))
            if not code:
                return
            d1, d2 = self._parse_date_range()
            key = self._result_detail_cache_key(row)
            cached = self.result_detail_cache.get(key)
            if cached:
                ds, tr = cached
                self.last_day_stats, self.last_trades = ds, tr
                self.render_day_stats(ds)
                self.render_trades(tr)
                self.info.configure(text="已載入快取明細｜%s｜平均每日獲利 %s｜總淨利 %s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f" % (
                    self.option_title(opt), format_money_plain(row.get("avg", 0)), format_money_plain(row.get("total", 0)),
                    float(params.get("tp_points", 0.0) or 0.0), float(params.get("sl_points", 0.0) or 0.0),
                    float(params.get("loss_exit", 0.0) or 0.0), float(params.get("lock_profit_exit", 0.0) or 0.0)
                ))
                self.tabs.select(self.summary_frame)
                return

            def worker():
                ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="明細讀取", start_date=d1, end_date=d2)
                if not ticks:
                    raise ValueError("所選商品在回測日期範圍沒有可用逐筆資料。")
                run_params = dict(params)
                run_params.update({
                    "strategy_name": strategy_name,
                    "lots": int(params.get("lots", self.lots.get() or 1) or 1),
                    "product_code": code,
                    "progress": lambda cur, total, detail: self.progress_update(cur, total, "點選明細即時計算｜%s｜%s" % (self.option_title(opt), detail)),
                })
                ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, **run_params)
                return key, ds, tr, row

            def done(payload):
                k, ds, tr, src_row = payload
                self.result_detail_cache[k] = (ds, tr)
                self.last_day_stats, self.last_trades = ds, tr
                self.render_day_stats(ds)
                self.render_trades(tr)
                p = src_row.get("params") or {}
                self.info.configure(text="已即時計算並載入明細｜%s｜平均每日獲利 %s｜總淨利 %s｜停利 %.2f 停損 %.2f 認賠 %.0f 賺飽 %.0f" % (
                    self.option_title(src_row.get("opt")), format_money_plain(src_row.get("avg", 0)), format_money_plain(src_row.get("total", 0)),
                    float(p.get("tp_points", 0.0) or 0.0), float(p.get("sl_points", 0.0) or 0.0),
                    float(p.get("loss_exit", 0.0) or 0.0), float(p.get("lock_profit_exit", 0.0) or 0.0)
                ))
                self.tabs.select(self.summary_frame)

            self.run_background("載入該列每日/交易明細", worker, done)
        except Exception:
            pass


    def on_result_selected(self, _event=None):
        try:
            sel = self.result_tree.selection()
            if not sel:
                return
            row = self.result_row_map.get(sel[0])
            if not row:
                return
            self.load_result_row_detail(row)
        except Exception:
            pass

    def browse(self):
        ps = filedialog.askopenfilenames(filetypes=[("官方 Daily ZIP/CSV", "*.zip *.csv *.rpt *.txt"), ("ZIP 壓縮檔", "*.zip"), ("CSV/RPT", "*.csv *.rpt *.txt"), ("所有檔案", "*.*")])
        if ps:
            self.paths = list(ps)
            names = [os.path.basename(p) for p in self.paths]
            if len(names) <= 3:
                self.file_text.set("；".join(names))
            else:
                self.file_text.set("已選 %d 個檔案：%s ..." % (len(names), "；".join(names[:3])))
            self.raw_options = []
            self.options = []
            self.option_map = {}
            self.primary_month_by_file_code = {}
            try:
                if self.product_combo is not None and self.product_combo.winfo_exists():
                    self.product_combo.configure(values=[])
            except Exception:
                pass
            self.product_choice.set("")
            self.ticks = []
            self.selected_code = ""

    def _resolved_paths(self):
        paths = list(self.paths or [])
        if not paths:
            text = self.file_text.get().strip()
            if text and os.path.exists(text):
                paths = [text]
        if not paths:
            raise ValueError("請先選擇官方 Daily ZIP 或 CSV 檔案")
        return paths

    def _parse_date_range(self):
        s1 = str(self.date_start_text.get() or "").strip()
        s2 = str(self.date_end_text.get() or "").strip()
        d1 = _date_from_text(s1) if s1 else None
        d2 = _date_from_text(s2) if s2 else None
        if s1 and not d1:
            raise ValueError("回測起日格式錯誤，請用 YYYY-MM-DD。")
        if s2 and not d2:
            raise ValueError("回測迄日格式錯誤，請用 YYYY-MM-DD。")
        if d1 and d2 and d1 > d2:
            raise ValueError("回測起日不可晚於迄日。")
        return d1, d2

    def date_range_text(self):
        try:
            d1, d2 = self._parse_date_range()
        except Exception:
            return "日期格式錯誤"
        if not d1 and not d2:
            return "全部日期"
        return "%s～%s" % (_date_text(d1) if d1 else "最早", _date_text(d2) if d2 else "最新")

    def load_cache_products_on_start(self):
        if self.busy:
            return
        if not cache_has_any_ticks():
            return
        options = load_product_summary_cache()
        if not options:
            self.file_text.set("已載入本機快取資料庫｜%s" % os.path.basename(ticks_cache_db_path()))
            self.info.configure(text="已偵測到 ticks_cache.db，但尚未建立商品摘要快取；請按『重整商品清單/排名』一次。之後重開會直接讀摘要快取，不再等兩分鐘。")
            return
        self.paths = []
        self.raw_options = list(options)
        if self.margin_items():
            # 版本升級或期交所資料更新後，啟動時直接重算商品類別/保證金，避免沿用舊摘要快取。
            self.options = self.enrich_options(options)
            save_product_summary_cache(self.options)
        else:
            self.options = list(options)
        self.apply_hot_ranks()
        self.primary_month_by_file_code = {}
        self.file_text.set("已載入本機快取資料庫｜%s" % os.path.basename(ticks_cache_db_path()))
        self.filter_products()
        self.info.configure(text="快速啟動完成｜已讀商品摘要快取｜股票期貨商品數：%d｜已重算保證金資料" % len(self.options))

    def import_selected_files(self):
        try:
            paths = self._resolved_paths()
        except Exception as e:
            messagebox.showerror("匯入失敗", str(e))
            return
        def worker():
            result = import_sources_to_cache(paths, progress=lambda cur, total, detail: self.progress_update(cur, total, detail))
            options = scan_products_from_cache(progress=lambda cur, total, detail: self.progress_update(cur, total, "重算商品｜" + detail))
            return result, options
        def done(result):
            summary, options = result
            self.raw_options = options
            self.options = self.enrich_options(options)
            self.apply_hot_ranks()
            save_product_summary_cache(self.options)
            self.primary_month_by_file_code = {}
            self.ticks = []
            self.selected_code = ""
            self.filter_products()
            self.info.configure(text="快取更新完成｜新增來源%d｜略過%d｜覆蓋%d｜新增tick %s｜股票期貨商品數：%d" % (
                summary.get("imported", 0), summary.get("skipped", 0), summary.get("replaced", 0), f"{int(summary.get('inserted', 0)):,}", len(self.options)
            ))
        self.run_background("匯入/追加CSV到快取", worker, done)

    def read_ticks_for_code(self, code, strategy_name, progress_prefix="讀取", start_date=None, end_date=None):
        if start_date is None and end_date is None:
            d1, d2 = self._parse_date_range()
        else:
            d1, d2 = start_date, end_date
        if cache_has_code(code):
            return read_cached_ticks(code, strategy_name, d1, d2, progress=lambda cur, total, detail: self.progress_update(cur, total, progress_prefix + "｜" + detail))
        # 沒有快取時才退回舊的直接讀原始檔流程。
        paths = self._resolved_paths()
        ticks = read_official_ticks(paths, code, strategy_name, dict(self.primary_month_by_file_code), progress=lambda cur, total, detail: self.progress_update(cur, total, progress_prefix + "｜" + detail))
        if d1 or d2:
            filtered = []
            for t in ticks:
                sdate = _date_from_text(str(t.session_key).split(":")[0]) or t.d
                if d1 and sdate < d1:
                    continue
                if d2 and sdate > d2:
                    continue
                filtered.append(t)
            ticks = filtered
        return ticks

    def scan_files(self):
        """只從永久快取資料庫重整商品清單/熱門排名；不重新讀原始 CSV。"""
        if not cache_has_any_ticks():
            messagebox.showinfo("尚無快取資料", "請先選擇官方 Daily CSV/ZIP，按「匯入/追加到快取」。")
            return

        def worker():
            options = scan_products_from_cache(progress=lambda cur, total, detail: self.progress_update(cur, total, "重整商品｜" + detail))
            if not options:
                raise ValueError("快取資料庫內沒有可用商品。")
            return options

        def done(options):
            self.raw_options = options
            self.options = self.enrich_options(options)
            self.apply_hot_ranks()
            save_product_summary_cache(self.options)
            self.primary_month_by_file_code = {}
            self.ticks = []
            self.selected_code = ""
            self.filter_products()
            big, small = self.hot_rankings()
            if self.margin_items():
                self.info.configure(text="商品清單/排名已重整｜大股期前15：%d｜小股期前15：%d｜已排除台積電/聯電與非股票期貨｜未重讀原始CSV" % (len(big), len(small)))
            else:
                self.info.configure(text="商品清單已重整｜尚未更新期交所保證金資料，無法自動排除非股票期貨")

        self.run_background("重整商品清單/排名", worker, done)

    def _product_dialog_widget_alive(self, widget):
        try:
            return widget is not None and bool(widget.winfo_exists())
        except Exception:
            return False

    def open_product_dialog(self):
        """把商品選擇與待回測群組移到彈出視窗，避免主面板被商品區塊佔高。"""
        try:
            if self.product_dialog is not None and self.product_dialog.winfo_exists():
                self.product_dialog.lift()
                self.product_dialog.focus_force()
                return
        except Exception:
            pass

        dlg = Toplevel(self.root)
        self.product_dialog = dlg
        dlg.title("商品選擇 / 待回測群組")
        try:
            dlg.geometry(str(self.get_setting("geometry.product_dialog", "1080x520")) or "1080x520")
            dlg.minsize(820, 420)
        except Exception:
            pass

        def _close_dialog():
            try:
                self.set_setting("geometry.product_dialog", dlg.geometry())
                self.save_settings()
            except Exception:
                pass
            self.product_combo = None
            self.group_tree = None
            self.product_status = None
            self.product_dialog = None
            try:
                dlg.destroy()
            except Exception:
                pass

        try:
            dlg.protocol("WM_DELETE_WINDOW", _close_dialog)
        except Exception:
            pass

        product_frame = ttk.LabelFrame(dlg, text="商品選擇", padding=8)
        product_frame.pack(fill="x", padx=8, pady=8)
        product_frame.columnconfigure(1, weight=1)
        ttk.Label(product_frame, text="輸入商品代號關鍵字：").grid(row=0, column=0, sticky="e", padx=4, pady=4)
        keyword_entry = self.register_lock_widget(ttk.Entry(product_frame, textvariable=self.product_keyword, width=20))
        keyword_entry.grid(row=0, column=1, sticky="w", padx=4, pady=4)
        ttk.Label(product_frame, text="選擇商品：").grid(row=1, column=0, sticky="e", padx=4, pady=4)
        self.product_combo = self.register_lock_widget(ttk.Combobox(product_frame, textvariable=self.product_choice, values=[], width=85, state="readonly"))
        self.product_combo.grid(row=1, column=1, columnspan=4, sticky="ew", padx=4, pady=4)
        self.product_combo.bind("<<ComboboxSelected>>", lambda _e: self.on_product_selected())
        add_btn = ttk.Button(product_frame, text="加入待回測", command=self.add_selected_product_to_group)
        add_btn.grid(row=1, column=5, sticky="w", padx=4, pady=4)
        self.lock_widgets.append(add_btn)
        self.product_status = ttk.Label(product_frame, textvariable=self.margin_info, anchor="w", justify="left")
        self.product_status.grid(row=2, column=0, columnspan=6, sticky="w", padx=4, pady=(6, 2))

        group_frame = ttk.LabelFrame(dlg, text="待回測群組", padding=8)
        group_frame.pack(fill=BOTH, expand=True, padx=8, pady=(0, 8))
        group_frame.columnconfigure(0, weight=1)
        group_frame.rowconfigure(0, weight=1)
        self.group_tree = ttk.Treeview(group_frame, columns=("idx", "name", "rank"), show="headings", height=8)
        for col, title, width in (("idx", "序", 45), ("name", "商品名稱", 280), ("rank", "熱門排名", 90)):
            self.group_tree.heading(col, text=title)
            self.group_tree.column(col, width=width, anchor="center", stretch=True)
        gbar = ttk.Scrollbar(group_frame, orient="vertical", command=self.group_tree.yview)
        self.group_tree.configure(yscrollcommand=gbar.set)
        self.group_tree.grid(row=0, column=0, sticky="nsew")
        gbar.grid(row=0, column=1, sticky="ns")
        group_btns = ttk.Frame(group_frame)
        group_btns.grid(row=1, column=0, columnspan=2, sticky="w", pady=(6, 0))
        remove_btn = ttk.Button(group_btns, text="移除選取商品", command=self.remove_selected_group_products)
        remove_btn.pack(side="left", padx=(0, 5))
        clear_btn = ttk.Button(group_btns, text="清空待回測群組", command=self.clear_backtest_group)
        clear_btn.pack(side="left", padx=5)
        close_btn = ttk.Button(group_btns, text="關閉", command=_close_dialog)
        close_btn.pack(side="left", padx=5)
        self.lock_widgets.extend([remove_btn, clear_btn, close_btn])

        self.filter_products()
        self.render_backtest_group()
        try:
            keyword_entry.focus_set()
        except Exception:
            pass

    def filter_products(self):
        kw = self.product_keyword.get().strip().upper()
        matches = []
        self.option_map = {}
        for opt in self.options:
            text = opt.display
            if not kw or kw in opt.code or kw in text.upper():
                matches.append(text)
                self.option_map[text] = opt
        combo_alive = self._product_dialog_widget_alive(getattr(self, "product_combo", None))
        if combo_alive:
            try:
                self.product_combo.configure(values=matches[:300])
            except Exception:
                combo_alive = False
        if matches:
            current = self.product_choice.get()
            if current not in matches:
                self.product_choice.set(matches[0])
                if combo_alive:
                    self.on_product_selected()
        else:
            self.product_choice.set("")
            self.selected_code = ""
            self.update_margin_text_for_option(None)

    def on_product_selected(self):
        opt = self.option_map.get(self.product_choice.get())
        if opt:
            self.selected_code = opt.code
            self.ticks = []
            first = opt.first_dt.strftime("%Y-%m-%d %H:%M:%S") if opt.first_dt else ""
            last = opt.last_dt.strftime("%Y-%m-%d %H:%M:%S") if opt.last_dt else ""
            self.info.configure(text="已選商品：%s｜自動主力月份：%s｜總筆數：%s｜時間：%s ～ %s" % (self.option_title(opt), opt.primary_month, f"{opt.total_rows:,}", first, last))
            self.update_margin_text_for_option(opt)
            self.update_ratio_preview()

    def load_ticks(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再選商品。")
            return
        opt = self.option_map.get(self.product_choice.get())
        if not opt:
            messagebox.showerror("讀取失敗", "請先選擇商品")
            return
        strategy_name = self.auto_strategy_for_option(opt)
        code = opt.code
        try:
            d1, d2, _notes = self.resolve_date_range_for_code(code, self.date_start_text, self.date_end_text, "回測")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return

        def worker():
            ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="讀取", start_date=d1, end_date=d2)
            if not ticks:
                raise ValueError("所選商品在目前日期範圍沒有可用逐筆資料。請確認策略時段或日期範圍。")
            return code, ticks

        def done(result):
            code2, ticks = result
            self.selected_code = code2
            self.ticks = ticks
            sessions = sorted(set(t.session_label for t in self.ticks))
            months = sorted(set(t.month for t in self.ticks))
            prices = [t.price for t in self.ticks]
            data_range, data_days = self.ticks_date_range_text(self.ticks)
            self.info.configure(text="讀取完成｜商品：%s｜自動月份：%s｜逐筆數：%s｜時段數：%d｜實際使用：%s，共%d天｜價格 %.2f ～ %.2f" % (self.option_title(code2), "/".join(months), f"{len(self.ticks):,}", len(sessions), data_range, data_days, min(prices), max(prices)))

        self.run_background("讀取所選商品逐筆", worker, done)

    def params(self, tp_override=None):
        opt = self.option_map.get(self.product_choice.get())
        if not self.selected_code:
            self.selected_code = opt.code if opt else ""
        return dict(
            strategy_name=self.auto_strategy_for_option(opt) if opt else self.strategy.get(),
            lots=self.lots.get(),
            tp_points=self.tp_points.get() if tp_override is None else tp_override,
            sl_points=self.sl_points.get(),
            loss_exit=self.loss_exit.get(),
            lock_profit_exit=self.lock_profit_exit.get(),
            product_code=self.selected_code,
            k_minutes=self.get_k_minutes(), ma_period=self.get_ma_period(),
            one_way_fee=self.one_way_fee_value(),
        )

    def run_single(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再選商品。")
            return
        opt = self.option_map.get(self.product_choice.get())
        if not opt:
            messagebox.showerror("回測失敗", "請先選擇商品")
            return
        code = opt.code
        self.save_current_param_texts()
        params = self.params()
        params["product_code"] = code
        strategy_name = self.auto_strategy_for_option(opt)
        tp_points = self.tp_points.get()
        sl_points = self.sl_points.get()
        try:
            d1, d2, _notes = self.resolve_date_range_for_code(code, self.date_start_text, self.date_end_text, "回測")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return
        ticks_snapshot = list(self.ticks) if self.selected_code == code else []

        def worker():
            ticks = ticks_snapshot or self.read_ticks_for_code(code, strategy_name, progress_prefix="讀取", start_date=d1, end_date=d2)
            if not ticks:
                raise ValueError("所選商品在目前日期範圍沒有可用逐筆資料。請確認策略時段或日期範圍。")
            params2 = dict(params)
            params2["progress"] = lambda cur, total, detail: self.progress_update(cur, total, "回測｜" + detail)
            ds, tr, records, events = run_strategy_backtest_ticks(ticks, **params2)
            return code, ticks, ds, tr, records, events

        def done(result):
            code2, ticks, ds, tr, _records, _events = result
            self.selected_code = code2
            self.ticks = ticks
            self.last_day_stats, self.last_trades = ds, tr
            total = sum(x["net"] for x in ds)
            avg, valid_days = self.average_net_excluding_zero_trade_days(ds)
            summary = self.day_stats_summary(ds)
            self.info.configure(text="單組回測｜商品 %s｜%s%s｜實際使用：%s，共%d天，有效%d天｜停利/觸發 %.2f 點｜停損 %.2f 點｜總淨利：%s 元｜平均每日損益：%s 元｜平倉次數：%d" % (self.option_title(code2), strategy_name, ("｜%dMA|%d分K" % (self.get_ma_period(), self.get_k_minutes()) if is_three_ma_strategy(strategy_name) else ""), summary["range"], summary["total_days"], valid_days, tp_points, sl_points, format_money_plain(total), format_money_plain(avg), len(tr)))
            self.render_day_stats(ds)
            self.render_trades(tr)
            self.tabs.select(self.summary_frame)

        self.run_background("執行單組回測", worker, done)

    def run_sweep(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再選商品。")
            return
        opt = self.option_map.get(self.product_choice.get())
        if not opt:
            messagebox.showerror("比例測試失敗", "請先選擇商品")
            return
        code = opt.code
        strategy_name = self.strategy.get()
        lots = self.lots.get()
        ratio_text = str(self.ratio_text.get() or "").strip()
        margin = float(opt.base_margin or 0.0)
        if margin <= 0:
            messagebox.showerror("比例測試失敗", "此商品缺少期交所保證金資料或最新價，請先按「更新期交所保證金資料」並重新掃描商品。")
            return

        # v015：比例測試專用「找最佳日期」，不再使用一般「回測起訖日」。
        # 也不再沿用 self.ticks，避免先前讀過全資料後，比例測試仍拿全資料重跑。
        if not str(self.opt_start_text.get() or "").strip() or not str(self.opt_end_text.get() or "").strip():
            messagebox.showerror("比例測試日期未設定", "比例測試請使用「找最佳起日／找最佳迄日」。\n它不會使用上方的一般回測起訖日。")
            return
        try:
            d1, d2, _notes = self.resolve_date_range_for_code(code, self.opt_start_text, self.opt_end_text, "找最佳")
        except Exception as e:
            messagebox.showerror("日期錯誤", str(e))
            return

        valid_has_start = bool(str(self.valid_start_text.get() or "").strip())
        valid_has_end = bool(str(self.valid_end_text.get() or "").strip())
        if valid_has_start != valid_has_end:
            messagebox.showerror("驗證日期未完整", "若要驗證，請同時設定「驗證起日」與「驗證迄日」。\n若不驗證，兩格都留空。")
            return
        val_d1 = val_d2 = None
        if valid_has_start and valid_has_end:
            try:
                val_d1, val_d2, _vnotes = self.resolve_date_range_for_code(code, self.valid_start_text, self.valid_end_text, "驗證")
            except Exception as e:
                messagebox.showerror("驗證日期錯誤", str(e))
                return

        def worker():
            ticks = self.read_ticks_for_code(code, strategy_name, progress_prefix="找最佳讀取", start_date=d1, end_date=d2)
            if not ticks:
                raise ValueError("所選商品在找最佳日期範圍沒有可用逐筆資料。請確認找最佳起訖日。")
            ticks_val = []
            if val_d1 and val_d2:
                ticks_val = self.read_ticks_for_code(code, strategy_name, progress_prefix="驗證讀取", start_date=val_d1, end_date=val_d2)
                if not ticks_val:
                    raise ValueError("所選商品在驗證日期範圍沒有可用逐筆資料。請確認驗證起訖日。")
            rows = []
            best = None
            multiplier = product_multiplier_from_master_item(self.margin_item_for(code), strategy_name)
            if ratio_text == "":
                ratios = list(range(5, 16))
            else:
                try:
                    r_single = float(ratio_text)
                except Exception:
                    raise ValueError("測試分母請留空，或只填一個數字，例如 10")
                if r_single <= 0:
                    raise ValueError("測試分母必須大於 0")
                ratios = [r_single]
            for r in ratios:
                tp_ntd = margin / float(r)
                tp_points = tp_ntd / multiplier
                sl_points_auto = tp_points
                loss_exit_auto = tp_ntd * 3.0
                lock_profit_exit_auto = tp_ntd * 2.0
                params = dict(
                    strategy_name=strategy_name, lots=lots, tp_points=tp_points, sl_points=sl_points_auto,
                    loss_exit=loss_exit_auto, lock_profit_exit=lock_profit_exit_auto, product_code=code,
                    one_way_fee=self.one_way_fee_value(),
                )
                ratio_index = len(rows)
                total_work = max(1, len(ratios) * len(ticks))
                def _ratio_progress(cur, total, detail, _idx=ratio_index, _ratio=r):
                    self.progress_update(_idx * len(ticks) + cur, total_work, "找最佳 N=%g｜%s" % (_ratio, detail))
                params2 = dict(params)
                params2["progress"] = _ratio_progress
                ds, tr, _records, _events = run_strategy_backtest_ticks(ticks, **params2)
                total = sum(x["net"] for x in ds)
                avg, valid_days = self.average_net_excluding_zero_trade_days(ds)
                summary = self.day_stats_summary(ds)
                peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                tp_count = sum(x["tp"] for x in ds)
                sl_count = sum(x["sl"] for x in ds)
                rev_count = sum(x["reverse"] for x in ds)

                val_total = val_avg = None
                val_valid_days = 0
                val_range = ""
                val_ds = []
                val_tr = []
                if ticks_val:
                    vparams = dict(params)
                    vparams["progress"] = lambda cur, total, detail, _ratio=r: self.progress_update(cur, total, "驗證 N=%g｜%s" % (_ratio, detail))
                    val_ds, val_tr, _vrecs, _vevents = run_strategy_backtest_ticks(ticks_val, **vparams)
                    val_total = sum(x["net"] for x in val_ds)
                    val_avg, val_valid_days = self.average_net_excluding_zero_trade_days(val_ds)
                    val_summary = self.day_stats_summary(val_ds)
                    val_range = val_summary["range"]

                row = {
                    "ratio": r, "tp_points": tp_points, "tp_ntd": tp_ntd, "sl_points": sl_points_auto,
                    "loss_exit": loss_exit_auto, "lock_exit": lock_profit_exit_auto,
                    "total": total, "avg": avg, "valid_days": valid_days, "total_days": summary["total_days"],
                    "data_range": summary["range"], "trades": len(tr), "tp": tp_count, "sl": sl_count, "reverse": rev_count,
                    "peak": peak, "trough": trough, "ds": ds, "tr": tr,
                    "val_total": val_total, "val_avg": val_avg, "val_valid_days": val_valid_days, "val_range": val_range,
                    "val_ds": val_ds, "val_tr": val_tr,
                }
                rows.append(row)
                if best is None or avg > best["avg"]:
                    best = row
            if not rows:
                raise ValueError("測試分母沒有可用數值")
            return code, ticks, rows, best

        def done(result):
            code2, ticks, rows, best = result
            self.selected_code = code2
            # v015：比例測試只保存本次找最佳日期範圍內的 ticks，避免下一次又被誤當成全範圍資料。
            self.ticks = ticks
            self.clear_tree(self.sweep_tree)
            self.last_sweep = rows
            self.sweep_row_map = {}
            for row in rows:
                tag = "pos" if row["avg"] > 0 else "neg" if row["avg"] < 0 else "zero"
                val_total_text = "" if row.get("val_total") is None else format_money_plain(row.get("val_total", 0))
                val_avg_text = "" if row.get("val_avg") is None else format_money_plain(row.get("val_avg", 0))
                iid = self.sweep_tree.insert("", END, values=(
                    "1/%g" % row["ratio"], "%.2f" % row["tp_points"], "%.0f" % row["tp_ntd"], "%.2f" % row["sl_points"], "%.0f" % row["loss_exit"], "%.0f" % row["lock_exit"],
                    format_money_plain(row["total"]), format_money_plain(row["avg"]), row["valid_days"], row["data_range"],
                    val_total_text, val_avg_text, row.get("val_valid_days", ""), row.get("val_range", ""),
                    row["trades"], row["tp"], row["sl"], row["reverse"], format_money_plain(row["peak"]), format_money_plain(row["trough"])
                ), tags=(tag,))
                self.sweep_row_map[iid] = row
            if best:
                val_part = ""
                if best.get("val_total") is not None:
                    val_part = "｜驗證：%s，有效%d天，平均%s，總淨利%s" % (best.get("val_range", ""), best.get("val_valid_days", 0), format_money_plain(best.get("val_avg", 0)), format_money_plain(best.get("val_total", 0)))
                self.info.configure(text="比例測試完成｜商品 %s｜%s｜找最佳實際使用：%s，共%d天，有效%d天｜基準原始保證金約%s元｜最佳：1/%g｜停利 %.2f 點/%s新台幣｜平均每日損益 %s｜總淨利 %s%s" % (self.option_title(code2), strategy_name, best["data_range"], best["total_days"], best["valid_days"], safe_int_text(margin), best["ratio"], best["tp_points"], safe_int_text(best["tp_ntd"]), format_money_plain(best["avg"]), format_money_plain(best["total"]), val_part))
                self.last_day_stats, self.last_trades = best["ds"], best["tr"]
                self.render_day_stats(best["ds"])
                self.render_trades(best["tr"])
                self.tabs.select(self.sweep_frame)

        self.run_background("執行保證金比例測試", worker, done)

    def on_sweep_selected(self, _event=None):
        try:
            sel = self.sweep_tree.selection()
            if not sel:
                return
            row = self.sweep_row_map.get(sel[0])
            if not row:
                return
            self.last_day_stats, self.last_trades = row.get("ds", []), row.get("tr", [])
            self.render_day_stats(self.last_day_stats)
            self.render_trades(self.last_trades)
            try:
                self.tabs.select(self.summary_frame)
            except Exception:
                pass
            self.info.configure(text="已切換每日總表｜分母 1/%g｜實際使用：%s，有效%d天｜平均每日損益 %s｜總淨利 %s" % (row.get("ratio", 0), row.get("data_range", ""), row.get("valid_days", 0), format_money_plain(row.get("avg", 0)), format_money_plain(row.get("total", 0))))
        except Exception:
            pass

    def hot_top20_options(self):
        big, small = self.hot_rankings()
        return list(big[:10]) + list(small[:10])

    def run_hot_optimize(self):
        if not self.options:
            messagebox.showinfo("尚未掃描商品", "請先按「重整商品清單/排名」，再執行熱門商品最佳化。")
            return
        targets = self.hot_top20_options()
        if not targets:
            messagebox.showinfo("沒有熱門商品", "目前沒有可最佳化的大股期/小股期前10名。")
            return
        strategy_by_kind = {"大股期": "大股期策略", "小股期": "小股期策略"}
        ratio_values = list(range(5, 16))
        # v015：熱門最佳化只使用「找最佳日期」，不再退回一般回測日期，避免誤跑全部資料。
        if not str(self.opt_start_text.get() or "").strip() or not str(self.opt_end_text.get() or "").strip():
            messagebox.showerror("找最佳日期未設定", "一鍵最佳化熱門商品請先設定「找最佳起日／找最佳迄日」。\n它不會使用上方的一般回測起訖日。")
            return
        if bool(str(self.valid_start_text.get() or "").strip()) != bool(str(self.valid_end_text.get() or "").strip()):
            messagebox.showerror("驗證日期未完整", "若要驗證，請同時設定「驗證起日」與「驗證迄日」。\n若不驗證，兩格都留空。")
            return
        def worker():
            results = []
            total_jobs = max(1, len(targets) * len(ratio_values))
            job = 0
            for opt in targets:
                strategy_name = strategy_by_kind.get(opt.product_kind, self.strategy.get())
                # 背景執行中只做純解析；比例測試/熱門最佳化不再吃一般回測起訖日。
                opt_d1 = _date_from_text(str(self.opt_start_text.get() or "").strip())
                opt_d2 = _date_from_text(str(self.opt_end_text.get() or "").strip())
                if str(self.valid_start_text.get() or "").strip() and str(self.valid_end_text.get() or "").strip():
                    val_d1 = _date_from_text(str(self.valid_start_text.get() or "").strip())
                    val_d2 = _date_from_text(str(self.valid_end_text.get() or "").strip())
                else:
                    val_d1 = val_d2 = None
                margin = float(opt.base_margin or 0.0)
                if margin <= 0:
                    continue
                item = self.margin_item_for(opt.code)
                multiplier = product_multiplier_from_master_item(item, strategy_name)
                ticks_opt = self.read_ticks_for_code(opt.code, strategy_name, progress_prefix="最佳化讀取", start_date=opt_d1, end_date=opt_d2)
                if not ticks_opt:
                    continue
                best = None
                for r in ratio_values:
                    job += 1
                    tp_ntd = margin / float(r)
                    tp_points = tp_ntd / multiplier
                    params = dict(strategy_name=strategy_name, lots=self.lots.get(), tp_points=tp_points, sl_points=tp_points,
                                  loss_exit=tp_ntd * 3.0, lock_profit_exit=tp_ntd * 2.0, product_code=opt.code)
                    params["progress"] = lambda cur, total, detail, _job=job, _opt=opt, _r=r: self.progress_update((_job-1) * 1000 + (cur/max(1,total))*1000, total_jobs*1000, "熱門商品 %d/%d｜%s｜分母 %g/15｜%s" % (_job, total_jobs, self.option_title(_opt), _r, detail))
                    ds, tr, _records, _events = run_strategy_backtest_ticks(ticks_opt, **params)
                    avg, valid_days = self.average_net_excluding_zero_trade_days(ds)
                    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds)
                    summary = self.day_stats_summary(ds)
                    peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                    trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
                    cand = {"ratio": r, "tp_ntd": tp_ntd, "tp_points": tp_points, "avg": avg, "total": total, "valid_days": valid_days, "range": summary["range"], "total_days": summary["total_days"], "peak": peak, "trough": trough, "ds": ds, "tr": tr,
                            "profit_hit": any(bool(x.get("hit_profit_exit")) or int(x.get("profit_exit", 0) or 0) > 0 for x in ds),
                            "loss_hit": any(bool(x.get("hit_loss_exit")) or int(x.get("loss_exit", 0) or 0) > 0 for x in ds)}
                    if best is None or cand["avg"] > best["avg"]:
                        best = cand
                if best is None:
                    continue
                # 驗證同一個最佳分母。
                ticks_val = self.read_ticks_for_code(opt.code, strategy_name, progress_prefix="驗證讀取", start_date=val_d1, end_date=val_d2)
                val = dict(best)
                if ticks_val:
                    r = best["ratio"]
                    tp_ntd = margin / float(r)
                    tp_points = tp_ntd / multiplier
                    params = dict(strategy_name=strategy_name, lots=self.lots.get(), tp_points=tp_points, sl_points=tp_points,
                                  loss_exit=tp_ntd * 3.0, lock_profit_exit=tp_ntd * 2.0, product_code=opt.code)
                    ds, tr, _records, _events = run_strategy_backtest_ticks(ticks_val, **params)
                    avg, valid_days = self.average_net_excluding_zero_trade_days(ds)
                    total = sum(float(x.get("net", 0.0) or 0.0) for x in ds)
                    summary = self.day_stats_summary(ds)
                    val = {"avg": avg, "total": total, "valid_days": valid_days, "range": summary["range"], "total_days": summary["total_days"], "ds": ds, "tr": tr}
                results.append({"opt": opt, "strategy": strategy_name, "best": best, "val": val})
            results.sort(key=lambda x: x["best"].get("avg", 0.0), reverse=True)
            return results
        def done(results):
            self.clear_tree(self.optimize_tree)
            self.last_optimize = results
            for idx, row in enumerate(results, start=1):
                opt = row["opt"]
                best = row["best"]
                val = row["val"]
                tag = "pos" if float(best.get("avg", 0.0)) > 0 else "neg" if float(best.get("avg", 0.0)) < 0 else "zero"
                self.optimize_tree.insert("", END, values=(
                    idx, opt.product_kind, getattr(opt, "hot_rank", ""), getattr(opt, "hot_status", ""), opt.code, opt.stock_name,
                    "1/%g" % best["ratio"], format_money_plain(best["avg"]), format_money_plain(best["total"]), best["valid_days"], best["range"],
                    format_money_plain(val.get("avg", 0)), format_money_plain(val.get("total", 0)), val.get("valid_days", 0), val.get("range", ""),
                    "%.2f" % best["tp_points"], safe_int_text(best["tp_ntd"]), format_money_plain(best["peak"]), format_money_plain(best["trough"])
                ), tags=(tag,))
            if results:
                top = results[0]
                b = top["best"]
                self.info.configure(text="熱門商品最佳化完成｜共%d檔｜最佳排名以平均每日損益排序｜第1名 %s 1/%g｜找最佳：%s，有效%d天，平均%s" % (len(results), self.option_title(top["opt"]), b["ratio"], b["range"], b["valid_days"], format_money_plain(b["avg"])))
            else:
                self.info.configure(text="熱門商品最佳化完成，但沒有可用結果。請確認快取日期、保證金資料與熱門商品資料。")
            self.tabs.select(self.optimize_frame)
        self.run_background("一鍵最佳化熱門商品", worker, done)

    def open_current_table_large(self):
        selected = self.tabs.select()
        if selected == str(getattr(self, "result_frame", "")):
            tree, title = self.result_tree, "回測結果"
        elif selected == str(self.summary_frame):
            tree, title = self.summary_tree, "每日總表"
        elif selected == str(self.detail_frame):
            tree, title = self.detail_tree, "交易明細"
        else:
            tree, title = getattr(self, "result_tree", self.summary_tree), "回測結果"
        original_cols = list(tree["columns"])
        display_cols = list(tree["displaycolumns"])
        if not display_cols or display_cols == ["#all"]:
            display_cols = list(original_cols)
        cols = list(original_cols)
        win = Toplevel(self.root)
        win.title(title + "｜放大檢視")
        self.apply_dialog_geometry(win, "large_table", self.get_setting("geometry.large_table", "1400x850"))
        if not self.get_setting("geometry.large_table", ""):
            try:
                win.state("zoomed")
            except Exception:
                pass
        frame = ttk.Frame(win, padding=8)
        frame.pack(fill=BOTH, expand=True)
        big = ttk.Treeview(frame, columns=cols, show="headings")
        try:
            big["displaycolumns"] = display_cols
        except Exception:
            pass
        try:
            big.tag_configure("pos", foreground="#FF0000")
            big.tag_configure("neg", foreground="#008000")
            big.tag_configure("long", foreground="#FF0000")
            big.tag_configure("short", foreground="#008000")
            big.tag_configure("zero", foreground="#333333")
            # 放大交易明細視窗也套用同樣的日期底色與損益文字色。
            for _bg_idx, _bg in ((0, "#FFFBE6"), (1, "#EAF4FF")):
                big.tag_configure(f"trade_pos_day{_bg_idx}", foreground="#FF0000", background=_bg)
                big.tag_configure(f"trade_neg_day{_bg_idx}", foreground="#008000", background=_bg)
                big.tag_configure(f"trade_zero_day{_bg_idx}", foreground="#333333", background=_bg)
            big.tag_configure("day_total_pos", foreground="#FF0000", background="#FFFFFF")
            big.tag_configure("day_total_neg", foreground="#008000", background="#FFFFFF")
            big.tag_configure("day_total_zero", foreground="#333333", background="#FFFFFF")
        except Exception:
            pass
        ybar = ttk.Scrollbar(frame, orient="vertical", command=big.yview)
        xbar = ttk.Scrollbar(frame, orient="horizontal", command=big.xview)
        big.configure(yscrollcommand=ybar.set, xscrollcommand=xbar.set)
        for col in cols:
            big.heading(col, text=tree.heading(col, "text"))
            width = int(tree.column(col, "width") or 100)
            big.column(col, width=max(width, 100), anchor=tree.column(col, "anchor") or "center", stretch=True)
        large_result_row_map = {}
        for item in tree.get_children():
            new_iid = big.insert("", END, values=tree.item(item, "values"), tags=tree.item(item, "tags"))
            if tree is getattr(self, "result_tree", None):
                try:
                    row = self.result_row_map.get(item)
                    if row:
                        large_result_row_map[new_iid] = row
                except Exception:
                    pass

        if tree is getattr(self, "result_tree", None):
            hint = ttk.Label(frame, text="提示：點選任一組結果，會載入該組的每日總表與交易明細。", foreground="#005A9E")
            hint.grid(row=2, column=0, columnspan=2, sticky="w", pady=(6, 0))

            def _open_large_result_detail(_event=None):
                try:
                    sel = big.selection()
                    if not sel:
                        return
                    row = large_result_row_map.get(sel[0])
                    if not row:
                        return
                    self.load_result_row_detail(row)
                except Exception:
                    pass

            big.bind("<<TreeviewSelect>>", _open_large_result_detail, add="+")
            big.bind("<Double-1>", _open_large_result_detail, add="+")

        big.grid(row=0, column=0, sticky="nsew")
        ybar.grid(row=0, column=1, sticky="ns")
        xbar.grid(row=1, column=0, sticky="ew")
        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)

    def render_day_stats(self, ds):
        self.clear_tree(self.summary_tree)
        for x in ds:
            net = float(x.get("net", 0.0) or 0.0)
            tag = "pos" if net > 0 else "neg" if net < 0 else "zero"
            self.summary_tree.insert("", END, values=(
                x["session"], x["month"], x["minutes"], x["ticks"], x["trades"], x.get("win_trades", 0), x.get("loss_trades", 0), format_money_plain(net),
                x["tp"], x["sl"], x["reverse"], x["force"], x["loss_exit"], x["profit_exit"],
                format_money_plain(x.get("peak_pnl", 0.0)), format_money_plain(x.get("trough_pnl", 0.0)), x["stop_reason"]
            ), tags=(tag,))
        if ds:
            valid = [x for x in ds if float(x.get("trades", 0) or 0) > 0]
            n = len(valid) if valid else len(ds)
            base = valid if valid else ds
            avg_trades = sum(float(x["trades"]) for x in base) / n
            avg_win = sum(float(x.get("win_trades", 0) or 0) for x in base) / n
            avg_loss_trade = sum(float(x.get("loss_trades", 0) or 0) for x in base) / n
            avg_net = sum(float(x["net"]) for x in base) / n
            avg_tp = sum(float(x["tp"]) for x in base) / n
            avg_sl = sum(float(x["sl"]) for x in base) / n
            avg_reverse = sum(float(x["reverse"]) for x in base) / n
            avg_force = sum(float(x["force"]) for x in base) / n
            avg_loss_exit = sum(float(x["loss_exit"]) for x in base) / n
            avg_profit_exit = sum(float(x["profit_exit"]) for x in base) / n
            peak = max((float(x.get("peak_pnl", 0.0) or 0.0) for x in ds), default=0.0)
            trough = min((float(x.get("trough_pnl", 0.0) or 0.0) for x in ds), default=0.0)
            tag = "pos" if avg_net > 0 else "neg" if avg_net < 0 else "zero"
            self.summary_tree.insert("", END, values=("平均", "", "", "", "%.2f" % avg_trades, "%.2f" % avg_win, "%.2f" % avg_loss_trade, format_money_plain(avg_net), "%.2f" % avg_tp, "%.2f" % avg_sl, "%.2f" % avg_reverse, "%.2f" % avg_force, "%.2f" % avg_loss_exit, "%.2f" % avg_profit_exit, format_money_plain(peak), format_money_plain(trough), "平均已剔除0平倉日" if valid and len(valid) != len(ds) else ""), tags=(tag,))

    def _trade_session_date_key(self, session_text):
        text = str(session_text or "").strip()
        # session 常見格式為「2026-06-12 日盤」；只取日期讓同一日（日/夜盤）底色一致。
        m = re.search(r"(\d{4}-\d{2}-\d{2})", text)
        if m:
            return m.group(1)
        m = re.search(r"(\d{8})", text)
        if m:
            raw = m.group(1)
            return raw[:4] + "-" + raw[4:6] + "-" + raw[6:8]
        return text

    def render_trades(self, tr):
        self.clear_tree(self.detail_tree)
        day_color_index = {}
        next_color_index = 0
        current_day = None
        day_total = 0.0

        def insert_day_total(day_key, total_value):
            if not day_key:
                return
            pnl_key = "pos" if total_value > 0 else "neg" if total_value < 0 else "zero"
            self.detail_tree.insert("", END, values=(
                "當日累計", "", "", "", "", format_money_plain(total_value),
                day_key, "", "", "", "", ""
            ), tags=("day_total_" + pnl_key,))

        for t in tr:
            side = str(t.get("side", "") or "")
            session_text = str(t.get("session", "") or "")
            day_key = self._trade_session_date_key(session_text)
            if current_day is None:
                current_day = day_key
            elif day_key != current_day:
                insert_day_total(current_day, day_total)
                day_total = 0.0
                current_day = day_key
            if day_key not in day_color_index:
                day_color_index[day_key] = next_color_index % 2
                next_color_index += 1
            bg_idx = day_color_index.get(day_key, 0)
            net = float(t.get("net", 0.0) or 0.0)
            day_total += net
            pnl_key = "pos" if net > 0 else "neg" if net < 0 else "zero"
            tag = f"trade_{pnl_key}_day{bg_idx}"
            self.detail_tree.insert("", END, values=(
                side, t["entry_time"].strftime('%H:%M:%S'), "%.2f" % t["entry"],
                t["exit_time"].strftime('%H:%M:%S'), "%.2f" % t["exit"], format_money_plain(net),
                session_text, t["month"], t["event"], t["reason"],
                format_money_plain(t["gross"]), "%.0f" % t["fee"]
            ), tags=(tag,))
        if current_day is not None:
            insert_day_total(current_day, day_total)

    def _selected_summary_session_set(self):
        sessions = set()
        try:
            for iid in list(self.summary_tree.selection() or []):
                vals = self.summary_tree.item(iid, "values")
                if vals and str(vals[0]) not in ("平均", "合計"):
                    sessions.add(str(vals[0]))
        except Exception:
            pass
        return sessions

    def export_csv(self):
        if not self.last_group_results and not self.last_day_stats:
            messagebox.showinfo("沒有結果", "請先執行群組參數回測，或點選一筆回測結果載入明細。")
            return
        p = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
        if not p:
            return

        result_rows = self._current_result_rows_for_display() if self.last_group_results else []
        selected_sessions = self._selected_summary_session_set()
        day_rows = list(self.last_day_stats or [])
        trade_rows = list(self.last_trades or [])
        if selected_sessions:
            day_rows = [x for x in day_rows if str(x.get("session", "")) in selected_sessions]
            trade_rows = [t for t in trade_rows if str(t.get("session", "")) in selected_sessions]
        result_filter = str(self.result_filter_text.get() or "總表")
        day_filter = "、".join(sorted(selected_sessions)) if selected_sessions else "全部日期"

        with open(p, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.writer(f)
            if result_rows:
                w.writerow(["回測結果", "商品篩選", result_filter, "規則", "每檔商品前10名；排名=平均每日獲利/原始保證金"])
                w.writerow(["排序", "商品名稱", "獲利/原始保證金", "平均每日獲利", "總淨利", "有效天數", "日期範圍", "MA", "K棒", "停利/觸發點", "停損點", "認賠", "賺飽", "平倉次數", "停利次數", "停損次數", "反手次數", "最高損益", "最低損益", "狀態"])
                for idx, row in enumerate(result_rows, start=1):
                    opt = row.get("opt")
                    params = row.get("params") or {}
                    avg = row.get("avg", "")
                    if isinstance(avg, (int, float)) and float(avg) < -1e17:
                        avg = ""
                    score = self.result_rank_score(row)
                    score_text = "" if score < -1e17 else score
                    w.writerow([
                        idx, self.product_name_text(opt), score_text, avg, row.get("total", 0), row.get("valid_days", 0), row.get("range", ""),
                        (str(normalize_ma_period(params.get("ma_period", 3))) + "MA") if params else "", normalize_k_minutes(params.get("k_minutes", 1)),
                        params.get("tp_points", ""), params.get("sl_points", ""), params.get("loss_exit", ""), params.get("lock_profit_exit", ""),
                        row.get("trades", 0), row.get("tp", 0), row.get("sl", 0), row.get("reverse", 0), row.get("peak", 0), row.get("trough", 0), row.get("status", "")
                    ])
                w.writerow([])
            if day_rows:
                w.writerow(["目前選取參數的每日總表", "日期篩選", day_filter])
                w.writerow(["日期/時段", "自動月份", "分鐘數", "逐筆數", "平倉次數", "賺錢次數", "賠錢次數", "淨利", "停利", "停損", "反手", "時間到", "認賠", "賺飽", "最高損益", "最低損益", "停止原因"])
                for x in day_rows:
                    w.writerow([x["session"], x["month"], x["minutes"], x["ticks"], x["trades"], x.get("win_trades", 0), x.get("loss_trades", 0), x["net"], x["tp"], x["sl"], x["reverse"], x["force"], x["loss_exit"], x["profit_exit"], x.get("peak_pnl", 0.0), x.get("trough_pnl", 0.0), x["stop_reason"]])
                avg_base = [x for x in day_rows if float(x.get("trades", 0) or 0) > 0] or day_rows
                n = len(avg_base)
                if n:
                    w.writerow([
                        "平均", "", "", "",
                        sum(float(x["trades"]) for x in avg_base) / n,
                        sum(float(x.get("win_trades", 0) or 0) for x in avg_base) / n,
                        sum(float(x.get("loss_trades", 0) or 0) for x in avg_base) / n,
                        sum(float(x["net"]) for x in avg_base) / n,
                        sum(float(x["tp"]) for x in avg_base) / n,
                        sum(float(x["sl"]) for x in avg_base) / n,
                        sum(float(x["reverse"]) for x in avg_base) / n,
                        sum(float(x["force"]) for x in avg_base) / n,
                        sum(float(x["loss_exit"]) for x in avg_base) / n,
                        sum(float(x["profit_exit"]) for x in avg_base) / n,
                        max((float(x.get("peak_pnl", 0.0) or 0.0) for x in day_rows), default=0.0),
                        min((float(x.get("trough_pnl", 0.0) or 0.0) for x in day_rows), default=0.0),
                        "平均已剔除0平倉日" if len(avg_base) != len(day_rows) else "",
                    ])
                w.writerow([])
                w.writerow(["目前選取參數的交易明細", "日期篩選", day_filter])
                w.writerow(["方向", "進場時間", "進場價", "出場時間", "出場價", "淨損益", "日期/時段", "月份", "事件", "原因", "毛損益", "手續費"])
                cur_day = None
                day_total = 0.0
                for t in trade_rows:
                    dkey = self._trade_session_date_key(t.get("session", ""))
                    if cur_day is None:
                        cur_day = dkey
                    elif dkey != cur_day:
                        w.writerow(["當日累計", "", "", "", "", day_total, cur_day, "", "", "", "", ""])
                        day_total = 0.0
                        cur_day = dkey
                    day_total += float(t.get("net", 0.0) or 0.0)
                    w.writerow([t["side"], t["entry_time"].strftime('%H:%M:%S'), t["entry"], t["exit_time"].strftime('%H:%M:%S'), t["exit"], t["net"], t["session"], t["month"], t["event"], t["reason"], t["gross"], t["fee"]])
                if cur_day is not None:
                    w.writerow(["當日累計", "", "", "", "", day_total, cur_day, "", "", "", "", ""])
        messagebox.showinfo("匯出完成", p)



def _install_exception_logging():
    def _hook(exc_type, exc, tb):
        log_startup("Unhandled exception:\n" + "".join(traceback.format_exception(exc_type, exc, tb)))
    try:
        sys.excepthook = _hook
    except Exception:
        pass


def main():
    _install_exception_logging()
    try:
        multiprocessing.freeze_support()
    except Exception:
        pass
    try:
        log_startup("Starting TrainBacktester %s | python=%s | cwd=%s" % (APP_VERSION, sys.version.replace("\n", " "), os.getcwd()))
    except Exception:
        pass
    try:
        import ctypes
        try:
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            ctypes.windll.user32.SetProcessDPIAware()
    except Exception:
        pass
    root = None
    try:
        root = Tk()
        app = App(root)
        try:
            root.after(100, app.force_window_visible)
            root.after(1800, app.force_window_visible)
        except Exception:
            pass
        root.mainloop()
    except Exception as exc:
        detail = traceback.format_exc()
        log_startup("Startup failed:\n" + detail)
        try:
            messagebox.showerror("TrainBacktester startup failed", str(exc) + "\n\nLog: " + startup_log_path())
        except Exception:
            pass
        raise

if __name__ == "__main__":
    main()
